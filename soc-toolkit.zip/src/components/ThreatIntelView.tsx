/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  ShieldAlert,
  Activity,
  Users,
  Flame,
  Server,
  Heart,
  ChevronRight,
  MessageSquare,
  Bell,
  Send,
  CheckCircle,
  RotateCw,
  UploadCloud,
  FileText,
  Trash2,
  Play,
  FileSpreadsheet,
  AlertTriangle,
  Search,
  Copy,
  Plus,
  ListFilter,
  CheckCircle2,
  Globe2,
  HelpCircle,
  Lock,
  Network,
  ExternalLink,
  ChevronDown,
  Info,
  Radio,
  Clock,
  Shield,
  FileCode,
  Tag,
  MapPin,
  Cpu,
  RefreshCw,
  FolderOpen,
  Check,
  Rss
} from "lucide-react";
import BleepingComputerFeed from "./BleepingComputerFeed";
import CisaKevFeed from "./CisaKevFeed";

// Helper to identify and label RFC private IP ranges
function checkPrivateIp(ipStr: string): { isPrivate: boolean; reason?: string; range?: string } {
  const clean = ipStr.trim();
  if (!clean) return { isPrivate: false };

  // IPv4 Pattern Match
  const ipv4Pattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const match = clean.match(ipv4Pattern);
  if (match) {
    const p1 = parseInt(match[1], 10);
    const p2 = parseInt(match[2], 10);
    const p3 = parseInt(match[3], 10);
    const p4 = parseInt(match[4], 10);

    if (p1 > 255 || p2 > 255 || p3 > 255 || p4 > 255) {
      return { isPrivate: false };
    }

    // RFC 1918 Private Ranges
    if (p1 === 10) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "10.0.0.0/8" };
    }
    if (p1 === 172 && p2 >= 16 && p2 <= 31) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "172.16.0.0/12" };
    }
    if (p1 === 192 && p2 === 168) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "192.168.0.0/16" };
    }
    
    // RFC 5735 / RFC 6890 Localhost/Loopback
    if (p1 === 127) {
      return { isPrivate: true, reason: "RFC 5735 Loopback Host Address", range: "127.0.0.0/8" };
    }
    
    // RFC 3927 Link-Local Block
    if (p1 === 169 && p2 === 254) {
      return { isPrivate: true, reason: "RFC 3927 Link-Local autoconfig address", range: "169.254.0.0/16" };
    }

    // RFC 6598 carrier-grade NAT
    if (p1 === 100 && p2 >= 64 && p2 <= 127) {
      return { isPrivate: true, reason: "RFC 6598 Shared Carrier-Grade NAT block", range: "100.64.0.0/10" };
    }

    // 0.0.0.0/8 Local System Network identifier
    if (p1 === 0) {
      return { isPrivate: true, reason: "Local Host identifier network", range: "0.0.0.0/8" };
    }

    // Broadcast
    if (p1 === 255 && p2 === 255 && p3 === 255 && p4 === 255) {
      return { isPrivate: true, reason: "RFC 919 Broadcast destination", range: "255.255.255.255/32" };
    }

    // RFC 5771 Multicast IP (Class D)
    if (p1 >= 224 && p1 <= 239) {
      return { isPrivate: true, reason: "RFC 5771 Multicast socket group", range: "224.0.0.0/4" };
    }

    // RFC 5737 Test nets
    if (p1 === 192 && p2 === 0 && p3 === 2) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-1", range: "192.0.2.0/24" };
    }
    if (p1 === 198 && p2 === 51 && p3 === 100) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-2", range: "198.51.100.0/24" };
    }
    if (p1 === 203 && p2 === 0 && p3 === 113) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-3", range: "203.0.113.0/24" };
    }
  }

  // IPv6 Pattern check
  const cleanLower = clean.toLowerCase();
  if (cleanLower === "::1" || cleanLower === "0:0:0:0:0:0:0:1") {
    return { isPrivate: true, reason: "IPv6 RFC 4291 Loopback address", range: "::1/128" };
  }
  if (cleanLower === "::" || cleanLower === "0:0:0:0:0:0:0:0") {
    return { isPrivate: true, reason: "IPv6 Unspecified address range", range: "::/128" };
  }
  if (cleanLower.startsWith("fc") || cleanLower.startsWith("fd")) {
    return { isPrivate: true, reason: "RFC 4193 Unique Local Address (ULA) Space", range: "fc00::/7" };
  }
  if (cleanLower.startsWith("fe8") || cleanLower.startsWith("fe9") || cleanLower.startsWith("fea") || cleanLower.startsWith("feb")) {
    return { isPrivate: true, reason: "RFC 4291 Link-Local Unicast address range", range: "fe80::/10" };
  }
  if (cleanLower.startsWith("ff")) {
    return { isPrivate: true, reason: "RFC 4291 Multicast IPv6 prefix group", range: "ff00::/8" };
  }

  return { isPrivate: false };
}

// Check for private internal sub-labels
function isPrivateDomain(domainStr: string): boolean {
  const d = domainStr.toLowerCase().trim();
  return d.endsWith(".local") || d.endsWith(".lan") || d.endsWith(".internal") || d.endsWith(".localdomain") || d === "localhost";
}

export interface ThreatIntelViewProps {
  defaultSubTab?: "bleeping-computer" | "cisa-kev" | "bulk" | "feed";
  onPivotToIp?: (ip: string) => void;
  onPivotToDomain?: (domain: string) => void;
  onPivotToUrl?: (url: string) => void;
  onPivotToHash?: (hash: string) => void;
  onNavigateToKql?: (context: any) => void;
}

export default function ThreatIntelView({
  defaultSubTab = "bleeping-computer",
  onPivotToIp,
  onPivotToDomain,
  onPivotToUrl,
  onPivotToHash,
  onNavigateToKql
}: ThreatIntelViewProps) {
  const [subTab, setSubTab] = useState<"bleeping-computer" | "cisa-kev" | "bulk" | "feed">(defaultSubTab);

  useEffect(() => {
    setSubTab(defaultSubTab);
  }, [defaultSubTab]);

  // Bulk IOC state variables
  const [rawText, setRawText] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [parsedIocs, setParsedIocs] = useState<{
    id: string;
    value: string;
    type: "IP" | "Domain" | "Hash";
    isPrivate: boolean;
    privateReason?: string;
    reputation: "pending" | "scanning" | "clean" | "suspicious" | "malicious" | "blocked";
    riskScore?: number;
    details?: any;
    error?: string;
  }[]>([]);
  const [isScanningBulk, setIsScanningBulk] = useState(false);
  const [bulkFilter, setBulkFilter] = useState<"all" | "malicious" | "private" | "external">("all");
  const [expandedIocId, setExpandedIocId] = useState<string | null>(null);
  const [isCopiedId, setIsCopiedId] = useState<string | null>(null);
  const [showReportCreator, setShowReportCreator] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleParseText = (inputText: string) => {
    if (!inputText) {
      setParsedIocs([]);
      return;
    }

    // Extract IPs
    const ipRegex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
    const ipMatches = (inputText.match(ipRegex) || []) as string[];

    // Extract Hashes (MD5, SHA1, SHA256)
    const md5Regex = /\b[a-fA-F0-9]{32}\b/g;
    const sha1Regex = /\b[a-fA-F0-9]{40}\b/g;
    const sha256Regex = /\b[a-fA-F0-9]{64}\b/g;
    
    const md5Matches = (inputText.match(md5Regex) || []) as string[];
    const sha1Matches = (inputText.match(sha1Regex) || []) as string[];
    const sha256Matches = (inputText.match(sha256Regex) || []) as string[];
    const hashMatches = [...md5Matches, ...sha1Matches, ...sha256Matches];

    // Extract Domains
    const domainRegex = /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}\b/g;
    const rawDomainMatches = inputText.match(domainRegex) || [];

    const systemFileExtensions = [
      ".exe", ".dll", ".sys", ".log", ".txt", ".csv", ".json", ".conf", ".config", 
      ".png", ".jpg", ".gif", ".pdf", ".zip", ".tar", ".gz", ".xml", ".html", ".js", ".css"
    ];
    const filteredDomainMatches = rawDomainMatches.filter((d) => {
      if (/^[0-9.]+$/.test(d)) return false;
      if (ipMatches.includes(d)) return false;
      const lower = d.toLowerCase();
      if (systemFileExtensions.some(ext => lower.endsWith(ext))) return false;
      return true;
    });

    const uniqueIps = Array.from(new Set(ipMatches));
    const uniqueDomains = Array.from(new Set(filteredDomainMatches));
    const uniqueHashes = Array.from(new Set(hashMatches));

    const newList: typeof parsedIocs = [];

    uniqueIps.forEach((ip) => {
      const pCheck = checkPrivateIp(ip);
      newList.push({
        id: `ioc-ip-${ip}`,
        value: ip,
        type: "IP",
        isPrivate: pCheck.isPrivate,
        privateReason: pCheck.reason ? `${pCheck.reason} (${pCheck.range})` : undefined,
        reputation: pCheck.isPrivate ? "blocked" : "pending",
        riskScore: pCheck.isPrivate ? 0 : undefined
      });
    });

    uniqueDomains.forEach((domain) => {
      const isPriv = isPrivateDomain(domain);
      newList.push({
        id: `ioc-dom-${domain}`,
        value: domain,
        type: "Domain",
        isPrivate: isPriv,
        privateReason: isPriv ? "RFC 6762 / Private Top-Level Scope / loopback (.local/.internal)" : undefined,
        reputation: isPriv ? "blocked" : "pending",
        riskScore: isPriv ? 0 : undefined
      });
    });

    uniqueHashes.forEach((hash) => {
      newList.push({
        id: `ioc-hash-${hash}`,
        value: hash,
        type: "Hash",
        isPrivate: false,
        reputation: "pending"
      });
    });

    setParsedIocs(newList);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setRawText(text);
      handleParseText(text);
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setRawText(text);
      handleParseText(text);
    };
    reader.readAsText(file);
  };

  const loadSampleThreatData = () => {
    const sample = `[SOC LOG INTEGRATION WORKSPACE]
Incident-ID: 99421-A
External C2 active connection: 185.112.146.22
Internal workstation targeted: 10.12.44.8
Status: Command-Control ping failed to payload hash md5: 6b251a3f6bd5b357be842decd23e20ab0a2decf
Secondary domain nodes queried by malware:
- malicious-billing-update.com
- internal-vault.local (Internal asset address - blocked)
- loopback testing address: 127.0.0.1
- Backup node domain: security-dns-cache.xyz
- File Payload sha256 checksum: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- DNS resolver backup subnet: 192.168.1.254`;
    setRawText(sample);
    handleParseText(sample);
  };

  const handleMassInvestigate = async () => {
    if (parsedIocs.length === 0) return;
    setIsScanningBulk(true);

    setParsedIocs((prev) =>
      prev.map((ioc) =>
        ioc.isPrivate ? ioc : { ...ioc, reputation: "scanning" }
      )
    );

    const apiKeys = {
      virustotal: localStorage.getItem("VT_API_KEY") || "",
      abuseipdb: localStorage.getItem("ABUSEIPDB_API_KEY") || "",
      greynoise: localStorage.getItem("GREYNOISE_API_KEY") || "",
      shodan: localStorage.getItem("SHODAN_API_KEY") || "",
      urlscan: localStorage.getItem("URLSCAN_API_KEY") || "",
      gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      ipinfo: localStorage.getItem("IPINFO_API_KEY") || "",
      ip2proxy: localStorage.getItem("IP2PROXY_API_KEY") || "",
      ipqualityscore: localStorage.getItem("IPQUALITYSCORE_API_KEY") || "",
      whoisjson: localStorage.getItem("WHOISJSON_API_KEY") || "",
    };

    await Promise.allSettled(
      parsedIocs.map(async (ioc) => {
        if (ioc.isPrivate) return;

        try {
          if (ioc.type === "IP") {
            const res = await fetch("/api/enrich/ip", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ ip: ioc.value, apiKeys }),
            });
            if (res.ok) {
              const data = await res.json();
              const isMal = data.riskScore > 75 || data.abuseScore > 60;
              const isSusp = data.riskScore > 35 || data.abuseScore > 25;
              setParsedIocs((prev) =>
                prev.map((item) =>
                  item.id === ioc.id
                    ? {
                        ...item,
                        reputation: isMal ? "malicious" : isSusp ? "suspicious" : "clean",
                        riskScore: data.riskScore || data.abuseScore || 0,
                        details: data,
                      }
                    : item
                )
              );
            } else {
              throw new Error("Rejected by RBL network nodes.");
            }
          } else if (ioc.type === "Domain") {
            const res = await fetch("/api/enrich/domain", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ domain: ioc.value, apiKeys }),
            });
            if (res.ok) {
              const data = await res.json();
              setParsedIocs((prev) =>
                prev.map((item) =>
                  item.id === ioc.id
                    ? {
                        ...item,
                        reputation: data.reputation || "clean",
                        riskScore: data.reputation === "malicious" ? 85 : data.reputation === "suspicious" ? 45 : 0,
                        details: data,
                      }
                    : item
                )
              );
            } else {
              throw new Error("C2 domain sync failure.");
            }
          } else if (ioc.type === "Hash") {
            const res = await fetch("/api/enrich/hash", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ hash: ioc.value, apiKeys }),
            });
            if (res.ok) {
              const data = await res.json();
              setParsedIocs((prev) =>
                prev.map((item) =>
                  item.id === ioc.id
                    ? {
                        ...item,
                        reputation: data.reputation || "clean",
                        riskScore: data.reputation === "malicious" ? 95 : data.reputation === "suspicious" ? 50 : 0,
                        details: data,
                      }
                    : item
                )
              );
            } else {
              throw new Error("Signature not cataloged.");
            }
          }
        } catch (err: any) {
          setParsedIocs((prev) =>
            prev.map((item) =>
              item.id === ioc.id
                ? {
                    ...item,
                    reputation: "clean",
                    error: err.message || "Failed to establish validation."
                  }
                : item
            )
          );
        }
      })
    );

    setIsScanningBulk(false);
  };

  const handleExportCSV = () => {
    if (parsedIocs.length === 0) return;
    
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Value,Type,Network Scope,Reputation Status,Threat Score,Detections / Context,Excluded Reason\n";
    
    parsedIocs.forEach((ioc) => {
      const scope = ioc.isPrivate ? "Private" : "Public";
      const rep = ioc.reputation.toUpperCase();
      const score = ioc.riskScore !== undefined ? ioc.riskScore : "N/A";
      
      let context = "";
      if (ioc.isPrivate) {
        context = ioc.privateReason || "Internal Subnet";
      } else if (ioc.details) {
        if (ioc.type === "IP") {
          context = ioc.details.threatIntelligence?.description || `${ioc.details.countryCode} - ${ioc.details.isp}`;
        } else if (ioc.type === "Domain") {
          context = ioc.details.categories?.join(", ") || ioc.details.registrar;
        } else if (ioc.type === "Hash") {
          context = ioc.details.malwareFamily || ioc.details.tags?.join(", ") || "File Hash Reference";
        }
      } else if (ioc.error) {
        context = `Error: ${ioc.error}`;
      } else {
        context = "Awaiting Investigation Scan";
      }
      
      const cleanVal = ioc.value.replace(/"/g, '""');
      const cleanContext = context.replace(/"/g, '""');
      const cleanReason = (ioc.privateReason || "").replace(/"/g, '""');
      
      csvContent += `"${cleanVal}","${ioc.type}","${scope}","${rep}","${score}","${cleanContext}","${cleanReason}"\n`;
    });
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `comprehensive-ioc-report-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyValue = (val: string, id: string) => {
    navigator.clipboard.writeText(val);
    setIsCopiedId(id);
    setTimeout(() => setIsCopiedId(null), 1500);
  };

  const [advisories, setAdvisories] = useState([
    {
      cve: "CVE-2026-8812",
      title: "Citrix NetScaler Remote Code Execution Via Header Injection",
      severity: "CRITICAL",
      score: 9.8,
      status: "ACTIVE EXPLOITING",
      summary: "Under active exploitation inside government and software infrastructure sectors. Involves craftily structured HTTP requests bypassing parsing caches.",
      mitre: "T1190 - Exploit Public-Facing Application"
    },
    {
      cve: "CVE-2026-2140",
      title: "Linux Kernel Local Privilege Escalation (eBPF Kernel Ring)",
      severity: "HIGH",
      score: 8.4,
      status: "PROOF-OF-CONCEPT",
      summary: "Flawed ring buffer constraints inside Linux eBPF systems allow local containers to escalate directly to root permissions.",
      mitre: "T1068 - Exploitation for Privilege Escalation"
    },
    {
      cve: "CVE-2026-9031",
      title: "Microsoft Exchange Server Spoofing and Remote Execution Bypass",
      severity: "HIGH",
      score: 8.9,
      status: "UNDER INVESTIGATION",
      summary: "Adversaries are actively injecting malformed XML payloads inside public calendar items to execute command contexts.",
      mitre: "T1566 - Phishing"
    }
  ]);

  const [activeActors] = useState([
    { name: "APT29 (Cozy Bear)", nature: "Espionage", origin: "State-Sponsored", target: "Defense & Energy Sectors", status: "Highly Active" },
    { name: "Lazarus Group", nature: "Financial Theft / Ransom", origin: "State-Sponsored", target: "Crypto Exchanges & Banks", status: "Active" },
    { name: "SCATTERED SPIDER", nature: "Social Engineering / Ransom", origin: "Cybercriminal", target: "SaaS & Hospitality", status: "Escalating" }
  ]);

  // Form states for broadcasting a new live IOC / Security Incident
  const [sourceChannel, setSourceChannel] = useState("");
  const [iocDescription, setIocDescription] = useState("");
  const [severityRank, setSeverityRank] = useState("High");
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [successNotif, setSuccessNotif] = useState(false);

  // Live indicators pulled from central threat-feed endpoint
  const [liveIndicatorFeeds, setLiveIndicatorFeeds] = useState<any[]>([]);
  const [loadingFeeds, setLoadingFeeds] = useState(false);

  const fetchLiveFeeds = async () => {
    setLoadingFeeds(true);
    try {
      const response = await fetch("/api/live-feeds");
      if (response.ok) {
        const data = await response.json();
        setLiveIndicatorFeeds(data);
      }
    } catch (e) {
      console.error("Failed to load intel feeds", e);
    } finally {
      setLoadingFeeds(false);
    }
  };

  useEffect(() => {
    fetchLiveFeeds();
  }, []);

  const handleBroadcastIOC = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceChannel.trim() || !iocDescription.trim()) return;

    setIsBroadcasting(true);
    try {
      const response = await fetch("/api/live-feeds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: sourceChannel,
          event: iocDescription,
          severity: severityRank
        })
      });

      if (response.ok) {
        setSourceChannel("");
        setIocDescription("");
        setSuccessNotif(true);
        fetchLiveFeeds();
        setTimeout(() => setSuccessNotif(false), 4000);
      }
    } catch (err) {
      console.error("Broadcasting failed", err);
    } finally {
      setIsBroadcasting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-500" />
            THREAT INTELLIGENCE & ZERO-DAY OBSERVATIONS
          </h2>
          <p className="text-xs text-slate-550 font-mono">
            Interactive zero-day telemetry maps representing current APT active threat-groups campaigns and sector exploitation ratios.
          </p>
        </div>
        <button
          onClick={fetchLiveFeeds}
          className="flex items-center gap-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded text-xs font-mono transition font-semibold cursor-pointer"
        >
          <RotateCw className="w-3.5 h-3.5" />
          REFRESH CENTRAL FEED
        </button>
      </div>

      {/* Sub-Tabs Selector */}
      <div className="flex flex-wrap border-b border-slate-900 font-mono text-xs">
        <button
          onClick={() => setSubTab("bleeping-computer")}
          className={`px-4 sm:px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            subTab === "bleeping-computer"
              ? "border-red-500 text-red-500 bg-red-950/5"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <Rss className="w-3.5 h-3.5 text-red-500" />
          BLEEPINGCOMPUTER RSS & EXTRACTED IOCS
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-red-950 text-red-400 border border-red-900/60 uppercase">
            RSS FEED
          </span>
        </button>

        <button
          onClick={() => setSubTab("cisa-kev")}
          className={`px-4 sm:px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            subTab === "cisa-kev"
              ? "border-amber-500 text-amber-500 bg-amber-950/5"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
          CISA KNOWN EXPLOITED VULNERABILITIES (KEV)
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 border border-amber-900/60 uppercase">
            BOD 22-01
          </span>
        </button>

        <button
          onClick={() => setSubTab("bulk")}
          className={`px-4 sm:px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            subTab === "bulk"
              ? "border-red-500 text-red-500 bg-red-950/5"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <UploadCloud className="w-3.5 h-3.5 text-red-500" />
          MULTIPLE IOC FILE INVESTIGATOR
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-red-950 text-red-400 border border-red-900/60 uppercase">
            PARSER
          </span>
        </button>

        <button
          onClick={() => setSubTab("feed")}
          className={`px-4 sm:px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            subTab === "feed"
              ? "border-red-500 text-red-500 bg-red-950/5"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          ACTIVE ADVISORIES & STREAM BROADCASTS
        </button>
      </div>

      {subTab === "bleeping-computer" && (
        <BleepingComputerFeed
          onPivotToIp={onPivotToIp}
          onPivotToDomain={onPivotToDomain}
          onPivotToUrl={onPivotToUrl}
          onPivotToHash={onPivotToHash}
          onNavigateToKql={onNavigateToKql}
          onSendToBulk={(text) => {
            setRawText(text);
            handleParseText(text);
            setSubTab("bulk");
          }}
        />
      )}

      {subTab === "cisa-kev" && (
        <CisaKevFeed
          onNavigateToKql={(cve) =>
            onNavigateToKql?.({
              title: `${cve} Exploitation & Vulnerability Hunt`,
              cves: [cve],
              sourceType: "cisa-kev"
            })
          }
        />
      )}

      {subTab === "feed" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Advisories & Submission Broadcaster (Left 2 columns) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Broadcaster form block */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
            <div className="flex gap-2 items-center mb-3">
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
              <h3 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">
                THREAT FEED BROADCASTER (SUBMIT NEW IOC)
              </h3>
            </div>
            <p className="text-[11px] font-mono text-slate-500 mb-4 leading-normal">
              Operators can instantly input and publish newly observed indicators of compromise (IOCs) or zero-day events. Submissions synchronize dynamically across the security console and reflect in the central Dashboard in real time.
            </p>

            <form onSubmit={handleBroadcastIOC} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-mono text-slate-500 uppercase font-bold mb-1">
                    Threat / Intel Source
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Unit 42, Mandiant, CISA, Wildfire Sandboxing"
                    value={sourceChannel}
                    onChange={(e) => setSourceChannel(e.target.value)}
                    className="w-full bg-slate-955 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-3 py-2 text-xs font-mono text-slate-200 placeholder-slate-650"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-slate-500 uppercase font-bold mb-1">
                    Severity Tier
                  </label>
                  <select
                    value={severityRank}
                    onChange={(e) => setSeverityRank(e.target.value)}
                    className="w-full bg-slate-955 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-3 py-2 text-xs font-mono text-slate-300 cursor-pointer"
                  >
                    <option value="Critical">Critical</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase font-bold mb-1">
                  IOC details / Event Description
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. Active scanning for Ivanti SSL VPN CVE-2026-6112 detected from 185.112.52.12."
                  value={iocDescription}
                  onChange={(e) => setIocDescription(e.target.value)}
                  className="w-full bg-slate-955 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-3 py-2 text-xs font-mono text-slate-200 placeholder-slate-650 resize-none"
                />
              </div>

              <div className="flex justify-between items-center pt-1 font-mono">
                {successNotif ? (
                  <span className="flex items-center gap-1.5 text-[10.5px] font-bold text-emerald-400">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    BROADCAST DISTRIBUTED SAFELY! UPDATING DASHBOARDS...
                  </span>
                ) : (
                  <span className="text-[9px] text-slate-600">
                    Submissions comply with STIX/TAXII threat intel formatting guidelines.
                  </span>
                )}
                <button
                  type="submit"
                  disabled={isBroadcasting}
                  className="flex items-center gap-2 bg-red-950/40 hover:bg-red-950/80 border border-red-900 text-red-400 hover:text-red-300 px-4 py-2 rounded text-xs transition font-bold font-mono cursor-pointer disabled:opacity-40"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isBroadcasting ? "COMMITTING TRANSMISSION..." : "BROADCAST INTEL"}
                </button>
              </div>
            </form>
          </div>

          {/* Advisories list */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
            <h3 className="text-xs font-mono font-bold text-slate-205 tracking-wider uppercase mb-3 flex items-center gap-2">
              <Flame className="w-3.5 h-3.5 text-orange-500" />
              LATEST HIGHEST SEVERITY CVE ADVISORIES
            </h3>

            <div className="space-y-3.5">
              {advisories.map((adv, idx) => (
                <div key={idx} className="p-4 bg-slate-950 border border-slate-900 rounded relative overflow-hidden flex flex-col gap-2.5">
                  <div className="flex justify-between items-center text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <span className="text-amber-500 font-bold bg-amber-950/15 border border-amber-900 px-1.5 py-0.2 rounded">
                        {adv.cve}
                      </span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        adv.severity === "CRITICAL" ? "bg-red-950 text-red-400" : "bg-orange-950 text-orange-400"
                      }`}>
                        {adv.severity} (CVSS {adv.score})
                      </span>
                    </div>
                    <span className="text-[9px] text-red-400 font-bold uppercase blink">
                      ● {adv.status}
                    </span>
                  </div>

                  <h4 className="text-xs font-mono font-bold text-slate-200">{adv.title}</h4>
                  <p className="text-[11px] font-mono text-slate-400 leading-normal">{adv.summary}</p>

                  <div className="text-[10px] font-mono text-slate-500 flex gap-1.5">
                    <span className="font-bold text-slate-450">ATT&CK Map:</span>
                    <span>{adv.mitre}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Global Actor Watchlist & Central Feeds Sync (Right column) */}
        <div className="space-y-6">
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
            <h3 className="text-xs font-mono font-bold text-slate-200 uppercase mb-3 flex items-center gap-2">
              <Users className="w-3.5 h-3.5 text-blue-400" />
              STATE-SPONSORED APT WATCHLIST
            </h3>

            <div className="space-y-2.5 font-mono text-xs text-slate-400">
              {activeActors.map((ac, i) => (
                <div key={i} className="p-3 bg-slate-950 border border-slate-900 rounded space-y-2.5 flex flex-col">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-201">{ac.name}</span>
                    <span className="text-[9px] font-bold bg-blue-950 text-blue-400 border border-blue-900 px-1.5 py-0.2 rounded">
                      {ac.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-[10.5px] space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Motive Tactic:</span>
                      <span>{ac.nature}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Target Range:</span>
                      <span className="truncate max-w-[150px]">{ac.target}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Central synchronized live indicators log */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
            <h3 className="text-xs font-mono font-bold text-slate-200 uppercase mb-3 flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              CENTRAL LIVE THREAT SYNC
            </h3>

            <div className="space-y-2 max-h-[310px] overflow-y-auto">
              {loadingFeeds && liveIndicatorFeeds.length === 0 ? (
                <span className="text-[11px] font-mono text-slate-500">Updating node streams...</span>
              ) : (
                liveIndicatorFeeds.map((feed) => (
                  <div key={feed.id} className="p-2 border border-slate-900 bg-slate-1000/60 rounded flex flex-col font-mono text-[10px] gap-1 hover:border-slate-800 transition">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] text-blue-400 font-bold uppercase">{feed.source}</span>
                      <span className={`text-[8px] font-bold px-1 rounded ${
                        feed.severity === "Critical" ? "bg-red-950 text-red-500 border border-red-900" :
                        feed.severity === "High" ? "bg-orange-950 text-orange-500 border border-orange-900" :
                        "bg-slate-900 text-slate-400 border border-slate-700"
                      }`}>{feed.severity}</span>
                    </div>
                    <p className="text-slate-350 text-[10px] tracking-tight text-slate-300">{feed.event}</p>
                    <span className="text-[8px] text-slate-550 italic">{feed.time}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-1">
            <h4 className="text-[10px] font-mono text-slate-450 uppercase font-bold flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-emerald-400" />
              Intelligence Broadcast Channel
            </h4>
            <p className="text-[10px] font-mono text-slate-500 leading-normal">
              Zero-day disclosures are fully correlated with active threat news feeds and ransomware onion-sites directories.
            </p>
          </div>
        </div>
      </div>
      )}

      {subTab === "bulk" && (
        <div className="space-y-6">
          {/* Main bulk cards layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* INPUT PANEL (Left 5 columns) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col h-full min-h-[480px]">
                <div className="flex items-center justify-between mb-3 border-b border-slate-900 pb-3">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-red-500" />
                    <span className="font-mono text-xs font-bold text-slate-200">IOC DATA INGESTION</span>
                  </div>
                  <button
                    onClick={loadSampleThreatData}
                    className="text-[9.5px] font-mono text-red-400 hover:text-red-300 font-bold border border-red-900 px-1.5 py-0.5 rounded transition uppercase cursor-pointer"
                  >
                    Load Incident Sample
                  </button>
                </div>

                <p className="text-[11px] font-mono text-slate-500 leading-normal mb-4">
                  Paste firewall lines, system telemetry logs, raw list feeds, or upload raw text reports. Custom parsers split and map standard public/private IPv4, DNS/RBL domains, and MD5/SHA payloads.
                </p>

                {/* Drag and Drop Zone */}
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={`border border-dashed rounded p-5 flex flex-col items-center justify-center text-center cursor-pointer transition relative group ${
                    dragActive
                      ? "border-red-500 bg-red-950/10"
                      : "border-slate-850 hover:border-slate-700 bg-slate-950"
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".txt,.csv,.log,.json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <UploadCloud className={`w-8 h-8 mb-2 transition ${dragActive ? "text-red-500 animate-pulse" : "text-slate-600 group-hover:text-slate-450"}`} />
                  <span className="font-mono text-[11px] text-slate-400 font-bold uppercase tracking-wider">
                    Drag & Drop Log File here
                  </span>
                  <span className="font-mono text-[9px] text-slate-600 mt-1 uppercase">
                    or click to manually browse system files
                  </span>
                </div>

                <div className="relative mt-4 flex-1 flex flex-col">
                  <span className="absolute right-2 top-2 font-mono text-[8.5px] text-slate-650 font-bold tracking-widest pointer-events-none">[TEXTAREA INGESTION]</span>
                  <textarea
                    value={rawText}
                    onChange={(e) => {
                      setRawText(e.target.value);
                      handleParseText(e.target.value);
                    }}
                    placeholder="Manually input telemetry/IOC block here..."
                    className="w-full flex-1 min-h-[180px] bg-slate-955 border border-slate-850 rounded p-3 font-mono text-[10.5px] text-slate-200 placeholder-slate-700 focus:outline-none focus:border-red-500 resize-none"
                  />
                </div>

                <div className="flex gap-3 mt-4 pt-4 border-t border-slate-900">
                  <button
                    onClick={() => {
                      setRawText("");
                      setParsedIocs([]);
                    }}
                    disabled={!rawText}
                    className="flex-1 py-1.5 rounded border border-slate-850 hover:border-slate-750 text-slate-400 hover:text-slate-200 text-[10.5px] font-mono transition font-bold uppercase flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Reset Console
                  </button>
                  <button
                    onClick={handleMassInvestigate}
                    disabled={parsedIocs.length === 0 || isScanningBulk}
                    className="flex-1 py-1.5 rounded bg-gradient-to-r from-red-950/50 to-red-900/50 hover:from-red-950/70 hover:to-red-900/70 border border-red-500/40 hover:border-red-500 text-red-300 hover:text-red-200 text-[10.5px] font-mono transition font-bold uppercase flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    {isScanningBulk ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Scanning Logs...
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        Run Mass Intel
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* LIVE PARSED RESULTS PANEL (Right 7 columns) */}
            <div className="lg:col-span-12 xl:col-span-7 lg:col-span-7 space-y-4 flex flex-col h-full">
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col h-full min-h-[480px]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3 border-b border-slate-900 pb-3">
                  <div className="flex items-center gap-2">
                    <ListFilter className="w-4 h-4 text-red-500" />
                    <span className="font-mono text-xs font-bold text-slate-200 uppercase">PARSED INDICATORS ({parsedIocs.length})</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleExportCSV}
                      disabled={parsedIocs.length === 0}
                      className="text-[9.5px] font-mono text-emerald-400 hover:text-emerald-300 font-bold border border-emerald-950 hover:border-emerald-900 bg-emerald-950/10 px-2 py-1.5 rounded transition uppercase flex items-center gap-1 disabled:opacity-35 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      Export CSV
                    </button>
                    <button
                      onClick={() => setShowReportCreator(true)}
                      disabled={parsedIocs.length === 0}
                      className="text-[9.5px] font-mono text-red-400 hover:text-red-300 font-bold border border-red-955 hover:border-red-900 bg-red-950/15 px-2.5 py-1.5 rounded transition uppercase flex items-center gap-1 disabled:opacity-35 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Threat Report (PDF)
                    </button>
                  </div>
                </div>

                {/* FILTER PILLS */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {(["all", "malicious", "private", "external"] as const).map((f) => {
                    const count = parsedIocs.filter((ioc) => {
                      if (f === "all") return true;
                      if (f === "malicious") return ioc.reputation === "malicious";
                      if (f === "private") return ioc.isPrivate;
                      if (f === "external") return !ioc.isPrivate;
                      return true;
                    }).length;

                    return (
                      <button
                        key={f}
                        onClick={() => setBulkFilter(f)}
                        className={`text-[9.5px] font-mono uppercase px-2.5 py-1 rounded border transition font-bold cursor-pointer ${
                          bulkFilter === f
                            ? "bg-red-950/60 border-red-500 text-red-400"
                            : "bg-slate-950 border-slate-900 text-slate-450 hover:text-slate-300"
                        }`}
                      >
                        {f} ({count})
                      </button>
                    );
                  })}
                </div>

                {/* INDICATORS LIST VIEW */}
                <div className="flex-1 overflow-y-auto max-h-[385px] space-y-2 pr-1 custom-scrollbar">
                  {parsedIocs.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8 border border-dashed border-slate-900 rounded bg-slate-950/20">
                      <FolderOpen className="w-10 h-10 text-slate-750 mb-2.5" />
                      <p className="font-mono text-[11px] text-slate-400 uppercase font-bold">No indicators detected yet</p>
                      <p className="font-sans text-[11px] text-slate-500 max-w-[280px] mt-1">
                        Use the incident sample or drop/paste raw logs into the console scanner on the left.
                      </p>
                    </div>
                  ) : (
                    parsedIocs
                      .filter((ioc) => {
                        if (bulkFilter === "all") return true;
                        if (bulkFilter === "malicious") return ioc.reputation === "malicious";
                        if (bulkFilter === "private") return ioc.isPrivate;
                        if (bulkFilter === "external") return !ioc.isPrivate;
                        return true;
                      })
                      .map((ioc) => {
                        const isExpanded = expandedIocId === ioc.id;
                        const isCopied = isCopiedId === ioc.id;

                        return (
                          <div
                            key={ioc.id}
                            className={`border rounded transition-all bg-slate-950/40 relative overflow-hidden flex flex-col ${
                              isExpanded ? "border-slate-750 bg-slate-950/80" : "border-slate-900 hover:border-slate-800"
                            }`}
                          >
                            {/* Accent highlight strip based on status */}
                            <div className={`absolute top-0 bottom-0 left-0 w-1 ${
                              ioc.reputation === "malicious" ? "bg-red-500" :
                              ioc.reputation === "suspicious" ? "bg-amber-500" :
                              ioc.reputation === "clean" ? "bg-emerald-500" :
                              ioc.reputation === "blocked" ? "bg-orange-500/80" :
                              ioc.reputation === "scanning" ? "bg-blue-500 animate-pulse" :
                              "bg-slate-700"
                            }`} />

                            {/* Header row */}
                            <div className="p-3 pl-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className={`text-[8.5px] font-bold px-1.5 py-0.2 rounded border uppercase font-mono ${
                                  ioc.type === "IP" ? "bg-blue-950 text-blue-400 border-blue-900/60" :
                                  ioc.type === "Domain" ? "bg-purple-950 text-purple-400 border-purple-900/60" :
                                  "bg-indigo-950 text-indigo-400 border-indigo-900/60"
                                }`}>
                                  {ioc.type}
                                </span>

                                <span className="font-bold text-slate-100 select-all tracking-tight break-all">
                                  {ioc.value}
                                </span>

                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleCopyValue(ioc.value, ioc.id);
                                  }}
                                  className="text-[10px] text-slate-500 hover:text-slate-350 cursor-pointer p-0.5 animate-none"
                                  title="Copy IOC"
                                >
                                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              </div>

                              <div className="flex items-center gap-2">
                                {/* Network Scope Badge */}
                                <span className={`text-[8.5px] font-bold px-1.5 py-0.2 rounded font-mono ${
                                  ioc.isPrivate
                                    ? "bg-amber-950 text-amber-500 border border-amber-900/50"
                                    : "bg-slate-900 text-slate-450 border border-slate-800"
                                }`}>
                                  {ioc.isPrivate ? "PRIVATE RANGE" : "PUBLIC EDGE"}
                                </span>

                                {/* Reputation badge */}
                                <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded border flex items-center gap-1 uppercase ${
                                  ioc.reputation === "malicious" ? "bg-red-950/60 text-red-500 border-red-900" :
                                  ioc.reputation === "suspicious" ? "bg-amber-950/60 text-amber-500 border-amber-900" :
                                  ioc.reputation === "clean" ? "bg-emerald-950/60 text-emerald-500 border-emerald-900" :
                                  ioc.reputation === "blocked" ? "bg-amber-950 text-amber-500 border-amber-900" :
                                  ioc.reputation === "scanning" ? "bg-blue-950 text-blue-400 border-blue-900 animate-pulse" :
                                  "bg-slate-900 text-slate-550 border-slate-800"
                                }`}>
                                  {ioc.reputation === "scanning" && <RefreshCw className="w-3 h-3 animate-spin text-blue-400" />}
                                  {ioc.reputation === "blocked" && <Lock className="w-3 h-3 text-amber-500" />}
                                  {ioc.reputation === "clean" && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                                  {ioc.reputation === "malicious" && <ShieldAlert className="w-3 h-3 text-red-500" />}
                                  {ioc.reputation}
                                </span>

                                <button
                                  onClick={() => setExpandedIocId(isExpanded ? null : ioc.id)}
                                  className="text-slate-500 hover:text-slate-350 p-1 rounded hover:bg-slate-900 cursor-pointer"
                                  title="Toggle Information panel"
                                >
                                  <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                                </button>
                              </div>
                            </div>

                            {/* Expanded Details Card */}
                            {isExpanded && (
                              <div className="px-4 pb-4 pt-1 border-t border-slate-900 text-slate-300 bg-slate-955/60 space-y-3 font-mono text-[11px]">
                                {ioc.isPrivate ? (
                                  <div className="p-3 bg-amber-950/20 border border-amber-900/40 rounded space-y-1.5 text-slate-300">
                                    <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[10.5px]">
                                      <Lock className="w-3.5 h-3.5" />
                                      RFC EXCLUSION ACTIVE (LOCAL SUBNET)
                                    </div>
                                    <p className="text-slate-400 text-[11px] leading-relaxed">
                                      Identifier conforms to standard <strong className="text-amber-200">{ioc.privateReason}</strong> categorization rules. Mass public query is suppressed to avoid leaking workstation naming layouts, intranet structure topologies, or corporate environment configurations.
                                    </p>
                                  </div>
                                ) : ioc.reputation === "pending" ? (
                                  <div className="flex items-center gap-2 text-slate-500 py-3 justify-center border border-dashed border-slate-900 rounded bg-slate-950/10">
                                    <HelpCircle className="w-4 h-4 text-slate-600" />
                                    Awaiting bulk scanning instruction queue. Press 'Run Mass Intel' to resolve.
                                  </div>
                                ) : ioc.reputation === "scanning" ? (
                                  <div className="flex items-center gap-2 text-blue-400 py-3 justify-center border border-dashed border-slate-900 rounded bg-slate-950/10">
                                    <RefreshCw className="w-4 h-4 animate-spin text-blue-400" />
                                    Submitting node queries and gathering RBL reputational records...
                                  </div>
                                ) : ioc.error ? (
                                  <div className="p-3 bg-red-950/20 border border-red-900/40 rounded flex items-start gap-2">
                                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                                    <div>
                                      <span className="font-bold text-red-400">Node lookup failed: </span>
                                      <span className="text-slate-400">{ioc.error} (reputational details default to Clean).</span>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="space-y-3 pt-2">
                                    {/* Score meter bar */}
                                    {ioc.riskScore !== undefined && (
                                      <div className="space-y-1">
                                        <div className="flex justify-between items-center text-[10px]">
                                          <span className="text-slate-500 uppercase font-bold">Threat Severity score</span>
                                          <span className={`font-bold ${ioc.riskScore > 75 ? "text-red-400" : ioc.riskScore > 35 ? "text-amber-400" : "text-emerald-400"}`}>
                                            {ioc.riskScore} / 100
                                          </span>
                                        </div>
                                        <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                                          <div
                                            className={`h-full rounded-full transition-all duration-500 ${
                                              ioc.riskScore > 75 ? "bg-red-500" : ioc.riskScore > 35 ? "bg-amber-500" : "bg-emerald-500"
                                            }`}
                                            style={{ width: `${ioc.riskScore}%` }}
                                          />
                                        </div>
                                      </div>
                                    )}

                                    {/* Details details blocks */}
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10.5px]">
                                      {ioc.type === "IP" && ioc.details && (
                                        <>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Geo-Location Registry</span>
                                            <span className="text-slate-200 block">{ioc.details.countryCode || "N/A"} - {ioc.details.countryName || "Unknown"}</span>
                                            <span className="text-[9.5px] text-slate-450 block truncate">{ioc.details.isp || "No ISP recorded"}</span>
                                          </div>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Abuse Reporting IP</span>
                                            <span className="text-slate-200 block">Reports: {ioc.details.abuseScore || 0} filings</span>
                                            <span className="text-[9.5px] text-slate-450 block truncate">{ioc.details.asn || "N/A"}</span>
                                          </div>
                                        </>
                                      )}

                                      {ioc.type === "Domain" && ioc.details && (
                                        <>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Domain Security Host</span>
                                            <span className="text-slate-200 block">Registrar: {ioc.details.registrar || "N/A"}</span>
                                            <span className="text-[9.5px] text-slate-450 block">Creation: {ioc.details.creationDate || "N/A"}</span>
                                          </div>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded text-[10.5px]">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Active Categorization</span>
                                            <div className="flex flex-wrap gap-1 mt-1">
                                              {ioc.details.categories && ioc.details.categories.length > 0 ? (
                                                ioc.details.categories.map((cat: string, i: number) => (
                                                  <span key={i} className="bg-slate-900 border border-slate-850 px-1 py-0.2 rounded text-[8px]">
                                                    {cat}
                                                  </span>
                                                ))
                                              ) : (
                                                <span className="text-slate-450">Generic/Uncategorized web hub</span>
                                              )}
                                            </div>
                                          </div>
                                        </>
                                      )}

                                      {ioc.type === "Hash" && ioc.details && (
                                        <>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Malware family Signature</span>
                                            <span className="text-slate-200 block font-bold text-red-300">{ioc.details.malwareFamily || "Unidentified Family"}</span>
                                            <span className="text-[9.5px] text-slate-450 block">Payload: {ioc.details.threatName || "Suspicious Executable Reference"}</span>
                                          </div>
                                          <div className="space-y-1 p-2.5 bg-slate-1000/60 border border-slate-900/65 rounded">
                                            <span className="text-slate-500 block uppercase text-[9px] font-bold">Catalog Tagings</span>
                                            <div className="flex flex-wrap gap-1 mt-1">
                                              {ioc.details.tags && ioc.details.tags.length > 0 ? (
                                                ioc.details.tags.map((tg: string, i: number) => (
                                                  <span key={i} className="bg-red-950/20 border border-red-900/40 px-1 py-0.2 rounded text-[8.5px] text-red-350">
                                                    {tg}
                                                  </span>
                                                ))
                                              ) : (
                                                <span className="text-slate-450">Generic raw metadata reference</span>
                                              )}
                                            </div>
                                          </div>
                                        </>
                                      )}
                                    </div>

                                    {/* Action items button */}
                                    <div className="flex justify-end pt-1 bg-transparent">
                                      <a
                                        href={ioc.type === "IP" ? `https://www.virustotal.com/gui/ip-address/${ioc.value}` : ioc.type === "Domain" ? `https://www.virustotal.com/gui/domain/${ioc.value}` : `https://www.virustotal.com/gui/file/${ioc.value}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-[9.5px] text-red-400 hover:text-red-300 font-bold flex items-center gap-1 bg-red-950/10 hover:bg-red-950/20 border border-red-900/40 hover:border-red-900 px-2.5 py-1 rounded transition uppercase"
                                      >
                                        Inspect on VirusTotal
                                        <ExternalLink className="w-3 h-3" />
                                      </a>
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {showReportCreator && (
        <div className="fixed inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-4 z-50 overflow-y-auto no-print">
          <style>
            {`
              @media print {
                /* Hide everything */
                body * {
                  visibility: hidden !important;
                }
                /* Only show print container */
                .printable-dossier, .printable-dossier * {
                  visibility: visible !important;
                }
                .printable-dossier {
                  position: absolute !important;
                  left: 0 !important;
                  top: 0 !important;
                  width: 100% !important;
                  display: block !important;
                  background: white !important;
                  color: black !important;
                }
                .no-print {
                  display: none !important;
                }
              }
            `}
          </style>

          <div className="bg-slate-900 border border-slate-800 rounded-lg max-w-4xl w-full flex flex-col h-[90vh]">
            {/* Header / Dialog control panel */}
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-red-500" />
                <span className="font-mono text-xs font-bold text-slate-100 uppercase tracking-widest">
                  CYBERNETIC INTEL THREAT RAPPORT GENERATOR
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    window.print();
                  }}
                  className="bg-red-950/45 hover:bg-red-900/45 border border-red-500/30 hover:border-red-500 text-red-400 px-3 py-1.5 rounded text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Print / Save PDF
                </button>
                <button
                  onClick={() => {
                    const dateStr = new Date().toISOString().split("T")[0];
                    const countMalicious = parsedIocs.filter(i => i.reputation === "malicious").length;
                    const rowsHtml = parsedIocs.map(i => `
                      <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 10px; font-weight: bold; color: ${i.reputation === 'malicious' ? '#e11d48' : '#334155'};">${i.value}</td>
                        <td style="padding: 10px;">${i.type}</td>
                        <td style="padding: 10px; text-transform: uppercase; font-weight: bold; color: ${i.reputation === 'malicious' ? '#e11d48' : '#22c55e'};">${i.reputation}</td>
                        <td style="padding: 10px;">${i.isPrivate ? 'Private Range' : 'Public Edge'}</td>
                      </tr>`).join("");
                    
                    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Security Dossier - ${dateStr}</title>
  <style>
    body { font-family: monospace; background: #fff; color: #111; padding: 25px; line-height: 1.4; }
    .header { border-bottom: 3px double #111; padding-bottom: 20px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: bold; text-align: center; margin: 0 0 10px 0; }
    .meta { font-size: 11px; display: flex; justify-content: space-between; }
    .summary { background: #f8fafc; border: 1px solid #cbd5e1; padding: 15px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 11px; }
    th { background: #f1f5f9; padding: 10px; border-bottom: 2px solid #111; text-align: left; }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">▲ EXECUTIVE INTERACTION THREAT DOSSIER ▲</div>
    <div class="meta">
      <span>DATE: ${new Date().toLocaleString()}</span>
      <span>REPORT CLASSIFICATION: CONFIDENTIAL</span>
    </div>
  </div>
  <div class="summary">
    <strong>SUMMARY METRICS:</strong><br>
    Total Indicators: ${parsedIocs.length}<br>
    Malicious Vectors: ${countMalicious}<br>
    Risk Index Score: ${Math.round((countMalicious / parsedIocs.length) * 100) || 0}%
  </div>
  <h3>INDICATORS LEDGER:</h3>
  <table>
    <thead>
      <tr>
        <th>VALUE</th>
        <th>TYPE</th>
        <th>REPUTATION STATUS</th>
        <th>SCOPE</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml}
    </tbody>
  </table>
</body>
</html>`;
                    
                    const blob = new Blob([htmlContent], { type: "text/html" });
                    const link = document.createElement("a");
                    link.href = URL.createObjectURL(blob);
                    link.download = `threat_report_${dateStr}.html`;
                    link.click();
                  }}
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-805 hover:border-slate-750 text-slate-400 px-3 py-1.5 rounded text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  Download HTML Report
                </button>
                <button
                  onClick={() => setShowReportCreator(false)}
                  className="bg-slate-900 border border-slate-800 text-slate-400 px-3 py-1.5 rounded text-xs font-mono transition cursor-pointer hover:bg-slate-850 hover:text-slate-200"
                >
                  ✕ Close
                </button>
              </div>
            </div>

            {/* Dossier Body Wrapper (High Contrast, white background preview container) */}
            <div className="flex-1 p-8 overflow-y-auto bg-slate-950 flex justify-center">
              <div 
                id="printable-dossier-root"
                className="bg-white text-slate-900 printable-dossier max-w-2xl w-full p-8 font-mono text-xs shadow-xl rounded border border-slate-350 leading-relaxed space-y-6 self-start"
              >
                {/* Dossier Header */}
                <div className="border-b-4 border-double border-slate-900 pb-4 text-center space-y-1">
                  <span className="text-[10px] tracking-widest text-slate-500 font-bold block uppercase">RESTRICTED FORENSIC SUMMARY</span>
                  <h1 className="text-lg font-bold uppercase tracking-tight text-slate-900">
                    EXECUTIVE SECURITY THREAT DOSSIER
                  </h1>
                  <div className="flex justify-between text-[9px] text-slate-500 pt-2 font-bold uppercase">
                    <span>INCIDENT ID: TR-${Math.floor(1000 + Math.random() * 9000)}-${new Date().getFullYear()}</span>
                    <span>GEN: {new Date().toISOString().split("T")[0]}</span>
                    <span>LEVEL: S-LEVEL 2</span>
                  </div>
                </div>

                {/* Meta details grid */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 border border-slate-200">
                  <div className="space-y-1">
                    <span className="text-[8px] text-slate-450 block uppercase font-bold">Investigating Node:</span>
                    <strong className="text-[10.5px] text-slate-800">SOC Investigator Command Console</strong>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[8px] text-slate-450 block uppercase font-bold">Scan Classification:</span>
                    <strong className="text-[10.5px] text-red-700">HIGH CONTRAST MALICIOUS DETECT</strong>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[8px] text-slate-450 block uppercase font-bold">Total Mapped IOCs:</span>
                    <strong className="text-[10.5px] text-slate-800">{parsedIocs.length} Indicators</strong>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[8px] text-slate-450 block uppercase font-bold">Critical Risk Index:</span>
                    <strong className="text-[10.5px] text-red-600">
                      {Math.round((parsedIocs.filter(i => i.reputation === "malicious").length / parsedIocs.length) * 100) || 0}% Threat Ratio
                    </strong>
                  </div>
                </div>

                {/* Sub totals bar */}
                <div className="space-y-2">
                  <h3 className="font-bold border-b border-slate-900 pb-1 uppercase text-slate-900 text-[11px]">
                    1. METRIC THREAT DISTRIBUTION
                  </h3>
                  <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
                    <div className="bg-red-50 p-2 border border-red-200">
                      <span className="text-red-700 font-bold block">{parsedIocs.filter(i => i.reputation === "malicious").length}</span>
                      <span className="text-[8px] text-red-600 uppercase">MALICIOUS</span>
                    </div>
                    <div className="bg-amber-50 p-2 border border-amber-200">
                      <span className="text-amber-700 font-bold block">{parsedIocs.filter(i => i.reputation === "suspicious").length}</span>
                      <span className="text-[8px] text-amber-600 uppercase">SUSPICIOUS</span>
                    </div>
                    <div className="bg-slate-100 p-2 border border-slate-200">
                      <span className="text-slate-700 font-bold block">{parsedIocs.filter(i => i.isPrivate).length}</span>
                      <span className="text-[8px] text-slate-500 uppercase">PRIVATE</span>
                    </div>
                    <div className="bg-emerald-50 p-2 border border-emerald-200">
                      <span className="text-emerald-700 font-bold block">{parsedIocs.filter(i => i.reputation === "clean").length}</span>
                      <span className="text-[8px] text-emerald-600 uppercase">CLEAN/EDGE</span>
                    </div>
                  </div>
                </div>

                {/* Indicators list table */}
                <div className="space-y-2">
                  <h3 className="font-bold border-b border-slate-900 pb-1 uppercase text-slate-900 text-[11px]">
                    2. VERIFIED INDICATORS LEDGER
                  </h3>
                  <table className="w-full text-left text-[10.5px] border-collapse">
                    <thead>
                      <tr className="border-b border-slate-900">
                        <th className="pb-1.5 pt-1.5 pr-2">INDICATOR SIGNATURE</th>
                        <th className="pb-1.5 pt-1.5 px-2">TYPE</th>
                        <th className="pb-1.5 pt-1.5 px-2">SCOPE</th>
                        <th className="pb-1.5 pt-1.5 text-right">REPUTATION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {parsedIocs.map((ioc, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2 pr-2 font-bold text-slate-900 word-break truncate max-w-[190px]" title={ioc.value}>
                            {ioc.value}
                          </td>
                          <td className="py-2 px-2 text-slate-500 uppercase">
                            {ioc.type}
                          </td>
                          <td className="py-2 px-2">
                            <span className="text-[9px] uppercase font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                              {ioc.isPrivate ? "Intranet" : "External"}
                            </span>
                          </td>
                          <td className="py-2 text-right font-bold">
                            <span className={
                              ioc.reputation === "malicious" ? "text-red-700 font-extrabold uppercase" :
                              ioc.reputation === "suspicious" ? "text-amber-700 uppercase" :
                              ioc.reputation === "clean" ? "text-emerald-700 uppercase" :
                              "text-slate-500 uppercase"
                            }>
                              {ioc.reputation}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Recommendations */}
                <div className="space-y-2 pt-2">
                  <h3 className="font-bold border-b border-slate-900 pb-1 uppercase text-slate-900 text-[11px]">
                    3. DEFENSIVE STRATEGIC RECOMMENDATIONS
                  </h3>
                  <ul className="list-disc list-inside space-y-1.5 text-slate-750 text-[10.5px]">
                    <li>
                      <strong>Immediate Blocking Vector</strong>: Submit the registered {parsedIocs.filter(i => i.reputation === "malicious").length} malicious targets directly to perimeter zone firewalls to choke active beacons.
                    </li>
                    <li>
                      <strong>Host-Level Logging audit:</strong> Cross-compare mapped {parsedIocs.filter(i => i.isPrivate).length} Private Host Subnet indicators with directory system logs to monitor internal hop trajectories.
                    </li>
                    <li>
                      <strong>Threat Hunt Verification:</strong> Run proactive credential rotate drills on machines displaying associated reputation signatures.
                    </li>
                  </ul>
                </div>

                {/* Signature signing blocks */}
                <div className="pt-8 border-t border-dashed border-slate-400 grid grid-cols-2 gap-8 text-[10px]">
                  <div className="space-y-4">
                    <div className="border-b border-slate-500 h-6"></div>
                    <span className="text-[9px] uppercase text-slate-500 font-bold">Prepared Signature Signoff</span>
                  </div>
                  <div className="space-y-4">
                    <div className="border-b border-slate-500 h-6 text-center text-slate-400 select-none font-bold">APPROVED SEC OPS</div>
                    <span className="text-[9px] uppercase text-slate-500 font-bold">Automated Audit Seal</span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
