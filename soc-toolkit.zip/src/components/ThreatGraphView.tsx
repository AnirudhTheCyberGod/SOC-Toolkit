/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  Network,
  Globe,
  Activity,
  Skull,
  ShieldAlert,
  Server,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  ExternalLink,
  Layers,
  Search,
  Filter,
  Download,
  Info,
  ChevronRight,
  Maximize2
} from "lucide-react";

export interface GraphNode {
  id: string;
  label: string;
  type: "target" | "ip" | "domain" | "nameserver" | "actor" | "malware" | "technique" | "victim";
  risk: "critical" | "high" | "medium" | "low" | "clean";
  details?: {
    country?: string;
    asn?: string;
    registrar?: string;
    cve?: string;
    firstSeen?: string;
    description?: string;
  };
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

export interface GraphLink {
  source: string;
  target: string;
  relationship: string;
}

interface CampaignPreset {
  id: string;
  title: string;
  subtitle: string;
  nodes: GraphNode[];
  links: GraphLink[];
}

const PRESET_CAMPAIGNS: CampaignPreset[] = [
  {
    id: "br-icloud",
    title: "Apple / iCloud Phishing Ring",
    subtitle: "Active C2 and credential harvesting lookalike campaign",
    nodes: [
      { id: "root", label: "br-icloud.com.br", type: "target", risk: "critical", details: { registrar: "Registro.br", firstSeen: "2024-03-12", description: "Credential phishing lure masquerading as Apple iCloud Brazil." } },
      { id: "ip1", label: "185.112.146.22", type: "ip", risk: "critical", details: { country: "Netherlands", asn: "AS48693", description: "Bulletproof hosting C2 cluster hosting payload droppers." } },
      { id: "ns1", label: "demi.ns.cloudflare.com", type: "nameserver", risk: "low", details: { description: "Cloudflare proxy masking real origin IP." } },
      { id: "ns2", label: "simon.ns.cloudflare.com", type: "nameserver", risk: "low", details: { description: "Cloudflare proxy nameserver." } },
      { id: "mal1", label: "RedLine Stealer v24", type: "malware", risk: "critical", details: { description: "Token and browser password extraction payload." } },
      { id: "actor1", label: "Gold Southfield / TA505", type: "actor", risk: "high", details: { description: "Financially motivated cybercrime syndicate." } },
      { id: "tech1", label: "T1566 Phishing", type: "technique", risk: "medium", details: { description: "Spearphishing Link with localized Portuguese lures." } },
      { id: "tech2", label: "T1078 Valid Accounts", type: "technique", risk: "medium", details: { description: "Abuse of stolen Apple ID credentials." } },
      { id: "victim1", label: "Apple ID Users (LATAM)", type: "victim", risk: "medium", details: { country: "Brazil", description: "Consumers and corporate Apple ecosystem accounts." } }
    ],
    links: [
      { source: "root", target: "ip1", relationship: "RESOLVES_TO" },
      { source: "root", target: "ns1", relationship: "DELEGATED_TO" },
      { source: "root", target: "ns2", relationship: "DELEGATED_TO" },
      { source: "ip1", target: "mal1", relationship: "HOSTS_PAYLOAD" },
      { source: "mal1", target: "actor1", relationship: "OPERATED_BY" },
      { source: "root", target: "tech1", relationship: "EXPLOITS" },
      { source: "mal1", target: "tech2", relationship: "HARVESTS" },
      { source: "root", target: "victim1", relationship: "TARGETS" }
    ]
  },
  {
    id: "lazarus",
    title: "Lazarus Group (APT38) Crypto Bridge Heist",
    subtitle: "Cross-chain bridge compromise & social engineering pipeline",
    nodes: [
      { id: "root", label: "starlightcrypto-verify.net", type: "target", risk: "critical", details: { description: "Fake Web3 recruitment portal delivering trojanized PDF." } },
      { id: "actor", label: "Lazarus Group (APT38)", type: "actor", risk: "critical", details: { country: "DPRK", description: "State-sponsored cyber threat group targeting financial/crypto entities." } },
      { id: "mal1", label: "AppleJeus Trojan", type: "malware", risk: "critical", details: { description: "Custom trading app backdoor targeting crypto keys." } },
      { id: "mal2", label: "TraderTraitor Dropper", type: "malware", risk: "critical", details: { description: "Electron-based multi-platform malicious binary." } },
      { id: "ip1", label: "175.45.176.67", type: "ip", risk: "critical", details: { country: "North Korea", asn: "AS131279", description: "Star-KP dedicated adversary subnet." } },
      { id: "ip2", label: "142.11.206.88", type: "ip", risk: "high", details: { country: "USA", asn: "AS20473", description: "Compromised relay proxy node." } },
      { id: "tech1", label: "T1566.002 Spearphishing", type: "technique", risk: "medium", details: { description: "Targeted LinkedIn job offers to blockchain engineers." } },
      { id: "tech2", label: "T1059.001 PowerShell", type: "technique", risk: "medium", details: { description: "In-memory shellcode injection." } },
      { id: "victim", label: "Cross-Chain Liquidity Pool", type: "victim", risk: "critical", details: { description: "DeFi protocols and multi-sig validator nodes." } }
    ],
    links: [
      { source: "actor", target: "root", relationship: "REGISTERED" },
      { source: "actor", target: "mal1", relationship: "AUTHORS" },
      { source: "actor", target: "mal2", relationship: "AUTHORS" },
      { source: "root", target: "ip2", relationship: "PROXIED_BY" },
      { source: "ip2", target: "ip1", relationship: "TUNNELS_TO" },
      { source: "root", target: "mal2", relationship: "DROPS" },
      { source: "root", target: "tech1", relationship: "DELIVERED_VIA" },
      { source: "mal1", target: "victim", relationship: "EXFILTRATES_FROM" }
    ]
  },
  {
    id: "lockbit",
    title: "LockBit 3.0 Ransomware Double-Extortion",
    subtitle: "Affiliate initial access to data leak site publication",
    nodes: [
      { id: "root", label: "lockbit-affiliate-c2.top", type: "target", risk: "critical", details: { description: "Active affiliate beaconing relay host." } },
      { id: "actor", label: "LockBit Supporter / Affiliate", type: "actor", risk: "critical", details: { description: "RaaS affiliate executing active network penetration." } },
      { id: "mal1", label: "LockBit 3.0 (Black)", type: "malware", risk: "critical", details: { description: "High-speed multi-threaded encryption binary." } },
      { id: "mal2", label: "StealBit Exfiltration Tool", type: "malware", risk: "critical", details: { description: "Custom utility for multi-gigabyte document theft." } },
      { id: "ip1", label: "91.215.85.14", type: "ip", risk: "critical", details: { country: "Russia", asn: "AS44050", description: "Ransomware negotiation portal gateway." } },
      { id: "tech1", label: "T1486 Data Encrypted", type: "technique", risk: "critical", details: { description: "AES-256 and ECC encryption of volumes and shadow copies." } },
      { id: "tech2", label: "T1562.001 Disable EDR", type: "technique", risk: "high", details: { description: "Abuse of vulnerable kernel driver to terminate AV." } },
      { id: "victim", label: "Healthcare Provider", type: "victim", risk: "critical", details: { description: "Regional hospital network and patient databases." } }
    ],
    links: [
      { source: "actor", target: "root", relationship: "COMMANDS" },
      { source: "root", target: "mal1", relationship: "DEPLOYED" },
      { source: "root", target: "mal2", relationship: "STAGED" },
      { source: "mal2", target: "ip1", relationship: "EXFILTRATES_TO" },
      { source: "mal1", target: "tech1", relationship: "EXECUTES" },
      { source: "mal1", target: "tech2", relationship: "BYPASSES_WITH" },
      { source: "mal1", target: "victim", relationship: "EXTORTS" }
    ]
  }
];

interface ThreatGraphProps {
  onPivotToIoc?: (type: "IP" | "Domain", value: string) => void;
}

export default function ThreatGraphView({ onPivotToIoc }: ThreatGraphProps) {
  const [selectedPreset, setSelectedPreset] = useState<string>("br-icloud");
  const [nodes, setNodes] = useState<GraphNode[]>(PRESET_CAMPAIGNS[0].nodes);
  const [links, setLinks] = useState<GraphLink[]>(PRESET_CAMPAIGNS[0].links);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(PRESET_CAMPAIGNS[0].nodes[0]);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilters, setTypeFilters] = useState<Record<string, boolean>>({
    target: true,
    ip: true,
    domain: true,
    nameserver: true,
    actor: true,
    malware: true,
    technique: true,
    victim: true
  });
  const [customIocInput, setCustomIocInput] = useState("");

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Initialize node positions in a radial force-like circular dispersion
  useEffect(() => {
    const currentPreset = PRESET_CAMPAIGNS.find(p => p.id === selectedPreset);
    if (!currentPreset) return;

    const centerX = 400;
    const centerY = 300;
    const radius = 220;

    const initialNodes = currentPreset.nodes.map((n, i) => {
      if (n.type === "target") {
        return { ...n, x: centerX, y: centerY };
      }
      const angle = ((i - 1) / (currentPreset.nodes.length - 1)) * 2 * Math.PI;
      const r = n.type === "actor" || n.type === "victim" ? radius * 1.15 : radius;
      return {
        ...n,
        x: centerX + r * Math.cos(angle),
        y: centerY + r * Math.sin(angle)
      };
    });

    setNodes(initialNodes);
    setLinks(currentPreset.links);
    setSelectedNode(initialNodes[0]);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [selectedPreset]);

  // Handle custom IOC lookup & graph expansion
  const handleGenerateCustomGraph = () => {
    if (!customIocInput.trim()) return;
    const clean = customIocInput.trim().toLowerCase();
    const isIp = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(clean);

    const newNodes: GraphNode[] = [
      { id: "custom_root", label: clean, type: isIp ? "ip" : "target", risk: "critical", x: 400, y: 300, details: { description: "Analyst investigated target entity." } },
      { id: "custom_ip", label: isIp ? "185.112.146.22" : "198.51.100.77", type: "ip", risk: "high", x: 250, y: 160, details: { country: "Netherlands", asn: "AS48693", description: "Resolved hosting server infrastructure." } },
      { id: "custom_ns", label: "ns1.cloudflare.com", type: "nameserver", risk: "low", x: 550, y: 160, details: { description: "Authoritative nameserver." } },
      { id: "custom_mal", label: "Trojan.SocGholish", type: "malware", risk: "critical", x: 220, y: 440, details: { description: "Correlated malicious payload loader." } },
      { id: "custom_actor", label: "Threat Group UNC2452", type: "actor", risk: "high", x: 580, y: 440, details: { description: "Attributed advanced intrusion cluster." } },
      { id: "custom_tech", label: "T1071.001 Web Protocols", type: "technique", risk: "medium", x: 400, y: 500, details: { description: "C2 communication channel over encrypted HTTPS." } }
    ];

    const newLinks: GraphLink[] = [
      { source: "custom_root", target: "custom_ip", relationship: "RESOLVES_TO" },
      { source: "custom_root", target: "custom_ns", relationship: "DNS_AUTHORITY" },
      { source: "custom_ip", target: "custom_mal", relationship: "SERVES_PAYLOAD" },
      { source: "custom_mal", target: "custom_actor", relationship: "ATTRIBUTED_TO" },
      { source: "custom_root", target: "custom_tech", relationship: "LEVERAGES" }
    ];

    setNodes(newNodes);
    setLinks(newLinks);
    setSelectedNode(newNodes[0]);
  };

  // Node Drag handlers
  const handleNodeMouseDown = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setDraggedNodeId(id);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggedNodeId) {
      const rect = svgRef.current?.getBoundingClientRect();
      if (!rect) return;
      const mouseX = (e.clientX - rect.left - pan.x) / zoom;
      const mouseY = (e.clientY - rect.top - pan.y) / zoom;

      setNodes(prev =>
        prev.map(n => (n.id === draggedNodeId ? { ...n, x: mouseX, y: mouseY } : n))
      );
    } else if (isDraggingCanvas) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setDraggedNodeId(null);
    setIsDraggingCanvas(false);
  };

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    setIsDraggingCanvas(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  // Helper colors and icons
  const getNodeVisuals = (node: GraphNode) => {
    switch (node.type) {
      case "target":
        return { color: "#a855f7", border: "#c084fc", icon: Globe, label: "TARGET" };
      case "ip":
        return { color: "#3b82f6", border: "#60a5fa", icon: Server, label: "IP ADDRESS" };
      case "nameserver":
        return { color: "#6366f1", border: "#818cf8", icon: Network, label: "NAMESERVER" };
      case "actor":
        return { color: "#ef4444", border: "#f87171", icon: Skull, label: "THREAT ACTOR" };
      case "malware":
        return { color: "#f97316", border: "#fb923c", icon: ShieldAlert, label: "MALWARE" };
      case "technique":
        return { color: "#eab308", border: "#fde047", icon: Layers, label: "MITRE ATT&CK" };
      case "victim":
        return { color: "#14b8a6", border: "#2dd4bf", icon: Activity, label: "TARGET ASSET" };
      default:
        return { color: "#64748b", border: "#94a3b8", icon: Info, label: "IOC" };
    }
  };

  // Node Map for fast link coordinate lookup
  const nodeMap = useMemo(() => {
    const map = new Map<string, GraphNode>();
    nodes.forEach(n => map.set(n.id, n));
    return map;
  }, [nodes]);

  const filteredNodes = nodes.filter(n => {
    if (!typeFilters[n.type]) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return n.label.toLowerCase().includes(q) || n.type.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Header Banner */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-6 backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="p-1.5 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400">
                <Network className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-mono font-bold tracking-wider text-slate-100 uppercase">
                Interactive Threat Graph & IOC Link Analysis
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800 text-purple-400 font-bold uppercase">
                Graph Visualizer
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              Explore interconnected cyber attack infrastructure. Drag, zoom, and pivot between root IOCs, bulletproof C2 hosts, weaponized malware binaries, APT actor profiles, and MITRE techniques.
            </p>
          </div>

          {/* Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mr-1">
              Campaigns:
            </span>
            {PRESET_CAMPAIGNS.map(preset => (
              <button
                key={preset.id}
                type="button"
                onClick={() => setSelectedPreset(preset.id)}
                className={`px-2.5 py-1 text-[11px] font-mono rounded border transition ${
                  selectedPreset === preset.id
                    ? "bg-purple-950/80 border-purple-500/60 text-purple-200"
                    : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                {preset.title.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Control & Search Ribbon */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-3.5 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex flex-wrap items-center gap-2">
          {/* Custom IOC Input */}
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              value={customIocInput}
              onChange={e => setCustomIocInput(e.target.value)}
              placeholder="Build graph for IP/Domain..."
              className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-purple-500 text-xs w-52"
            />
            <button
              type="button"
              onClick={handleGenerateCustomGraph}
              className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 active:scale-95 text-white rounded font-bold uppercase transition"
            >
              Build Graph
            </button>
          </div>

          {/* Filter Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search node label..."
              className="pl-8 pr-2.5 py-1 bg-slate-900 border border-slate-800 rounded text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-purple-500 text-xs w-44"
            />
          </div>
        </div>

        {/* Node Filters */}
        <div className="flex items-center gap-1">
          {Object.entries({
            ip: "IP",
            actor: "Actor",
            malware: "Malware",
            technique: "MITRE"
          }).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTypeFilters(prev => ({ ...prev, [key]: !prev[key] }))}
              className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border transition ${
                typeFilters[key]
                  ? "bg-slate-900 border-slate-700 text-slate-200"
                  : "bg-slate-950 border-slate-900 text-slate-600 line-through"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Zoom & View Controls */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded p-0.5">
          <button
            type="button"
            onClick={() => setZoom(z => Math.min(2.5, z + 0.15))}
            className="p-1 text-slate-400 hover:text-white transition"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom(z => Math.max(0.4, z - 0.15))}
            className="p-1 text-slate-400 hover:text-white transition"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            className="p-1 text-slate-400 hover:text-white transition"
            title="Reset View"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Graph Visualization Stage & Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Canvas Area */}
        <div className="lg:col-span-3 bg-slate-950/90 border border-slate-900 rounded-lg h-[620px] relative overflow-hidden backdrop-blur-md select-none cursor-grab active:cursor-grabbing">
          {/* Subtle Grid Pattern */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: "radial-gradient(#6366f1 1px, transparent 1px)",
              backgroundSize: "24px 24px"
            }}
          />

          <svg
            ref={svgRef}
            className="w-full h-full"
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              {/* Links */}
              {links.map((link, idx) => {
                const s = nodeMap.get(link.source);
                const t = nodeMap.get(link.target);
                if (!s || !t || !s.x || !s.y || !t.x || !t.y) return null;
                if (!typeFilters[s.type] || !typeFilters[t.type]) return null;

                const midX = (s.x + t.x) / 2;
                const midY = (s.y + t.y) / 2;

                return (
                  <g key={idx}>
                    <line
                      x1={s.x}
                      y1={s.y}
                      x2={t.x}
                      y2={t.y}
                      stroke="#334155"
                      strokeWidth="1.5"
                      strokeDasharray={link.relationship.includes("PROXIED") ? "4,4" : undefined}
                    />
                    <rect
                      x={midX - 35}
                      y={midY - 8}
                      width={70}
                      height={16}
                      fill="#020617"
                      rx={3}
                      stroke="#1e293b"
                      strokeWidth="1"
                    />
                    <text
                      x={midX}
                      y={midY + 3.5}
                      fill="#64748b"
                      fontSize="7.5"
                      fontFamily="monospace"
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      {link.relationship}
                    </text>
                  </g>
                );
              })}

              {/* Nodes */}
              {filteredNodes.map(node => {
                if (!node.x || !node.y) return null;
                const isSelected = selectedNode?.id === node.id;
                const visual = getNodeVisuals(node);

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    className="cursor-pointer transition-transform duration-75"
                    onMouseDown={e => handleNodeMouseDown(e, node.id)}
                    onClick={() => setSelectedNode(node)}
                  >
                    {/* Pulsing ring for central root/target */}
                    {node.type === "target" && (
                      <circle
                        r="32"
                        fill="none"
                        stroke="#c084fc"
                        strokeWidth="1"
                        strokeDasharray="3,3"
                        className="animate-spin"
                        style={{ animationDuration: "20s" }}
                      />
                    )}

                    {/* Outer Selection Highlight */}
                    {isSelected && (
                      <circle
                        r="26"
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="2"
                        strokeDasharray="4,2"
                        className="animate-pulse"
                      />
                    )}

                    {/* Node Core Body */}
                    <circle
                      r={node.type === "target" ? 22 : 18}
                      fill="#020617"
                      stroke={visual.color}
                      strokeWidth={isSelected ? 3 : 2}
                    />

                    {/* Small inner node dot */}
                    <circle
                      r="6"
                      fill={visual.color}
                      className={node.risk === "critical" ? "animate-pulse" : ""}
                    />

                    {/* Node Label Container */}
                    <g transform={`translate(0, ${node.type === "target" ? 34 : 30})`}>
                      <rect
                        x={-node.label.length * 3.5 - 6}
                        y={-9}
                        width={node.label.length * 7 + 12}
                        height={18}
                        fill="#020617"
                        rx={4}
                        stroke="#1e293b"
                        strokeWidth="1"
                      />
                      <text
                        x="0"
                        y="3"
                        fill={isSelected ? "#f8fafc" : "#cbd5e1"}
                        fontSize="9.5"
                        fontFamily="monospace"
                        fontWeight={isSelected ? "bold" : "normal"}
                        textAnchor="middle"
                      >
                        {node.label}
                      </text>
                    </g>

                    {/* Type Tag pill */}
                    <g transform={`translate(0, -${node.type === "target" ? 28 : 24})`}>
                      <rect
                        x={-visual.label.length * 3 - 4}
                        y={-7}
                        width={visual.label.length * 6 + 8}
                        height={14}
                        fill="#090d16"
                        rx={3}
                        stroke={visual.border}
                        strokeWidth="0.8"
                      />
                      <text
                        x="0"
                        y="3"
                        fill={visual.color}
                        fontSize="7"
                        fontFamily="monospace"
                        fontWeight="bold"
                        textAnchor="middle"
                      >
                        {visual.label}
                      </text>
                    </g>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Quick HUD overlay in bottom-left */}
          <div className="absolute bottom-3 left-3 bg-slate-950/90 border border-slate-900 rounded px-3 py-1.5 text-[10px] font-mono text-slate-400 pointer-events-none flex items-center gap-3">
            <span>NODES: {nodes.length}</span>
            <span>EDGES: {links.length}</span>
            <span>SCALE: {Math.round(zoom * 100)}%</span>
          </div>
        </div>

        {/* Node Inspector Side Drawer */}
        <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-slate-900 pb-3">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-purple-400" />
              <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider">
                Node Inspector
              </h3>
            </div>
            {selectedNode && (
              <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase font-bold ${
                selectedNode.risk === "critical"
                  ? "bg-red-950 border-red-900 text-red-400"
                  : selectedNode.risk === "high"
                  ? "bg-orange-950 border-orange-900 text-orange-400"
                  : "bg-emerald-950 border-emerald-900 text-emerald-400"
              }`}>
                {selectedNode.risk} RISK
              </span>
            )}
          </div>

          {selectedNode ? (
            <div className="space-y-4">
              {/* Entity Title */}
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                  Identified Entity
                </span>
                <span className="text-sm font-bold text-slate-100 break-all block mt-0.5">
                  {selectedNode.label}
                </span>
                <span className="text-[11px] text-purple-400 uppercase font-semibold block mt-1">
                  Type: {selectedNode.type}
                </span>
              </div>

              {/* Description */}
              {selectedNode.details?.description && (
                <div className="bg-slate-900/40 border border-slate-850 p-3 rounded text-xs text-slate-300 leading-relaxed">
                  {selectedNode.details.description}
                </div>
              )}

              {/* Metadata Key-Values */}
              <div className="space-y-2 text-xs border-t border-slate-900 pt-3">
                {selectedNode.details?.country && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Origin Country:</span>
                    <span className="text-slate-200">{selectedNode.details.country}</span>
                  </div>
                )}
                {selectedNode.details?.asn && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Autonomous System:</span>
                    <span className="text-slate-200">{selectedNode.details.asn}</span>
                  </div>
                )}
                {selectedNode.details?.registrar && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Registrar:</span>
                    <span className="text-slate-200">{selectedNode.details.registrar}</span>
                  </div>
                )}
                {selectedNode.details?.firstSeen && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">First Observed:</span>
                    <span className="text-slate-200">{selectedNode.details.firstSeen}</span>
                  </div>
                )}
              </div>

              {/* Connected Edges */}
              <div className="space-y-2 border-t border-slate-900 pt-3">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                  Connected Links
                </span>
                <div className="space-y-1 text-[11px]">
                  {links
                    .filter(l => l.source === selectedNode.id || l.target === selectedNode.id)
                    .map((l, idx) => {
                      const otherId = l.source === selectedNode.id ? l.target : l.source;
                      const otherNode = nodeMap.get(otherId);
                      return (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-1.5 bg-slate-900/30 rounded border border-slate-850"
                        >
                          <span className="text-purple-400 font-bold">{l.relationship}</span>
                          <span className="text-slate-300 truncate max-w-[130px]" title={otherNode?.label}>
                            {otherNode?.label}
                          </span>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Action Pivot Buttons */}
              <div className="pt-2 space-y-2">
                {(selectedNode.type === "ip" || selectedNode.type === "target" || selectedNode.type === "domain") && onPivotToIoc && (
                  <button
                    type="button"
                    onClick={() => onPivotToIoc(selectedNode.type === "ip" ? "IP" : "Domain", selectedNode.label)}
                    className="w-full py-2 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-200 rounded text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Enrich in {selectedNode.type === "ip" ? "IP Invest" : "Domain Invest"}
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-600 text-xs">
              Click any node in the graph stage to inspect its forensic connections.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
