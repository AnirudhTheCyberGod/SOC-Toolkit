/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ActiveTab } from "../types";
import {
  LayoutDashboard,
  ShieldAlert,
  Terminal,
  Activity,
  Globe,
  Link2,
  Hash,
  UploadCloud,
  Mail,
  Skull,
  Compass,
  Newspaper,
  CalendarDays,
  Grid,
  Zap,
  FileCode2,
  Settings,
  ShieldCheck,
  AlertCircle,
  Camera,
  Cpu,
  Radio,
  Network,
  BookOpen,
  Binary,
  ListFilter,
  Sparkles,
  X,
  Equal,
  FileText,
  FileCheck
} from "lucide-react";

interface SidebarProps {
  currentTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  isOpen: boolean;
  isOpenOnMobile?: boolean;
  onToggle?: () => void;
  onCloseMobile?: () => void;
}

export default function Sidebar({
  currentTab,
  onTabChange,
  isOpen,
  isOpenOnMobile = false,
  onToggle,
  onCloseMobile
}: SidebarProps) {
  const navItems = [
    { id: ActiveTab.Dashboard, label: "Dashboard", icon: LayoutDashboard },
    { id: ActiveTab.LogAnalyzer, label: "AI Log Analyzer & Timeline", icon: FileText, badge: "AI", highlight: true },
    { id: ActiveTab.ThreatGraph, label: "Interactive Threat Graph", icon: Network, badge: "Graph", highlight: true },
    { id: ActiveTab.ThreatIntel, label: "Threat Intelligence & Feeds", icon: ShieldAlert, badge: "Bleeping+CISA", highlight: true },
    { id: ActiveTab.IOCInvestigator, label: "Multiple IOC Investigator", icon: ListFilter, badge: "Mass" },
    { id: ActiveTab.Whois, label: "WHOIS Terminal", icon: Terminal },
    { id: ActiveTab.IPInvest, label: "IP Investigation", icon: Activity },
    { id: ActiveTab.DomainInvest, label: "Domain Investigation", icon: Globe },
    { id: ActiveTab.URLAnalysis, label: "URL Analysis", icon: Link2 },
    { id: ActiveTab.Homograph, label: "Homograph & Typosquatting", icon: Globe, badge: "DNS" },
    { id: ActiveTab.IncidentReport, label: "Incident Report Exporter", icon: FileCheck, badge: "DFIR", highlight: true },
    { id: ActiveTab.AsnSsl, label: "ASN & SSL Diagnostics", icon: Network, badge: "New" },
    { id: ActiveTab.UrlScreenshot, label: "URL Sandbox Screenshot", icon: Camera, badge: "New" },
    { id: ActiveTab.HashAnalysis, label: "Hash Analysis", icon: Hash },
    { id: ActiveTab.FileAnalysis, label: "File Upload Sandbox", icon: UploadCloud, badge: "New" },
    { id: ActiveTab.HeaderAnalysis, label: "Email Header Analyzer", icon: Mail, badge: "New" },
    { id: ActiveTab.MalwareAnalysis, label: "Malware Analysis", icon: Skull },
    { id: ActiveTab.OsintHub, label: "OSINT Hub", icon: Compass },
    { id: ActiveTab.EventIdEncyclopedia, label: "Windows Event ID", icon: BookOpen, badge: "Docs" },
    { id: ActiveTab.PortLookup, label: "Protocol Port Lookup", icon: Binary, badge: "Tool" },
    { id: ActiveTab.Ransomware, label: "Ransomware Intel", icon: CalendarDays },
    { id: ActiveTab.Mitre, label: "MITRE ATT&CK", icon: Grid },
    { id: ActiveTab.KqlPlayground, label: "KQL Threat Hunt Generator", icon: FileCode2, badge: "TI Linked", highlight: true },
    { id: ActiveTab.Utilities, label: "SOC Utilities", icon: Zap },
    { id: ActiveTab.MacLookup, label: "MAC Address Resolver", icon: Cpu, badge: "New" },
    { id: ActiveTab.SIEM, label: "SIEM Agent Integration", icon: Radio, badge: "Agent" },
    { id: ActiveTab.AICommandInterpreter, label: "AI Command Interpreter", icon: Sparkles, badge: "AI", highlight: true },
    { id: ActiveTab.Settings, label: "Settings", icon: Settings }
  ];

  return (
    <aside
      id="soc-sidebar"
      className={`fixed md:sticky top-0 left-0 z-50 md:z-30 h-screen select-none bg-slate-950/95 md:bg-slate-950/80 backdrop-blur-md border-r border-slate-900 text-slate-200 transition-all duration-300 ease-in-out ${
        isOpen
          ? "w-64 translate-x-0 opacity-100"
          : "w-0 -translate-x-full md:w-0 md:opacity-0 md:pointer-events-none md:border-r-0"
      } ${
        isOpenOnMobile ? "!w-64 !translate-x-0 !opacity-100 !pointer-events-auto" : ""
      }`}
    >
      <div className="w-64 h-full flex flex-col overflow-y-auto overflow-x-hidden">
        {/* Brand Header - Aligned height h-14 with main window header */}
        <div className="h-14 px-4 border-b border-slate-900 flex items-center justify-between gap-2 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="bg-red-500/10 p-1.5 rounded border border-red-500/30 shrink-0">
              <ShieldCheck className="w-5 h-5 text-red-500" />
            </div>
            <div className="truncate">
              <h1 className="font-mono text-xs sm:text-sm font-bold tracking-widest text-slate-100 uppercase truncate">
                ThreatNexus
              </h1>
              <span className="text-[9px] font-mono text-red-400 uppercase tracking-wider block -mt-0.5">
                SOC SUITE
              </span>
            </div>
          </div>
          
          {/* '=' Toggle button inside Sidebar */}
          <button
            type="button"
            onClick={onToggle || onCloseMobile}
            className="p-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-100 transition-all duration-150 active:scale-95 cursor-pointer flex items-center justify-center shrink-0"
            title="Toggle sidebar (=)"
            aria-label="Toggle sidebar"
          >
            <Equal className="w-4 h-4 text-red-400 stroke-[2.5]" />
          </button>
        </div>

        {/* Network Status banner */}
        <div className="px-4 py-2 border-b border-slate-900 bg-slate-900/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[10px] font-mono text-emerald-400 tracking-wider">
              AGENT CONNECTED
            </span>
          </div>
          <AlertCircle className="w-3.5 h-3.5 text-slate-600 hover:text-slate-400 cursor-pointer" />
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => {
                  onTabChange(item.id);
                  onCloseMobile?.();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded font-mono text-xs text-left tracking-tight transition-all duration-150 group cursor-pointer ${
                  isActive
                    ? "bg-red-600/12 text-red-400 font-medium border-l-2 border-red-500 pl-2.5 shadow-inner"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
                }`}
              >
                <div className="flex items-center gap-3">
                  <IconComponent
                    className={`w-4 h-4 transition-transform duration-200 group-hover:scale-105 ${
                      isActive ? "text-red-500" : "text-slate-500 group-hover:text-slate-400"
                    }`}
                  />
                  <span className={item.highlight ? "text-emerald-400/90" : ""}>
                    {item.label}
                  </span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-red-950 text-red-400 border border-red-500/30 tracking-widest uppercase">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="p-4 border-t border-slate-900 bg-slate-950/40 font-mono text-[10px] text-slate-500 flex flex-col gap-1 shrink-0">
          <div className="flex justify-between items-center">
            <span>ROLE:</span>
            <span className="text-slate-300 font-semibold text-[9px] bg-slate-900 px-1 py-0.5 rounded border border-slate-800">
              SEC_ENGINEER
            </span>
          </div>
          <div className="flex justify-between">
            <span>HOST:</span>
            <span className="text-slate-400">SOC_TOOL_CLI</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
