/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { MitreTechnique } from "../types";
import { 
  Search, 
  Grid, 
  HelpCircle, 
  Layers, 
  ShieldAlert, 
  Settings, 
  Loader2, 
  RefreshCw, 
  SlidersHorizontal, 
  Cpu, 
  BookOpen, 
  Terminal, 
  Code, 
  Flame, 
  CheckSquare, 
  Globe, 
  ExternalLink, 
  ChevronDown, 
  ChevronRight, 
  Sparkles, 
  Filter, 
  Activity,
  AlertTriangle,
  PlaySquare,
  Sparkle
} from "lucide-react";

interface MitreSyncStatus {
  status: "idle" | "downloading";
  count: number;
  lastDownloaded: string;
  error: string | null;
}

export default function MitreView() {
  const [techniques, setTechniques] = useState<MitreTechnique[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Filtering & Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTactic, setSelectedTactic] = useState<string>("ALL");
  const [selectedPlatform, setSelectedPlatform] = useState<string>("ALL");
  const [showSubtechniques, setShowSubtechniques] = useState<boolean>(true);
  
  // Analysis Sidebar Workbench state
  const [selectedTech, setSelectedTech] = useState<MitreTechnique | null>(null);
  const [activeTab, setActiveTab] = useState<"intel" | "hunting" | "detection" | "response">("intel");
  
  // Local cache status tracker
  const [syncStatus, setSyncStatus] = useState<MitreSyncStatus>({
    status: "idle",
    count: 0,
    lastDownloaded: "",
    error: null
  });
  const [syncLoading, setSyncLoading] = useState(false);

  // Load techniques + status on mount
  const loadDatasetData = async () => {
    setLoading(true);
    try {
      const resp = await fetch("/api/mitre");
      if (resp.ok) {
        const data = await resp.json();
        setTechniques(data);

        // Also fetch initial selected technique if empty
        if (data.length > 0 && !selectedTech) {
          const defaultTech = data.find((t: MitreTechnique) => t.id === "T1059" || t.id === "T1078") || data[0];
          setSelectedTech(defaultTech);
        }
      }
    } catch (err) {
      console.error("MITRE load failed:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadSyncStatus = async () => {
    try {
      const resp = await fetch("/api/mitre/status");
      if (resp.ok) {
        setSyncStatus(await resp.json());
      }
    } catch (err) {
      console.error("MITRE status fetch failed:", err);
    }
  };

  useEffect(() => {
    loadDatasetData();
    loadSyncStatus();

    // Set up periodic status sync if background downloading is active
    const interval = setInterval(() => {
      loadSyncStatus();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const triggerCacheRefresh = async () => {
    setSyncLoading(true);
    try {
      const resp = await fetch("/api/mitre/refresh", { method: "POST" });
      if (resp.ok) {
        loadSyncStatus();
        // Delay and reload dataset
        setTimeout(() => {
          loadDatasetData();
        }, 1500);
      }
    } catch (err) {
      console.error("Trigger cache reload failed:", err);
    } finally {
      setSyncLoading(false);
    }
  };

  // Unique Tactics list compiled dynamically or mapped to standard framework sequence
  const tacticsHierarchy = [
    "Reconnaissance",
    "Resource Development",
    "Initial Access",
    "Execution",
    "Persistence",
    "Privilege Escalation",
    "Defense Evasion",
    "Credential Access",
    "Discovery",
    "Lateral Movement",
    "Collection",
    "Command and Control",
    "Exfiltration",
    "Impact"
  ];

  // Dynamic Platforms filter compiler
  const platformOptions = ["ALL", "Windows", "Linux", "macOS", "Containers", "SaaS", "AWS", "Azure", "GCP", "Office 365"];

  // Filter & Search compiler
  const getFilteredTechniques = () => {
    return techniques.filter(tech => {
      // 1. Search Query mapping (ID, Name, Tactic, Threat Actor, Malware)
      if (searchQuery.trim() !== "") {
        const query = searchQuery.toLowerCase().trim();
        const matchesId = tech.id.toLowerCase().includes(query);
        const matchesName = tech.name.toLowerCase().includes(query);
        const matchesTactic = tech.tactics?.some(t => t.toLowerCase().includes(query)) || (tech.tactic && tech.tactic.toLowerCase().includes(query));
        const matchesActors = tech.threatActors?.some(a => a.name.toLowerCase().includes(query) || a.id.toLowerCase().includes(query)) || tech.threatGroups?.some(g => g.toLowerCase().includes(query));
        const matchesMalware = tech.malware?.some(m => m.name.toLowerCase().includes(query) || m.id.toLowerCase().includes(query));
        
        if (!matchesId && !matchesName && !matchesTactic && !matchesActors && !matchesMalware) {
          return false;
        }
      }

      // 2. Tactics mapping
      if (selectedTactic !== "ALL") {
        const matchesTactic = tech.tactics?.some(t => t.toLowerCase() === selectedTactic.toLowerCase()) || (tech.tactic && tech.tactic.toLowerCase() === selectedTactic.toLowerCase());
        if (!matchesTactic) return false;
      }

      // 3. Platforms mapping
      if (selectedPlatform !== "ALL") {
        const matchesPlatform = tech.platforms?.some(p => p.toLowerCase().includes(selectedPlatform.toLowerCase())) || tech.platforms === undefined;
        if (!matchesPlatform) return false;
      }

      // 4. Sub-techniques toggle mapping
      if (!showSubtechniques && tech.isSubtechnique) {
        return false;
      }

      return true;
    });
  };

  const filteredList = getFilteredTechniques();

  // Dynamic generators for hunters & engineers
  const kqlQuery = selectedTech ? generateKqlQuery(selectedTech) : "";
  const splQuery = selectedTech ? generateSplQuery(selectedTech) : "";
  const sigmaRule = selectedTech ? generateSigmaRule(selectedTech) : "";

  function generateKqlQuery(tech: MitreTechnique): string {
    const code = tech.id;
    const name = tech.name.toLowerCase();
    
    if (code.startsWith("T1059")) {
      return `DeviceProcessEvents
| where ProcessCommandLine has_any ("powershell", "-ep bypass", "encodedcommand", "iex", "Invoke-")
| where InitiatingProcessFileName != "sensg.exe"
| project Timestamp, DeviceName, AccountName, ProcessCommandLine, FolderPath`;
    }
    if (code.startsWith("T1003")) {
      return `DeviceProcessEvents
| where ProcessCommandLine has "lsass" or FolderPath has "lsass.exe"
| where FileName in~ ("rundll32.exe", "procdump.exe")
| project Timestamp, DeviceName, AccountName, FileName, ProcessCommandLine`;
    }
    if (code.startsWith("T1078")) {
      return `IdentityLogonEvents
| where LogonType in ("Interactive", "RemoteInteractive")
| where AccountName in~ ("administrator", "root", "admin")
| summarize LogonCount = count() by AccountName, IPAddress, DeviceName`;
    }
    if (code.startsWith("T1566")) {
      return `EmailEvents
| where MalwareFilterVerdict == "Suspicious" or AttachmentCount > 0
| where SenderMailFromAddress has_any (".xyz", ".icu", ".top")
| project Timestamp, SenderMailFromAddress, RecipientEmailAddress, Subject`;
    }
    
    return `// KQL hunt filter for ${tech.name} (${tech.id})
DeviceProcessEvents
| where ProcessCommandLine has_any ("${name}", "${tech.id}")
  or FileName has_any ("${tech.id.toLowerCase()}")
| project Timestamp, DeviceName, AccountName, ProcessCommandLine, FolderPath, InitiatingProcessCommandLine
| limit 100`;
  }

  function generateSplQuery(tech: MitreTechnique): string {
    const code = tech.id;
    const name = tech.name.toLowerCase();
    
    if (code.startsWith("T1059")) {
      return `index=security sourcetype=WinEventLog:Security EventCode=4688 
(CommandLine="*powershell*" OR CommandLine="*-ep bypass*" OR CommandLine="*-encodedcommand*")
| table _time, host, user, CommandLine, ParentProcessName`;
    }
    if (code.startsWith("T1003")) {
      return `index=security sourcetype=WinEventLog:Security EventCode=4688 
(CommandLine="*lsass*" OR Image="*procdump*" OR Image="*rundll32.exe*")
| table _time, host, user, Image, CommandLine`;
    }
    if (code.startsWith("T1078")) {
      return `index=security sourcetype=WinEventLog:Security EventCode=4624 
(Logon_Type=2 OR Logon_Type=10) Account_Name IN ("administrator", "admin", "root")
| stats count by Account_Name, Source_Network_Address, host`;
    }
    if (code.startsWith("T1566")) {
      return `index=email sourcetype=m365:email (verdict="malicious" OR attachment_count>0)
| table _time, sender, recipient, subject, attachment_names`;
    }
    
    return `index=security sourcetype=WinEventLog:Security EventCode=4688 
(CommandLine="*${name}*" OR CommandLine="*${tech.id}*")
| table _time, host, user, CommandLine, ParentProcessName, Image`;
  }

  function generateSigmaRule(tech: MitreTechnique): string {
    const currentYear = new Date().getFullYear();
    const title = `Suspect Activity Matching ${tech.name}`;
    const ruleId = `sigma-${tech.id.toLowerCase()}-${Math.floor(Math.random() * 89999 + 10000)}`;
    
    return `title: ${title}
id: ${ruleId}
status: experimental
description: Detects command usage and system indicators mapped to ${tech.name} (${tech.id}).
references:
  - https://attack.mitre.org/techniques/${tech.id}
author: SOC Analyst Engine
date: ${currentYear}/06/17
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    CommandLine|contains:
      - '${tech.id}'
      - '${tech.name.toLowerCase()}'
  condition: selection
falsepositives:
  - Admin scripted updates and telemetry diagnostics
level: medium
tags:
  - attack.${tech.id.toLowerCase()}`;
}

  // Handle local state task checkmarks
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});
  const toggleCheckbox = (taskKey: string) => {
    setChecklist(prev => ({ ...prev, [taskKey]: !prev[taskKey] }));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Cache Sync Indicator */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Grid className="w-5 h-5 text-red-500" />
            <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase">
              MITRE ATT&CK FORENSICS EXPLORER
            </h2>
            <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded flex items-center gap-1">
              <Sparkles className="w-3" />
              STIX Real-Time Engine Active
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono leading-relaxed max-w-2xl">
            Query and pivot the entire Enterprise ATT&CK matrix locally. Align alerts to adversary tactics (TTP), create dynamic Sigma detection rules, and generate hunt playbooks.
          </p>
        </div>

        {/* Sync Status block */}
        <div className="bg-slate-950 p-3 border border-slate-900 rounded font-mono text-[11px] flex flex-col gap-1 shrink-0 md:min-w-64">
          <div className="flex justify-between items-center text-slate-400 border-b border-slate-900 pb-1 mb-1 font-bold">
            <span>STIX DATA REPOSITORY</span>
            <span className={`h-2 w-2 rounded-full ${syncStatus.status === "downloading" ? "bg-amber-500 animate-ping" : "bg-emerald-500"}`}></span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-550">Cache Status:</span>
            <span className={syncStatus.status === "downloading" ? "text-amber-400 font-bold" : "text-emerald-400 font-bold"}>
              {syncStatus.status === "downloading" ? "SYNCING..." : "CONNECTED"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-550">Cached Techs:</span>
            <span className="text-slate-200 font-bold">{syncStatus.count || "Prebuilt List"}</span>
          </div>
          <div className="flex justify-between mb-1.5">
            <span className="text-slate-550">Last Update:</span>
            <span className="text-slate-400 font-bold text-[10px] truncate max-w-36">
              {syncStatus.lastDownloaded ? new Date(syncStatus.lastDownloaded).toLocaleDateString() : "Online Initializer"}
            </span>
          </div>

          <button
            onClick={triggerCacheRefresh}
            disabled={syncStatus.status === "downloading" || syncLoading}
            className="w-full bg-slate-900 hover:bg-red-950/20 text-slate-300 hover:text-red-400 border border-slate-800 hover:border-red-500/30 py-1 rounded text-[10px] uppercase font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            {syncStatus.status === "downloading" ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-500" />
                <span>Downloading CTI 50MB...</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3 h-3 text-red-400" />
                <span>Force ATT&CK Re-sync</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Advanced Filter and Control Console */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
        <div className="flex flex-col lg:flex-row gap-3">
          {/* Main Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
            <input
              id="mitre-workbench-search"
              type="text"
              placeholder="Search by ID, name, code, tactics, known malware, or threat group (e.g. Cobalt Strike, APT29, Credentials)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-9 pr-4 py-2.5 text-xs font-mono text-slate-202 placeholder-slate-650"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-2 text-xs font-mono text-slate-500 hover:text-red-400"
              >
                CLEAR
              </button>
            )}
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap gap-2.5 items-center">
            {/* Tactic dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-955 p-1.5 border border-slate-900 rounded">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">TACTIC:</span>
              <select
                id="tactic-filter-select"
                value={selectedTactic}
                onChange={(e) => setSelectedTactic(e.target.value)}
                className="bg-slate-950 text-slate-300 font-mono text-[10px] focus:outline-none focus:text-red-400"
              >
                <option value="ALL">ALL TTPs</option>
                {tacticsHierarchy.map(tac => (
                  <option key={tac} value={tac}>{tac}</option>
                ))}
              </select>
            </div>

            {/* Platform dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-955 p-1.5 border border-slate-900 rounded">
              <Cpu className="w-3.5 h-3.5 text-slate-500" />
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">PLATFORM:</span>
              <select
                id="platform-filter-select"
                value={selectedPlatform}
                onChange={(e) => setSelectedPlatform(e.target.value)}
                className="bg-slate-950 text-slate-300 font-mono text-[10px] focus:outline-none focus:text-red-400"
              >
                {platformOptions.map(plat => (
                  <option key={plat} value={plat}>{plat}</option>
                ))}
              </select>
            </div>

            {/* Sub-techniques Toggle */}
            <button
              onClick={() => setShowSubtechniques(!showSubtechniques)}
              className={`px-3 py-1.5 rounded font-mono text-[10px] font-bold border transition cursor-pointer flex items-center gap-1.5 ${
                showSubtechniques
                  ? "bg-red-950/20 text-red-400 border-red-500/30"
                  : "bg-slate-900 text-slate-500 border-slate-800"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>SUB-TECHNIQUES: {showSubtechniques ? "SHOWN" : "HIDDEN"}</span>
            </button>
          </div>
        </div>

        {/* Dynamic Filters Metadata details */}
        {selectedTactic !== "ALL" || selectedPlatform !== "ALL" || searchQuery || !showSubtechniques ? (
          <div className="bg-slate-950 px-3 py-1.5 border border-slate-900 rounded font-mono text-[11px] text-slate-450 flex flex-wrap items-center gap-2">
            <span className="text-red-400 font-bold uppercase text-[10px]">Active Filters:</span>
            {searchQuery && <span className="bg-slate-900 text-slate-300 border border-slate-850 px-2 py-0.5 rounded">Query: &quot;{searchQuery}&quot;</span>}
            {selectedTactic !== "ALL" && <span className="bg-slate-900 text-slate-300 border border-slate-850 px-2 py-0.5 rounded">Tactic: {selectedTactic}</span>}
            {selectedPlatform !== "ALL" && <span className="bg-slate-900 text-slate-300 border border-slate-850 px-2 py-0.5 rounded">Platform: {selectedPlatform}</span>}
            {!showSubtechniques && <span className="bg-slate-900 text-slate-300 border border-slate-850 px-2 py-0.5 rounded">Exclude Sub-techniques</span>}
            <span className="ml-auto text-[10px] bg-red-950 text-red-400 border border-red-900/60 font-bold px-2 py-0.5 rounded">
              {filteredList.length} MATCHES
            </span>
          </div>
        ) : null}
      </div>

      {loading && (
        <div className="text-center py-12 font-mono text-xs text-slate-505 flex flex-col items-center gap-2 bg-slate-950/40 border border-slate-900 rounded-lg">
          <Loader2 className="w-8 h-8 animate-spin text-red-500" />
          <span>Synchronizing locally indexed STIX data...</span>
        </div>
      )}

      {/* Main Column Breakdown */}
      {!loading && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT: ATT&CK Tactical Columns Hierarchy (width: 8cols) */}
          <div className="lg:col-span-7 xl:col-span-8 bg-slate-950/40 backdrop-blur-md border border-slate-900 p-5 rounded-lg space-y-4">
            <div className="flex justify-between items-center border-b border-slate-900 pb-3">
              <h3 className="text-xs font-mono font-bold text-slate-205 uppercase tracking-wider flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-slate-400" />
                TACTICAL MATRIX WORKSPACE
              </h3>
              <span className="text-[10px] text-slate-505 font-mono">
                Showing {filteredList.length} of {techniques.length} techniques
              </span>
            </div>

            {/* Matrix Columns layout */}
            <div className="space-y-6">
              {tacticsHierarchy.map(tac => {
                // Filter items that match this tactic
                const ttpList = filteredList.filter(t => 
                  t.tactics?.some(pt => pt.toLowerCase() === tac.toLowerCase()) || 
                  (t.tactic && t.tactic.toLowerCase() === tac.toLowerCase())
                );

                if (ttpList.length === 0 && selectedTactic !== "ALL") {
                  return null;
                }

                return (
                  <div key={tac} className="space-y-2">
                    {/* Tactic Header block */}
                    <div className="bg-slate-950 p-2.5 border border-slate-900 rounded flex justify-between items-center relative overflow-hidden">
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-red-500"></div>
                      <span className="text-[11px] font-mono font-extrabold text-slate-200 tracking-wider uppercase pl-2">
                        {tac}
                      </span>
                      <span className="text-[10px] font-mono bg-slate-900 border border-slate-850 text-slate-400 px-2 py-0.5 rounded">
                        {ttpList.length} techniques
                      </span>
                    </div>

                    {/* Techniques in this tactic */}
                    {ttpList.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {ttpList.map(tech => {
                          const isSelected = selectedTech?.id === tech.id;
                          return (
                            <button
                              key={tech.id}
                              onClick={() => setSelectedTech(tech)}
                              className={`p-3 rounded text-left transition border font-mono text-[11px] cursor-pointer flex flex-col justify-between gap-1 relative overflow-hidden ${
                                isSelected
                                  ? "bg-red-950/20 text-red-400 border-red-500 shadow-lg"
                                  : "bg-slate-950/50 hover:bg-slate-950 text-slate-400 border-slate-900 hover:border-slate-800"
                              }`}
                            >
                              <div className="flex justify-between items-start gap-1 w-full">
                                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded leading-none ${
                                  isSelected 
                                    ? "bg-red-500/20 text-red-400 border border-red-500/30" 
                                    : "bg-slate-900 text-slate-350 border border-slate-800"
                                }`}>
                                  {tech.id}
                                </span>
                                
                                {tech.isSubtechnique && (
                                  <span className="text-[8px] bg-slate-900/80 text-teal-400 border border-teal-950 font-bold px-1 py-0.2 rounded uppercase tracking-wide">
                                    Sub-tech
                                  </span>
                                )}
                              </div>
                              <span className={`font-bold block tracking-tight line-clamp-1 ${isSelected ? "text-red-300" : "text-slate-250"}`}>
                                {tech.name}
                              </span>
                              <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">
                                {tech.description}
                              </p>
                              
                              {/* Extra attributes */}
                              <div className="flex flex-wrap gap-1 pt-1 border-t border-slate-900/60 mt-1">
                                {tech.platforms && tech.platforms.length > 0 && (
                                  <span className="text-[8px] text-slate-550 truncate max-w-28">
                                    {tech.platforms[0]} {tech.platforms.length > 1 ? `+${tech.platforms.length-1}` : ""}
                                  </span>
                                )}
                                <span className="text-[8px] text-slate-600 block ml-auto">
                                  Actors: {tech.threatActors?.length || tech.threatGroups?.length || 0}
                                </span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-3 bg-slate-950/30 border border-slate-900 rounded text-center text-slate-600 font-mono text-[10px] italic">
                        No active techniques match selected filters in this column category.
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* RIGHT: Analyst Forensics & Incident Response Workbench (width: 4cols) */}
          <div className="lg:col-span-5 xl:col-span-4 space-y-6 lg:sticky lg:top-6">
            
            <div className="bg-slate-950 border border-slate-900 rounded-lg overflow-hidden">
              <div className="bg-slate-950 p-4 border-b border-slate-900">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-500" />
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest">
                    ANALYST WORKBENCH (TTP-INTEL)
                  </h3>
                </div>
              </div>

              {selectedTech ? (
                <div className="space-y-0">
                  {/* Technique Summary Title block */}
                  <div className="bg-slate-950 p-4 border-b border-slate-900">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wide font-extrabold block mb-1">
                      TACTICAL MAP: {(selectedTech.tactics && selectedTech.tactics.join(" -> ")) || selectedTech.tactic}
                    </span>
                    <h4 className="text-sm font-mono font-extrabold text-amber-400 mb-1 leading-snug">
                      {selectedTech.name}
                    </h4>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs font-mono font-bold bg-slate-900 border border-slate-800 text-slate-200 px-2 py-0.5 rounded">
                        {selectedTech.id}
                      </span>
                      {selectedTech.isSubtechnique && (
                        <span className="text-[9px] font-mono font-bold bg-teal-950/50 text-teal-400 border border-teal-900/50 px-2 py-0.5 rounded">
                          SUB-TECHNIQUE OF: {selectedTech.parentTechniqueId}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Tabs Selector headers */}
                  <div className="flex border-b border-slate-900 bg-slate-950 select-none">
                    <button
                      onClick={() => setActiveTab("intel")}
                      className={`flex-1 text-center py-2.5 font-mono text-[10px] font-bold tracking-tight uppercase border-b-2 transition ${
                        activeTab === "intel"
                          ? "text-slate-100 border-red-500 bg-slate-900/30 font-extrabold"
                          : "text-slate-500 border-transparent hover:text-slate-350 hover:bg-slate-900/10"
                      }`}
                    >
                      <BookOpen className="w-3.5 h-3.5 mx-auto mb-0.5 text-blue-400" />
                      Intel
                    </button>
                    <button
                      onClick={() => setActiveTab("hunting")}
                      className={`flex-1 text-center py-2.5 font-mono text-[10px] font-bold tracking-tight uppercase border-b-2 transition ${
                        activeTab === "hunting"
                          ? "text-slate-100 border-red-500 bg-slate-900/30"
                          : "text-slate-500 border-transparent hover:text-slate-350 hover:bg-slate-900/10"
                      }`}
                    >
                      <Terminal className="w-3.5 h-3.5 mx-auto mb-0.5 text-amber-400" />
                      Hunting
                    </button>
                    <button
                      onClick={() => setActiveTab("detection")}
                      className={`flex-1 text-center py-2.5 font-mono text-[10px] font-bold tracking-tight uppercase border-b-2 transition ${
                        activeTab === "detection"
                          ? "text-slate-100 border-red-500 bg-slate-900/30"
                          : "text-slate-500 border-transparent hover:text-slate-350 hover:bg-slate-900/10"
                      }`}
                    >
                      <Code className="w-3.5 h-3.5 mx-auto mb-0.5 text-teal-400" />
                      Detection
                    </button>
                    <button
                      onClick={() => setActiveTab("response")}
                      className={`flex-1 text-center py-2.5 font-mono text-[10px] font-bold tracking-tight uppercase border-b-2 transition ${
                        activeTab === "response"
                          ? "text-slate-100 border-red-500 bg-slate-900/30"
                          : "text-slate-500 border-transparent hover:text-slate-350 hover:bg-slate-900/10"
                      }`}
                    >
                      <CheckSquare className="w-3.5 h-3.5 mx-auto mb-0.5 text-pink-400" />
                      Playbook
                    </button>
                  </div>

                  {/* Panel Content Scrollable Container */}
                  <div className="p-4 space-y-4 max-h-[550px] overflow-y-auto content-scoller">
                    
                    {/* ====== TAB 1: INTEL ====== */}
                    {activeTab === "intel" && (
                      <div className="space-y-4 font-mono text-xs text-slate-300">
                        {/* Platforms & Log Sources */}
                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-slate-950 p-2.5 border border-slate-900 rounded">
                            <span className="text-[9px] text-slate-550 font-bold block uppercase mb-1">TARGET PLATFORMS:</span>
                            <div className="flex flex-wrap gap-1 max-h-12 overflow-y-auto">
                              {selectedTech.platforms && selectedTech.platforms.length > 0 ? (
                                selectedTech.platforms.map(p => (
                                  <span key={p} className="bg-slate-900 border border-slate-800 text-slate-350 px-1 py-0.2 rounded text-[8px]">
                                    {p}
                                  </span>
                                ))
                              ) : (
                                <span className="text-slate-505 text-[9px] italic">Not constrained</span>
                              )}
                            </div>
                          </div>

                          <div className="bg-slate-950 p-2.5 border border-slate-900 rounded">
                            <span className="text-[9px] text-slate-550 font-bold block uppercase mb-1">RECOMMENDED LOGS:</span>
                            <div className="flex flex-wrap gap-1 max-h-12 overflow-y-auto">
                              {selectedTech.dataSources && selectedTech.dataSources.length > 0 ? (
                                selectedTech.dataSources.map(ds => (
                                  <span key={ds} className="bg-slate-900 border border-slate-800 text-teal-400 px-1 py-0.2 rounded text-[8px] truncate max-w-full" title={ds}>
                                    {ds}
                                  </span>
                                ))
                              ) : (
                                <span className="text-slate-505 text-[9px] italic">Process Creation / Audit logs</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Technical Description */}
                        <div>
                          <span className="text-[9px] text-slate-500 font-bold block uppercase mb-1">TECHNICAL DESCRIPTION:</span>
                          <p className="text-[11px] leading-relaxed text-slate-350 bg-slate-950 p-3 border border-slate-900 rounded max-h-48 overflow-y-auto">
                            {selectedTech.description}
                          </p>
                        </div>

                        {/* Observed Threat Actors */}
                        <div>
                          <span className="text-[9px] text-orange-400 font-bold block uppercase mb-1.5 flex items-center gap-1">
                            <Flame className="w-3.5 h-3.5 text-orange-500" />
                            KNOWN ADVERSARY GROUPS EXPLOITING TTP:
                          </span>
                          <div className="bg-slate-950 p-3 border border-slate-900 rounded space-y-2">
                            {selectedTech.threatActors && selectedTech.threatActors.length > 0 ? (
                              <div className="flex flex-wrap gap-1.5">
                                {selectedTech.threatActors.map(act => (
                                  <div key={act.id} className="bg-orange-950/20 text-orange-400 border border-orange-900/40 px-2 py-0.5 rounded text-[10px] font-bold" title={act.description}>
                                    {act.name} ({act.id || "G-ID"})
                                  </div>
                                ))}
                              </div>
                            ) : selectedTech.threatGroups && selectedTech.threatGroups.length > 0 ? (
                              <div className="flex flex-wrap gap-1.5">
                                {selectedTech.threatGroups.map((g, idx) => (
                                  <span key={idx} className="bg-slate-900 border border-slate-800 text-slate-350 px-2 py-0.5 rounded text-[10px] font-bold">
                                    {g}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <div className="text-slate-505 italic text-[10px]">No Advanced Persistent Threat (APT) groups mapped directly.</div>
                            )}
                          </div>
                        </div>

                        {/* Associated Malware implants */}
                        <div>
                          <span className="text-[9px] text-red-400 font-bold block uppercase mb-1.5 flex items-center gap-1">
                            <ShieldAlert className="w-3.5 h-3.5 text-red-500" />
                            OBSERVED IMMATURE PAYLOADS & MALWARE:
                          </span>
                          <div className="bg-slate-950 p-2.5 border border-slate-900 rounded font-mono text-[10px] leading-relaxed">
                            {selectedTech.malware && selectedTech.malware.length > 0 ? (
                              <div className="flex flex-wrap gap-1.5">
                                {selectedTech.malware.map(mw => (
                                  <span key={mw.id} className="bg-red-955/35 text-red-400 border border-red-900/50 px-2 py-0.5 rounded font-bold" title={mw.description}>
                                    {mw.name} ({mw.id || "S-ID"})
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <div className="text-slate-505 italic">No specific malware families referenced. Usually paired in multi-vector exploit sets.</div>
                            )}
                          </div>
                        </div>

                        {/* External References */}
                        <div>
                          <span className="text-[9px] text-slate-500 font-bold block uppercase mb-1 flex items-center gap-1">
                            <Globe className="w-3.5 h-3.5" />
                            EXTERNAL REFERENCES & STANDARDS:
                          </span>
                          <div className="bg-slate-950 p-2.5 border border-slate-900 rounded font-mono text-[10px] space-y-1">
                            <a
                              href={`https://attack.mitre.org/techniques/${selectedTech.id}`}
                              target="_blank"
                              referrerPolicy="no-referrer"
                              className="text-amber-500 hover:underline flex items-center gap-1"
                            >
                              <span>Official MITRE Profile URL</span>
                              <ExternalLink className="w-3 h-3 text-amber-500" />
                            </a>
                            {selectedTech.externalReferences && selectedTech.externalReferences.slice(0, 3).map((ref, i) => (
                              <div key={i} className="text-slate-400 truncate max-w-full">
                                {ref.url ? (
                                  <a href={ref.url} target="_blank" referrerPolicy="no-referrer" className="text-blue-400 hover:underline truncate block">
                                    - {ref.description || ref.source_name}
                                  </a>
                                ) : (
                                  <span className="text-slate-500 block">- {ref.source_name}</span>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ====== TAB 2: HUNTING (KQL/SPL Queries) ====== */}
                    {activeTab === "hunting" && (
                      <div className="space-y-4 font-mono text-[11px] text-slate-300">
                        {/* Threat Hunting Hypothesis Section */}
                        <div className="bg-slate-950 p-3 border border-red-900/30 rounded border-l-2 border-red-500">
                          <h5 className="font-bold text-red-400 text-[10px] uppercase mb-1">Threat Hunting Hypothesis:</h5>
                          <p className="text-slate-400 text-[10px] leading-relaxed">
                            Adversaries are actively exploiting <strong>{selectedTech.name} ({selectedTech.id})</strong> within our systems to bypass detection boundaries. 
                            We should check for process executions by abnormal parent entities or system credentials using non-standard CLI properties.
                          </p>
                        </div>

                        {/* KQL Codeblock */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase font-bold border-b border-slate-900 pb-1">
                            <span>MICROSOFT SENTINEL / ASIM (KQL)</span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(kqlQuery);
                              }}
                              className="text-[9px] hover:text-slate-100 bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded cursor-pointer"
                            >
                              Copy Query
                            </button>
                          </div>
                          <pre className="bg-slate-950/80 p-3 border border-slate-900 rounded font-mono text-[10px] leading-relaxed text-slate-300 overflow-x-auto select-all max-h-40">
                            {kqlQuery}
                          </pre>
                        </div>

                        {/* SPL Codeblock */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase font-bold border-b border-slate-900 pb-1">
                            <span>SPLUNK SEARCH ENGINE (SPL)</span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(splQuery);
                              }}
                              className="text-[9px] hover:text-slate-100 bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded cursor-pointer"
                            >
                              Copy Query
                            </button>
                          </div>
                          <pre className="bg-slate-950/80 p-3 border border-slate-900 rounded font-mono text-[10px] leading-relaxed text-slate-300 overflow-x-auto select-all max-h-40">
                            {splQuery}
                          </pre>
                        </div>

                        {/* Hunting Steps checklist */}
                        <div className="space-y-2">
                          <span className="text-[10px] text-slate-550 uppercase font-bold block">TACTICAL STEPS:</span>
                          <ol className="list-decimal pl-4 text-slate-400 text-[10.5px] space-y-1.5 font-sans">
                            <li>Filter on process names executing unusual directories (e.g. <code>AppData\Local\Temp</code>, <code>/tmp/</code>).</li>
                            <li>Match process creation logs with network socket activity to see if an external command agent is dropping payloads.</li>
                            <li>Audit lateral movement handshakes right around the timestamp of the suspicious login behavior.</li>
                            <li>Verify command lines with known malicious signatures or obfuscated keywords.</li>
                          </ol>
                        </div>
                      </div>
                    )}

                    {/* ====== TAB 3: DETECTION (SIGMA BUILDER) ====== */}
                    {activeTab === "detection" && (
                      <div className="space-y-4 font-mono text-[11px] text-slate-300">
                        {/* Detection guidance label */}
                        <div>
                          <span className="text-[9px] text-slate-450 font-bold block uppercase mb-1">MITRE DETECTIONS GUIDANCE:</span>
                          <p className="text-[10px] text-slate-400 leading-normal bg-slate-950 p-2.5 border border-slate-900 rounded italic">
                            {selectedTech.detection || "Monitor process creations, command-line audits, and file write indicators across standard endpoints."}
                          </p>
                        </div>

                        {/* Sigma Compiler container */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] text-teal-400 uppercase font-extrabold border-b border-teal-950 pb-1">
                            <span className="flex items-center gap-1">
                              <Code className="w-3.5 h-3.5" />
                              SIGMA DETECTION RULE COMPILER
                            </span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(sigmaRule);
                              }}
                              className="text-[9px] text-slate-300 hover:text-slate-100 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded cursor-pointer uppercase font-bold"
                            >
                              Copy Sigma YAML
                            </button>
                          </div>
                          <pre className="bg-slate-950/85 p-3 border border-teal-950/40 rounded font-mono text-[10px] leading-relaxed text-teal-450/90 overflow-x-auto select-all max-h-56">
                            {sigmaRule}
                          </pre>
                        </div>

                        {/* Mitigation metrics info */}
                        <div className="bg-slate-950 p-3 border border-slate-900 rounded font-sans text-xs text-slate-400 space-y-1">
                          <span className="text-[9px] font-mono font-bold text-teal-400 block uppercase">SIGMA COMPATIBILITY:</span>
                          <p className="text-[10.5px] leading-normal font-mono">
                            Rule matches log category <code>process_creation</code> across Windows events (4688) and Sysmon Event ID 1. Reroute outputs straight to SIEM agents or Splunk Indexers.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* ====== TAB 4: PLAYBOOK (IR ACTIONS) ====== */}
                    {activeTab === "response" && (
                      <div className="space-y-4 font-mono text-[11px] text-slate-300">
                        <div>
                          <span className="text-[9px] text-slate-500 font-bold block uppercase mb-1.5">SECURITY MITIGATIONS STACK:</span>
                          <div className="bg-slate-950 p-3 border border-slate-900 rounded">
                            {selectedTech.mitigations && selectedTech.mitigations.length > 0 ? (
                              <div className="space-y-3">
                                {selectedTech.mitigations.map((mit, i) => (
                                  <div key={i} className="space-y-0.5 border-b border-slate-900/40 pb-2 last:border-b-0 last:pb-0">
                                    <span className="text-[10px] text-emerald-400 font-bold block">
                                      {mit.id ? `${mit.id}: ` : ""}{mit.name}
                                    </span>
                                    <p className="text-[10px] text-slate-450 leading-relaxed font-sans font-medium">
                                      {mit.description}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-slate-455 text-[10px] leading-relaxed">
                                {selectedTech.mitigation || "Isolate system instances from endpoint controls. Force credential cycles and restrict administrative access loops."}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Interactive Forensics IR playbook checklist */}
                        <div className="space-y-2 select-none">
                          <span className="text-[9px] text-pink-400 font-bold block uppercase flex items-center gap-1">
                            <CheckSquare className="w-4 h-4 text-pink-500" />
                            INCIDENT RESPONSE PLAYBOOK TASK LIST:
                          </span>
                          
                          <div className="space-y-2 bg-slate-950 p-3 border border-slate-900 rounded">
                            {/* Checkbox 1 */}
                            <label className="flex items-start gap-2.5 cursor-pointer group">
                              <input
                                type="checkbox"
                                checked={!!checklist[`${selectedTech.id}-contain`]}
                                onChange={() => toggleCheckbox(`${selectedTech.id}-contain`)}
                                className="mt-1 accent-pink-500 text-slate-950"
                              />
                              <div className="text-[11px]">
                                <span className="font-extrabold text-slate-205 block group-hover:text-pink-400 transition">Containment Isolation</span>
                                <p className="text-[10px] text-slate-500 font-sans mt-0.5">
                                  Isolate host <code>SOC-VM-NODE</code> to lock out actor command lines for {selectedTech.id}.
                                </p>
                              </div>
                            </label>

                            {/* Checkbox 2 */}
                            <label className="flex items-start gap-2.5 cursor-pointer group pt-2 border-t border-slate-900/60">
                              <input
                                type="checkbox"
                                checked={!!checklist[`${selectedTech.id}-audit`]}
                                onChange={() => toggleCheckbox(`${selectedTech.id}-audit`)}
                                className="mt-1 accent-pink-500 text-slate-950"
                              />
                              <div className="text-[11px]">
                                <span className="font-extrabold text-slate-205 block group-hover:text-pink-400 transition">Audit Session Flags</span>
                                <p className="text-[10px] text-slate-500 font-sans mt-0.5">
                                  Terminate active credential tokens and look look for abnormal child implants.
                                </p>
                              </div>
                            </label>

                            {/* Checkbox 3 */}
                            <label className="flex items-start gap-2.5 cursor-pointer group pt-2 border-t border-slate-900/60">
                              <input
                                type="checkbox"
                                checked={!!checklist[`${selectedTech.id}-eradicate`]}
                                onChange={() => toggleCheckbox(`${selectedTech.id}-eradicate`)}
                                className="mt-1 accent-pink-500 text-slate-950"
                              />
                              <div className="text-[11px]">
                                <span className="font-extrabold text-slate-205 block group-hover:text-pink-400 transition">Eradication & Cycle</span>
                                <p className="text-[10px] text-slate-500 font-sans mt-0.5">
                                  Deploy mitigation and force MFA setup on the user account immediately.
                                </p>
                              </div>
                            </label>
                          </div>
                        </div>

                        {/* Interactive completions percent */}
                        {Object.keys(checklist).filter(k => k.startsWith(selectedTech.id) && checklist[k]).length > 0 && (
                          <div className="text-center bg-pink-950/20 text-pink-400 border border-pink-900/35 p-2 rounded text-[10px] uppercase font-bold animate-fade-in">
                            PROGRESS: {Object.keys(checklist).filter(k => k.startsWith(selectedTech.id) && checklist[k]).length} of 3 Tasks Checked Out
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center font-mono text-slate-600 text-xs flex flex-col items-center justify-center h-80">
                  <HelpCircle className="w-8 h-8 mb-2 opacity-50 text-slate-450" />
                  <span>Select any technique technique columns inside tactical matrix on the left to activate analyst workbench.</span>
                </div>
              )}
            </div>

            {/* Analyst Quick Insights card */}
            <div className="bg-slate-950 border border-slate-900 rounded-lg p-4 font-mono text-[11px] leading-relaxed space-y-3">
              <span className="text-[10px] font-bold text-slate-200 uppercase tracking-widest flex items-center gap-1.5">
                <Sparkle className="w-4 h-4 text-red-500" />
                INVESTIGATION INSIGHTS
              </span>
              <p className="text-slate-400 leading-normal font-sans text-xs">
                Filter by platform types like <strong>SaaS</strong> or <strong>Containers</strong> to isolate modern cloud vulnerabilities down to their specific adversarial mappings instantly.
              </p>
            </div>
            
          </div>
        </div>
      )}
    </div>
  );
}
