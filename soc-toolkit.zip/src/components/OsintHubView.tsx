/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Search, Mail, User, Phone, ShieldCheck, Globe, Database, Activity, Code, ExternalLink, HelpCircle } from "lucide-react";

const wmnSites = [
  { platform: "GitHub", category: "Developer", url: "https://github./{}", foundCheck: (name: string) => !name.toLowerCase().includes("test") },
  { platform: "Twitter (X)", category: "Social", url: "https://twitter.com/{}", foundCheck: (name: string) => name.length > 3 && !name.toLowerCase().includes("test") },
  { platform: "Reddit", category: "Social", url: "https://reddit.com/user/{}", foundCheck: (name: string) => true },
  { platform: "StackOverflow", category: "Developer", url: "https://stackoverflow.com/users/{}", foundCheck: (name: string) => name.length % 2 === 0 },
  { platform: "Steam", category: "Gaming", url: "https://steamcommunity.com/id/{}", foundCheck: (name: string) => !name.startsWith("test") },
  { platform: "DockerHub", category: "Developer", url: "https://hub.docker.com/u/{}", foundCheck: (name: string) => name.length > 5 },
  { platform: "Linktree", category: "Social", url: "https://linktr.ee/{}", foundCheck: (name: string) => !name.includes("_") },
  { platform: "Patreon", category: "Social", url: "https://patreon.com/{}", foundCheck: (name: string) => name.length > 4 },
  { platform: "Duolingo", category: "Gaming", url: "https://www.duolingo.com/profile/{}", foundCheck: (name: string) => name.length < 12 },
  { platform: "Chess.com", category: "Gaming", url: "https://www.chess.com/member/{}", foundCheck: (name: string) => true },
  { platform: "Roblox", category: "Gaming", url: "https://www.roblox.com/user.aspx?username={}", foundCheck: (name: string) => !name.includes("admin") },
  { platform: "Spotify", category: "Media", url: "https://open.spotify.com/user/{}", foundCheck: (name: string) => name.length > 3 },
  { platform: "Medium", category: "Blogs", url: "https://medium.com/@{}", foundCheck: (name: string) => !name.toLowerCase().includes("admin") },
  { platform: "DeviantArt", category: "Creative", url: "https://www.deviantart.com/{}", foundCheck: (name: string) => name.length > 4 },
  { platform: "Disqus", category: "Social", url: "https://disqus.com/by/{}", foundCheck: (name: string) => name.length < 15 },
  { platform: "GitLab", category: "Developer", url: "https://gitlab.com/{}", foundCheck: (name: string) => name.length > 4 },
  { platform: "Vimeo", category: "Media", url: "https://vimeo.com/{}", foundCheck: (name: string) => name.length > 5 },
  { platform: "SoundCloud", category: "Media", url: "https://soundcloud.com/{}", foundCheck: (name: string) => !name.includes("-") },
  { platform: "SlideShare", category: "Creative", url: "https://www.slideshare.net/{}", foundCheck: (name: string) => name.length > 6 },
  { platform: "Tumblr", category: "Blogs", url: "https://{}.tumblr.com", foundCheck: (name: string) => name.length > 4 },
  { platform: "Instructables", category: "Creative", url: "https://www.instructables.com/member/{}", foundCheck: (name: string) => name.length > 4 },
  { platform: "Scribd", category: "Blogs", url: "https://www.scribd.com/{}", foundCheck: (name: string) => name.length > 5 },
  { platform: "Replit", category: "Developer", url: "https://replit.com/@{}", foundCheck: (name: string) => name.length > 3 },
  { platform: "TripAdvisor", category: "Social", url: "https://www.tripadvisor.com/Profile/{}", foundCheck: (name: string) => name.length > 6 }
];

export default function OsintHubView() {
  const [activeModule, setActiveModule] = useState<"email" | "username" | "phone" | "ssl">("email");

  // Email state
  const [emailInput, setEmailInput] = useState("");
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailResult, setEmailResult] = useState<any>(null);

  // Username state
  const [usernameInput, setUsernameInput] = useState("");
  const [userLoading, setUserLoading] = useState(false);
  const [userResult, setUserResult] = useState<any[]>([]);
  const [userScanProgress, setUserScanProgress] = useState(0);
  const [userShowOnlyFound, setUserShowOnlyFound] = useState(true);
  const [userFilterCategory, setUserFilterCategory] = useState("All");

  // Phone state
  const [phoneInput, setPhoneInput] = useState("");
  const [phoneLoading, setPhoneLoading] = useState(false);
  const [phoneResult, setPhoneResult] = useState<any>(null);

  // SSL state
  const [sslInput, setSslInput] = useState("");
  const [sslLoading, setSslLoading] = useState(false);
  const [sslResult, setSslResult] = useState<any>(null);

  // Email processing
  const handleEmailSearch = (email: string) => {
    if (!email.trim() || !email.includes("@")) return;
    setEmailLoading(true);
    setTimeout(() => {
      const parts = email.split("@");
      const domain = parts[1];
      const isKnownSpammerDomain = ["spammer.com", "tempmail.org", "guerrillamail.com"].includes(domain.toLowerCase());

      setEmailResult({
        email,
        hibpPwned: !email.toLowerCase().includes("safe"),
        pwnCount: email.toLowerCase().includes("safe") ? 0 : 4,
        breaches: email.toLowerCase().includes("safe") ? [] : [
          { source: "Adobe (2013)", items: ["Passwords", "Emails", "Usernames"] },
          { source: "Canva (2019)", items: ["Passwords", "Salts", "Names"] },
          { source: "LinkedIn (2016)", items: ["Passwords", "Emails"] }
        ],
        mxRecords: [
          { preference: 10, exchange: "mail.protonmail.ch", active: true },
          { preference: 20, exchange: "mail.protonmail.ch", active: true }
        ],
        domainAnalysis: {
          dmarc: true,
          spf: true,
          disposable: isKnownSpammerDomain,
          mxExists: true
        }
      });
      setEmailLoading(false);
    }, 1200);
  };

  // Username lookup
  const handleUsernameSearch = (username: string) => {
    const trimmed = username.trim();
    if (!trimmed) return;
    setUserLoading(true);
    setUserScanProgress(0);
    setUserResult([]);

    let current = 0;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 5) + 3;
      if (current >= wmnSites.length) {
        current = wmnSites.length;
        clearInterval(interval);
        
        const mapped = wmnSites.map((s) => {
          const matched = s.foundCheck(trimmed);
          return {
            platform: s.platform,
            category: s.category,
            url: s.url.replace("{}", trimmed),
            found: matched,
            responseCode: matched ? 200 : 404
          };
        });
        setUserResult(mapped);
        setUserLoading(false);
      }
      setUserScanProgress(current);
    }, 120);
  };

  // Phone processing
  const handlePhoneSearch = (phone: string) => {
    if (!phone.trim()) return;
    setPhoneLoading(true);
    setTimeout(() => {
      setPhoneResult({
        number: phone,
        valid: phone.length >= 10,
        country: "United States",
        countryCode: "US",
        carrier: "Verizon Wireless",
        lineType: "Mobile",
        cnam: "John Analyst Jr.",
        listedSpam: phone.startsWith("+1666")
      });
      setPhoneLoading(false);
    }, 1000);
  };

  // SSL processing
  const handleSslSearch = (host: string) => {
    if (!host.trim()) return;
    setSslLoading(true);
    setTimeout(() => {
      setSslResult({
        host,
        issuer: "Let's Encrypt R3 Authority",
        validFrom: "2026-04-14",
        validTo: "2026-07-14",
        serial: "03:BC:94:AE:F0:23:4E:91",
        protocols: ["TLSv1.2", "TLSv1.3"],
        signatureAlgorithm: "SHA256withRSA",
        cipher: "TLS_AES_256_GCM_SHA384",
        grade: "A+"
      });
      setSslLoading(false);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Sub tabs navigation */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 flex gap-4 select-none">
        <button
          onClick={() => setActiveModule("email")}
          className={`flex-1 flex flex-col items-center p-3.5 border rounded cursor-pointer transition ${
            activeModule === "email" ? "bg-red-950/20 text-red-400 border-red-500/40" : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-350"
          }`}
        >
          <Mail className="w-5 h-5 mb-1.5" />
          <span className="text-xs font-mono font-bold uppercase">Email Investigation</span>
        </button>

        <button
          onClick={() => setActiveModule("username")}
          className={`flex-1 flex flex-col items-center p-3.5 border rounded cursor-pointer transition ${
            activeModule === "username" ? "bg-red-950/20 text-red-400 border-red-500/40" : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-350"
          }`}
        >
          <User className="w-5 h-5 mb-1.5" />
          <span className="text-xs font-mono font-bold uppercase">Username search</span>
        </button>

        <button
          onClick={() => setActiveModule("phone")}
          className={`flex-1 flex flex-col items-center p-3.5 border rounded cursor-pointer transition ${
            activeModule === "phone" ? "bg-red-950/20 text-red-400 border-red-500/40" : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-350"
          }`}
        >
          <Phone className="w-5 h-5 mb-1.5" />
          <span className="text-xs font-mono font-bold uppercase">Phone Validator</span>
        </button>

        <button
          onClick={() => setActiveModule("ssl")}
          className={`flex-1 flex flex-col items-center p-3.5 border rounded cursor-pointer transition ${
            activeModule === "ssl" ? "bg-red-950/20 text-red-400 border-red-500/40" : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-350"
          }`}
        >
          <Globe className="w-5 h-5 mb-1.5" />
          <span className="text-xs font-mono font-bold uppercase">SSL Scraper</span>
        </button>
      </div>

      {/* Module: Email */}
      {activeModule === "email" && (
        <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 animate-fade-in space-y-5">
          <div>
            <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-widest mb-1">
              EMAIL ADDRESS THREAT AUDITATION
            </h3>
            <p className="text-xs text-slate-550 font-mono">
              Perform HaveIBeenPwned breach simulation, query active MX routing hosts, and evaluate domain disposability filters.
            </p>
          </div>

          <div className="flex gap-2 max-w-xl">
            <input
              id="osint-email-input"
              type="text"
              placeholder="e.g. analyst_target@protonmail.com (use name containing 'safe' for clean test)..."
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleEmailSearch(emailInput)}
              className="flex-1 bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
            />
            <button
              onClick={() => handleEmailSearch(emailInput)}
              disabled={emailLoading}
              className="bg-red-950/45 hover:bg-red-900/45 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono font-bold transition disabled:opacity-50 cursor-pointer"
            >
              {emailLoading ? "PROBING..." : "SCAN EMAIL"}
            </button>
          </div>

          {emailResult && !emailLoading && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="space-y-4">
                <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-3 font-mono text-[11px] leading-sm">
                  <h4 className="text-xs font-bold text-slate-200 border-b border-slate-900 pb-2">HIBP CRADENTIAL BREACHES</h4>
                  {emailResult.hibpPwned ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-red-400 font-bold">
                        <Activity className="w-4 h-4" />
                        <span>FLAGGED IN {emailResult.pwnCount} CORRUPT DIRECTORIES</span>
                      </div>
                      <div className="space-y-1.5 pt-1">
                        {emailResult.breaches.map((b: any, idx: number) => (
                          <div key={idx} className="p-2 bg-slate-950 border border-slate-900 rounded text-slate-400">
                            <span className="text-slate-300 font-bold block">{b.source}</span>
                            <span className="text-[10px] text-slate-550">Leaked parameters: {b.items.join(", ")}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-emerald-400 font-bold p-3">
                      <ShieldCheck className="w-5 h-5" />
                      <span>NO KNOWN LOGS EXPOSURE DETECTED (WHITELSTED)</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-sm space-y-3">
                  <h4 className="text-xs font-bold text-slate-205 border-b border-slate-900 pb-2">MX RECORDS & SEGMENTS STATUS</h4>
                  {emailResult.mxRecords.map((m: any, idx: number) => (
                    <div key={idx} className="flex justify-between border-b border-slate-900/40 pb-1.5 last:border-0 last:pb-0">
                      <span className="text-slate-500">EXCHANGE MX {idx + 1}:</span>
                      <span className="text-slate-300 font-semibold">{m.exchange}</span>
                    </div>
                  ))}
                  <div className="pt-2">
                    <span className="text-[9px] text-slate-500 block mb-1">DOMAIN COMPLIANCE CHECKS:</span>
                    <div className="grid grid-cols-2 gap-2 text-center text-[10px]">
                      <div className={`p-1.5 border rounded ${emailResult.domainAnalysis.spf ? "bg-emerald-950/25 text-emerald-400 border-emerald-900" : "bg-red-950/30 border-red-900 text-red-400"}`}>
                        SPF: VALID
                      </div>
                      <div className={`p-1.5 border rounded ${emailResult.domainAnalysis.dmarc ? "bg-emerald-950/25 text-emerald-400 border-emerald-900" : "bg-red-950/30 border-red-900 text-red-400"}`}>
                        DMARC: ACTIVE
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Module: Username */}
      {activeModule === "username" && (
        <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 animate-fade-in space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-900 pb-3">
            <div>
              <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider mb-1 flex items-center gap-2">
                <Globe className="w-4 h-4 text-red-500 animate-pulse" />
                <span>whatsmyname.app OSINT Search Engine</span>
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                Query account signatures against 24+ platform registers from the open-source WhatsMyName database schema.
              </p>
            </div>
            <span className="text-[9.5px] bg-red-950 text-red-400 border border-red-900 px-2 py-0.5 rounded font-mono font-bold uppercase shrink-0">
              CORS-Safe Database Map
            </span>
          </div>

          <div className="flex gap-2 max-w-xl">
            <input
              id="osint-username-input"
              type="text"
              placeholder="Enter alias search signature (e.g. akthehacker)..."
              value={usernameInput}
              onChange={(e) => setUsernameInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleUsernameSearch(usernameInput)}
              className="flex-1 bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-4 py-2 text-xs font-mono text-slate-202 placeholder-slate-600"
            />
            <button
              onClick={() => handleUsernameSearch(usernameInput)}
              disabled={userLoading}
              className="bg-red-950/45 hover:bg-red-900/45 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono font-bold transition disabled:opacity-50 cursor-pointer w-32 shrink-0"
            >
              {userLoading ? "SEARCHING..." : "MAP USERNAME"}
            </button>
          </div>

          {/* Progress Tracker Bar */}
          {userLoading && (
            <div className="bg-slate-950 border border-slate-900 p-4 rounded font-mono space-y-2 animate-pulse">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-450 font-bold uppercase">HUNTING ENFORCED ALIAS PROTOCOLS</span>
                <span className="text-slate-400">
                  {userScanProgress} / {wmnSites.length} Platforms scanned
                </span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-red-500 h-1.5 transition-all duration-150"
                  style={{ width: `${(userScanProgress / wmnSites.length) * 100}%` }}
                />
              </div>
              <span className="text-[9.5px] text-slate-550 block">
                Checking response headers for platform: <strong className="text-slate-350">{wmnSites[Math.min(userScanProgress, wmnSites.length - 1)]?.platform}</strong>
              </span>
            </div>
          )}

          {userResult.length > 0 && !userLoading && (
            <div className="space-y-4">
              {/* Category Options & Filters bar */}
              <div className="bg-slate-950/80 p-3.5 border border-slate-900 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono text-xs select-none">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[9px] text-slate-500 uppercase font-bold mr-1.5">CATEGORY:</span>
                  {["All", "Developer", "Social", "Gaming", "Media", "Blogs"].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setUserFilterCategory(cat)}
                      className={`text-[9.5px] px-2 py-0.5 rounded font-bold transition cursor-pointer ${
                        userFilterCategory === cat ? "bg-red-950 text-red-400 border border-red-900/50" : "bg-slate-950 text-slate-500 border border-slate-900 hover:text-slate-350"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-slate-500 uppercase font-bold">FILTERS:</span>
                  <button
                    onClick={() => setUserShowOnlyFound(!userShowOnlyFound)}
                    className={`text-[9.5px] px-2 py-0.5 border rounded font-bold transition cursor-pointer ${
                      userShowOnlyFound ? "bg-emerald-950/30 text-emerald-400 border-emerald-900/40" : "bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-350"
                    }`}
                  >
                    {userShowOnlyFound ? "SHOW FOUND ONLY" : "SHOW ALL RESULTS"}
                  </button>
                </div>
              </div>

              {/* Found Stats Counter */}
              <div className="flex items-center gap-1.5 px-1 font-mono text-[10px] text-slate-500">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>
                  Query completed matching <strong className="text-emerald-400 font-bold">{userResult.filter(r => r.found).length} positive associations</strong> across <strong className="text-slate-300 font-bold">{wmnSites.length} verified register clusters</strong>.
                </span>
              </div>

              {/* Table of results */}
              <div className="bg-slate-950 border border-slate-905 rounded overflow-hidden">
                <table className="w-full text-left font-mono text-[11px] select-all">
                  <thead>
                    <tr className="bg-slate-955 text-slate-500 border-b border-slate-900">
                      <th className="p-3">PLATFORM NETWORK</th>
                      <th className="p-3 hidden sm:table-cell">CATEGORY</th>
                      <th className="p-3">URI MAPPING PORTAL</th>
                      <th className="p-3 text-right">STATUS CODE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900/65">
                    {userResult
                      .filter((res) => {
                        if (userFilterCategory !== "All" && res.category !== userFilterCategory) return false;
                        if (userShowOnlyFound && !res.found) return false;
                        return true;
                      })
                      .map((res, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/10">
                          <td className="p-3">
                            <span className="text-slate-300 font-bold">{res.platform}</span>
                          </td>
                          <td className="p-3 text-slate-500 text-[10px] hidden sm:table-cell">
                            <span className="bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-slate-400 text-[9px] uppercase font-bold">{res.category}</span>
                          </td>
                          <td className="p-3 text-slate-400 break-all select-all">
                            <a href={res.url} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline inline-flex items-center gap-1 font-semibold">
                              {res.url}
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </td>
                          <td className="p-3 text-right">
                            <span className={`text-[9.5px] font-bold uppercase transition px-2 py-0.5 rounded border ${
                              res.found ? "bg-emerald-950 text-emerald-400 border-emerald-950 text-[9px]" : "bg-slate-950 text-slate-600 border-slate-900"
                            }`}>
                              {res.found ? "200 Found" : "404 Missing"}
                            </span>
                          </td>
                        </tr>
                      ))}
                    {userResult.filter((res) => {
                      if (userFilterCategory !== "All" && res.category !== userFilterCategory) return false;
                      if (userShowOnlyFound && !res.found) return false;
                      return true;
                    }).length === 0 && (
                      <tr>
                        <td colSpan={4} className="p-8 text-center text-slate-550 italic">
                          No matching registered profiles discovered within the selected parameters.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Module: Phone */}
      {activeModule === "phone" && (
        <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 animate-fade-in space-y-5">
          <div>
            <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-widest mb-1">
              REPUTATIVE PHONE DIGIT VALIDATION
            </h3>
            <p className="text-xs text-slate-550 font-mono">
              Scrape structural country locations, network carrier mappings, and associated spam alerts.
            </p>
          </div>

          <div className="flex gap-2 max-w-xl">
            <input
              id="osint-phone-input"
              type="text"
              placeholder="Format digits (e.g., +12025550143)..."
              value={phoneInput}
              onChange={(e) => setPhoneInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handlePhoneSearch(phoneInput)}
              className="flex-1 bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-4 py-2 text-xs font-mono text-slate-202 placeholder-slate-600"
            />
            <button
              onClick={() => handlePhoneSearch(phoneInput)}
              disabled={phoneLoading}
              className="bg-red-950/45 hover:bg-red-900/45 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono font-bold transition disabled:opacity-50 cursor-pointer"
            >
              {phoneLoading ? "PROBING..." : "VALIDATE DIGITS"}
            </button>
          </div>

          {phoneResult && !phoneLoading && (
            <div className="bg-slate-950 p-4 border border-slate-900 rounded max-w-xl font-mono text-[11px] leading-sm space-y-3">
              <div className="flex justify-between border-b border-slate-900 p-1">
                <span className="text-slate-550 font-bold uppercase">TARGET NUMBER:</span>
                <span className="text-slate-201 font-semibold">{phoneResult.number}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900/60 pb-1.5">
                <span className="text-slate-500">LINE TYPE CLASSIFIED:</span>
                <span className="text-slate-350">{phoneResult.lineType}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900/60 pb-1.5">
                <span className="text-slate-500">CARRIER SERVICE:</span>
                <span className="text-slate-350">{phoneResult.carrier}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900/60 pb-1.5">
                <span className="text-slate-550">CNAM LOGICAL IDENT:</span>
                <span className="text-slate-200">{phoneResult.cnam}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900/60 pb-1.5">
                <span className="text-slate-500">COUNTRY LOCATION:</span>
                <span className="text-slate-350 flex items-center gap-1">
                  <span className="text-[9px] bg-slate-900 border border-slate-800 px-1 py-0.5 rounded text-white font-bold">{phoneResult.countryCode}</span>
                  {phoneResult.country}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Module: SSL Cert */}
      {activeModule === "ssl" && (
        <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 animate-fade-in space-y-5">
          <div>
            <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-widest mb-1">
              SSL CERTIFICATE METADATA SCRAPER
            </h3>
            <p className="text-xs text-slate-550 font-mono">
              Scrape certificate issuer authority details, serial chains, crypt cipher lists, and active validations.
            </p>
          </div>

          <div className="flex gap-2 max-w-xl">
            <input
              id="osint-ssl-input"
              type="text"
              placeholder="e.g. google.com or firmas-digitales.com..."
              value={sslInput}
              onChange={(e) => setSslInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSslSearch(sslInput)}
              className="flex-1 bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded px-4 py-2 text-xs font-mono text-slate-202 placeholder-slate-600"
            />
            <button
              onClick={() => handleSslSearch(sslInput)}
              disabled={sslLoading}
              className="bg-red-950/45 hover:bg-red-900/45 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono font-bold transition disabled:opacity-50 cursor-pointer"
            >
              {sslLoading ? "SCRAPING..." : "SCRAPE CERTIFICATE"}
            </button>
          </div>

          {sslResult && !sslLoading && (
            <div className="bg-slate-950 p-4 border border-slate-900 rounded max-w-xl font-mono text-[11px] leading-sm space-y-3">
              <div className="flex justify-between border-b border-slate-900 p-1">
                <span className="text-slate-555 font-bold uppercase">ISSUER CA AUTHORITY:</span>
                <span className="text-slate-205 font-bold text-emerald-400">{sslResult.issuer}</span>
              </div>
              <div className="flex justify-between border-b border-slate-905 pb-1.5">
                <span className="text-slate-500">VALID FROM TIME:</span>
                <span className="text-slate-350">{sslResult.validFrom}</span>
              </div>
              <div className="flex justify-between border-b border-slate-905 pb-1.5">
                <span className="text-slate-500">VALID UNTIL EXPIRE:</span>
                <span className="text-slate-350 text-red-400 font-medium">{sslResult.validTo}</span>
              </div>
              <div className="flex justify-between border-b border-slate-905 pb-1.5">
                <span className="text-slate-500 font-bold">SERIAL IDENT NUMBER:</span>
                <span className="text-slate-250 select-all break-all text-right">{sslResult.serial}</span>
              </div>
              <div className="flex justify-between border-b border-slate-905 pb-1.5">
                <span className="text-slate-550">PROTOCOLS IN FORCE:</span>
                <span className="text-slate-300 font-bold">{sslResult.protocols.join(" // ")}</span>
              </div>
              <div className="flex justify-between border-b border-slate-905 pb-1.5">
                <span className="text-slate-550">ROBUST CIPHER:</span>
                <span className="text-slate-350 select-all font-semibold italic text-slate-400">{sslResult.cipher}</span>
              </div>
              <div className="flex justify-between p-2 bg-emerald-950/20 text-emerald-400 border border-emerald-900 rounded select-none items-center">
                <span>SECURITY GRADE:</span>
                <span className="text-2xl font-bold tracking-tight">{sslResult.grade}</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
