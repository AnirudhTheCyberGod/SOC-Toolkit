/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Network,
  ShieldCheck,
  Search,
  Globe2,
  Server,
  Lock,
  Calendar,
  Layers,
  FileBadge,
  Eye,
  AlertCircle,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  Info
} from "lucide-react";

interface AsnResult {
  asn: string;
  provider: string;
  country: string;
  countryCode: string;
  prefixes: string[];
  registry?: string;
  allocatedDate?: string;
  reputationType?: "clean" | "suspicious" | "malicious";
  reputationExplanation?: string;
}

interface SslResult {
  host: string;
  peerCert: {
    subject: string;
    issuer: string;
    validFrom: string;
    validTo: string;
    serialNumber: string;
    fingerprint: string;
    sans: string[];
    bits?: number;
    protocol?: string;
  };
  isValid: boolean;
  daysRemaining: number;
  errorMessage?: string;
}

export default function AsnSslView() {
  const [activeSubTab, setActiveSubTab] = useState<"asn" | "ssl">("asn");
  
  // ASN State
  const [asnInput, setAsnInput] = useState("");
  const [asnLoading, setAsnLoading] = useState(false);
  const [asnResult, setAsnResult] = useState<AsnResult | null>(null);
  const [asnError, setAsnError] = useState<string | null>(null);
  const [asnCopied, setAsnCopied] = useState(false);

  // SSL State
  const [sslInput, setSslInput] = useState("");
  const [sslLoading, setSslLoading] = useState(false);
  const [sslResult, setSslResult] = useState<SslResult | null>(null);
  const [sslError, setSslError] = useState<string | null>(null);
  const [sslCopied, setSslCopied] = useState(false);

  // Common quick ASN buttons
  const commonAsns = [
    { label: "Cloudflare", asn: "13335" },
    { label: "Google LLC", asn: "15169" },
    { label: "Amazon", asn: "16509" },
    { label: "Microsoft", asn: "8075" }
  ];

  // Common quick SSL buttons
  const commonHosts = [
    "google.com",
    "github.com",
    "wikipedia.org",
    "expired.badssl.com"
  ];

  const handleCopyText = (text: string, isAsn: boolean) => {
    navigator.clipboard.writeText(text);
    if (isAsn) {
      setAsnCopied(true);
      setTimeout(() => setAsnCopied(false), 2000);
    } else {
      setSslCopied(true);
      setTimeout(() => setSslCopied(false), 2000);
    }
  };

  const handleAsnCheck = async (asnStr: string) => {
    const rawVal = asnStr.trim().toUpperCase();
    const digitsOnly = rawVal.replace(/^AS/gi, "");
    if (!digitsOnly || isNaN(Number(digitsOnly))) {
      setAsnError("Please enter a valid numerical ASN (e.g., AS13335 or 15169).");
      return;
    }

    setAsnLoading(true);
    setAsnError(null);
    setAsnResult(null);

    try {
      const response = await fetch("/api/asn/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ asn: digitsOnly })
      });

      if (response.ok) {
        const data = await response.json();
        setAsnResult(data);
      } else {
        const errData = await response.json().catch(() => ({}));
        setAsnError(errData.error || "Failed to look up ASN registry info.");
      }
    } catch (err: any) {
      setAsnError(`Network lookup failed: ${err.message}`);
    } finally {
      setAsnLoading(false);
    }
  };

  const handleSslCheck = async (hostStr: string) => {
    let cleanHost = hostStr.trim().toLowerCase();
    // Strip http:// or https:// if pasted accidentally
    cleanHost = cleanHost.replace(/^(https?:\/\/)?(www\.)?/i, "");
    // Strip paths or ports
    cleanHost = cleanHost.split("/")[0].split(":")[0];

    if (!cleanHost) {
      setSslError("Please enter a domain host to test (e.g., google.com).");
      return;
    }

    setSslLoading(true);
    setSslError(null);
    setSslResult(null);

    try {
      const response = await fetch("/api/ssl/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ host: cleanHost })
      });

      if (response.ok) {
        const data = await response.json();
        setSslResult(data);
      } else {
        const errData = await response.json().catch(() => ({}));
        setSslError(errData.error || "Failed to parse host SSL certificate details.");
      }
    } catch (err: any) {
      setSslError(`SSL diagnostics failed: ${err.message}`);
    } finally {
      setSslLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Title Segment */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
            <Network className="w-4 h-4 text-red-500 animate-pulse" />
            ASN & SSL SECURE DIAGNOSTICS
          </h2>
          <p className="text-xs text-slate-550 font-mono">
            Investigate Autonomous System routing paths and scan real-time target SSL certificate chains with full SAN validation.
          </p>
        </div>

        {/* Floating switch buttons */}
        <div className="flex gap-1.5 bg-slate-950 border border-slate-850 rounded p-1">
          <button
            onClick={() => setActiveSubTab("asn")}
            className={`text-[10px] font-mono px-3 py-1 rounded font-bold cursor-pointer transition ${
              activeSubTab === "asn"
                ? "bg-red-650 text-white"
                : "text-slate-450 hover:text-slate-200"
            }`}
          >
            ASN LOOKUP
          </button>
          <button
            onClick={() => setActiveSubTab("ssl")}
            className={`text-[10px] font-mono px-3 py-1 rounded font-bold cursor-pointer transition ${
              activeSubTab === "ssl"
                ? "bg-red-650 text-white"
                : "text-slate-450 hover:text-slate-200"
            }`}
          >
            SSL CERTIFICATE CHECKER
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeSubTab === "asn" ? (
          <motion.div
            key="asn-tab"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* Search Input Box */}
            <div className="bg-slate-950/40 border border-slate-900/80 rounded p-4 space-y-4">
              <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
                <div className="relative flex-1 w-full">
                  <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
                  <input
                    id="asn-lookup-search"
                    type="text"
                    placeholder="Enter Autonomous System Number (e.g. AS13335 or 15169)..."
                    value={asnInput}
                    onChange={(e) => setAsnInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAsnCheck(asnInput)}
                    className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-9 pr-4 py-2 text-xs font-mono text-slate-201 placeholder-slate-600"
                  />
                </div>
                <button
                  onClick={() => handleAsnCheck(asnInput)}
                  disabled={asnLoading}
                  className="w-full md:w-auto px-4 py-2 bg-red-650 hover:bg-red-600 text-white rounded text-xs font-mono font-bold cursor-pointer transition disabled:opacity-55 flex items-center justify-center gap-2 shrink-0"
                >
                  {asnLoading ? "SCANNING..." : "QUERY REGISTRY"}
                </button>
              </div>

              {/* Sample badging and shortcuts */}
              <div className="flex flex-wrap items-center justify-between gap-3 text-[10px] font-mono text-slate-500 border-t border-slate-900/60 pt-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span>QUICK PRESETS:</span>
                  {commonAsns.map((p) => (
                    <button
                      key={p.asn}
                      onClick={() => {
                        setAsnInput(p.asn);
                        handleAsnCheck(p.asn);
                      }}
                      className="bg-slate-950/80 hover:bg-slate-900 border border-slate-900 hover:border-slate-700 text-slate-400 hover:text-slate-202 text-[10px] px-2 py-0.5 rounded cursor-pointer transition"
                    >
                      {p.label} (AS{p.asn})
                    </button>
                  ))}
                </div>
                <a
                  href={`https://bgp.he.net/${asnInput ? `AS${asnInput.replace(/^AS/gi, "")}` : ""}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-slate-950 hover:bg-emerald-950/40 border border-slate-900 hover:border-emerald-900 text-slate-400 hover:text-emerald-400 text-[10px] px-2.5 py-1 rounded inline-flex items-center gap-1.5 transition ml-auto"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                  BGP.HE.NET TOOLKIT {asnInput && `(AS${asnInput.replace(/^AS/gi, "")})`}
                </a>
              </div>
            </div>

            {/* Error alerts */}
            {asnError && (
              <div className="p-4 bg-red-950/20 border border-red-900/60 rounded flex items-center gap-3 text-red-400 font-mono text-xs">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
                <span>{asnError}</span>
              </div>
            )}

            {/* Loading placeholder */}
            {asnLoading && (
              <div className="bg-slate-950/20 border border-slate-900/40 rounded p-16 text-center font-mono text-xs text-slate-500">
                <div className="w-6 h-6 border-2 border-slate-700 border-t-red-500 rounded-full animate-spin mx-auto mb-3" />
                Interrogating RIR records (ARIN, RIPE, APNIC, LACNIC) for secure ASN routing parameters...
              </div>
            )}

            {/* Results Output */}
            {asnResult && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                    <div className="flex items-center gap-2">
                      <Network className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-mono font-bold text-slate-100">ROUTING ALLOCATIONS DETAILS</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono bg-slate-900 text-slate-400 border border-slate-800 px-2 py-0.5 rounded uppercase font-bold select-all">
                        AS{asnResult.asn}
                      </span>
                      <a
                        href={`https://bgp.he.net/AS${asnResult.asn}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-emerald-950/20 hover:bg-emerald-900/40 text-emerald-400 border border-emerald-900 hover:border-emerald-700 text-[10px] font-mono px-2 py-0.5 rounded inline-flex items-center gap-1.5 transition select-none"
                      >
                        <ExternalLink className="w-3 h-3 text-emerald-400" />
                        BGP.HE.NET
                      </a>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">PROVIDER / ORG NAME</span>
                      <span className="text-slate-202 font-bold font-sans mt-0.5 block truncate text-sm select-all">{asnResult.provider}</span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">COUNTRY GEOLOCATION</span>
                      <span className="text-slate-202 font-bold mt-0.5 flex items-center gap-1.5 text-sm select-all">
                        <Globe2 className="w-4 h-4 text-slate-400" />
                        {asnResult.country} ({asnResult.countryCode})
                      </span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">ALLOCATION RIR REGISTRY</span>
                      <span className="text-emerald-400 font-bold mt-0.5 block select-all text-sm uppercase">{asnResult.registry || "IANA"}</span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">ALLOCATION DATE</span>
                      <span className="text-slate-202 font-bold mt-0.5 block select-all text-sm">{asnResult.allocatedDate || "Unknown Registration Date"}</span>
                    </div>
                  </div>

                  {/* CIDR Prefixes Section */}
                  <div className="pt-2">
                    <span className="text-[10px] text-slate-500 block font-mono uppercase mb-2">ANNOUNCED ROAD PREFIXES (CIDR)</span>
                    <div className="bg-slate-950/80 border border-slate-900 rounded p-3 h-48 overflow-y-auto space-y-1 text-[11px] font-mono">
                      {asnResult.prefixes && asnResult.prefixes.length > 0 ? (
                        asnResult.prefixes.map((cidr, index) => (
                          <div key={index} className="flex justify-between items-center py-1 border-b border-slate-900/50 last:border-0 hover:bg-slate-900/30 px-1.5 rounded">
                            <span className="text-slate-300 font-bold">{cidr}</span>
                            <button
                              onClick={() => handleCopyText(cidr, true)}
                              className="text-[9px] text-slate-500 hover:text-slate-300 transition"
                              title="Copy CIDR Prefix"
                            >
                              COPY
                            </button>
                          </div>
                        ))
                      ) : (
                        <div className="text-slate-600 text-center pt-16">No direct prefixes announced or indexed.</div>
                      )}
                    </div>
                    <span className="text-[9.5px] text-slate-600 mt-1.5 block font-mono text-right">
                      Aggregated total announced prefixes: {asnResult.prefixes ? asnResult.prefixes.length : 0} ipv4/ipv6 blocks.
                    </span>
                  </div>
                </div>

                {/* Right Routing Intel Analysis Card */}
                <div className="space-y-4">
                  <div className="bg-slate-950/60 border border-slate-900 rounded p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-900 pb-2">
                      <ShieldCheck className="w-4 h-4 text-red-500" />
                      <span className="text-xs font-mono font-bold text-slate-100">SECURITY INTEL CHECK</span>
                    </div>

                    <div className="space-y-3.5 font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block leading-tight">THREAT INTEL REPUTATION</span>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                            asnResult.reputationType === "malicious"
                              ? "bg-red-950/20 text-red-400 border-red-900"
                              : asnResult.reputationType === "suspicious"
                              ? "bg-amber-955/20 text-amber-400 border-amber-900"
                              : "bg-emerald-950/20 text-emerald-400 border-emerald-900"
                          }`}>
                            {asnResult.reputationType || "clean"}
                          </span>
                        </div>
                      </div>

                      <div className="p-3 bg-slate-950/80 border border-slate-900 rounded space-y-1.5 leading-relaxed text-slate-400 text-[11px]">
                        <span className="font-bold text-slate-300 text-xs block flex items-center gap-1.5">
                          <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                          Security Classification Details
                        </span>
                        <p>{asnResult.reputationExplanation || "This ASN is registered by a highly reputable core service provider with no current significant malicious threat vectors or botnet C2 hosting anomalies indexed recently."}</p>
                      </div>

                      <div className="bg-slate-900/30 p-2.5 rounded text-[10px] text-slate-500 leading-normal border border-slate-900">
                        Autonomous Systems represent independent routing nodes on global IP backbones. Large hosters like Amazon (AS16509) or Cloudflare (AS13335) routinely handle high bandwidth. Monitoring malicious prefix distributions helps detect proxy hijackings and threat-actor command structures.
                      </div>
                    </div>
                  </div>

                  {/* Hurricane Electric BGP Integration panel */}
                  <div className="bg-slate-950/60 border border-slate-900 rounded p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-900 pb-2">
                      <Globe2 className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">bgp.he.net Deep-Dive</span>
                    </div>
                    <p className="text-[11px] font-mono text-slate-400 leading-relaxed">
                      Examine complete eBGP peering charts, announcement graphs, upstream/downstream adjacency matrices, and multi-home status for <strong className="text-slate-200">AS{asnResult.asn}</strong> directly inside Hurricane Electric's global routing workspace.
                    </p>
                    
                    <div className="space-y-2 pt-1 font-mono text-[10px]">
                      <a
                        href={`https://bgp.he.net/AS${asnResult.asn}#_asinfo`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-300 px-3 py-2 rounded flex items-center justify-between hover:text-emerald-400 transition"
                      >
                        <span>AS Info & Peering Registry</span>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      </a>
                      <a
                        href={`https://bgp.he.net/AS${asnResult.asn}#_prefixes`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-300 px-3 py-2 rounded flex items-center justify-between hover:text-emerald-400 transition"
                      >
                        <span>Announced CIDR Subnets</span>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      </a>
                      <a
                        href={`https://bgp.he.net/AS${asnResult.asn}#_graph4`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-300 px-3 py-2 rounded flex items-center justify-between hover:text-emerald-400 transition"
                      >
                        <span>BGP v4 Visual Route Graph</span>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="ssl-tab"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.15 }}
            className="space-y-6"
          >
            {/* SSL Input Box */}
            <div className="bg-slate-950/40 border border-slate-900/80 rounded p-4 space-y-4">
              <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
                <div className="relative flex-1 w-full">
                  <Lock className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
                  <input
                    id="ssl-checking-search"
                    type="text"
                    placeholder="Enter target host or domain to fetch TLS chain (e.g. github.com)..."
                    value={sslInput}
                    onChange={(e) => setSslInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSslCheck(sslInput)}
                    className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-9 pr-4 py-2 text-xs font-mono text-slate-201 placeholder-slate-600"
                  />
                </div>
                <button
                  onClick={() => handleSslCheck(sslInput)}
                  disabled={sslLoading}
                  className="w-full md:w-auto px-4 py-2 bg-red-650 hover:bg-red-600 text-white rounded text-xs font-mono font-bold cursor-pointer transition disabled:opacity-55 flex items-center justify-center gap-2 shrink-0"
                >
                  {sslLoading ? "CHECKING TLS..." : "TEST SSL CERT"}
                </button>
              </div>

              {/* Sample badging and shortcuts */}
              <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono text-slate-500 border-t border-slate-900/60 pt-2">
                <span>QUICK TLS PRESETS:</span>
                {commonHosts.map((h) => (
                  <button
                    key={h}
                    onClick={() => {
                      setSslInput(h);
                      handleSslCheck(h);
                    }}
                    className="bg-slate-950/80 hover:bg-slate-900 border border-slate-900 hover:border-slate-700 text-slate-400 hover:text-slate-202 text-[10px] px-2 py-0.5 rounded cursor-pointer transition"
                  >
                    {h}
                  </button>
                ))}
              </div>
            </div>

            {/* Error alerts */}
            {sslError && (
              <div className="p-4 bg-red-950/20 border border-red-900/60 rounded flex items-center gap-3 text-red-400 font-mono text-xs">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
                <span>{sslError}</span>
              </div>
            )}

            {/* Loading placeholder */}
            {sslLoading && (
              <div className="bg-slate-950/20 border border-slate-900/40 rounded p-16 text-center font-mono text-xs text-slate-500">
                <div className="w-6 h-6 border-2 border-slate-700 border-t-red-500 rounded-full animate-spin mx-auto mb-3" />
                Establishing real TLS connection to secure socket layers and fetching active certificate payload details...
              </div>
            )}

            {/* Results Output */}
            {sslResult && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-mono font-bold text-slate-100 font-sans uppercase">PEM CERTIFICATE MANIFEST</span>
                    </div>
                    <span className="text-[10px] font-mono bg-slate-900 text-slate-400 border border-slate-800 px-2 py-0.5 rounded font-bold">
                      {sslResult.host}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">ISSUER CA</span>
                      <span className="text-slate-102 font-bold font-sans mt-0.5 block truncate text-sm select-all">{sslResult.peerCert.issuer || "Unknown CA Issuer"}</span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">VALID FROM</span>
                      <span className="text-slate-202 mt-0.5 block text-sm select-all">{new Date(sslResult.peerCert.validFrom).toLocaleString()}</span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">EXPIRATION (VALID UNTIL)</span>
                      <span className="text-slate-202 mt-0.5 block text-sm select-all">{new Date(sslResult.peerCert.validTo).toLocaleString()}</span>
                    </div>

                    <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                      <span className="text-[10px] text-slate-500 block uppercase">CIPHER STRENGTH</span>
                      <span className="text-emerald-400 mt-0.5 block text-sm font-bold uppercase select-all">
                        {sslResult.peerCert.protocol || "TLSv1.3"} // {sslResult.peerCert.bits || 256} BITS
                      </span>
                    </div>
                  </div>

                  {/* SANs Badges */}
                  <div className="pt-2">
                    <span className="text-[10px] text-slate-500 block font-mono uppercase mb-2">SUBJECT ALTERNATIVE NAMES (SANS)</span>
                    <div className="bg-slate-950/80 border border-slate-900 rounded p-3 text-xs font-mono flex flex-wrap gap-1.5 max-h-36 overflow-y-auto align-top">
                      {sslResult.peerCert.sans && sslResult.peerCert.sans.length > 0 ? (
                        sslResult.peerCert.sans.map((san, index) => (
                          <span
                            key={index}
                            className="bg-slate-900 hover:bg-slate-850 text-slate-300 text-[9.5px] px-2 py-0.5 rounded border border-slate-800 transition select-all leading-normal"
                          >
                            {san}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-600">No alternate domains registered.</span>
                      )}
                    </div>
                    <span className="text-[9.5px] text-slate-605 mt-1.5 block text-right font-mono text-slate-600">
                      Total names: {sslResult.peerCert.sans ? sslResult.peerCert.sans.length : 0} parsed records.
                    </span>
                  </div>

                  {/* Raw Cert properties */}
                  <div className="pt-2">
                    <span className="text-[10px] text-slate-500 block font-mono uppercase mb-1.5">CERTIFICATE COMPLIANCE FINGERPRINTS</span>
                    <div className="p-3 bg-slate-950 border border-slate-900 rounded space-y-2 text-[10.5px] font-mono select-all">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-900 pb-1.5 last:border-0 last:pb-0">
                        <span className="text-slate-500">SERIAL NUMBER:</span>
                        <span className="text-amber-500 font-bold break-all select-all">{sslResult.peerCert.serialNumber || "N/A"}</span>
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <span className="text-slate-500">SHA256 FINGERPRINT:</span>
                        <span className="text-emerald-400 font-bold break-all select-all font-mono leading-tight">{sslResult.peerCert.fingerprint || "N/A"}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right TLS Compliance Status card */}
                <div className="space-y-4">
                  <div className="bg-slate-950/60 border border-slate-900 rounded p-5 space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-900 pb-2">
                      <FileBadge className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-mono font-bold text-slate-100">EXPIRATION & FAULT INVENTORY</span>
                    </div>

                    <div className="text-xs font-mono space-y-3.5">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block">CERTIFICATE STATUS</span>
                        <div className="flex items-center gap-2 mt-1 select-none">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                            sslResult.isValid && sslResult.daysRemaining > 0
                              ? "bg-emerald-950/20 text-emerald-400 border-emerald-900"
                              : "bg-red-950/20 text-red-500 border-red-900 animate-pulse"
                          }`}>
                            {sslResult.isValid && sslResult.daysRemaining > 0 ? "VALID CERTIFICATE" : "VERIFICATION FAULT"}
                          </span>
                        </div>
                      </div>

                      <div className="p-4 bg-slate-950/80 border border-slate-900 rounded text-center">
                        <span className="text-[10px] text-slate-500 uppercase block">REMAINING DAYS ACTIVE</span>
                        <div className={`text-2xl font-mono font-extrabold mt-1 ${
                          sslResult.daysRemaining <= 14 ? "text-red-500" : "text-emerald-400"
                        }`}>
                          {sslResult.daysRemaining} Days
                        </div>
                        <span className="text-[9px] text-slate-500 block mt-1 uppercase">
                          {sslResult.daysRemaining <= 0 ? "EXPIRED CERTIFICATE" : "UNTIL RENEWAL RE-VALIDATION"}
                        </span>
                      </div>

                      {sslResult.errorMessage && (
                        <div className="p-3 bg-red-950/20 border border-red-900/60 text-red-400 rounded leading-relaxed text-[11px]">
                          <span className="font-bold block text-red-500 uppercase">Warning Error Flag:</span>
                          {sslResult.errorMessage}
                        </div>
                      )}

                      <div className="bg-slate-900/30 p-2.5 rounded text-[10px] text-slate-500 leading-normal border border-slate-900">
                        SSL/TLS handshakes verify the authentication trust of hostname endpoints. Observers mapping target server configurations must monitor rapid expiration flags and mismatches in Subject Alternative Names (SANs) to identify malicious DNS spoofing or certificate takeover anomalies.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
