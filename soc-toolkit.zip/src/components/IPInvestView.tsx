/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { IPAnalysisResult } from "../types";
import {
  Search,
  Shield,
  MapPin,
  Globe,
  Database,
  Terminal,
  Activity,
  AlertTriangle,
  UserCheck,
  Server,
  CloudLightning,
  AlertOctagon,
  CheckCircle,
  Copy,
  Check
} from "lucide-react";

interface IPInvestProps {
  onAddSearchLog: (log: { type: "IP" | "Domain" | "URL" | "Hash" | "Malware"; query: string; reputation: "clean" | "suspicious" | "malicious" | "unknown"; score?: number }) => void;
  initialQuery?: string;
}

// Helper to identify and label RFC private IP ranges
function checkPrivateIp(ipStr: string): { isPrivate: boolean; reason?: string; range?: string } {
  const clean = ipStr.trim();
  if (!clean) return { isPrivate: false };

  // IPv4 Pattern Match
  const ipv4Pattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const match = clean.match(ipv4Pattern);
  if (match) {
    const p1 = parseInt(match[1], 10);
    const p2 = parseInt(match[2], 10);
    const p3 = parseInt(match[3], 10);
    const p4 = parseInt(match[4], 10);

    if (p1 > 255 || p2 > 255 || p3 > 255 || p4 > 255) {
      return { isPrivate: false };
    }

    // RFC 1918 Private Ranges
    if (p1 === 10) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "10.0.0.0/8" };
    }
    if (p1 === 172 && p2 >= 16 && p2 <= 31) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "172.16.0.0/12" };
    }
    if (p1 === 192 && p2 === 168) {
      return { isPrivate: true, reason: "RFC 1918 Private Intranet Block", range: "192.168.0.0/16" };
    }
    
    // RFC 5735 / RFC 6890 Localhost/Loopback
    if (p1 === 127) {
      return { isPrivate: true, reason: "RFC 5735 Loopback Host Address", range: "127.0.0.0/8" };
    }
    
    // RFC 3927 Link-Local Block
    if (p1 === 169 && p2 === 254) {
      return { isPrivate: true, reason: "RFC 3927 Link-Local autoconfig address", range: "169.254.0.0/16" };
    }

    // RFC 6598 carrier-grade NAT
    if (p1 === 100 && p2 >= 64 && p2 <= 127) {
      return { isPrivate: true, reason: "RFC 6598 Shared Carrier-Grade NAT block", range: "100.64.0.0/10" };
    }

    // 0.0.0.0/8 Local System Network identifier
    if (p1 === 0) {
      return { isPrivate: true, reason: "Local Host identifier network", range: "0.0.0.0/8" };
    }

    // Broadcast
    if (p1 === 255 && p2 === 255 && p3 === 255 && p4 === 255) {
      return { isPrivate: true, reason: "RFC 919 Broadcast destination", range: "255.255.255.255/32" };
    }

    // RFC 5771 Multicast IP (Class D)
    if (p1 >= 224 && p1 <= 239) {
      return { isPrivate: true, reason: "RFC 5771 Multicast socket group", range: "224.0.0.0/4" };
    }

    // RFC 5737 Test nets
    if (p1 === 192 && p2 === 0 && p3 === 2) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-1", range: "192.0.2.0/24" };
    }
    if (p1 === 198 && p2 === 51 && p3 === 100) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-2", range: "198.51.100.0/24" };
    }
    if (p1 === 203 && p2 === 0 && p3 === 113) {
      return { isPrivate: true, reason: "RFC 5737 Documentation TEST-NET-3", range: "203.0.113.0/24" };
    }
  }

  // IPv6 Pattern check
  const cleanLower = clean.toLowerCase();
  if (cleanLower === "::1" || cleanLower === "0:0:0:0:0:0:0:1") {
    return { isPrivate: true, reason: "IPv6 RFC 4291 Loopback address", range: "::1/128" };
  }
  if (cleanLower === "::" || cleanLower === "0:0:0:0:0:0:0:0") {
    return { isPrivate: true, reason: "IPv6 Unspecified address range", range: "::/128" };
  }
  if (cleanLower.startsWith("fc") || cleanLower.startsWith("fd")) {
    return { isPrivate: true, reason: "RFC 4193 Unique Local Address (ULA) Space", range: "fc00::/7" };
  }
  if (cleanLower.startsWith("fe8") || cleanLower.startsWith("fe9") || cleanLower.startsWith("fea") || cleanLower.startsWith("feb")) {
    return { isPrivate: true, reason: "RFC 4291 Link-Local Unicast address range", range: "fe80::/10" };
  }
  if (cleanLower.startsWith("ff")) {
    return { isPrivate: true, reason: "RFC 4291 Multicast IPv6 prefix group", range: "ff00::/8" };
  }

  return { isPrivate: false };
}

export default function IPInvestView({ onAddSearchLog, initialQuery = "" }: IPInvestProps) {
  const [ipInput, setIpInput] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<IPAnalysisResult | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "vpn-detect" | "threat-intel" | "reputation" | "history" | "json">("overview");
  const [copied, setCopied] = useState(false);

  // Reactive inline private IP checking
  const ipCheck = checkPrivateIp(ipInput);

  const handleSearch = async (targetIp: string) => {
    const trimmed = targetIp.trim();
    if (!trimmed) return;

    // Strict blockage on Private IP subnets
    const checkResult = checkPrivateIp(trimmed);
    if (checkResult.isPrivate) {
      setResult(null);
      return;
    }

    setLoading(true);
    try {
      const parsedKeys = {
        virustotal: localStorage.getItem("VT_API_KEY") || "",
        abuseipdb: localStorage.getItem("ABUSEIPDB_API_KEY") || "",
        greynoise: localStorage.getItem("GREYNOISE_API_KEY") || "",
        shodan: localStorage.getItem("SHODAN_API_KEY") || "",
        urlscan: localStorage.getItem("URLSCAN_API_KEY") || "",
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
        ipinfo: localStorage.getItem("IPINFO_API_KEY") || "",
        ip2proxy: localStorage.getItem("IP2PROXY_API_KEY") || "",
        ipqualityscore: localStorage.getItem("IPQUALITYSCORE_API_KEY") || "",
      };

      const response = await fetch("/api/enrich/ip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ip: trimmed, apiKeys: parsedKeys }),
      });

      if (response.ok) {
        const data: IPAnalysisResult = await response.json();
        setResult(data);

        // Map risk reputation type
        let rep: "clean" | "suspicious" | "malicious" = "clean";
        if (data.riskScore > 75) rep = "malicious";
        else if (data.riskScore > 35) rep = "suspicious";

        onAddSearchLog({
          type: "IP",
          query: trimmed,
          reputation: rep,
          score: data.riskScore
        });
      }
    } catch (err) {
      console.error("IP lookup failure:", err);
    } finally {
      setLoading(false);
    }
  };

  const executeCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Search Bar */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1">
          IP ENRICHMENT ENGINE
        </h2>
        <p className="text-xs text-slate-500 font-mono mb-4 leading-sm">
          Run deep metadata correlation against VirusTotal, AbuseIPDB, Shodan, AlienVault OTX, and GreyNoise.
        </p>

        <div className="flex gap-2 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              id="ip-investigate-input"
              type="text"
              placeholder="Enter target IPv4 (e.g., 185.112.146.22)..."
              value={ipInput}
              onChange={(e) => setIpInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !ipCheck.isPrivate && handleSearch(ipInput)}
              className={`w-full bg-slate-950 border focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600 transition-all ${
                ipCheck.isPrivate
                  ? "border-amber-500/60 focus:border-amber-500 text-amber-200"
                  : "border-slate-850 focus:border-red-500"
              }`}
            />
          </div>
          <button
            onClick={() => handleSearch(ipInput)}
            disabled={loading || ipCheck.isPrivate}
            className={`px-5 py-2 rounded text-xs font-mono transition font-bold cursor-pointer disabled:opacity-50 ${
              ipCheck.isPrivate
                ? "bg-slate-900/60 border border-slate-800 text-slate-500 cursor-not-allowed"
                : "bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400"
            }`}
          >
            {loading ? "CORRELATING..." : ipCheck.isPrivate ? "BLOCKED" : "RUN ANALYSIS"}
          </button>
        </div>

        {/* Dynamic Private IP warning alert banner */}
        {ipCheck.isPrivate && (
          <div className="mt-4 p-3.5 bg-amber-950/20 border border-amber-900/60 rounded flex items-start gap-3 animate-fade-in relative overflow-hidden">
            <div className="absolute top-0 bottom-0 left-0 w-1 bg-amber-500" />
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="font-mono text-[11px] text-amber-200 space-y-1 bg-transparent">
              <div className="flex items-center gap-2">
                <span className="font-bold uppercase text-amber-400 font-mono tracking-wide">[DETECTION ALERT: LOCAL SUBNET RANGE]</span>
                <span className="bg-amber-950 border border-amber-900 px-1.5 py-0.2 rounded text-[9.5px] text-amber-300 font-bold select-all">
                  {ipCheck.range}
                </span>
              </div>
              <p className="text-slate-400 font-sans leading-relaxed text-[11.5px] pt-1">
                The identifier <strong className="text-amber-200 select-all font-mono">{ipInput.trim()}</strong> belongs to the <strong>{ipCheck.reason}</strong> category. Search is disabled because querying public threat intelligence platforms or RBL catalogs for private subnets is non-productive, returns zero active reputation, and risks disclosing network design layout configurations.
              </p>
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
          <div className="relative flex h-8 w-8">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-8 w-8 bg-red-600"></span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Consulting threat intelligence nodes...
          </span>
        </div>
      )}

      {result && !loading && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          {/* Left Column: Summary Card */}
          <div className="space-y-4">
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
              {/* Dynamic Risk Color Accents */}
              <div className={`absolute top-0 left-0 right-0 h-1 ${
                result.riskScore > 75 ? "bg-red-500" : result.riskScore > 35 ? "bg-orange-500" : "bg-emerald-500"
              }`} />

              <div className="flex justify-between items-center mb-4 text-slate-100">
                <span className="text-xs font-mono font-bold tracking-tight">
                  TARGET REPORT
                </span>
                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase ${
                  result.riskScore > 75 ? "bg-red-950 text-red-400 border-red-950" :
                  result.riskScore > 35 ? "bg-orange-950 text-orange-400 border-orange-950" :
                  "bg-emerald-950 text-emerald-400 border-emerald-950"
                }`}>
                  {result.riskScore > 75 ? "MALICIOUS" : result.riskScore > 35 ? "SUSPICIOUS" : "CLEAN"}
                </span>
              </div>

              {/* Radial or Big Risk Indicator */}
              <div className="flex flex-col items-center justify-center py-6 border-b border-slate-900/60 mb-4 bg-slate-950/30 rounded">
                <span className="text-[10px] font-mono text-slate-500 tracking-wider">
                  THREAT REPUTATION INDEX
                </span>
                <span className={`text-5xl font-mono font-extrabold mt-1 tracking-tight ${
                  result.riskScore > 75 ? "text-red-500" : result.riskScore > 35 ? "text-orange-500" : "text-emerald-500"
                }`}>
                  {result.riskScore}/100
                </span>
                <span className="text-[10px] font-mono text-slate-550 italic mt-1 leading-xs max-w-xs text-center px-4">
                  Aggregated risk from {result.reputation.abuseipdb?.reportedCount || 0} external reports.
                </span>
              </div>

              {/* Host Identifications */}
              <div className="space-y-3 font-mono text-[11px]">
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">IP ADDRESS:</span>
                  <span className="text-slate-350 font-bold">{result.ip}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">COUNTRY:</span>
                  <span className="text-slate-200 flex items-center gap-1">
                    <span className="text-slate-400 text-[10px] bg-slate-900 px-1 py-0.5 rounded border border-slate-800 uppercase font-bold">
                      {result.countryCode}
                    </span>
                    {result.country}
                  </span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">ASN LOGS:</span>
                  <span className="text-slate-350 text-right truncate max-w-[160px]">{result.asn}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">ISP ENTITY:</span>
                  <span className="text-slate-300 text-right truncate max-w-[160px]">{result.isp}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">ABUSE SCORE:</span>
                  <span className={`font-bold ${result.abuseScore > 50 ? "text-red-400" : "text-slate-400"}`}>
                    {result.abuseScore}%
                  </span>
                </div>
              </div>

              {/* Advanced Network Detection indicators */}
              <div className="grid grid-cols-3 gap-2 mt-4 font-mono text-[9px] text-center">
                <div className={`p-2 rounded border ${result.vpn ? "bg-orange-950/20 text-orange-400 border-orange-900/50" : "bg-slate-950 text-slate-600 border-slate-900"}`}>
                  <span className="block font-bold">VPN</span>
                  <span className="text-[10px] mt-0.5 block">{result.vpn ? "DETECTED" : "NO"}</span>
                </div>
                <div className={`p-2 rounded border ${result.proxy ? "bg-orange-950/20 text-orange-400 border-orange-900/50" : "bg-slate-950 text-slate-600 border-slate-900"}`}>
                  <span className="block font-bold">PROXY</span>
                  <span className="text-[10px] mt-0.5 block">{result.proxy ? "DETECTED" : "NO"}</span>
                </div>
                <div className={`p-2 rounded border ${result.tor ? "bg-red-950/20 text-red-400 border-red-900/50" : "bg-slate-950 text-slate-600 border-slate-900"}`}>
                  <span className="block font-bold">TOR INGRESS</span>
                  <span className="text-[10px] mt-0.5 block">{result.tor ? "ACTIVE" : "NO"}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Columns: Multi-Tab Detail Page */}
          <div className="lg:col-span-2 bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded flex flex-col h-full min-h-[460px]">
            {/* Header tab navigation */}
            <div className="flex border-b border-slate-900 bg-slate-950/95 p-1 select-none flex-wrap">
              {(["overview", "vpn-detect", "threat-intel", "reputation", "history", "json"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 font-mono text-[10px] uppercase font-bold tracking-wider transition border-b-2 cursor-pointer ${
                    activeTab === tab
                      ? "text-red-400 border-red-500 bg-slate-900/40"
                      : "text-slate-500 border-transparent hover:text-slate-300"
                  }`}
                >
                  {tab === "vpn-detect" ? "VPN/Proxy Intelligence" : tab}
                </button>
              ))}
            </div>

            {/* Content area based on selected tab */}
            <div className="p-5 flex-1 overflow-y-auto">
              {activeTab === "vpn-detect" && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2 mb-1">
                      <Shield className="w-4 h-4 text-blue-400" />
                      VPN & Proxy Tunnelling Intelligence
                    </h3>
                    <p className="text-[11px] font-mono text-slate-500 leading-sm">
                      Autonomous validation of IP hosting parameters, residential proxy scoring, and commercial VPN tunnels.
                    </p>
                  </div>

                  {/* High Level VPN Banner */}
                  <div className={`p-4 rounded border font-mono text-xs flex items-center justify-between gap-4 ${
                    result.vpn || result.vpnDetails?.isVpn
                      ? "bg-red-950/20 text-red-400 border-red-900/60"
                      : result.proxy || result.tor
                      ? "bg-orange-950/20 text-orange-400 border-orange-900/60"
                      : "bg-emerald-950/20 text-emerald-400 border-emerald-900/60"
                  }`}>
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase text-slate-500 font-bold block">TUNNEL CLASSIFICATION</span>
                      <div className="text-sm font-bold flex items-center gap-2">
                        {result.vpn || result.vpnDetails?.isVpn ? (
                          <>
                            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 animate-pulse" />
                            COMMERCIAL VPN SUB-NETWORK DETECTED
                          </>
                        ) : result.proxy ? (
                          <>
                            <AlertOctagon className="w-4 h-4 text-orange-400 shrink-0" />
                            RESIDENTIAL/ANONYMOUS PROXY INGRESS
                          </>
                        ) : result.tor ? (
                          <>
                            <AlertOctagon className="w-4 h-4 text-purple-400 shrink-0" />
                            ACTIVE TOR EXIT RELAY GATEWAY
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                            CLEAN CONNECTION: DIRECT RESIDENTIAL / INSTITUTIONAL ISP
                          </>
                        )}
                      </div>
                    </div>
                    {(result.vpnDetails?.confidenceScore !== undefined || result.vpn) && (
                      <div className="text-center bg-slate-950 p-2.5 rounded border border-slate-900 shrink-0">
                        <span className="text-[9px] uppercase text-slate-500">CONFIDENCE</span>
                        <div className="text-lg font-bold">
                          {result.vpnDetails?.confidenceScore ?? (result.vpn ? 95 : 0)}%
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Structured Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-3 font-mono text-[11px]">
                      <h4 className="text-[10px] font-bold text-slate-350 uppercase border-b border-slate-900 pb-2 flex items-center gap-2 font-mono">
                        <Globe className="w-3.5 h-3.5 text-blue-400" />
                        Network Attributes
                      </h4>

                      <div className="flex justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">VPN Provider/Network:</span>
                        <span className="text-slate-300 font-semibold">
                          {result.vpnDetails?.provider || (result.vpn ? "Commercial Proxy Service" : "N/A")}
                        </span>
                      </div>

                      <div className="flex justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">Proxy Protocol/Type:</span>
                        <span className="text-slate-300 font-semibold">
                          {result.vpnDetails?.proxyType || (result.proxy ? "SOCKS/HTTP Tunnel" : "N/A")}
                        </span>
                      </div>

                      <div className="flex justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">Connection Category:</span>
                        <span className="text-slate-300 font-semibold">
                          {result.vpnDetails?.connectionType || (result.hosting ? "Hosting Server / Cloud" : "Standard ISP")}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-500">Confidence Rating:</span>
                        <span className={`font-semibold ${
                          (result.vpnDetails?.confidenceScore ?? 0) > 70 ? "text-red-400" : "text-emerald-400"
                        }`}>
                          {result.vpnDetails?.confidenceScore !== undefined ? `${result.vpnDetails.confidenceScore}%` : result.vpn ? "High" : "None"}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-3 font-mono text-[11px]">
                      <h4 className="text-[10px] font-bold text-slate-350 uppercase border-b border-slate-900 pb-2 flex items-center gap-2 font-mono">
                        <Server className="w-3.5 h-3.5 text-orange-400" />
                        Routing & Tunnel Checks
                      </h4>

                      <div className="flex items-center justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">Vaporized / Virtual Server (Hosting):</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          result.hosting ? "bg-amber-95/20 text-amber-400 border border-amber-900" : "bg-slate-900 text-slate-500"
                        }`}>
                          {result.hosting ? "YES" : "NO"}
                        </span>
                      </div>

                      <div className="flex items-center justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">Commercial VPN Range Match:</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          result.vpn || result.vpnDetails?.isVpn ? "bg-red-95/20 text-red-450 border border-red-900" : "bg-slate-900 text-slate-500"
                        }`}>
                          {(result.vpn || result.vpnDetails?.isVpn) ? "FLAGGED" : "CLEAN"}
                        </span>
                      </div>

                      <div className="flex items-center justify-between border-b border-slate-900/40 pb-2">
                        <span className="text-slate-500">Anonymous Proxy Gateway:</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          result.proxy ? "bg-orange-950 text-orange-400 border border-orange-900" : "bg-slate-900 text-slate-500"
                        }`}>
                          {result.proxy ? "YES" : "NO"}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Tor Exit Node Gateway:</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          result.tor ? "bg-purple-950 text-purple-400 border border-purple-900" : "bg-slate-900 text-slate-500"
                        }`}>
                          {result.tor ? "ACTIVE" : "NO"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-950/40 border border-slate-900 p-3.5 rounded text-[10px] font-mono text-slate-500 leading-normal">
                    <span className="font-bold text-slate-400 uppercase block mb-1">🔍 SOC ANALYST NOTATION</span>
                    VPN and proxy metadata checks query both static commercial ranges (MaxMind, IP2Location) and dynamically observed threat feeds in real time. Known secure tunnels used by corporate proxies may register flags. Compare ISP name vs billing country to confirm local spoofing patterns.
                  </div>
                </div>
              )}

              {activeTab === "overview" && (
                <div className="space-y-6">
                  {/* Forensic Asset Overview */}
                  <div className="space-y-3">
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                      <Activity className="w-4 h-4 text-red-500" />
                      Forensic Asset Overview
                    </h3>
                    <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-3 font-mono text-[11px] leading-sm">
                      <div>
                        <span className="text-slate-500 block text-[9px] mb-0.5 uppercase">Threat Description</span>
                        <p className="text-slate-350">{result.threatIntelligence.description}</p>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[9px] mb-0.5 uppercase font-semibold">Active Flag Annotations</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {result.threatIntelligence.threatTypes.length > 0 ? (
                            result.threatIntelligence.threatTypes.map((t, i) => (
                              <span key={i} className="bg-red-950/30 text-red-400 border border-red-900 text-[10px] px-2 py-0.5 rounded font-mono">
                                {t}
                              </span>
                            ))
                          ) : (
                            <span className="text-emerald-500 text-[10px]">No malicious threat category alerts active.</span>
                          )}
                        </div>
                      </div>
                      {result.threatIntelligence.malwareFamilies.length > 0 && (
                        <div>
                          <span className="text-slate-500 block text-[9px] mb-0.5 uppercase font-semibold">Associated Malware Vectors</span>
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {result.threatIntelligence.malwareFamilies.map((fam, i) => (
                              <span key={i} className="bg-orange-950/30 text-orange-400 border border-orange-900 text-[10px] px-2 py-0.5 rounded font-mono font-bold">
                                {fam}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Real-time Web Grounding & APT Association */}
                  <div className="space-y-3 pt-2">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                        <Globe className="w-4 h-4 text-blue-400" />
                        AI web discovery & threat associations
                      </h3>
                      <span className="text-[9px] bg-slate-900 border border-slate-800 text-blue-400 font-mono px-2 py-0.5 rounded flex items-center gap-1">
                        <Search className="w-3 h-3 text-blue-450 shrink-0" />
                        Google Grounding Active
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Threat Actor/APT Block */}
                      <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                        <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                          <UserCheck className="w-4 h-4 text-orange-450" />
                          Associated APT & Threat Actor Groups
                        </div>
                        {result.threatActors && result.threatActors.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {result.threatActors.map((actor, idx) => (
                              <span key={idx} className="bg-orange-950/40 text-orange-400 border border-orange-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                                {actor}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <p className="text-slate-500 text-[10px] italic">No Advanced Persistent Threat (APT) groups directly associated with this IOC in the wild.</p>
                        )}
                      </div>

                      {/* Malware / Trojan / Virus Type Block */}
                      <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                        <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                          <CloudLightning className="w-4 h-4 text-red-400" />
                          Associated Malware, Trojans & Viruses
                        </div>
                        {result.malwareAssociations && result.malwareAssociations.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {result.malwareAssociations.map((malware, idx) => (
                              <span key={idx} className="bg-red-950/40 text-red-400 border border-red-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                                {malware}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <p className="text-slate-500 text-[10px] italic">No active structural Trojan, worm, or ransomware profiles linked with this IOC.</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* MITRE ATT&CK Mapping Segment */}
                  <div className="space-y-3 pt-2">
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-amber-500" />
                      MITRE ATT&CK TACTICS & TECHNIQUES MAPPED
                    </h3>

                    {result.mitreMappings && result.mitreMappings.length > 0 ? (
                      <div className="space-y-2">
                        {result.mitreMappings.map((mapping, idx) => (
                          <div key={idx} className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px]">
                            <div className="flex justify-between items-start mb-1.5">
                              <div className="flex items-center gap-2">
                                <span className="bg-amber-950 text-amber-400 border border-amber-900/60 font-bold text-[10px] px-2 py-0.5 rounded">
                                  {mapping.id}
                                </span>
                                <span className="text-slate-250 font-bold font-mono text-xs">{mapping.name}</span>
                              </div>
                              <span className="text-[10px] text-slate-500 uppercase tracking-wide font-semibold">
                                TACTIC: {mapping.tactic}
                              </span>
                            </div>
                            <p className="text-slate-400 text-[11px] leading-normal">{mapping.description}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] text-slate-500 italic">
                        No active TTP techniques dynamically mapped to this target asset.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === "threat-intel" && (
                <div className="space-y-4">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    Autonomous Threat Intelligence Nodes (GreyNoise / Shodan)
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* GreyNoise sensor logs */}
                    <div className="bg-slate-950 p-4 border border-slate-900/80 rounded space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                        <span className="font-mono text-xs text-slate-300 font-bold">GreyNoise Sensor</span>
                        <span className={`text-[8px] px-1 rounded ${result.reputation.greynoise?.classification === "malicious" ? "bg-red-950 text-red-400" : "bg-emerald-950 text-emerald-400"}`}>
                          {result.reputation.greynoise?.classification.toUpperCase() || "BENIGN"}
                        </span>
                      </div>
                      <div className="space-y-2 font-mono text-[10px]">
                        <div className="flex justify-between">
                          <span className="text-slate-500">ATTRIBUTED ACTOR:</span>
                          <span className="text-slate-300">{result.reputation.greynoise?.actor || "Unknown"}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block mb-1">SCANNING COGNITIVE TAGS:</span>
                          <div className="flex flex-wrap gap-1">
                            {result.reputation.greynoise?.tags?.map((t, idx) => (
                              <span key={idx} className="bg-slate-900 text-slate-300 border border-slate-800 px-1 rounded">
                                {t}
                              </span>
                            )) || <span className="text-slate-600">None detected</span>}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Shodan passive scans */}
                    <div className="bg-slate-950 p-4 border border-slate-900/80 rounded space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                        <span className="font-mono text-xs text-slate-300 font-bold">Shodan Network Profile</span>
                        <span className="text-[10px] text-slate-500 uppercase">PORT SCANNER</span>
                      </div>
                      <div className="space-y-2 font-mono text-[10px]">
                        <div className="flex justify-between">
                          <span className="text-slate-500">DETECTED OS:</span>
                          <span className="text-slate-300">{result.reputation.shodan?.os || "Unknown Core"}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block mb-1">ACTIVE OPEN PORTS:</span>
                          <div className="flex flex-wrap gap-1">
                            {result.reputation.shodan?.ports?.map((p, idx) => (
                              <span key={idx} className="bg-orange-950 text-orange-400 border border-orange-950 px-1 rounded font-bold">
                                {p}
                              </span>
                            )) || <span className="text-slate-650">No ports</span>}
                          </div>
                        </div>
                        {result.reputation.shodan?.vulnerabilities && (
                          <div>
                            <span className="text-slate-500 block mb-1">CVE VULNERS:</span>
                            <div className="flex flex-wrap gap-1">
                              {result.reputation.shodan.vulnerabilities.map((v, idx) => (
                                <span key={idx} className="bg-red-950 text-red-400 border border-red-900 px-1 rounded">
                                  {v}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "reputation" && (
                <div className="space-y-4">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-4 h-4 text-red-500" />
                    Reputation Feeds & Blacklists
                  </h3>

                  <div className="space-y-3 font-mono text-xs">
                    {/* AbuseIPDB Report */}
                    {result.reputation.abuseipdb && (
                      <div className="bg-slate-950 p-4 border border-slate-900 rounded flex justify-between items-center">
                        <div>
                          <h4 className="font-bold text-slate-300">AbuseIPDB Verified Index</h4>
                          <span className="text-[10px] text-slate-500 block">Reports: {result.reputation.abuseipdb.reportedCount} occurrences</span>
                        </div>
                        <div className="text-right">
                          <span className="text-lg font-bold text-red-400">{result.reputation.abuseipdb.score}%</span>
                        </div>
                      </div>
                    )}

                    {/* VirusTotal lookup indicators */}
                    {result.reputation.virustotal && (
                      <div className="bg-slate-950 p-4 border border-slate-900 rounded flex justify-between items-center">
                        <div>
                          <h4 className="font-bold text-slate-300">VirusTotal Multi-Engine Scoring</h4>
                          <span className="text-[10px] text-slate-500 block">Verified checks count: {result.reputation.virustotal.total}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-lg font-bold text-red-400">
                            {result.reputation.virustotal.malicious} / {result.reputation.virustotal.total} engines flagging
                          </span>
                        </div>
                      </div>
                    )}

                    {/* AlienVault OTX */}
                    {result.reputation.otx && (
                      <div className="bg-slate-955 p-4 border border-slate-900 rounded flex justify-between items-center">
                        <div>
                          <h4 className="font-bold text-slate-300">AlienVault Open Threat Exchange</h4>
                          <span className="text-[10px] text-slate-550 block">Pulses associated with this address</span>
                        </div>
                        <div className="text-right font-semibold">
                          <span className="text-blue-400">{result.reputation.otx.pulseCount} active pulses</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === "history" && (
                <div className="space-y-4">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                    Historical Investigation Records Cached
                  </h3>

                  <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                    <table className="w-full text-left font-mono text-[11px] select-none">
                      <thead>
                        <tr className="bg-slate-950/90 text-slate-500 border-b border-slate-900">
                          <th className="p-3 uppercase">Timestamp</th>
                          <th className="p-3 uppercase">Trigger Event</th>
                          <th className="p-3 uppercase">Intelligence Source</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60">
                        {result.historicalData.map((item, i) => (
                          <tr key={i} className="hover:bg-slate-900/20">
                            <td className="p-3 text-slate-400">{item.date}</td>
                            <td className="p-3 font-semibold text-slate-305">{item.activityType}</td>
                            <td className="p-3 text-slate-500">{item.source}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === "json" && (
                <div className="space-y-2 h-full flex flex-col">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] font-mono text-slate-500">FORRENSIC ATTRIBUTES STRUCTURE</span>
                    <button
                      onClick={executeCopy}
                      className="flex items-center gap-1.5 text-[10px] font-mono text-blue-400 hover:text-blue-300 bg-slate-900 border border-slate-800 px-2 py-1 rounded cursor-pointer"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {copied ? "COPIED" : "COPY RAW JSON"}
                    </button>
                  </div>
                  <pre className="p-4 bg-slate-950 border border-slate-900/80 rounded font-mono text-[10px] text-emerald-400 overflow-x-auto max-h-[340px] flex-1">
                    {result.rawJson}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
