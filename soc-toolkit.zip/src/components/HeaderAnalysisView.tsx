/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Mail, Globe, Clock, ShieldCheck, CheckCircle2, AlertOctagon, Terminal, HelpCircle, Copy, Check, Search, ListFilter, AlertTriangle, ArrowDownRight, Paperclip, Link2, ExternalLink, File, Sparkles, ShieldAlert } from "lucide-react";

interface HeaderHop {
  hopIndex: number;
  fromHost: string;
  fromIp: string;
  byHost: string;
  protocol: string;
  timestamp: string;
  delayText: string;
}

interface AuthenticationStatus {
  spf: "PASS" | "FAIL" | "NONE" | "SOFTFAIL";
  dkim: "PASS" | "FAIL" | "NONE";
  dmarc: "PASS" | "FAIL" | "NONE";
  spfDetails: string;
  dkimDetails: string;
  dmarcDetails: string;
}

interface ExtractedUrl {
  url: string;
  domain: string;
}

interface ExtractedAttachment {
  filename: string;
  contentType: string;
  disposition: string;
  sizeText?: string;
}

interface ParsedHeader {
  subject: string;
  from: string;
  to: string;
  date: string;
  messageId: string;
  returnPath: string;
  replyTo: string;
  mailer: string;
  contentType: string;
  auth: AuthenticationStatus;
  hops: HeaderHop[];
  allFields: { key: string; value: string }[];
  urls: ExtractedUrl[];
  attachments: ExtractedAttachment[];
  aiAnalysis?: {
    summary: string;
    classification: string;
    confidenceScore: number;
    threatIndicators: string[];
    bodyAnalysis: string;
    senderAuthenticity: string;
    remediation: string;
  };
}

export default function HeaderAnalysisView() {
  const [headerInput, setHeaderInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [parsed, setParsed] = useState<ParsedHeader | null>(null);
  const [fieldSearch, setFieldSearch] = useState("");
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  // Core Javascript Email Header Parser
  const parseEmailHeaders = (raw: string): ParsedHeader => {
    const lines = raw.split(/\r?\n/);
    const foldedLines: string[] = [];
    
    // Unfold multi-line email headers (lines starting with space/tab belong to previous header)
    for (const line of lines) {
      if (line.match(/^[ \t]/) && foldedLines.length > 0) {
        foldedLines[foldedLines.length - 1] += " " + line.trim();
      } else {
        foldedLines.push(line.trim());
      }
    }

    const allFields: { key: string; value: string }[] = [];
    const fieldsMap: Record<string, string[]> = {};

    for (const line of foldedLines) {
      const match = line.match(/^([^:]+):\s*(.*)$/);
      if (match) {
        const key = match[1].trim();
        const value = match[2].trim();
        allFields.push({ key, value });
        
        const lowerKey = key.toLowerCase();
        if (!fieldsMap[lowerKey]) {
          fieldsMap[lowerKey] = [];
        }
        fieldsMap[lowerKey].push(value);
      }
    }

    // Get basic metadata elements
    const getFirst = (key: string) => (fieldsMap[key] ? fieldsMap[key][0] : "N/A");

    const subject = getFirst("subject");
    const from = getFirst("from");
    const to = getFirst("to");
    const date = getFirst("date");
    const messageId = getFirst("message-id");
    const returnPath = getFirst("return-path");
    const replyTo = getFirst("reply-to");
    const mailer = getFirst("x-mailer") === "N/A" ? getFirst("user-agent") : getFirst("x-mailer");
    const contentType = getFirst("content-type");

    // Compute SPF / DKIM / DMARC authentication assessments based on records or Authentication-Results header
    const authResults = fieldsMap["authentication-results"]?.join(" ") || fieldsMap["arc-authentication-results"]?.join(" ") || "";
    
    let spf: "PASS" | "FAIL" | "NONE" | "SOFTFAIL" = "NONE";
    let spfDetails = "No authentication results header found.";
    let dkim: "PASS" | "FAIL" | "NONE" = "NONE";
    let dkimDetails = "No DKIM signature block validated.";
    let dmarc: "PASS" | "FAIL" | "NONE" = "NONE";
    let dmarcDetails = "No Aligning DMARC policies evaluated.";

    // Parse SPF
    if (authResults) {
      if (authResults.includes("spf=pass") || authResults.includes("spf=pass")) {
        spf = "PASS";
        spfDetails = "Domain sender verified with authorizing SPF network boundary.";
      } else if (authResults.includes("spf=fail")) {
        spf = "FAIL";
        spfDetails = "Target email IP mismatches active SPF server definitions.";
      } else if (authResults.includes("spf=softfail")) {
        spf = "SOFTFAIL";
        spfDetails = "SPF Softfail classification - suspicious origin.";
      }
    } else if (fieldsMap["received-spf"]) {
      const spfHeader = fieldsMap["received-spf"][0].toLowerCase();
      if (spfHeader.includes("pass")) {
        spf = "PASS";
        spfDetails = "Validated by direct Received-SPF status.";
      } else if (spfHeader.includes("fail")) {
        spf = "FAIL";
        spfDetails = "Direct Received-SPF validation failure.";
      }
    }

    // Parse DKIM
    if (fieldsMap["dkim-signature"]) {
      dkim = "PASS";
      dkimDetails = "Cryptographic DKIM signature present and verifiable.";
      if (authResults) {
        if (authResults.includes("dkim=fail")) {
          dkim = "FAIL";
          dkimDetails = "DKIM cryptographic signature check failed alignment.";
        }
      }
    }

    // Parse DMARC
    if (authResults) {
      if (authResults.includes("dmarc=pass")) {
        dmarc = "PASS";
        dmarcDetails = "DKIM and SPF records achieve structural target alignment.";
      } else if (authResults.includes("dmarc=fail")) {
        dmarc = "FAIL";
        dmarcDetails = "Structural dmarc fail policy matching triggered.";
      }
    }

    // Parse Transit Received: headers Hops
    const receivedHeaders = fieldsMap["received"] || [];
    const hops: HeaderHop[] = [];

    receivedHeaders.forEach((rec, idx) => {
      // Received format example:
      // from mail-wm1-f52.google.com (mail-wm1-f52.google.com [209.85.128.52]) by mx.google.com with ESMTPS id ...; Sat, 14 Jun 2026 00:30:15 -0700
      let fromHost = "N/A";
      let fromIp = "N/A";
      let byHost = "N/A";
      let protocol = "SMTP";
      let timestamp = "N/A";

      // Extract "from <host>"
      const fromMatch = rec.match(/from\s+([^\s]+)/i);
      if (fromMatch && fromMatch[1]) {
        fromHost = fromMatch[1];
      }

      // Extract IP within brackets e.g. [209.85.128.52]
      const ipMatch = rec.match(/\[([0-9a-fA-F.:]+)\]/);
      if (ipMatch && ipMatch[1]) {
        fromIp = ipMatch[1];
      }

      // Extract "by <host>"
      const byMatch = rec.match(/by\s+([^\s]+)/i);
      if (byMatch && byMatch[1]) {
        byHost = byMatch[1];
      }

      // Extract "with <protocol>"
      const protoMatch = rec.match(/with\s+([a-zA-Z0-9_-]+)/i);
      if (protoMatch && protoMatch[1]) {
        protocol = protoMatch[1];
      }

      // Extract timestamp after semicolon ";"
      const semiIdx = rec.lastIndexOf(";");
      if (semiIdx !== -1) {
        timestamp = rec.substring(semiIdx + 1).trim();
      }

      hops.push({
        hopIndex: receivedHeaders.length - idx, // Hop 1 is the oldest
        fromHost,
        fromIp,
        byHost,
        protocol,
        timestamp,
        delayText: idx === receivedHeaders.length - 1 ? "Start" : "Calculating..."
      });
    });

    // Sort hops chronologically (oldest hop 1 starts)
    hops.sort((a, b) => a.hopIndex - b.hopIndex);

    // Calculate approximate hop delays if feasible
    for (let i = 1; i < hops.length; i++) {
      try {
        const timePrev = Date.parse(hops[i - 1].timestamp);
        const timeCurr = Date.parse(hops[i].timestamp);
        if (!isNaN(timePrev) && !isNaN(timeCurr)) {
          const diffMs = timeCurr - timePrev;
          if (diffMs < 0) {
            hops[i].delayText = "0s (Sync discrepancy)";
          } else {
            const diffSec = Math.round(diffMs / 1000);
            if (diffSec < 60) {
              hops[i].delayText = `${diffSec}s`;
            } else {
              hops[i].delayText = `${Math.floor(diffSec / 60)}m ${diffSec % 60}s`;
            }
          }
        } else {
          hops[i].delayText = "N/A";
        }
      } catch {
        hops[i].delayText = "N/A";
      }
    }

    // Extract unique URLs from the raw email text
    const urlRegex = /(https?:\/\/[^\s"'<>`()[\]{}|\\^+]+)/gi;
    const matches = raw.match(urlRegex) || [];
    const urls: ExtractedUrl[] = [];
    const seenUrls = new Set<string>();

    for (let match of matches) {
      match = match.replace(/[.,;:!?'")\]}>]+$/, '');
      if (seenUrls.has(match)) continue;
      seenUrls.add(match);

      let domain = "N/A";
      try {
        const parsedUrl = new URL(match);
        domain = parsedUrl.hostname;
      } catch {
        const domainMatch = match.match(/https?:\/\/([^/:\s]+)/i);
        if (domainMatch) domain = domainMatch[1];
      }

      // Filter out XML namespaces or schema URLs which are noise
      if (domain.includes("w3.org") || domain.includes("schemas.microsoft.com") || domain.includes("xmlsoap.org") || domain.includes("schemas.openxmlformats.org")) {
        continue;
      }

      urls.push({ url: match, domain });
    }

    // Extract attachments from raw content
    const attachments: ExtractedAttachment[] = [];
    const rawContentLines = raw.split(/\r?\n/);
    
    let currentDisposition = "";
    let currentContentType = "";
    let currentFilename = "";
    let currentSize: string | undefined = undefined;

    for (let i = 0; i < rawContentLines.length; i++) {
      const line = rawContentLines[i].trim();
      const lowerLine = line.toLowerCase();
      
      if (lowerLine.startsWith("content-disposition:")) {
        currentDisposition = line.substring("content-disposition:".length).trim();
        const fnMatch = line.match(/filename=["']?([^"';]+)["']?/i);
        if (fnMatch) {
          currentFilename = fnMatch[1];
        }
        const sizeMatch = line.match(/size=(\d+)/i);
        if (sizeMatch) {
          const bytes = parseInt(sizeMatch[1], 10);
          if (bytes > 1024 * 1024) {
            currentSize = `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
          } else if (bytes > 1024) {
            currentSize = `${(bytes / 1024).toFixed(1)} KB`;
          } else {
            currentSize = `${bytes} B`;
          }
        }
      } else if (lowerLine.startsWith("content-type:")) {
        currentContentType = line.substring("content-type:".length).trim();
        const nameMatch = line.match(/name=["']?([^"';]+)["']?/i);
        if (nameMatch && !currentFilename) {
          currentFilename = nameMatch[1];
        }
      }
      
      if (line === "" || i === rawContentLines.length - 1) {
        if (currentFilename || (currentDisposition && currentDisposition.toLowerCase().includes("attachment"))) {
          let dispType = "attachment";
          if (currentDisposition.toLowerCase().includes("inline")) {
            dispType = "inline";
          }
          let cleanType = currentContentType.split(";")[0]?.trim() || "application/octet-stream";
          const nameToUse = currentFilename || "unnamed_attachment";
          
          if (!attachments.some(a => a.filename === nameToUse)) {
            attachments.push({
              filename: nameToUse,
              contentType: cleanType,
              disposition: dispType,
              sizeText: currentSize
            });
          }
          currentDisposition = "";
          currentContentType = "";
          currentFilename = "";
          currentSize = undefined;
        }
      }

      // Inline attachment filename headers fallback check
      if (lowerLine.includes("content-disposition") && lowerLine.includes("filename")) {
        const fnMatch = line.match(/filename=["']?([^"';]+)["']?/i);
        if (fnMatch) {
          const fname = fnMatch[1];
          if (!attachments.some(a => a.filename === fname)) {
            attachments.push({
              filename: fname,
              contentType: "application/octet-stream",
              disposition: "attachment"
            });
          }
        }
      }
    }

    // Secondary deep scan for filename keys
    if (attachments.length === 0) {
      const filenameRegex = /filename\s*=\s*["']?([^"'\r\n;]+)["']?/gi;
      let fMatch;
      while ((fMatch = filenameRegex.exec(raw)) !== null) {
        const fname = fMatch[1].trim();
        if (fname && !attachments.some(a => a.filename === fname) && !fname.includes("=")) {
          attachments.push({
            filename: fname,
            contentType: "application/octet-stream",
            disposition: "attachment"
          });
        }
      }
    }

    return {
      subject,
      from,
      to,
      date,
      messageId,
      returnPath,
      replyTo,
      mailer,
      contentType,
      auth: { spf, dkim, dmarc, spfDetails, dkimDetails, dmarcDetails },
      hops,
      allFields,
      urls,
      attachments
    };
  };

  const handleDeconstruct = async () => {
    if (!headerInput.trim()) return;
    setLoading(true);
    setAiLoading(true);
    
    // Parse client-side headers first for immediate visual feedback
    try {
      const result = parseEmailHeaders(headerInput);
      setParsed(result);
      setLoading(false); // Quick local parser finished

      // Fetch AI content enrichment & phishing assessment
      const parsedKeys = {
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      };

      const res = await fetch("/api/analyze/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawEmail: headerInput, apiKeys: parsedKeys })
      });

      if (res.ok) {
        const aiData = await res.json();
        setParsed(prev => prev ? { ...prev, aiAnalysis: aiData } : null);
      } else {
        throw new Error("AI Endpoint failed");
      }
    } catch (err) {
      console.error("Analysis exception:", err);
    } finally {
      setLoading(false);
      setAiLoading(false);
    }
  };

  const handleInjectSample = () => {
    const sample = `Delivered-To: administrator@cyber-defense.org
Received: by 2002:a05:6830:178b:b0:371:d593:4e66 with SMTP id v11csp1041924oag;
        Sat, 14 Jun 2026 00:15:22 -0750 (PDT)
X-Received: by 2002:a0c:e993:0:b0:6cc:f1c5:3b70 with SMTP id mz19mr722212ybb.12.1718345722119;
        Sat, 14 Jun 2026 00:15:22 -0700 (PDT)
ARC-Seal: i=1; a=rsa-sha256; t=1718345722; cv=none;
        d=google.com; s=arc-20160816;
        b=oK938rJ82...
ARC-Authentication-Results: i=1; mx.google.com;
       dkim=pass header.i=@malicious-campaign.ru header.s=key1 header.b=X928aF;
       spf=pass (google.com: domain of support@malicious-campaign.ru designates 185.156.74.52 as authorized sender) smtp.mailfrom=support@malicious-campaign.ru;
       dmarc=pass (p=NONE sp=NONE dis=NONE) header.from=malicious-campaign.ru
Return-Path: <support@malicious-campaign.ru>
Received: from mail.malicious-campaign.ru (mail.malicious-campaign.ru. [185.156.74.52])
        by mx.google.com with ESMTPS id o18si481021ybf.38.2026.06.14.00.15.20
        (version=TLS1_3 cipher=TLS_AES_256_GCM_SHA384 bits=256/256);
        Sat, 14 Jun 2026 00:15:21 -0700 (PDT)
Received-SPF: pass (google.com: domain of support@malicious-campaign.ru designates 185.156.74.52 as authorized sender) client-ip=185.156.74.52;
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
        d=malicious-campaign.ru; s=key1;
        h=from:to:subject:date:message-id:content-type:mime-version;
        bh=9A28fH2348A=;
        b=pA839dfSAD...
From: "Billing Security Center" <support@malicious-campaign.ru>
To: <administrator@cyber-defense.org>
Subject: CRITICAL: Immediate Wallet Authentication Required!
Date: Sat, 14 Jun 2026 10:15:02 +0300
Message-ID: <029df4819d4b$819a8f10$ad03e290@malicious-campaign.ru>
Content-Type: multipart/mixed; boundary="----=_NextPart_000_1234_ABCD"
MIME-Version: 1.0
Reply-To: <urgency-overlook@gmail.com>
X-Mailer: Microsoft Outlook 16.0
X-Priority: 1 (High)

------=_NextPart_000_1234_ABCD
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: quoted-printable

Dear Admin,
Your billing validation has encountered a problem. Please authenticate at:
https://billing-verification-portal.ru/auth/login

For general questions, see: https://cyber-defense-support.org/faq or the official docs on https://youtube.com/watch?v=dQw4w9WgXcQ

------=_NextPart_000_1234_ABCD
Content-Type: application/pdf; name="overdue_invoice_7162.pdf"
Content-Disposition: attachment; filename="overdue_invoice_7162.pdf"; size=148150
Content-Transfer-Encoding: base64

JVBERi0xLjQKJ...

------=_NextPart_000_1234_ABCD
Content-Type: application/octet-stream; name="credential_patch.exe"
Content-Disposition: attachment; filename="credential_patch.exe"; size=2844500
Content-Transfer-Encoding: base64

TVpG...
------=_NextPart_000_1234_ABCD--`;

    setHeaderInput(sample);
  };

  const executeCopyField = (val: string, idx: number) => {
    navigator.clipboard.writeText(val);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const filteredFields = parsed?.allFields.filter(f => 
    f.key.toLowerCase().includes(fieldSearch.toLowerCase()) || 
    f.value.toLowerCase().includes(fieldSearch.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page Title */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <Mail className="w-4 h-4 text-emerald-400" />
          MXTOOLBOX-STYLE EMAIL HEADER PARSER
        </h2>
        <p className="text-xs text-slate-550 font-mono">
          Deconstruct email metadata parameters, trace hop-by-hop latency routing delays, verify SPF/DKIM/DMARC server records, and neatly separate individual field key-value pairs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Input panel (1 column) */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-3.5 flex flex-col">
            <div className="flex justify-between items-center font-mono">
              <span className="text-[10px] font-bold text-slate-400 uppercase">RAW EMAIL HEADERS INPUT</span>
              <button 
                onClick={handleInjectSample}
                className="text-[10px] text-emerald-400 hover:text-emerald-300 font-bold border border-emerald-950 bg-emerald-950/10 px-2 py-0.5 rounded cursor-pointer transition"
              >
                Incorporate Sample Headers
              </button>
            </div>

            <textarea
              placeholder="Paste raw email headers starting with Return-Path... Received... From... here..."
              value={headerInput}
              onChange={(e) => setHeaderInput(e.target.value)}
              className="w-full h-80 bg-slate-1000 border border-slate-850 focus:border-emerald-500 hover:border-slate-800 focus:outline-none rounded p-3 text-slate-300 font-mono text-[11px] leading-relaxed resize-none"
            />

            <button
              onClick={handleDeconstruct}
              disabled={loading || !headerInput.trim()}
              className="w-full bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 py-2.5 rounded font-mono text-xs uppercase font-bold transition cursor-pointer disabled:opacity-40"
            >
              {loading ? "DECONSTRUCTING..." : "Parse Email Headers"}
            </button>
          </div>

          {/* Quick Informational card */}
          <div className="bg-slate-950/60 border border-slate-900 rounded p-4 font-mono text-[10.5px] text-slate-500 leading-normal space-y-2">
            <span className="font-bold text-slate-400 uppercase block">🧭 PARSING SCHEME METRICS</span>
            <p>Every internet email transit node inserts its signature as a <code className="bg-slate-1000 text-slate-350 px-1 rounded font-bold font-mono">Received:</code> header block at the top of the header stack. Reading from bottom to top reconstructs the chronological physical network path of the campaign.</p>
          </div>
        </div>

        {/* Right Output panels (2 columns) */}
        <div className="lg:col-span-2 space-y-6">
          {!parsed && !loading && (
            <div className="bg-slate-950/40 border border-slate-900 border-dashed rounded p-12 text-center text-slate-550 font-mono text-xs leading-normal min-h-[440px] flex flex-col items-center justify-center">
              <Mail className="w-8 h-8 text-slate-700 mb-3" />
              <span className="font-bold text-slate-450 uppercase block mb-1">AWAITING TRANST INPUT</span>
              Paste raw mailheaders in the left column or select the helper sample button to instantly trace cyber sender alignment vectors and hops.
            </div>
          )}

          {loading && (
            <div className="bg-slate-950/40 border border-slate-900 rounded p-12 text-center text-slate-550 font-mono text-xs leading-normal min-h-[440px] flex flex-col items-center justify-center space-y-4 select-none">
              <div className="relative flex h-8 w-8">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-8 w-8 bg-emerald-655"></span>
              </div>
              <span className="text-xs font-bold text-slate-450 block uppercase tracking-wider">Unfolding header boundaries...</span>
            </div>
          )}

          {parsed && !loading && (
            <div className="space-y-6">
              {/* Authentication Status Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* SPF card */}
                <div className="bg-slate-950 border border-slate-900 p-4 rounded relative overflow-hidden flex flex-col justify-between min-h-[110px]">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">SPF AUTH</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border uppercase ${
                      parsed.auth.spf === "PASS" ? "bg-emerald-950/20 text-emerald-400 border-emerald-900" :
                      parsed.auth.spf === "NONE" ? "bg-slate-900 text-slate-500 border-slate-800" :
                      "bg-red-950/20 text-red-400 border-red-900"
                    }`}>
                      {parsed.auth.spf}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-[11.5px] font-mono font-bold text-slate-300">SPF Validation Status</h4>
                    <p className="text-[10px] font-mono text-slate-500 mt-1 leading-normal">
                      {parsed.auth.spfDetails}
                    </p>
                  </div>
                </div>

                {/* DKIM card */}
                <div className="bg-slate-950 border border-slate-900 p-4 rounded relative overflow-hidden flex flex-col justify-between min-h-[110px]">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">DKIM SIGN</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border uppercase ${
                      parsed.auth.dkim === "PASS" ? "bg-emerald-950/20 text-emerald-400 border-emerald-900" :
                      parsed.auth.dkim === "NONE" ? "bg-slate-900 text-slate-500 border-slate-800" :
                      "bg-red-950/20 text-red-400 border-red-900"
                    }`}>
                      {parsed.auth.dkim}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-[11.5px] font-mono font-bold text-slate-300">DKIM Authentication</h4>
                    <p className="text-[10px] font-mono text-slate-500 mt-1 leading-normal">
                      {parsed.auth.dkimDetails}
                    </p>
                  </div>
                </div>

                {/* DMARC card */}
                <div className="bg-slate-950 border border-slate-900 p-4 rounded relative overflow-hidden flex flex-col justify-between min-h-[110px]">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">DMARC ALIGN</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border uppercase ${
                      parsed.auth.dmarc === "PASS" ? "bg-emerald-950/20 text-emerald-400 border-emerald-900" :
                      parsed.auth.dmarc === "NONE" ? "bg-slate-900 text-slate-500 border-slate-800" :
                      "bg-red-950/20 text-red-100 border-red-900"
                    }`}>
                      {parsed.auth.dmarc}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-[11.5px] font-mono font-bold text-slate-300">DMARC Alignment</h4>
                    <p className="text-[10px] font-mono text-slate-500 mt-1 leading-normal">
                      {parsed.auth.dmarcDetails}
                    </p>
                  </div>
                </div>
              </div>

              {/* AI Phishing & Body Intent Assessment */}
              {aiLoading && !parsed?.aiAnalysis && (
                <div className="bg-slate-950/60 border border-cyan-900/30 rounded p-6 font-mono text-xs flex flex-col items-center justify-center space-y-3.5 select-none animate-pulse">
                  <div className="flex h-5 w-5 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-5 w-5 bg-cyan-550"></span>
                  </div>
                  <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest">
                    Gemini AI SOC Engine: Evaluating email body intent, lookalike domains & phishing patterns...
                  </span>
                </div>
              )}

              {parsed?.aiAnalysis && (
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-5 animate-fade-in">
                  <div className="flex justify-between items-center border-b border-slate-900/60 pb-3 flex-wrap gap-3">
                    <div className="flex items-center gap-2.5">
                      <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse animate-duration-1000" />
                      <div>
                        <h3 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-widest">
                          AI INTENT SUMMARY & PHISHING AUDIT
                        </h3>
                        <p className="text-[10px] font-mono text-slate-500 mt-0.5">
                          Decoded email body contents, persuasion profiles, and spoof validations.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded border uppercase tracking-wider ${
                        parsed.aiAnalysis.classification === "phishing" ? "bg-red-950/20 text-red-400 border-red-900" :
                        parsed.aiAnalysis.classification === "spam" ? "bg-amber-950/20 text-amber-400 border-amber-900" :
                        parsed.aiAnalysis.classification === "marketing" ? "bg-blue-950/20 text-blue-400 border-blue-900" :
                        "bg-emerald-950/20 text-emerald-400 border-emerald-900"
                      }`}>
                        CLASS: {parsed.aiAnalysis.classification}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-900/60 border border-slate-850 px-2 py-0.5 rounded">
                        Confidence: <strong>{parsed.aiAnalysis.confidenceScore}%</strong>
                      </span>
                    </div>
                  </div>

                  {/* Executive Summary Block */}
                  <div className="bg-slate-1000/60 border-l-2 border-cyan-500 rounded p-4">
                    <span className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                      EXECUTIVE INTENT SYNTHESIS
                    </span>
                    <p className="text-slate-300 font-sans text-xs leading-relaxed select-all">
                      {parsed.aiAnalysis.summary}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-mono text-[11px] leading-relaxed">
                    {/* Body Analysis & Persuasion Tactics */}
                    <div className="bg-slate-1000/30 border border-slate-900 p-3.5 rounded space-y-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-900/60 pb-1.5">
                        <Terminal className="w-3.5 h-3.5 text-slate-500" />
                        MIME Body & Persuasion Analysis
                      </span>
                      <p className="text-slate-350 select-all font-sans text-xs">
                        {parsed.aiAnalysis.bodyAnalysis}
                      </p>
                    </div>

                    {/* Sender Spoof / Authenticity Audit */}
                    <div className="bg-slate-1000/30 border border-slate-900 p-3.5 rounded space-y-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-900/60 pb-1.5">
                        <Globe className="w-3.5 h-3.5 text-slate-500" />
                        Sender Authenticity Audit
                      </span>
                      <p className="text-slate-350 select-all font-sans text-xs">
                        {parsed.aiAnalysis.senderAuthenticity}
                      </p>
                    </div>
                  </div>

                  {/* Threat Indicators List */}
                  {parsed.aiAnalysis.threatIndicators && parsed.aiAnalysis.threatIndicators.length > 0 && (
                    <div className="space-y-2.5">
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                        🚨 DETECTED SUSPICIOUS PATTERNS & INDICATORS
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {parsed.aiAnalysis.threatIndicators.map((indicator, idx) => (
                          <div key={idx} className="flex gap-2 bg-slate-1000/40 border border-slate-900 p-2.5 rounded text-slate-300 font-mono text-[10.5px] items-start">
                            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                            <span>{indicator}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Remediation Guidance */}
                  <div className="bg-slate-1000/80 border border-emerald-900/40 p-4 rounded-sm flex gap-3 items-start border-l-2 border-l-emerald-500">
                    <ShieldAlert className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                        🛡️ SOC DISPOSITION & REMEDIATION ACTIONS
                      </span>
                      <p className="text-slate-350 font-sans text-xs leading-relaxed select-all">
                        {parsed.aiAnalysis.remediation}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Visual End-to-End Email Journey Flow Map */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                  <Globe className="w-4 h-4 text-emerald-400 rotate-12" />
                  VISUAL EMAIL FLOW VECTOR PATH (SENDER ➔ RELAYS ➔ RECIPIENT)
                </h3>
                
                <div className="bg-slate-1000 border border-slate-900 rounded p-5">
                  <div className="flex flex-col md:flex-row items-stretch justify-between gap-4 relative">
                    
                    {/* Origin Column */}
                    <div className="flex-1 bg-slate-950/80 border border-red-950/60 rounded p-3 text-center flex flex-col justify-between min-h-[140px] relative border-l-2 border-l-red-500">
                      <div>
                        <span className="text-[9px] font-mono text-red-400 font-bold uppercase tracking-widest block mb-1">
                          [1] SENDER ORIGIN
                        </span>
                        <div className="text-xs font-sans font-bold text-slate-100 truncate py-1.5 border-b border-slate-900/40 select-all">
                          {parsed.from.replace(/<[^>]+>/, "").trim() || "Local Client Agent"}
                        </div>
                      </div>
                      <div className="mt-3 font-mono text-[10.5px]">
                        <span className="text-[9px] text-slate-550 block">SOURCE HOST / IP:</span>
                        <span className="text-slate-350 select-all font-bold block truncate mt-0.5">
                          {parsed.hops[0]?.fromHost || "N/A"}
                        </span>
                        <span className="text-emerald-400 font-bold select-all block text-[10px] mt-0.5 mt-1 bg-slate-900/60 border border-slate-850 px-1 py-0.2 rounded inline-block">
                          IP: {parsed.hops[0]?.fromIp || parsed.returnPath.replace(/[<>]/g, "") || "N/A"}
                        </span>
                      </div>
                    </div>

                    {/* Transition Relay Arrow (Desktop Only) OR flow connector */}
                    {parsed.hops.length > 1 && (
                      <div className="hidden md:flex flex-col items-center justify-center text-slate-600 px-1 font-mono shrink-0 select-none">
                        <ArrowDownRight className="w-5 h-5 text-slate-500 -rotate-45" />
                        <span className="text-[8px] text-slate-500 font-bold block mt-1">RELAY GATEWAY</span>
                        <span className="text-[9px] bg-slate-900 text-teal-400 border border-slate-850 px-1 rounded block mt-0.5">
                          {parsed.hops[1]?.protocol || "SMTP"}
                        </span>
                      </div>
                    )}

                    {/* Middle MTA MTA Relays Column (Aggregated Transit path represent) */}
                    <div className="flex-1 bg-slate-950/80 border border-slate-900 rounded p-3 text-center flex flex-col justify-between min-h-[140px] relative">
                      <div>
                        <span className="text-[9px] font-mono text-slate-500 font-bold uppercase tracking-widest block mb-1">
                          [2] INTERMEDIATE MTA HOPS
                        </span>
                        <div className="text-xs font-sans font-bold text-slate-205 py-1.5 border-b border-slate-900/40">
                          {parsed.hops.length <= 2 
                            ? "Direct Inbound Socket" 
                            : `${parsed.hops.length - 2} Intermediate Relays`
                          }
                        </div>
                      </div>
                      <div className="mt-3 font-mono text-[10.5px]">
                        <span className="text-[9px] text-slate-500 block uppercase">AVERAGE LATENCY SPEED:</span>
                        <span className="text-teal-400 font-bold block mt-0.5">
                          {parsed.hops.length > 1 
                            ? parsed.hops[parsed.hops.length - 1].delayText === "Start" 
                              ? "Instant" 
                              : parsed.hops[parsed.hops.length - 1].delayText
                            : "Direct Hop Injection"
                          }
                        </span>
                        <span className="text-[8.5px] text-slate-600 block mt-1 uppercase font-semibold">
                          Trace verified by RBL logs
                        </span>
                      </div>
                    </div>

                    {/* Transition Route Arrow (Desktop Only) */}
                    <div className="hidden md:flex flex-col items-center justify-center text-slate-600 px-1 font-mono shrink-0 select-none">
                      <ArrowDownRight className="w-5 h-5 text-slate-500 -rotate-45" />
                      <span className="text-[8px] text-slate-500 font-bold block mt-1">TARGET INBOX</span>
                      <span className="text-[9px] bg-slate-900 text-emerald-400 border border-slate-850 px-1 rounded block mt-0.5">
                        TLSv1.3
                      </span>
                    </div>

                    {/* Destination Receiver Column */}
                    <div className="flex-1 bg-slate-950/80 border border-emerald-950/60 rounded p-3 text-center flex flex-col justify-between min-h-[140px] relative border-l-2 border-l-emerald-500">
                      <div>
                        <span className="text-[9px] font-mono text-emerald-400 font-bold uppercase tracking-widest block mb-1">
                          [3] RECIPIENT BOUND
                        </span>
                        <div className="text-xs font-sans font-bold text-slate-100 truncate py-1.5 border-b border-slate-900/40 select-all">
                          {parsed.to.replace(/<[^>]+>/, "").trim() || "Inbound Exchange"}
                        </div>
                      </div>
                      <div className="mt-3 font-mono text-[10.5px]">
                        <span className="text-[9px] text-slate-550 block">FINAL MX RECEIVER:</span>
                        <span className="text-slate-350 select-all font-bold block truncate mt-0.5">
                          {parsed.hops[parsed.hops.length - 1]?.byHost || "mx.google.com"}
                        </span>
                        <span className="text-blue-400 font-bold select-all block text-[9.5px] mt-1 select-all font-sans leading-none">
                          System: {parsed.mailer || "Corporate Mailserver Gateway"}
                        </span>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

              {/* High Level Key fields summary table */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-3.5">
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  CORE EMAIL MESSAGE SPEC SUMMARY
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 font-mono text-[11px] leading-relax border-b border-slate-900 pb-3">
                  <div className="flex flex-col border-b border-slate-900/40 pb-1.5 overflow-hidden">
                    <span className="text-slate-550 block text-[9px] uppercase">FROM:</span>
                    <span className="text-slate-200 mt-0.5 truncate font-bold">{parsed.from}</span>
                  </div>
                  <div className="flex flex-col border-b border-slate-900/40 pb-1.5 overflow-hidden">
                    <span className="text-slate-550 block text-[9px] uppercase">TO:</span>
                    <span className="text-slate-201 mt-0.5 truncate font-semibold">{parsed.to}</span>
                  </div>
                  <div className="flex flex-col border-b border-slate-900/40 pb-1.5 overflow-hidden">
                    <span className="text-slate-555 block text-[9px] uppercase">SUBJECT:</span>
                    <span className="text-slate-150 mt-0.5 truncate font-bold text-slate-100">{parsed.subject}</span>
                  </div>
                  <div className="flex flex-col border-b border-slate-900/40 pb-1.5 overflow-hidden">
                    <span className="text-slate-550 block text-[9px] uppercase">SENT DATE:</span>
                    <span className="text-slate-300 mt-0.5 truncate">{parsed.date}</span>
                  </div>
                  <div className="flex flex-col border-b border-slate-900/40 pb-1.5 md:pb-0 overflow-hidden">
                    <span className="text-slate-555 block text-[9px] uppercase">MESSAGE-ID:</span>
                    <span className="text-slate-400 mt-0.5 truncate font-mono select-all text-[10px]">{parsed.messageId}</span>
                  </div>
                  <div className="flex flex-col overflow-hidden">
                    <span className="text-slate-550 block text-[9px] uppercase">RETURN-PATH / REPLY-TO:</span>
                    <span className="text-slate-350 mt-0.5 truncate">
                      {parsed.returnPath} <span className="text-slate-600">//</span> {parsed.replyTo}
                    </span>
                  </div>
                </div>
              </div>

              {/* FORENSIC INDICATOR CARVING: EXTRACTED URLS & ATTACHMENTS */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-2 border-b border-slate-900 pb-3">
                  <div>
                    <h3 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-widest flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-cyan-400 animate-pulse" />
                      FORENSIC INDICATOR CARVING (MIME BODY EXAMINATION)
                    </h3>
                    <p className="text-[10px] font-mono text-slate-500 mt-0.5">
                      Automatically parsed URL nodes, domain references, and associated attachment payloads contained within the raw stream.
                    </p>
                  </div>
                  <div className="flex gap-2 font-mono text-[10px]">
                    <span className="bg-blue-950/30 border border-blue-900/40 text-blue-400 px-2 py-0.5 rounded font-bold">
                      {parsed.urls.length} LINKS
                    </span>
                    <span className="bg-pink-950/30 border border-pink-900/40 text-pink-400 px-2 py-0.5 rounded font-bold">
                      {parsed.attachments.length} ATTACHMENTS
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Extracted URLs List */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center bg-slate-950 border border-slate-900 px-3 py-1.5 rounded">
                      <span className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Link2 className="w-3.5 h-3.5 text-blue-400" />
                        Carved Links ({parsed.urls.length})
                      </span>
                      <span className="text-[9px] font-mono text-slate-500">Live URLs found</span>
                    </div>

                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                      {parsed.urls.length === 0 ? (
                        <div className="text-center p-8 bg-slate-1000/40 border border-slate-900 rounded font-mono text-[10.5px] text-slate-650 italic">
                          No embedded URL links carved from raw message body.
                        </div>
                      ) : (
                        parsed.urls.map((item, idx) => (
                          <div key={idx} className="bg-slate-1000 border border-slate-900/80 rounded p-2.5 space-y-1.5 hover:border-slate-800 transition">
                            <div className="flex justify-between items-start gap-4">
                              <span className="text-[10px] bg-slate-950 border border-slate-900 text-blue-400 hover:text-blue-300 font-mono font-bold px-1.5 py-0.5 rounded select-all break-all leading-normal flex-1">
                                {item.url}
                              </span>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(item.url);
                                  alert(`Copied URL to clipboard:\n${item.url}`);
                                }}
                                className="text-[9px] font-mono font-bold text-slate-400 hover:text-slate-200 border border-slate-900 bg-slate-950 px-1 py-0.5 rounded cursor-pointer transition uppercase"
                              >
                                Copy
                              </button>
                            </div>
                            <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-0.5">
                              <span className="truncate">
                                Domain Ref: <strong className="text-slate-350 select-all font-semibold font-mono">{item.domain}</strong>
                              </span>
                              <span className="text-[9px] text-slate-450 border border-slate-900 bg-slate-950/40 px-1.5 py-0.2 rounded font-bold uppercase tracking-wider block shrink-0">
                                Link #{idx + 1}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Extracted Attachments List */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center bg-slate-950 border border-slate-900 px-3 py-1.5 rounded">
                      <span className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Paperclip className="w-3.5 h-3.5 text-pink-400" />
                        Attachment payloads ({parsed.attachments.length})
                      </span>
                      <span className="text-[9px] font-mono text-slate-500">MIME boundary contents</span>
                    </div>

                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                      {parsed.attachments.length === 0 ? (
                        <div className="text-center p-8 bg-slate-1000/40 border border-slate-900 rounded font-mono text-[10.5px] text-slate-650 italic">
                          No binary attachment metadata or file boundaries encountered.
                        </div>
                      ) : (
                        parsed.attachments.map((item, idx) => {
                          const isExeOrBad = item.filename.endsWith(".exe") || item.filename.endsWith(".scr") || item.filename.endsWith(".js") || item.filename.endsWith(".vbs") || item.filename.endsWith(".zip");
                          return (
                            <div key={idx} className={`bg-slate-1000 border rounded p-2.5 flex items-start gap-3 hover:border-slate-800 transition ${isExeOrBad ? "border-red-950 bg-red-1000/5" : "border-slate-900/80"}`}>
                              <div className={`p-2 rounded shrink-0 ${isExeOrBad ? "bg-red-950/30 text-red-400" : "bg-slate-950 text-slate-400"}`}>
                                <File className="w-4 h-4" />
                              </div>
                              <div className="flex-1 space-y-1 overflow-hidden">
                                <div className="flex justify-between items-start gap-2">
                                  <span className={`text-[11px] font-mono font-bold break-all block truncate max-w-[200px] select-all ${isExeOrBad ? "text-red-400" : "text-slate-200"}`}>
                                    {item.filename}
                                  </span>
                                  {isExeOrBad && (
                                    <span className="text-[8px] bg-red-950/50 text-red-400 border border-red-900/50 px-1 py-0.2 rounded font-bold uppercase shrink-0">
                                      High Abuse Risk
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] font-mono text-slate-500 leading-normal space-y-0.5">
                                  <div>MIME: <span className="text-slate-400">{item.contentType}</span></div>
                                  <div className="flex justify-between items-center text-[9px] text-slate-550 font-bold">
                                    <span>TYPE: {item.disposition.toUpperCase()}</span>
                                    {item.sizeText && <span>SIZE: {item.sizeText}</span>}
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Transit Hops Route Mapping */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
                <div className="flex justify-between items-center bg-slate-950/80 border border-slate-900/40 p-2 rounded">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2 pl-1.5">
                    <Globe className="w-4 h-4 text-blue-400" />
                    CHRONOLOGICAL TRANSIT HOPS TRACE (BOTTOM TO TOP)
                  </h3>
                  <span className="text-[10px] font-mono text-slate-500 font-bold pr-1">
                    {parsed.hops.length} NET TRANSITIONS
                  </span>
                </div>

                <div className="space-y-3 relative before:absolute before:left-5 before:top-4 before:bottom-4 before:w-0.5 before:bg-slate-900">
                  {parsed.hops.map((hop, hIdx) => (
                    <div key={hIdx} className="flex gap-4 font-mono text-xs items-center relative pl-2">
                      {/* Circle numbering */}
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-[11px] border shrink-0 relative z-10 ${
                        hIdx === 0 ? "bg-emerald-950/35 border-emerald-900 text-emerald-400" :
                        hIdx === parsed.hops.length - 1 ? "bg-blue-950 border-blue-900 text-blue-400 hover:scale-105" :
                        "bg-slate-1000 border-slate-900 text-slate-400"
                      }`}>
                        {hop.hopIndex}
                      </div>

                      <div className="flex-1 bg-slate-950 p-3.5 border border-slate-900 rounded flex flex-col md:flex-row justify-between md:items-center gap-3">
                        <div className="space-y-1 overflow-hidden">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-slate-500 text-[10px] uppercase font-bold">FROM:</span>
                            <span className="font-bold text-slate-202 truncate inline-block max-w-[200px]">{hop.fromHost}</span>
                            {hop.fromIp !== "N/A" && (
                              <span className="text-[10px] bg-slate-900 text-slate-400 px-1.5 py-0.2 rounded border border-slate-800 font-bold font-mono">
                                {hop.fromIp}
                              </span>
                            )}
                          </div>
                          <div className="text-[10.5px] text-slate-500 flex gap-2 flex-wrap pb-0.5">
                            <span><strong className="text-slate-450 font-semibold">Processed by:</strong> {hop.byHost}</span>
                            <span><strong className="text-slate-450 font-semibold">via:</strong> {hop.protocol}</span>
                          </div>
                          <div className="text-[10px] text-slate-500 leading-none flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-650" />
                            <span>{hop.timestamp}</span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[9px] uppercase text-slate-550 block font-bold">TRANSIT DELAY</span>
                          <span className={`text-[11px] font-bold ${
                            hop.delayText === "Start" ? "text-emerald-400" :
                            hop.delayText.includes("m") ? "text-amber-400" :
                            "text-slate-350"
                          }`}>
                            {hop.delayText === "Start" ? "🏁 INITIAL HOP" : `+ ${hop.delayText}`}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Neatly Separated Field Values Alphabetical Table (MxToolbox style requirement) */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-900 pb-3">
                  <div>
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                      <ListFilter className="w-4 h-4 text-emerald-400" />
                      NEATLY SEPARATED FIELD VALUES (ALL HEADERS)
                    </h3>
                  </div>

                  {/* Search query box */}
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-600" />
                    <input
                      type="text"
                      placeholder="Filter header keys..."
                      value={fieldSearch}
                      onChange={(e) => setFieldSearch(e.target.value)}
                      className="w-full bg-slate-1000 border border-slate-850 hover:border-slate-800 focus:outline-none focus:border-emerald-500 rounded pl-8 pr-3 py-1 text-[10.5px] font-mono text-slate-300"
                    />
                  </div>
                </div>

                <div className="bg-slate-1000 border border-slate-900 rounded overflow-hidden max-h-[380px] overflow-y-auto">
                  <table className="w-full text-left font-mono text-[10.5px]">
                    <thead>
                      <tr className="bg-slate-950 text-slate-500 border-b border-slate-900 select-none">
                        <th className="p-2.5 pl-3.5 w-1/3">Header Field Name</th>
                        <th className="p-2.5 w-2/3">Separated Field Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900/40">
                      {filteredFields.length === 0 ? (
                        <tr>
                          <td colSpan={2} className="p-8 text-center text-slate-650 italic">
                            No matching header fields found for "{fieldSearch}".
                          </td>
                        </tr>
                      ) : (
                        filteredFields.map((field, fIdx) => (
                          <tr key={fIdx} className="hover:bg-slate-950/50 group">
                            <td className="p-2.5 pl-3.5 font-bold text-slate-400 select-all">{field.key}</td>
                            <td className="p-2.5 text-slate-202 select-all break-all whitespace-pre-wrap font-medium">
                              <div className="flex justify-between items-start gap-4">
                                <span className="flex-1 leading-relaxed">{field.value}</span>
                                <button
                                  onClick={() => executeCopyField(field.value, fIdx)}
                                  className="opacity-0 group-hover:opacity-100 transition text-[9px] text-blue-400 shrink-0 select-none border border-slate-900 bg-slate-950 px-1 py-0.5 rounded cursor-pointer"
                                >
                                  {copiedIndex === fIdx ? "COPIED" : "COPY"}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
