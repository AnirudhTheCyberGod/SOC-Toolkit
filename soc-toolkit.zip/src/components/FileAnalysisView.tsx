/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { UploadCloud, FileText, Cpu, AlertTriangle, ShieldCheck, Check, Copy, HardDrive, Terminal, Search, ShieldAlert, Zap } from "lucide-react";
import { HashAnalysisResult } from "../types";

export default function FileAnalysisView() {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [sha256, setSha256] = useState<string>("");
  const [sha1, setSha1] = useState<string>("");
  const [hashing, setHashing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HashAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);

  // Heuristic scan state (For text-based upload code files)
  const [codeReview, setCodeReview] = useState<string>("");
  const [isCodeFile, setIsCodeFile] = useState(false);
  const [heuristicsLoading, setHeuristicsLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Helper utility to convert ArrayBuffer to HEX
  const bufferToHex = (buffer: ArrayBuffer): string => {
    const bytes = new Uint8Array(buffer);
    return Array.from(bytes)
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");
  };

  // Compute actual file SHA-256 and SHA-1 handles client-side
  const computeFileHashes = async (selectedFile: File) => {
    setHashing(true);
    try {
      const buffer = await selectedFile.arrayBuffer();
      
      // Compute SHA-256
      const sha256Buffer = await crypto.subtle.digest("SHA-256", buffer);
      const sha256Hex = bufferToHex(sha256Buffer);
      setSha256(sha256Hex);

      // Compute SHA-1
      const sha1Buffer = await crypto.subtle.digest("SHA-1", buffer);
      const sha1Hex = bufferToHex(sha1Buffer);
      setSha1(sha1Hex);

      // Check if text/code-readable (by MIME or small size)
      const isTextReadable = 
        selectedFile.type.startsWith("text/") || 
        selectedFile.name.endsWith(".py") || 
        selectedFile.name.endsWith(".js") || 
        selectedFile.name.endsWith(".sh") || 
        selectedFile.name.endsWith(".bat") || 
        selectedFile.name.endsWith(".ps1") || 
        selectedFile.name.endsWith(".json") || 
        selectedFile.name.endsWith(".html") || 
        selectedFile.size < 1024 * 1024; // text under 1MB
      
      setIsCodeFile(isTextReadable);
      setCodeReview(""); // reset
      setResult(null); // reset VT
    } catch (err) {
      console.error("Hashing routine error:", err);
    } finally {
      setHashing(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const selectedFile = e.dataTransfer.files[0];
      setFile(selectedFile);
      await computeFileHashes(selectedFile);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      await computeFileHashes(selectedFile);
    }
  };

  const triggerUploadInput = () => {
    fileInputRef.current?.click();
  };

  // Query VirusTotal database or simulate report via existing Hash Analysis API using actual computed hash
  const queryVirusTotal = async () => {
    if (!sha256) return;
    setLoading(true);
    try {
      const parsedKeys = {
        virustotal: localStorage.getItem("VT_API_KEY") || "",
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      };

      const response = await fetch("/api/enrich/hash", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hash: sha256, apiKeys: parsedKeys }),
      });

      if (response.ok) {
        const data: HashAnalysisResult = await response.json();
        setResult(data);
      }
    } catch (err) {
      console.error("VirusTotal inquiry error:", err);
    } finally {
      setLoading(false);
    }
  };

  // Static AI code analysis via Gemini API
  const performHeuristicScan = async () => {
    if (!file) return;
    setHeuristicsLoading(true);
    try {
      // Read first 15,000 characters
      const text = await file.text();
      const payloadLimit = text.substring(0, 15000);

      const parsedKeys = {
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      };

      const response = await fetch("/api/analyze/file-heuristics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: file.name,
          fileSize: file.size,
          fileType: file.type || "unknown/plain",
          code: payloadLimit,
          apiKeys: parsedKeys
        })
      });

      if (response.ok) {
        const data = await response.json();
        setCodeReview(data.output || "Heural review completed.");
      } else {
        setCodeReview("Failed to compile AI heuristics report.");
      }
    } catch (err) {
      console.error("Heuristic runtime issue:", err);
      setCodeReview("Heuristic compilation script halted unexpectedly.");
    } finally {
      setHeuristicsLoading(false);
    }
  };

  const executeCopyJson = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <UploadCloud className="w-4 h-4 text-orange-500 animate-pulse" />
          FILE UPLOAD & VIRUSTOTAL SANDBOX
        </h2>
        <p className="text-xs text-slate-550 font-mono leading-sm">
          Interactive dropzone to ingest file buffers, compute handles (SHA-256/SHA-1) locally, execute VirusTotal scans, and generate static AI code analysis.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload Column */}
        <div className="lg:col-span-1 space-y-4">
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`p-6 border-2 border-dashed rounded font-mono text-center transition flex flex-col items-center justify-center min-h-[220px] cursor-pointer ${
              dragActive 
                ? "border-red-500 bg-red-950/10" 
                : file 
                ? "border-emerald-900/60 bg-emerald-950/5" 
                : "border-slate-850 hover:border-slate-800 bg-slate-950/40"
            }`}
            onClick={triggerUploadInput}
          >
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            {file ? (
              <div className="space-y-3.5 w-full">
                <div className="p-3 bg-emerald-950/30 border border-emerald-900/60 text-emerald-400 rounded-full w-12 h-12 flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div className="space-y-1.5 px-2">
                  <span className="text-xs text-slate-200 font-bold block truncate" title={file.name}>
                    {file.name}
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    Size: {(file.size / 1024).toFixed(2)} KB // Type: {file.type || "unknown"}
                  </span>
                </div>
                <span className="text-[10px] text-slate-450 border border-slate-900 bg-slate-950/80 px-2 py-1 rounded inline-block">
                  Click or drag to replace target
                </span>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3 bg-slate-950 border border-slate-900 text-slate-500 rounded-full w-11 h-11 flex items-center justify-center mx-auto">
                  <HardDrive className="w-5 h-5 text-slate-450" />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-slate-300 font-bold block">Drag & Drop Forensic File</span>
                  <span className="text-[10px] text-slate-500 block">Or click to explore local directory</span>
                </div>
                <span className="text-[9px] text-slate-600 bg-slate-950/70 border border-slate-900/40 px-1.5 py-0.5 rounded">
                  Max size: 64MB // Sandbox-secured
                </span>
              </div>
            )}
          </div>

          {/* Local Cryptographic Signatures */}
          {file && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 font-mono space-y-3 text-[11px] select-all">
              <h3 className="text-[10px] font-bold text-slate-350 uppercase border-b border-slate-900 pb-2 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-blue-400" />
                LOCAL SIGNATURE HANDLES
              </h3>

              {hashing ? (
                <div className="flex items-center gap-2 text-slate-500 py-2">
                  <Cpu className="w-4 h-4 animate-spin text-blue-400" />
                  <span>Computing file digests locally...</span>
                </div>
              ) : (
                <div className="space-y-3.5">
                  <div className="space-y-1.5">
                    <span className="text-slate-500 text-[9px] font-bold uppercase block">SHA-256 HASH SPEC:</span>
                    <div className="bg-slate-950 p-2 border border-slate-900 rounded break-all select-all text-slate-300 text-[10.5px] relative group h-12 overflow-y-auto">
                      {sha256}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <span className="text-slate-500 text-[10px] font-bold uppercase block">SHA-1 HASH SPEC:</span>
                    <div className="bg-slate-950 p-2 border border-slate-900 rounded break-all select-all text-slate-350 text-[10.5px] h-10 overflow-y-auto">
                      {sha1}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Trigger Scan Controls */}
          {file && !hashing && (
            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={queryVirusTotal}
                disabled={loading}
                className="w-full bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400 py-2.5 rounded font-mono text-xs uppercase font-bold transition cursor-pointer disabled:opacity-40"
              >
                {loading ? "querying sandbox..." : "Query VirusTotal Index"}
              </button>

              {isCodeFile && (
                <button
                  onClick={performHeuristicScan}
                  disabled={heuristicsLoading}
                  className="w-full bg-blue-950/40 hover:bg-blue-900/40 border border-blue-500/30 hover:border-blue-550 text-blue-400 py-2.5 rounded font-mono text-xs uppercase font-bold transition cursor-pointer disabled:opacity-40 flex items-center justify-center gap-1.5"
                >
                  {heuristicsLoading ? (
                    <>
                      <Cpu className="w-3.5 h-3.5 animate-spin text-blue-400" />
                      Decomposing script...
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-yellow-400" />
                      Heuristic AI Script Scan
                    </>
                  )}
                </button>
              )}
            </div>
          )}
        </div>

        {/* Threat Intelligence / Sandbox Result Area */}
        <div className="lg:col-span-2 space-y-4">
          {/* Default State: Waiting */}
          {!file && (
            <div className="bg-slate-950/40 border border-slate-900 border-dashed rounded p-12 text-center text-slate-550 font-mono text-xs leading-normal min-h-[400px] flex flex-col items-center justify-center">
              <HardDrive className="w-8 h-8 text-slate-700 mb-3 animate-pulse" />
              <span className="font-bold text-slate-400 uppercase block mb-1">AWAITING FORENSIC INPUT</span>
              Drop, upload, or browse a local target file to compute cryptographic structures and deploy integrated checking pipelines.
            </div>
          )}

          {/* Case 1: VirusTotal Result Panel */}
          {result && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4 animate-fade-in">
              <div className="flex justify-between items-center border-b border-slate-900 pb-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-red-500" />
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                    VIRUSTOTAL DETECTOR SANDBOX REPORT
                  </h3>
                </div>
                <span className={`text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded uppercase border ${
                  result.reputation === "malicious" ? "bg-red-950 text-red-400 border-red-900" : "bg-emerald-955 text-emerald-400 border-emerald-900"
                }`}>
                  {result.reputation}
                </span>
              </div>

              {/* VT Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-slate-950 p-3 rounded border border-slate-900/80">
                  <span className="text-slate-500 text-[9px] block">MALWARE CO-CLASS:</span>
                  <span className={`text-sm font-bold block mt-1 ${result.reputation === "malicious" ? "text-red-400" : "text-emerald-400"}`}>
                    {result.malwareFamily}
                  </span>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-900/80">
                  <span className="text-slate-500 text-[9px] block">SCAN DETECTION SCORE:</span>
                  <span className="text-sm font-bold text-slate-200 block mt-1">
                    {result.stats.malicious} / {result.stats.malicious + result.stats.harmless} engines
                  </span>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-900/80">
                  <span className="text-slate-500 text-[9px] block">KNOWN FIRST SEEN:</span>
                  <span className="text-sm font-bold text-slate-400 block mt-1">
                    {result.firstSeen || "Never Seen"}
                  </span>
                </div>
              </div>

              {/* Vendors Check Table */}
              <div className="bg-slate-1000 border border-slate-900 rounded max-h-[220px] overflow-y-auto">
                <table className="w-full text-left font-mono text-[10.5px]">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 border-b border-slate-900">
                      <th className="p-2 pl-3">AV Scanning Engine</th>
                      <th className="p-2">Detection Signature</th>
                      <th className="p-2 text-right pr-3">Verdict</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900/60">
                    {result.detections.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="p-6 text-center text-slate-550 italic">
                          File signature is completely clean across all participating engines.
                        </td>
                      </tr>
                    ) : (
                      result.detections.map((det, id) => (
                        <tr key={id} className="hover:bg-slate-950/40">
                          <td className="p-2 pl-3 font-semibold text-slate-350">{det.engine}</td>
                          <td className="p-2 text-red-500 font-bold break-all">{det.result}</td>
                          <td className="p-2 text-right pr-3 font-bold text-red-400 uppercase">{det.category}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-center bg-slate-950 p-3 rounded border border-slate-900 font-mono text-[10px]">
                <span className="text-slate-550">SIGNATURE METRICS GENERATOR</span>
                <button
                  onClick={executeCopyJson}
                  className="text-blue-400 hover:text-blue-300 flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? "COPIED" : "EXPORT JSON RESULTS"}
                </button>
              </div>
            </div>
          )}

          {/* Case 2: AI Code Heuristics Review Panel */}
          {codeReview && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4 animate-fade-in relative overflow-hidden">
              <div className="absolute top-0 right-0 h-24 w-24 bg-blue-500/5 rounded-full blur-xl"></div>
              <div className="flex justify-between items-center border-b border-slate-900 pb-3">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-blue-400" />
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                    HEURISTIC AI STATIC CODE ANALYSIS
                  </h3>
                </div>
                <span className="bg-blue-950 text-blue-400 border border-blue-900 text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase">
                  HEURAL SCAN ENGINE
                </span>
              </div>

              {/* Code output review markdown body */}
              <div className="bg-slate-1000 border border-slate-900 rounded p-4 font-mono text-[11px] leading-relaxed text-slate-300 max-h-[360px] overflow-y-auto whitespace-pre-wrap select-text">
                {codeReview}
              </div>

              <div className="bg-slate-950/40 border border-slate-900 rounded p-3 text-[10px] text-slate-500 leading-normal font-mono">
                <span className="font-bold text-slate-400 block mb-0.5 uppercase">🛡️ ANOMALY ENGINE NOTATION</span>
                AI heuristics parse raw file tokens seeking command pipeline invocations, network socket binders (reverse TCP), base64 encoded chunks, or cipher variables. Validate flags against real sandboxed behavior.
              </div>
            </div>
          )}

          {/* Loading States */}
          {loading && (
            <div className="bg-slate-950/40 border border-slate-900 rounded p-12 text-center text-slate-550 font-mono text-xs leading-normal flex flex-col items-center justify-center min-h-[300px]">
              <div className="relative flex h-8 w-8 mb-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-8 w-8 bg-red-600"></span>
              </div>
              <span className="text-xs font-bold text-slate-450 block uppercase mb-1">SCANNING SIGNATURE INDEX</span>
              Querying VirusTotal APIs, file hash caches, and threat reputation mappings...
            </div>
          )}

          {heuristicsLoading && (
            <div className="bg-slate-950/40 border border-slate-900 rounded p-12 text-center text-slate-550 font-mono text-xs leading-normal flex flex-col items-center justify-center min-h-[300px]">
              <div className="relative flex h-8 w-8 mb-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-8 w-8 bg-blue-650"></span>
              </div>
              <span className="text-xs font-bold text-slate-450 block uppercase mb-1">COMPUTING STATIC HEURISTICS</span>
              Executing token decomposition, mapping execution nodes, and tracing data pipelines...
            </div>
          )}

          {/* File state without scans triggered */}
          {file && !result && !codeReview && !loading && !heuristicsLoading && (
            <div className="bg-slate-950/40 border border-slate-900 border-dashed rounded p-12 text-center text-slate-500 font-mono text-xs leading-normal min-h-[350px] flex flex-col items-center justify-center select-none">
              <Cpu className="w-7 h-7 text-slate-700 mb-2.5" />
              <span className="font-bold text-slate-400 uppercase block mb-1">FILE LOADED SUCCESSFULLY</span>
              Local cryptographic calculations completed. Select a scan pipeline in the left panel to trigger VirusTotal reputation query or AI script heuristics analysis.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
