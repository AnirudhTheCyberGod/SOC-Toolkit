/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { HashAnalysisResult } from "../types";
import { Search, ShieldAlert, Hash, Calendar, FileText, Tag, Copy, Check, Globe, UserCheck, CloudLightning, Terminal, Fingerprint } from "lucide-react";

interface HashTypeMeta {
  detected: boolean;
  type: string;
  charCount: number;
  format: string;
  security: "highly-compromised" | "vulnerable" | "strong" | "unknown";
  notes: string;
}

function identifyHashType(hashStr: string): HashTypeMeta {
  const hash = hashStr.trim();
  const len = hash.length;
  
  if (len === 0) {
    return { detected: false, type: "None", charCount: 0, format: "N/A", security: "unknown", notes: "Please enter a hash value." };
  }

  const isHex = /^[a-fA-F0-9]+$/.test(hash);
  const isBase64 = /^[a-zA-Z0-9+/=]+$/.test(hash);

  // bcrypt checking
  if ((hash.startsWith("$2a$") || hash.startsWith("$2b$") || hash.startsWith("$2y$")) && len === 60) {
    return {
      detected: true,
      type: "bcrypt",
      charCount: len,
      format: "Blowfish/Crypt format",
      security: "strong",
      notes: "Slow password hashing function incorporating a work factor and custom safe salt. Excellent security against brute force GPU speedups."
    };
  }

  // MD5 crypt
  if (hash.startsWith("$1$") && len === 34) {
    return {
      detected: true,
      type: "MD5-crypt",
      charCount: len,
      format: "Crypt format",
      security: "highly-compromised",
      notes: "Legacy Unix system crypt variant. Extensively vulnerable to modern offline dictionary crack loops."
    };
  }

  // SHA-256 crypt
  if (hash.startsWith("$5$")) {
    return {
      detected: true,
      type: "SHA-256-crypt",
      charCount: len,
      format: "Crypt format",
      security: "strong",
      notes: "SHA-256 password crypt with standard iteration stretch count. High modern security profile."
    };
  }

  // SHA-512 crypt
  if (hash.startsWith("$6$")) {
    return {
      detected: true,
      type: "SHA-512-crypt",
      charCount: len,
      format: "Crypt format",
      security: "strong",
      notes: "SHA-512 password crypt with multiple dynamic salt iterations. Industry-standard modern security factor."
    };
  }

  if (isHex) {
    if (len === 8) {
      return {
        detected: true,
        type: "CRC-32 (Checksum)",
        charCount: len,
        format: "Hexadecimal (32-bit)",
        security: "highly-compromised",
        notes: "Error-detecting checksum. Not cryptographic. Can be trivially modified with an arbitrary collision sequence."
      };
    }
    if (len === 32) {
      return {
        detected: true,
        type: "MD5 (or NTLM / MD4)",
        charCount: len,
        format: "Hexadecimal (128-bit)",
        security: "highly-compromised",
        notes: "Broken integrity hash. Deprecated worldwide due to high-speed collision-generation exploits (within seconds on consumer GPUs)."
      };
    }
    if (len === 40) {
      return {
        detected: true,
        type: "SHA-1",
        charCount: len,
        format: "Hexadecimal (160-bit)",
        security: "vulnerable",
        notes: "Vulnerable to choosing-prefix collision attacks. Deprecated by major web security root certificate systems."
      };
    }
    if (len === 56) {
      return {
        detected: true,
        type: "SHA-224 / SHA-3-224",
        charCount: len,
        format: "Hexadecimal (224-bit)",
        security: "strong",
        notes: "Part of the SHA-2 family. Generally secure but rarely seen in standard enterprise catalogs."
      };
    }
    if (len === 64) {
      return {
        detected: true,
        type: "SHA-256 / SHA-3-256",
        charCount: len,
        format: "Hexadecimal (256-bit)",
        security: "strong",
        notes: "Golden standard file signature checksum. Resistant to all known collision and brute-force cryptographic capabilities."
      };
    }
    if (len === 96) {
      return {
        detected: true,
        type: "SHA-384 / SHA-3-384",
        charCount: len,
        format: "Hexadecimal (384-bit)",
        security: "strong",
        notes: "Part of the SHA-2 family. Strong security factor, used primarily in high-security IPsec and SSL frameworks."
      };
    }
    if (len === 128) {
      return {
        detected: true,
        type: "SHA-512 / SHA-3-512",
        charCount: len,
        format: "Hexadecimal (512-bit)",
        security: "strong",
        notes: "Ultra-heavy hashing standard. High level of collision resistance and cryptographic safety bounds."
      };
    }
  }

  // Fallback for hex values that have weird length or base64 hashes (like some SHA Digests)
  if (isBase64 && len === 44 && hash.endsWith("=")) {
    return {
      detected: true,
      type: "SHA-256 (Base64)",
      charCount: len,
      format: "Base64 string",
      security: "strong",
      notes: "A standard highly-secure SHA-256 output, encoded utilizing Base64 mapping rather than traditional hexadecimal representation."
    };
  }

  return {
    detected: false,
    type: "Unknown Hash Structure",
    charCount: len,
    format: isHex ? "Hexadecimal" : isBase64 ? "Base64" : "ASCII Raw Text",
    security: "unknown",
    notes: "Length does not conform to traditional standard cryptographic signatures. Might be a custom salts block, encryption, or truncated."
  };
}

interface HashAnalysisProps {
  onAddSearchLog: (log: { type: "IP" | "Domain" | "URL" | "Hash" | "Malware"; query: string; reputation: "clean" | "suspicious" | "malicious" | "unknown"; score?: number }) => void;
  initialQuery?: string;
}

export default function HashAnalysisView({ onAddSearchLog, initialQuery = "" }: HashAnalysisProps) {
  const [hashInput, setHashInput] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HashAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [copiedHashKey, setCopiedHashKey] = useState<string | null>(null);

  const handleCopyHash = (val: string, key: string) => {
    navigator.clipboard.writeText(val);
    setCopiedHashKey(key);
    setTimeout(() => setCopiedHashKey(null), 1500);
  };

  const handleSearch = async (targetHash: string) => {
    const trimmed = targetHash.trim();
    if (!trimmed) return;
    setLoading(true);
    try {
      const parsedKeys = {
        virustotal: localStorage.getItem("VT_API_KEY") || "",
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      };

      const response = await fetch("/api/enrich/hash", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hash: trimmed, apiKeys: parsedKeys }),
      });

      if (response.ok) {
        const data: HashAnalysisResult = await response.json();
        setResult(data);

        onAddSearchLog({
          type: "Hash",
          query: trimmed,
          reputation: data.reputation,
          score: data.reputationScore !== undefined ? data.reputationScore : (data.reputation === "malicious" ? 95 : data.reputation === "suspicious" ? 45 : 0)
        });
      }
    } catch (err) {
      console.error("Hash lookup failure:", err);
    } finally {
      setLoading(false);
    }
  };

  const executeCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1">
          CRYPTOGRAPHIC HASH & AV ENRICHMENT
        </h2>
        <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
          Check signature structures (MD5, SHA1, SHA256) for malicious Trojan indicators mapped against VirusTotal and MalwareBazaar file databases.
        </p>

        <div className="flex gap-2 max-w-2xl">
          <div className="relative flex-1">
            <Hash className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              id="hash-investigate-input"
              type="text"
              placeholder="Enter cryptographic hash file signature (MD5 / SHA256)..."
              value={hashInput}
              onChange={(e) => setHashInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch(hashInput)}
              className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
            />
          </div>
          <button
            onClick={() => handleSearch(hashInput)}
            disabled={loading}
            className="bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono transition font-bold disabled:opacity-50 cursor-pointer"
          >
            {loading ? "SEARCHING..." : "ANALYZE HASH"}
          </button>
        </div>

        {/* Real-time Hash Identification Panel */}
        {hashInput.trim().length > 0 && (
          <div className="mt-4 p-3 bg-slate-950/60 border border-slate-900 rounded font-mono text-[11px] space-y-2 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900/60 pb-2">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                <span className="text-slate-350 uppercase font-bold text-[10px]">Real-Time Structural Analysis</span>
              </div>
              <div className="flex items-center gap-3 text-slate-500 text-[10px]">
                <span>Char Count: <strong className="text-slate-300">{hashInput.trim().length}</strong></span>
                <span>Format: <strong className="text-slate-300">{identifyHashType(hashInput).format}</strong></span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-1 text-[11px]">
              <div className="sm:col-span-1">
                <span className="text-slate-550 block text-[9px] uppercase font-bold">Inferred Type</span>
                <span className="text-slate-200 font-bold block text-xs mt-0.5">{identifyHashType(hashInput).type}</span>
              </div>
              <div className="sm:col-span-1">
                <span className="text-slate-550 block text-[9px] uppercase font-bold">Cryptographic Health</span>
                <span className={`font-bold mt-1 inline-flex items-center px-1.5 py-0.2 rounded border text-[8.5px] uppercase ${
                  identifyHashType(hashInput).security === "strong" ? "bg-emerald-950/45 text-emerald-400 border-emerald-950" :
                  identifyHashType(hashInput).security === "vulnerable" ? "bg-amber-950/45 text-amber-500 border-amber-900" :
                  identifyHashType(hashInput).security === "highly-compromised" ? "bg-red-950/45 text-red-400 border-red-900 animate-pulse" :
                  "bg-slate-900 border-slate-800 text-slate-400"
                }`}>
                  {identifyHashType(hashInput).security.replace("-", " ")}
                </span>
              </div>
              <div className="sm:col-span-2">
                <span className="text-slate-550 block text-[9px] uppercase font-bold">Technical Vectors / Strength Profile</span>
                <p className="text-slate-405 text-[10.5px] mt-0.5 leading-normal">{identifyHashType(hashInput).notes}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
          <div className="relative flex h-8 w-8">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-8 w-8 bg-orange-600"></span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Consulting global signature indices and sandboxed file reports...
          </span>
        </div>
      )}

      {result && !loading && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          {/* Summary */}
          <div className="space-y-4">
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
              <div className={`absolute top-0 left-0 right-0 h-1 ${
                result.reputation === "malicious" ? "bg-red-500" :
                result.reputation === "suspicious" ? "bg-orange-500" :
                "bg-emerald-500"
              }`} />

              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono text-slate-400">FILE SIGNATURE DETAILS</span>
                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase ${
                  result.reputation === "malicious" ? "bg-red-950 text-red-400 border-red-950" :
                  result.reputation === "suspicious" ? "bg-orange-950 text-orange-400 border-orange-950" :
                  "bg-emerald-950 text-emerald-400 border-emerald-950"
                }`}>
                  {result.reputation}
                </span>
              </div>

              {/* Big Reputation Score Indicator */}
              {result.reputationScore !== undefined && (
                <div className="flex flex-col items-center justify-center py-5 border-b border-slate-900/60 mb-4 bg-slate-950/30 rounded">
                  <span className="text-[10px] font-mono text-slate-500 tracking-wider font-bold">
                    FILE REPUTATION SCORE
                  </span>
                  <span className={`text-5xl font-mono font-extrabold mt-1 tracking-tight ${
                    result.reputationScore > 75 ? "text-red-500" : 
                    result.reputationScore > 35 ? "text-orange-500" : 
                    "text-emerald-500"
                  }`}>
                    {result.reputationScore}/100
                  </span>
                  <span className="text-[9px] font-mono text-slate-550 italic mt-1 leading-xs max-w-xs text-center px-4">
                    Based on {result.stats?.malicious || 0} engine flags out of {(result.stats?.malicious || 0) + (result.stats?.harmless || 0)} antivirus vendors.
                  </span>
                </div>
              )}

              {/* Big threat result */}
              <div className="border-b border-slate-900 pb-4 mb-4 select-none">
                <span className="text-[10px] font-mono text-slate-550 block mb-1">MAPPED MALWARE FAMILY:</span>
                <h3 className={`text-xl font-mono font-bold ${
                  result.reputation === "malicious" ? "text-red-500" :
                  result.reputation === "suspicious" ? "text-orange-500" :
                  "text-emerald-500"
                }`}>
                  {result.malwareFamily}
                </h3>
              </div>

              {/* Hashes & telemetry */}
              <div className="space-y-3 font-mono text-[10px] text-slate-400 mb-4">
                <div className="flex flex-col border-b border-slate-900/40 pb-1.5 break-all">
                  <span className="text-slate-550 uppercase">TARGET HASH ({result.type}):</span>
                  <span className="text-slate-200 mt-0.5">{result.hash}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">FIRST SEEN:</span>
                  <span className="text-slate-350">{result.firstSeen}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">LAST SEEN:</span>
                  <span className="text-slate-350">{result.lastSeen}</span>
                </div>
              </div>

              {/* Filenames list */}
              <div>
                <span className="text-[9px] font-mono text-slate-500 block mb-1.5 uppercase tracking-widest font-bold">
                  Identified Filenames Mapped
                </span>
                <div className="bg-slate-950 p-2.5 border border-slate-900 rounded font-mono text-[10px] text-slate-400 space-y-1 max-h-[140px] overflow-y-auto">
                  {!result.fileNames || result.fileNames.length === 0 ? (
                    <div className="text-slate-600 italic text-[9.5px]">No mapped filenames reported in VirusTotal feed.</div>
                  ) : (
                    (Array.isArray(result.fileNames) ? result.fileNames : []).map((name, idx) => (
                      <div key={idx} className="flex items-center gap-1.5">
                        <FileText className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="truncate">{name}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Tags */}
              <div className="mt-4">
                <span className="text-[9px] font-mono text-slate-550 block mb-1.5 uppercase font-bold">
                  Classifier Tags Mapped
                </span>
                <div className="flex flex-wrap gap-1">
                  {(Array.isArray(result.tags) ? result.tags : []).map((tag, idx) => (
                    <span key={idx} className="bg-slate-905 border border-slate-900 text-slate-350 px-2 py-0.5 rounded text-[9px] font-mono font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Second Card: Forensic Attributes */}
            {(result.size !== undefined || result.typeDescription || result.magic || result.creationTime || result.md5 || result.sha1) && (
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4 font-mono text-[11px] text-slate-400">
                <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-widest flex items-center gap-1.5">
                    <Fingerprint className="w-4 h-4 text-emerald-400 shrink-0" />
                    Forensic File Attributes
                  </span>
                  <span className="text-[9px] text-slate-500 uppercase">VT EXTRAS</span>
                </div>

                <div className="space-y-2.5">
                  {result.typeDescription && (
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-550">FILE TYPE:</span>
                      <span className="text-slate-300 font-bold text-right truncate max-w-[160px]">{result.typeDescription}</span>
                    </div>
                  )}
                  {result.size !== undefined && (
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-550">FILE SIZE:</span>
                      <span className="text-slate-300">
                        {result.size.toLocaleString()} B {result.size > 1024 ? `(${(result.size / 1024).toFixed(1)} KB)` : ""}
                      </span>
                    </div>
                  )}
                  {result.creationTime && (
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-550">CREATION DATE:</span>
                      <span className="text-slate-300">{result.creationTime}</span>
                    </div>
                  )}
                  {result.magic && (
                    <div className="flex flex-col border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-550">MAGIC HEADER:</span>
                      <span className="text-slate-350 text-[10px] leading-relaxed mt-0.5 break-words">{result.magic}</span>
                    </div>
                  )}

                  {/* Hash block */}
                  <div className="space-y-2 pt-1">
                    <span className="text-[9px] text-slate-550 uppercase font-bold tracking-wider">Related Signature Hashes</span>
                    {result.md5 && (
                      <div className="bg-slate-950/80 p-2 border border-slate-900/60 rounded flex items-center justify-between text-[10px]">
                        <span className="text-slate-550 mr-2 uppercase shrink-0">MD5:</span>
                        <span className="text-slate-300 font-mono truncate mr-2 select-all">{result.md5}</span>
                        <button
                          onClick={() => handleCopyHash(result.md5!, "md5")}
                          className="text-slate-500 hover:text-slate-300 shrink-0 cursor-pointer"
                          title="Copy MD5"
                        >
                          {copiedHashKey === "md5" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    )}
                    {result.sha1 && (
                      <div className="bg-slate-950/80 p-2 border border-slate-900/60 rounded flex items-center justify-between text-[10px]">
                        <span className="text-slate-550 mr-2 uppercase shrink-0">SHA1:</span>
                        <span className="text-slate-300 font-mono truncate mr-2 select-all">{result.sha1}</span>
                        <button
                          onClick={() => handleCopyHash(result.sha1!, "sha1")}
                          className="text-slate-500 hover:text-slate-300 shrink-0 cursor-pointer"
                          title="Copy SHA-1"
                        >
                          {copiedHashKey === "sha1" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    )}
                    {result.sha256 && (
                      <div className="bg-slate-950/80 p-2 border border-slate-900/60 rounded flex items-center justify-between text-[10px]">
                        <span className="text-slate-550 mr-2 uppercase shrink-0">SHA256:</span>
                        <span className="text-slate-300 font-mono truncate mr-2 select-all">{result.sha256}</span>
                        <button
                          onClick={() => handleCopyHash(result.sha256!, "sha256")}
                          className="text-slate-500 hover:text-slate-300 shrink-0 cursor-pointer"
                          title="Copy SHA-256"
                        >
                          {copiedHashKey === "sha256" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* VT Extra Tags */}
                  {result.vtTags && result.vtTags.length > 0 && (
                    <div className="pt-2">
                      <span className="text-[9px] text-slate-550 uppercase font-bold tracking-wider block mb-1">VirusTotal Metadata Tags</span>
                      <div className="flex flex-wrap gap-1">
                        {result.vtTags.map((tag, idx) => (
                          <span key={idx} className="bg-emerald-950/20 border border-emerald-900/30 text-emerald-400 px-1.5 py-0.5 rounded text-[8.5px]">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* AV details */}
          <div className="lg:col-span-2 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col justify-between h-full min-h-[440px]">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase">
                  ANTI-VIRUS VENDOR SCAN ANALYSIS
                </h3>
                <span className="text-[9px] font-mono text-slate-500">HASH DE-CRACK DETECTOR</span>
              </div>

              {/* AV detections results */}
              {!result.detections || !Array.isArray(result.detections) || result.detections.length === 0 ? (
                <div className="p-8 text-center text-slate-600 bg-slate-950 border border-slate-900 rounded font-mono text-[11px]">
                  No antivirus vendors flagged this hash signature file as bad (Clean Whitelisted).
                </div>
              ) : (
                <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                  <table className="w-full text-left font-mono text-[11px] select-none">
                     <thead>
                       <tr className="bg-slate-955 text-slate-500 border-b border-slate-900">
                         <th className="p-3">AV Vendor</th>
                         <th className="p-3">Result</th>
                         <th className="p-3 text-right">Severity</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-900/60">
                       {(Array.isArray(result.detections) ? result.detections : []).map((d, id) => (
                        <tr key={id} className="hover:bg-slate-900/20">
                          <td className="p-3 font-semibold text-slate-300">{d.engine}</td>
                          <td className="p-3 text-red-400 font-medium break-all">{d.result}</td>
                          <td className="p-3 text-right">
                            <span className="bg-red-950 text-red-500 border border-red-950 text-[9px] px-1 py-0.5 rounded font-bold uppercase">
                              {d.category}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center font-mono text-[10px] select-none">
              <span className="text-slate-600">STRUCTURED FILE META EXPORTS</span>
              <button
                onClick={executeCopy}
                className="text-[10px] font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 bg-slate-950 border border-slate-900 px-2.5 py-1 rounded cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "COPIED" : "EXPORT JSON HASH"}
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Web Grounding & APT/Malware Associations below the main row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6 animate-fade-in">
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4 lg:col-span-1">
            <div className="flex justify-between items-center border-b border-slate-900 pb-2">
              <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-400" />
                AI web findings
              </h3>
              <span className="text-[9px] bg-slate-900 border border-slate-800 text-blue-400 font-mono px-2 py-0.5 rounded flex items-center gap-1">
                <Search className="w-3 h-3 text-blue-450 shrink-0" />
                Active
              </span>
            </div>

            <div className="space-y-4">
              {/* Threat Actor/APT Block */}
              <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                  <UserCheck className="w-4 h-4 text-orange-400" />
                  Associated APT Groups
                </div>
                {result.threatActors && Array.isArray(result.threatActors) && result.threatActors.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {result.threatActors.map((actor, idx) => (
                      <span key={idx} className="bg-orange-950/40 text-orange-400 border border-orange-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                        {actor}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-[10px] italic">No Advanced Persistent Threat (APT) groups directly associated with this file hash signature.</p>
                )}
              </div>

              {/* Malware / Trojan / Virus Type Block */}
              <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                <div className="flex items-center gap-1.5 text-slate-305 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                  <CloudLightning className="w-4 h-4 text-red-400" />
                  Associated Malware Type
                </div>
                {result.malwareAssociations && Array.isArray(result.malwareAssociations) && result.malwareAssociations.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 mt-1 font-bold">
                    {result.malwareAssociations.map((malware, idx) => (
                      <span key={idx} className="bg-red-950/40 text-red-400 border border-red-900/50 text-[10px] px-2.5 py-0.5 rounded">
                        {malware}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-[10px] italic">No dynamic malware families associated with this signature outside of core scanner engine matches.</p>
                )}
              </div>
            </div>
          </div>

          {/* MITRE ATT&CK Mapping Segment on the right spanning 2 cols */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-3 lg:col-span-2">
            <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2 border-b border-slate-900 pb-2 mb-1">
              <Terminal className="w-4 h-4 text-amber-500" />
              MITRE ATT&CK TACTICS & TECHNIQUES MAPPED TO HASH SIGNATURE
            </h3>

            {result.mitreMappings && Array.isArray(result.mitreMappings) && result.mitreMappings.length > 0 ? (
              <div className="space-y-2">
                {result.mitreMappings.map((mapping, idx) => (
                  <div key={idx} className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px]">
                    <div className="flex justify-between items-start mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="bg-amber-950 text-amber-400 border border-amber-900/60 font-bold text-[10px] px-2 py-0.5 rounded">
                          {mapping.id}
                        </span>
                        <span className="text-slate-250 font-bold font-mono text-xs">{mapping.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wide font-semibold">
                        TACTIC: {mapping.tactic}
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] leading-normal">{mapping.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] text-slate-500 italic">
                No active TTP techniques dynamically mapped to hash properties.
              </div>
            )}
          </div>
        </div>
      </>
    )}
  </div>
  );
}
