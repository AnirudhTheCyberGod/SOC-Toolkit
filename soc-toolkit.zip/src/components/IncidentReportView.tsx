/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  FileText,
  Printer,
  Download,
  Copy,
  Check,
  ShieldAlert,
  AlertTriangle,
  Building2,
  Scale,
  DollarSign,
  Activity,
  Layers,
  Sparkles,
  Clock,
  CheckCircle2,
  Calendar,
  Lock,
  UserCheck
} from "lucide-react";

interface IncidentReportData {
  documentId: string;
  title: string;
  severity: string;
  date: string;
  executiveSummary: {
    overview: string;
    businessImpact: string;
    compliance: string;
    financialExposure: string;
    signoffStatus: string;
  };
  technicalForensics: {
    technicalSummary: string;
    actor: string;
    assets: string[];
    timeline: Array<{
      timestamp: string;
      message: string;
      severity: string;
      techniqueId?: string;
      tactic?: string;
    }>;
    iocs: Array<{ type: string; value: string; notes?: string }>;
  };
  markdown: string;
}

const PRESET_INCIDENTS = [
  {
    title: "Executive Spearphishing & Credential Compromise",
    severity: "P2 - High",
    actor: "TA505 / Phishing Cluster",
    assets: ["CORP-LAPTOP-102", "O365-TENANT-ROOT", "SSO-GATEWAY-01"],
    desc: "A targeted spearphishing lure spoofing iCloud enterprise services resulted in valid session token theft. The adversary attempted lateral movement toward internal billing directories before endpoint EDR isolation was engaged."
  },
  {
    title: "LockBit 3.0 Ransomware Lateral Incursion",
    severity: "P1 - Critical",
    actor: "LockBit Affiliate Group",
    assets: ["FILE-SRV-04", "BACKUP-NAS-01", "DC02.CORP.LOCAL"],
    desc: "Adversary gained initial access via compromised VPN credentials, executed PsExec lateral propagation, and staged 120GB of accounting data for extortion. Automated host quarantine mitigated widespread encryption."
  },
  {
    title: "AWS CloudTrail API Token Unauthorized Exposure",
    severity: "P2 - High",
    actor: "Automated Cloud Scraper / Undetermined",
    assets: ["AWS-PROD-IAM-ROLE", "S3-CUSTOMER-VAULT", "LAMBDA-PAYMENT-SVC"],
    desc: "An orphaned CI/CD pipeline token leaked to an external test repository. Multiple DescribeInstances and GetObject API calls were intercepted from bulletproof hosting subnets within 14 minutes."
  }
];

export default function IncidentReportView() {
  const [activeTab, setActiveTab] = useState<"executive" | "technical" | "markdown">("executive");
  const [incidentTitle, setIncidentTitle] = useState(PRESET_INCIDENTS[0].title);
  const [severity, setSeverity] = useState(PRESET_INCIDENTS[0].severity);
  const [actor, setActor] = useState(PRESET_INCIDENTS[0].actor);
  const [affectedAssets, setAffectedAssets] = useState(PRESET_INCIDENTS[0].assets.join(", "));
  const [description, setDescription] = useState(PRESET_INCIDENTS[0].desc);
  const [report, setReport] = useState<IncidentReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerateReport = async () => {
    setLoading(true);
    try {
      const apiKey = localStorage.getItem("GEMINI_API_KEY") || "";
      const assetsList = affectedAssets.split(",").map(a => a.trim()).filter(Boolean);

      const res = await fetch("/api/ai/incident-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          incidentTitle,
          severity,
          actor,
          affectedAssets: assetsList,
          description,
          timelineEvents: [
            { timestamp: "T-00:00", message: "Initial phishing link delivery via email gateway", severity: "medium", techniqueId: "T1566", tactic: "Initial Access" },
            { timestamp: "T+00:03", message: "User credentials entered on lookalike portal", severity: "high", techniqueId: "T1078", tactic: "Credential Access" },
            { timestamp: "T+00:07", message: "PowerShell dropper execution on endpoint", severity: "critical", techniqueId: "T1059.001", tactic: "Execution" },
            { timestamp: "T+00:11", message: "Outbound C2 beaconing to 185.112.146.22", severity: "critical", techniqueId: "T1071", tactic: "Command & Control" },
            { timestamp: "T+00:14", message: "Endpoint isolated & session tokens revoked", severity: "info", techniqueId: "T1562", tactic: "Containment" }
          ],
          iocs: [
            { type: "Domain", value: "br-icloud.com.br", notes: "Credential Phishing Lure" },
            { type: "IP Address", value: "185.112.146.22", notes: "C2 Controller (Netherlands)" },
            { type: "SHA-256", value: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", notes: "Dropper Payload Binary" }
          ],
          apiKey
        })
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setReport(data);
    } catch (err: any) {
      console.error("Report generation error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleGenerateReport();
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadMarkdown = () => {
    if (!report?.markdown) return;
    const blob = new Blob([report.markdown], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Incident-Report-${report.documentId}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    if (!report) return;
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Incident-Report-${report.documentId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyMarkdown = () => {
    if (!report?.markdown) return;
    navigator.clipboard.writeText(report.markdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Header Banner */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-6 backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="p-1.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <FileText className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-mono font-bold tracking-wider text-slate-100 uppercase">
                One-Click Incident Report Exporter
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-400 font-bold uppercase">
                Executive & Technical DFIR
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              Compile enterprise-grade cyber incident reports tailored for both C-suite executives and forensic engineers. Includes business impact risk, GDPR/SEC compliance metrics, MITRE ATT&CK kill chain mappings, and instant PDF/Markdown export.
            </p>
          </div>

          {/* Incident Presets */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mr-1">
              Templates:
            </span>
            {PRESET_INCIDENTS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setIncidentTitle(p.title);
                  setSeverity(p.severity);
                  setActor(p.actor);
                  setAffectedAssets(p.assets.join(", "));
                  setDescription(p.desc);
                }}
                className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 active:scale-95 transition"
              >
                {p.severity.split(" - ")[0]}: {p.title.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Incident Configuration Controls */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4 font-mono text-xs">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
              Incident Title
            </label>
            <input
              type="text"
              value={incidentTitle}
              onChange={e => setIncidentTitle(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
              Incident Priority / Severity
            </label>
            <select
              value={severity}
              onChange={e => setSeverity(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="P1 - Critical">P1 - Critical (Enterprise Disruption)</option>
              <option value="P2 - High">P2 - High (Targeted Incursion / Breach)</option>
              <option value="P3 - Medium">P3 - Medium (Isolated Malware / Phishing)</option>
              <option value="P4 - Low">P4 - Low (Policy / Scanner Ingress)</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
              Attributed Threat Actor
            </label>
            <input
              type="text"
              value={actor}
              onChange={e => setActor(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
              Compromised / Affected Assets (Comma Separated)
            </label>
            <input
              type="text"
              value={affectedAssets}
              onChange={e => setAffectedAssets(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
              Analyst Incident Briefing
            </label>
            <input
              type="text"
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="flex justify-end pt-1">
          <button
            type="button"
            onClick={handleGenerateReport}
            disabled={loading}
            className="px-5 py-2 rounded bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold uppercase tracking-wider flex items-center gap-2 transition disabled:opacity-50 cursor-pointer shadow-lg shadow-emerald-950/40"
          >
            {loading ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Compiling Report...
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                Generate Incident Report
              </>
            )}
          </button>
        </div>
      </div>

      {/* Report Workspace */}
      {report && (
        <div className="bg-slate-950/80 border border-slate-900 rounded-lg backdrop-blur-md overflow-hidden font-sans">
          {/* Action Header Ribbon */}
          <div className="p-4 border-b border-slate-900 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
            {/* Audience View Switcher */}
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded p-0.5">
              <button
                type="button"
                onClick={() => setActiveTab("executive")}
                className={`px-3 py-1 rounded transition ${
                  activeTab === "executive"
                    ? "bg-emerald-600 text-white font-bold shadow"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Executive Summary
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("technical")}
                className={`px-3 py-1 rounded transition ${
                  activeTab === "technical"
                    ? "bg-emerald-600 text-white font-bold shadow"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Technical DFIR
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("markdown")}
                className={`px-3 py-1 rounded transition ${
                  activeTab === "markdown"
                    ? "bg-emerald-600 text-white font-bold shadow"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Raw Markdown
              </button>
            </div>

            {/* Export Actions */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrint}
                className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5"
                title="Print or Save as PDF"
              >
                <Printer className="w-3.5 h-3.5 text-slate-400" />
                <span>Print / PDF</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadMarkdown}
                className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5"
                title="Download Markdown Report"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>.MD</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadJson}
                className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5"
                title="Download JSON Telemetry"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>.JSON</span>
              </button>

              <button
                type="button"
                onClick={handleCopyMarkdown}
                className="px-3 py-1.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy Text</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Printable Report Document Body */}
          <div className="p-6 md:p-8 space-y-8 print:p-0 print:bg-white print:text-black">
            {/* Document Header */}
            <div className="border-b border-slate-850 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest block font-bold">
                  THREATNEXUS INCIDENT REPORT // {report.documentId}
                </span>
                <h1 className="text-xl md:text-2xl font-mono font-bold text-slate-100 uppercase tracking-wide mt-1">
                  {report.title}
                </h1>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs font-mono text-slate-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    {report.date}
                  </span>
                  <span>•</span>
                  <span>Classification: CONFIDENTIAL // TLP:AMBER</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`px-3 py-1.5 rounded font-mono text-xs font-bold uppercase border ${
                  report.severity.includes("P1")
                    ? "bg-red-950/80 border-red-800 text-red-400"
                    : "bg-orange-950/80 border-orange-800 text-orange-400"
                }`}>
                  {report.severity}
                </span>
              </div>
            </div>

            {/* TAB 1: EXECUTIVE SUMMARY */}
            {activeTab === "executive" && (
              <div className="space-y-6">
                {/* Executive Brief Card */}
                <div className="bg-slate-900/40 border border-slate-850 rounded-lg p-6 space-y-3">
                  <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    Executive Briefing & Strategic Overview
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {report.executiveSummary.overview}
                  </p>
                </div>

                {/* Key Executive Pillars */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Business Impact */}
                  <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-2">
                    <div className="flex items-center gap-2 text-blue-400 font-mono text-xs font-bold uppercase">
                      <Activity className="w-4 h-4" />
                      <span>Business & Line Impact</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {report.executiveSummary.businessImpact}
                    </p>
                  </div>

                  {/* Regulatory & Compliance */}
                  <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-2">
                    <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-bold uppercase">
                      <Scale className="w-4 h-4" />
                      <span>Regulatory & Compliance</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {report.executiveSummary.compliance}
                    </p>
                  </div>

                  {/* Financial Risk */}
                  <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-2">
                    <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold uppercase">
                      <DollarSign className="w-4 h-4" />
                      <span>Estimated Exposure</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {report.executiveSummary.financialExposure}
                    </p>
                  </div>
                </div>

                {/* Sign-off Authorization */}
                <div className="bg-slate-900/40 border border-slate-850 rounded-lg p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-mono text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                      <UserCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase block">
                        Signoff Status
                      </span>
                      <span className="text-slate-100 font-bold">
                        {report.executiveSummary.signoffStatus}
                      </span>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Timestamp: {report.date} 09:30 UTC // Chain of Custody Verified
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: TECHNICAL DFIR REPORT */}
            {activeTab === "technical" && (
              <div className="space-y-6">
                {/* Forensic Chronology */}
                <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-4 font-mono">
                  <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    Forensic Chronology & Attack Timeline
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-850 text-slate-500 text-[10px] uppercase">
                          <th className="py-2 px-3">Timestamp</th>
                          <th className="py-2 px-3">Description</th>
                          <th className="py-2 px-3">Severity</th>
                          <th className="py-2 px-3">MITRE Technique</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/60 text-slate-300">
                        {report.technicalForensics.timeline.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/40">
                            <td className="py-2 px-3 text-slate-400 font-bold">{item.timestamp}</td>
                            <td className="py-2 px-3">{item.message}</td>
                            <td className="py-2 px-3">
                              <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase font-bold ${
                                item.severity === "critical"
                                  ? "bg-red-950 border-red-900 text-red-400"
                                  : item.severity === "high"
                                  ? "bg-orange-950 border-orange-900 text-orange-400"
                                  : "bg-slate-900 border-slate-800 text-slate-400"
                              }`}>
                                {item.severity}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-emerald-400 font-mono">
                              {item.techniqueId} {item.tactic}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Compromised Assets & IOC Matrix */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
                  {/* Affected Assets */}
                  <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-3">
                    <h3 className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
                      <Lock className="w-4 h-4 text-emerald-400" />
                      Targeted / Compromised Assets
                    </h3>
                    <div className="space-y-1.5">
                      {report.technicalForensics.assets.map((asset, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between p-2 bg-slate-950/60 border border-slate-850 rounded text-slate-200"
                        >
                          <span className="font-bold">{asset}</span>
                          <span className="text-[10px] text-amber-400 uppercase">Isolated</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* IOC Table */}
                  <div className="bg-slate-900/30 border border-slate-850 rounded-lg p-5 space-y-3">
                    <h3 className="font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-400" />
                      Forensic IOCs & Artifacts
                    </h3>
                    <div className="space-y-1.5">
                      {report.technicalForensics.iocs.map((ioc, i) => (
                        <div
                          key={i}
                          className="p-2 bg-slate-950/60 border border-slate-850 rounded text-slate-200 space-y-0.5"
                        >
                          <div className="flex justify-between text-[10px] text-slate-500">
                            <span>{ioc.type}</span>
                            <span>{ioc.notes}</span>
                          </div>
                          <div className="text-[11px] font-mono text-emerald-300 break-all select-all">
                            {ioc.value}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: RAW MARKDOWN */}
            {activeTab === "markdown" && (
              <div className="font-mono text-xs">
                <pre className="p-4 bg-slate-1000 border border-slate-850 rounded-lg text-slate-300 overflow-x-auto leading-relaxed whitespace-pre-wrap select-all">
                  {report.markdown}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
