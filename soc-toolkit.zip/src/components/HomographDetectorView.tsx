/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Globe,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Search,
  RotateCcw,
  ShieldAlert,
  Terminal,
  Activity,
  Copy,
  Check,
  Zap,
  ArrowRight
} from "lucide-react";

interface PermutationItem {
  variant: string;
  punycode?: string;
  type: "Homoglyph" | "Omission" | "Repetition" | "Transposition" | "Replacement" | "Bitsquatting" | "Combosquatting" | "TLD Swap";
  risk: "High" | "Medium" | "Low";
  ip?: string | null;
  status: "Resolving / Registered" | "Unregistered / Available" | "Checking";
}

interface HomographAnalysisResult {
  originalDomain: string;
  isIdnHomoglyph: boolean;
  detectedHomoglyphs: Array<{
    position: number;
    character: string;
    charCode: string;
  }>;
  totalPermutations: number;
  registeredCount: number;
  overallRisk: string;
  permutations: PermutationItem[];
}

const PRESET_DOMAINS = [
  { label: "apple.com", desc: "High-value brand target" },
  { label: "br-icloud.com.br", desc: "Active phishing combosquatting lure" },
  { label: "paypal.com", desc: "Frequent financial phishing target" },
  { label: "microsoft.com", desc: "Corporate credential harvesting" }
];

interface HomographProps {
  onPivotToDomain?: (domain: string) => void;
  onPivotToUrl?: (url: string) => void;
}

export default function HomographDetectorView({ onPivotToDomain, onPivotToUrl }: HomographProps) {
  const [domainInput, setDomainInput] = useState("apple.com");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HomographAnalysisResult | null>(null);
  const [error, setError] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [copiedDomain, setCopiedDomain] = useState<string | null>(null);

  const handleAnalyze = async (domainToTest?: string) => {
    const target = (domainToTest || domainInput).trim();
    if (!target) {
      setError("Please provide a domain to inspect.");
      return;
    }
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/homograph/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: target })
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Failed to analyze homograph permutations.");
    } finally {
      setLoading(false);
    }
  };

  // Run on initial mount
  useEffect(() => {
    handleAnalyze("apple.com");
  }, []);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDomain(text);
    setTimeout(() => setCopiedDomain(null), 1500);
  };

  const filteredPermutations = (result?.permutations || []).filter(p => {
    if (filterType === "registered") return p.status === "Resolving / Registered";
    if (filterType === "high-risk") return p.risk === "High";
    if (filterType === "homoglyph") return p.type === "Homoglyph";
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Header Banner */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-6 backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="p-1.5 rounded bg-blue-500/10 border border-blue-500/30 text-blue-400">
                <Globe className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-mono font-bold tracking-wider text-slate-100 uppercase">
                Homograph & Typosquatting Detector
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950/60 border border-blue-800 text-blue-400 font-bold uppercase">
                IDN & Permutations
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              Detect Internationalized Domain Name (IDN) homoglyph spoofing (e.g. Cyrillic "а" instead of Latin "a") and simulate weaponized typosquatting permutations. ThreatNexus probes DNS records in real-time to identify active lookalike lures targeting your brand or employees.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mr-1">
              Targets:
            </span>
            {PRESET_DOMAINS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setDomainInput(p.label);
                  handleAnalyze(p.label);
                }}
                className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 active:scale-95 transition"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Workbench */}
      <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleAnalyze();
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Globe className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              value={domainInput}
              onChange={e => setDomainInput(e.target.value)}
              placeholder="e.g. apple.com, paypal.com, or suspicious lookalike URL"
              className="w-full pl-10 pr-4 py-2.5 bg-slate-1000/90 border border-slate-850 rounded font-mono text-xs text-slate-100 focus:outline-none focus:border-blue-500/60"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-mono text-xs font-bold uppercase tracking-wider rounded transition flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-lg shadow-blue-950/40"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Auditing DNS...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                Audit Typosquatting
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-500/30 text-red-300 text-xs font-mono rounded flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Results Overview */}
      {result && (
        <div className="space-y-6">
          {/* Top Metrics Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono">
            <div className="bg-slate-950/80 border border-slate-900 rounded p-4">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Target Entity
              </span>
              <span className="text-base font-bold text-slate-200 mt-1 block truncate">
                {result.originalDomain}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                IDN Homoglyphs
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-base font-bold ${
                  result.isIdnHomoglyph ? "text-red-400" : "text-emerald-400"
                }`}>
                  {result.isIdnHomoglyph ? "DETECTED" : "CLEAN (ASCII)"}
                </span>
              </div>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Permutations Audited
              </span>
              <span className="text-xl font-bold text-slate-200 mt-1 block">
                {result.totalPermutations} <span className="text-xs text-slate-500 font-normal">vectors</span>
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-900 rounded p-4">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
                Active DNS Resolutions
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-xl font-bold text-red-400">
                  {result.registeredCount}
                </span>
                <span className="text-xs text-slate-500">live lookalikes</span>
              </div>
            </div>
          </div>

          {/* IDN Homoglyph Warning Card if detected */}
          {result.isIdnHomoglyph && (
            <div className="bg-red-950/30 border border-red-500/40 rounded-lg p-5 backdrop-blur-md space-y-3 font-mono">
              <div className="flex items-center gap-2 text-red-400">
                <ShieldAlert className="w-5 h-5 animate-pulse" />
                <h3 className="text-xs font-bold uppercase tracking-wider">
                  Critical Alert: Non-ASCII IDN Homoglyphs Present
                </h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                This domain utilizes Unicode characters from external non-Latin alphabets (such as Cyrillic or Greek) that appear visually identical to standard Latin characters. This is a classic indicator of a sophisticated spearphishing campaign.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                {result.detectedHomoglyphs.map((h, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded bg-red-950 border border-red-800 text-red-300 text-xs flex items-center gap-2"
                  >
                    <span>Char: '{h.character}'</span>
                    <span className="text-[10px] text-red-400 font-bold">({h.charCode})</span>
                    <span className="text-[10px] text-slate-500">Pos: {h.position}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Permutations Table */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-lg p-5 backdrop-blur-md space-y-4 font-mono">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider">
                  Simulated Typosquatting Permutations & Active Resolvers
                </h3>
              </div>

              {/* Filter Buttons */}
              <div className="flex items-center gap-1.5 text-xs">
                {[
                  { id: "all", label: "All" },
                  { id: "registered", label: "Resolving Only" },
                  { id: "high-risk", label: "High Risk" },
                  { id: "homoglyph", label: "Homoglyphs" }
                ].map(f => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setFilterType(f.id)}
                    className={`px-2.5 py-0.5 rounded text-[11px] border transition ${
                      filterType === f.id
                        ? "bg-blue-950 border-blue-800 text-blue-300 font-bold"
                        : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-900 text-[10px] text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-3">Lookalike Variant</th>
                    <th className="py-2.5 px-3">Vector Type</th>
                    <th className="py-2.5 px-3">Threat Risk</th>
                    <th className="py-2.5 px-3">DNS Status</th>
                    <th className="py-2.5 px-3">Resolved IP</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900/60 text-slate-300">
                  {filteredPermutations.map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40 transition">
                      <td className="py-2.5 px-3 font-semibold text-slate-200 flex items-center gap-2">
                        <span>{p.variant}</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(p.variant)}
                          className="text-slate-600 hover:text-slate-400 transition"
                          title="Copy Domain"
                        >
                          {copiedDomain === p.variant ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 uppercase">
                          {p.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border uppercase font-bold ${
                          p.risk === "High"
                            ? "bg-red-950/60 border-red-900 text-red-400"
                            : "bg-amber-950/60 border-amber-900 text-amber-400"
                        }`}>
                          {p.risk}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`text-[11px] font-bold flex items-center gap-1.5 ${
                          p.status === "Resolving / Registered"
                            ? "text-red-400"
                            : "text-slate-500"
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            p.status === "Resolving / Registered" ? "bg-red-500 animate-ping" : "bg-slate-600"
                          }`} />
                          {p.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-[11px] font-mono text-slate-400">
                        {p.ip || "—"}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {onPivotToDomain && (
                            <button
                              type="button"
                              onClick={() => onPivotToDomain(p.variant)}
                              className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10px] text-slate-300 hover:text-white transition flex items-center gap-1"
                              title="Enrich in Domain Invest"
                            >
                              <span>Domain</span>
                              <ExternalLink className="w-2.5 h-2.5 text-slate-500" />
                            </button>
                          )}
                          {onPivotToUrl && (
                            <button
                              type="button"
                              onClick={() => onPivotToUrl(`https://${p.variant}`)}
                              className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10px] text-slate-300 hover:text-white transition flex items-center gap-1"
                              title="Scan in URL Analysis"
                            >
                              <span>URL</span>
                              <ExternalLink className="w-2.5 h-2.5 text-slate-500" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
