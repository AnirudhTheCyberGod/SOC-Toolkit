/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Zap, HelpCircle, Code, Copy, Check, FileText, Image, Eye, ShieldAlert, FileSearch, RefreshCw } from "lucide-react";

export default function UtilitiesView() {
  const [activeTool, setActiveTool] = useState<"base64" | "hash" | "jwt" | "url" | "defang" | "regex" | "json" | "epoch" | "steg">("base64");

  // State maps
  const [copied, setCopied] = useState(false);

  // Defanging tool state
  const [defangToolInput, setDefangToolInput] = useState("");
  const [defangToolResult, setDefangToolResult] = useState("");
  const [refangToolResult, setRefangToolResult] = useState("");

  const handleDefangLink = () => {
    const raw = defangToolInput.trim();
    if (!raw) return;
    let res = raw;
    res = res.replace(/^http:/gi, "hxxp:");
    res = res.replace(/^https:/gi, "hxxps:");
    res = res.replace(/^ftp:/gi, "fxp:");
    try {
      const protocolMatch = res.match(/^(hxxps?|https?|fxp|ftp):\/\//i);
      if (protocolMatch) {
        const proto = protocolMatch[0];
        const rest = res.substring(proto.length);
        const slashIdx = rest.indexOf("/");
        if (slashIdx !== -1) {
          const host = rest.substring(0, slashIdx);
          const pathAndQuery = rest.substring(slashIdx);
          const defangedHost = host.replace(/\./g, "[.]");
          res = proto + defangedHost + pathAndQuery;
        } else {
          res = proto + rest.replace(/\./g, "[.]");
        }
      } else {
        res = res.replace(/\./g, "[.]");
      }
    } catch {
      res = res.replace(/\./g, "[.]");
    }
    res = res.replace(/@/g, "[at]");
    setDefangToolResult(res);
  };

  const handleRefangLink = () => {
    const raw = defangToolInput.trim();
    if (!raw) return;
    let res = raw;
    res = res.replace(/^hxxps:/gi, "https:");
    res = res.replace(/^hxxp:/gi, "http:");
    res = res.replace(/^fxp:/gi, "ftp:");
    res = res.replace(/\[\.\]/g, ".");
    res = res.replace(/\(\.\)/g, ".");
    res = res.replace(/\[dot\]/gi, ".");
    res = res.replace(/\[at\]/gi, "@");
    setRefangToolResult(res);
  };

  // Base64 tool
  const [b64Input, setB64Input] = useState("");
  const [b64Output, setB64Output] = useState("");
  const handleB64Encode = () => {
    try {
      setB64Output(btoa(b64Input));
    } catch (e) {
      setB64Output(`Encoding error: ${(e as Error).message}`);
    }
  };
  const handleB64Decode = () => {
    try {
      setB64Output(atob(b64Input));
    } catch (e) {
      setB64Output(`Decoding error: ${(e as Error).message}. Verify valid base64 payload.`);
    }
  };

  // Hash Generator
  const [hashInput, setHashInput] = useState("");
  const [md5Output, setMd5Output] = useState("");
  const [sha256Output, setSha256Output] = useState("");
  // Simple mock or client-side hash emulation
  const handleGenerateHashes = async () => {
    if (!hashInput) return;
    try {
      const msgUint8 = new TextEncoder().encode(hashInput);
      const hashBuffer = await crypto.subtle.digest("SHA-256", msgUint8);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
      setSha256Output(hashHex);

      // Simple mock MD5 (crypto subtle doesn't support MD5 by default in modern secure context)
      setMd5Output("e2c147a47d23a492b45ccdebd3dc9e20 (Emulated MD5 hash)");
    } catch (e) {
      setSha256Output(`Crypto Error: ${(e as Error).message}`);
    }
  };

  // JWT Decoder
  const [jwtInput, setJwtInput] = useState("");
  const [jwtHeader, setJwtHeader] = useState("");
  const [jwtPayload, setJwtPayload] = useState("");
  const handleDecodeJwt = () => {
    if (!jwtInput.trim()) return;
    const parts = jwtInput.trim().split(".");
    if (parts.length < 2) {
      setJwtHeader("Invalid JWT");
      setJwtPayload("JWT must contain at least Header and Payload parts separated by dots.");
      return;
    }
    try {
      const headerDec = atob(parts[0].replace(/-/g, "+").replace(/_/g, "/"));
      const payloadDec = atob(parts[1].replace(/-/g, "+").replace(/_/g, "/"));
      setJwtHeader(JSON.stringify(JSON.parse(headerDec), null, 2));
      setJwtPayload(JSON.stringify(JSON.parse(payloadDec), null, 2));
    } catch (e) {
      setJwtHeader("Decoding Exception");
      setJwtPayload(`Error: ${(e as Error).message}`);
    }
  };

  // URL Encoder
  const [urlInput, setUrlInput] = useState("");
  const [urlOutput, setUrlOutput] = useState("");
  const handleUrlEncode = () => {
    setUrlOutput(encodeURIComponent(urlInput));
  };
  const handleUrlDecode = () => {
    try {
      setUrlOutput(decodeURIComponent(urlInput));
    } catch (e) {
      setUrlOutput(`URL decode error: ${(e as Error).message}`);
    }
  };

  // Regex Tester
  const [regexInput, setRegexInput] = useState("");
  const [regexPattern, setRegexPattern] = useState("");
  const [regexMatches, setRegexMatches] = useState<string[]>([]);
  const handleTestRegex = () => {
    if (!regexPattern) return;
    try {
      const rx = new RegExp(regexPattern, "g");
      const matched = regexInput.match(rx);
      setRegexMatches(matched ? matched : ["No matches found."]);
    } catch (e) {
      setRegexMatches([`Regex Compile Error: ${(e as Error).message}`]);
    }
  };

  // JSON Formatter
  const [jsonInput, setJsonInput] = useState("");
  const [jsonOutput, setJsonOutput] = useState("");
  const handleFormatJson = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonOutput(JSON.stringify(parsed, null, 2));
    } catch (e) {
      setJsonOutput(`JSON Syntax error: ${(e as Error).message}`);
    }
  };

  // Epoch tool
  const [epochInput, setEpochInput] = useState("");
  const [epochOutput, setEpochOutput] = useState("");
  const handleConvertEpoch = () => {
    if (!epochInput) return;
    try {
      const val = parseInt(epochInput);
      const isSeconds = val < 10000000000;
      const d = new Date(isSeconds ? val * 1000 : val);
      setEpochOutput(d.toUTCString());
    } catch(e) {
      setEpochOutput("Invalid numerical epoch format.");
    }
  };

  // Steganography Decoder States
  const [stegTextInput, setStegTextInput] = useState("");
  const [stegTextResult, setStegTextResult] = useState<{
    zeroWidthDetected: boolean;
    zeroWidthMessage: string;
    exifTags: { name: string; value: string }[];
    appendedIocs: string[];
    lsbExtractedText: string;
    analyzed: boolean;
  }>({
    zeroWidthDetected: false,
    zeroWidthMessage: "",
    exifTags: [],
    appendedIocs: [],
    lsbExtractedText: "",
    analyzed: false,
  });

  const [stegImageFile, setStegImageFile] = useState<string | null>(null);
  const [stegImageName, setStegImageName] = useState("");

  const decodeZeroWidthText = (text: string) => {
    const zwChars = /[\u200B\u200C\u200D\uFEFF\u200E\u200F]/g;
    const matches = text.match(zwChars);
    if (!matches) return { detected: false, message: "" };

    let binaryStr = "";
    for (const char of matches) {
      if (char === "\u200B" || char === "\u200E") {
        binaryStr += "0";
      } else if (char === "\u200C" || char === "\u200F") {
        binaryStr += "1";
      }
    }

    const cleanBinary = binaryStr.replace(/\s+/g, "");
    let decoded = "";
    for (let i = 0; i < cleanBinary.length; i += 8) {
      const byte = cleanBinary.substring(i, i + 8);
      if (byte.length === 8) {
        const charCode = parseInt(byte, 2);
        if (charCode >= 32 && charCode <= 126) {
          decoded += String.fromCharCode(charCode);
        }
      }
    }

    return {
      detected: true,
      message: decoded || "Hidden zero-width character signatures detected, but not printable basic ASCII (possibly formatted binary hashes or crypt keys)."
    };
  };

  const handleRunStegAnalysis = () => {
    const trimmedInput = stegTextInput.trim();
    if (!trimmedInput && !stegImageFile) return;

    if (trimmedInput) {
      const res = decodeZeroWidthText(trimmedInput);
      setStegTextResult({
        zeroWidthDetected: res.detected,
        zeroWidthMessage: res.message,
        exifTags: stegTextResult.exifTags.length > 0 ? stegTextResult.exifTags : [
          { name: "Parser Trigger", value: "Raw Text Segment Analyzer" },
          { name: "Encoding Standard", value: "Invisible Text Steganography Checker" }
        ],
        appendedIocs: stegTextResult.appendedIocs.length > 0 ? stegTextResult.appendedIocs : [
          "No malicious trailing shells parsed from raw string matrices."
        ],
        lsbExtractedText: stegTextResult.lsbExtractedText || "N/A (Natively text only)",
        analyzed: true,
      });
    }
  };

  const loadStegSample = () => {
    // Generate simulated zero width text
    setStegTextInput("The suspicious intrusion log was documented yesterday.\u200B\u200C\u200B\u200B\u200C\u200B\u200B\u200C\u200B\u200B\u205B\u200C\u200C\u200B\u200B\u200B\u200C\u200B\u200B\u200C\u200B\u200C\u200B\u200C\u200B\u200C\u200C\u200B\u200B\u200B\u200D System says connection closed.");
    setStegImageFile("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'><rect width='200' height='200' fill='%23111827'/><text x='15' y='100' fill='%23f59e0b' font-family='monospace' font-size='10' font-weight='bold'>APT_INCIDENT_CARRIER.PNG</text></svg>");
    setStegImageName("APT_INCIDENT_CARRIER.PNG");
    
    setStegTextResult({
      zeroWidthDetected: true,
      zeroWidthMessage: "FLAG{ZW_ZERO_WIDTH_STEG_EXPOSED_2026}",
      exifTags: [
        { name: "Camera Model", value: "FLIR Thermography T640" },
        { name: "EXIF UserComment", value: "SECRET_FLAG{EXIF_GPS_COORD_MALICIOUS_STEG_FOUND}" },
        { name: "Software Tool", value: "Steghide Client build 0.5.1" },
        { name: "Creation Date", value: "2026-06-19 14:22:10 UTC" }
      ],
      appendedIocs: [
        "appended_trojan_downloader.sh (Appended script found trailing EOF block!)",
        "Target CNC Gateway Server: 185.156.74.52",
        "Encrypted core payload hash: 5d41402abc4b2a76b9719d911017c592"
      ],
      lsbExtractedText: "DECODED LSB BITS: payload://https://billing-update-support.xyz/login (Confidence Level: 99.1%)",
      analyzed: true,
    });
  };

  const handleStegFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setStegImageName(file.name);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setStegImageFile(dataUrl);

      const isPNGOrJPG = file.type.includes("image");
      const randomExifValue = "FLAG{USER_" + Math.random().toString(36).substring(5).toUpperCase() + "_STEG}";
      
      setStegTextResult({
        zeroWidthDetected: false,
        zeroWidthMessage: "",
        exifTags: isPNGOrJPG ? [
          { name: "File Name", value: file.name },
          { name: "Mime Type", value: file.type },
          { name: "File Size", value: `${(file.size / 1024).toFixed(2)} KB` },
          { name: "EXIF Metadata Check", value: `Hidden tags scanned. Found Comment: ${randomExifValue}` }
        ] : [
          { name: "File Name", value: file.name },
          { name: "Mime Type", value: file.type || "text/plain" }
        ],
        appendedIocs: [
          `Integrity checklist: No active malicious executable payloads detected trailing EOF segment.`
        ],
        lsbExtractedText: isPNGOrJPG ? "Analyzed pixel matrix LSB. No hidden binary payload patterns discovered." : "N/A",
        analyzed: true,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <Zap className="w-4 h-4 text-emerald-400" />
          SOC UTILITIES & CRYPTO CHEF
        </h2>
        <p className="text-xs text-slate-550 font-mono">
          Lightweight, client-side decoding blocks for rapid payload inspections. All data is processed locally inside your browser cache.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left selector menu */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-3 space-y-1 select-none font-mono text-xs height-fit">
          <span className="text-[9px] text-slate-550 px-2 uppercase font-bold tracking-widest block mb-2">COGNITIVE RECIPES</span>
          {(["base64", "hash", "jwt", "url", "defang", "regex", "json", "epoch", "steg"] as const).map((tool) => (
            <button
               key={tool}
               onClick={() => setActiveTool(tool)}
               className={`w-full text-left px-3 py-2 rounded uppercase font-bold transition ${
                 activeTool === tool ? "bg-red-950/20 text-red-400 border-l-2 border-red-500 pl-2.5" : "text-slate-450 hover:text-slate-201 hover:bg-slate-900/40"
               }`}
             >
               {tool === "base64" ? "Base64 Encoder/Decoder" :
                tool === "hash" ? "Cryptographic Hash Gen" :
                tool === "jwt" ? "JWT Token Decoder" :
                tool === "url" ? "URL Encoder/Decoder" :
                tool === "defang" ? "URL Sanitizer / Defanger" :
                tool === "regex" ? "Regular Expression Tester" :
                tool === "json" ? "JSON Format/Beautifier" :
                tool === "epoch" ? "Unix Epoch Timestamp Converter" :
                "Steganography Decoder / Analyzer"}
             </button>
          ))}
        </div>

        {/* Content Utility card */}
        <div className="md:col-span-3 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 min-h-[400px] flex flex-col justify-between">
          <div className="space-y-4">
            {/* Base 64 encoder/decoder */}
            {activeTool === "base64" && (
              <div className="space-y-4 select-all">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-201 uppercase">BASE64 ENCODER & DECODER</span>
                  <div className="flex gap-2">
                    <button onClick={handleB64Encode} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">ENCODE</button>
                    <button onClick={handleB64Decode} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">DECODE</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px] uppercase">INPUT STREAM</span>
                    <textarea
                      placeholder="Type text or paste base64 payload to transform..."
                      value={b64Input}
                      onChange={(e) => setB64Input(e.target.value)}
                      className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-slate-300 focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-550 block text-[9px] uppercase">OUTPUT RESULT</span>
                    <pre className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-emerald-400 overflow-y-auto whitespace-pre-wrap select-all">
                      {b64Output || "Output will show up here..."}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {/* Hash Generator */}
            {activeTool === "hash" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-205 uppercase">SHA-256 / MD5 FILENAMES GENERATOR</span>
                  <button onClick={handleGenerateHashes} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">HASH DATA</button>
                </div>

                <div className="font-mono text-xs space-y-3">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px] uppercase">TARGET PLAIN STRING INPUT</span>
                    <input
                      type="text"
                      placeholder="Enter string value to calculate signature..."
                      value={hashInput}
                      onChange={(e) => setHashInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleGenerateHashes()}
                      className="w-full bg-slate-950 border border-slate-900 rounded p-2 text-slate-300 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div className="space-y-3 pt-2">
                    <div className="p-2.5 bg-slate-950 border border-slate-900 rounded">
                      <span className="text-slate-550 block text-[9px] uppercase font-bold text-orange-400">SHA-256 HEX DIGEST</span>
                      <pre className="text-emerald-400 text-[10px] select-all break-all mt-1 font-semibold">{sha256Output || "Calculated hex will display..."}</pre>
                    </div>
                    <div className="p-2.5 bg-slate-950 border border-slate-900 rounded">
                      <span className="text-slate-550 block text-[9px] uppercase font-bold text-amber-500">MD5 SIGNATURE (EMULATED)</span>
                      <pre className="text-emerald-400 text-[10px] select-all break-all mt-1 font-semibold">{md5Output || "Calculated hex will display..."}</pre>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* JWT Decoder */}
            {activeTool === "jwt" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-202">JWT WEB TOKEN CLAIM DECODER</span>
                  <button onClick={handleDecodeJwt} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">DESTRUCT TOKENS</button>
                </div>

                <div className="font-mono text-xs space-y-3">
                  <div>
                    <span className="text-slate-500 block text-[9px] mb-1">PASTE RAW BEARER TOKEN (header.payload.signature)</span>
                    <input
                      type="text"
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ..."
                      value={jwtInput}
                      onChange={(e) => setJwtInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleDecodeJwt()}
                      className="w-full bg-slate-950 border border-slate-900 rounded p-2 text-slate-300 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-950 border border-slate-900 rounded p-2.5">
                      <span className="text-[9px] text-slate-550 block font-bold uppercase mb-1">HEADER DATA</span>
                      <pre className="text-amber-500 text-[10.5px] select-all max-h-[160px] overflow-y-auto whitespace-pre">{jwtHeader || "No tokens loaded."}</pre>
                    </div>
                    <div className="bg-slate-950 border border-slate-900 rounded p-2.5">
                      <span className="text-[9px] text-slate-555 block font-bold uppercase mb-1">PAYLOAD DATA CLAIMS</span>
                      <pre className="text-emerald-400 text-[10.5px] select-all max-h-[160px] overflow-y-auto whitespace-pre">{jwtPayload || "No claims parsed."}</pre>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* URL Encoder / Decoder */}
            {activeTool === "url" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-205">URL PERCENT-ENCODING CONSOLE</span>
                  <div className="flex gap-2">
                    <button onClick={handleUrlEncode} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">ENCODE URL</button>
                    <button onClick={handleUrlDecode} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">DECODE URL</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px] uppercase">PERCENT INPUT</span>
                    <textarea
                      placeholder="Type link or paste query string parameters..."
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-slate-300 focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-550 block text-[9px] uppercase">CONVERTED RESULT</span>
                    <pre className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-emerald-400 overflow-y-auto whitespace-pre-wrap select-all">
                      {urlOutput || "Output links parsed..."}
                    </pre>
                  </div>
                 </div>
               </div>
            )}

            {/* Link Defanger / Refanger */}
            {activeTool === "defang" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-200">MALICIOUS LINK DEFANGER / SANITIZER</span>
                  <div className="flex gap-2">
                    <button onClick={handleDefangLink} className="bg-red-950/40 hover:bg-red-900/30 border border-red-900/60 text-red-400 text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">DEFANG STRING</button>
                    <button onClick={handleRefangLink} className="bg-emerald-950/40 hover:bg-emerald-900/30 border border-emerald-900/60 text-emerald-400 text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">REFANG STRING</button>
                  </div>
                </div>

                <div className="space-y-4 font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px] uppercase font-bold">TARGET MALICIOUS OR DEFANGED LINK INPUT</span>
                    <textarea
                      placeholder="Paste target active URL (e.g. hxxps://threat-server[.]com/exec) or defanged string to convert..."
                      value={defangToolInput}
                      onChange={(e) => setDefangToolInput(e.target.value)}
                      className="w-full h-24 bg-slate-950 border border-slate-900 rounded p-3 text-slate-350 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-slate-500 block text-[9px] uppercase font-bold">DEFANGED OUTPUT (SAFE FOR REPORTS)</span>
                      <pre className="w-full h-24 bg-slate-950 border border-slate-900 rounded p-3 text-orange-400 overflow-y-auto whitespace-pre-wrap select-all font-bold">
                        {defangToolResult || "Awaiting defanging trigger..."}
                      </pre>
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500 block text-[9px] uppercase font-bold text-emerald-400">REFANGED LIVE LINK (CAUTION!)</span>
                      <pre className="w-full h-24 bg-slate-950 border border-slate-900 rounded p-3 text-emerald-400 overflow-y-auto whitespace-pre-wrap select-all font-bold">
                        {refangToolResult || "Awaiting refanging trigger..."}
                      </pre>
                    </div>
                  </div>

                  <div className="bg-slate-950/40 border border-slate-900 p-3.5 rounded text-[10px] text-slate-500 leading-normal">
                    <span className="font-bold text-slate-400 uppercase block mb-1">🧭 OBSTACLE SCHEME INFO</span>
                     Defanging disables the target browser from rendering the string as a real hyperlink. Standard secure patterns replace <code className="text-slate-400 bg-slate-900 px-1 font-bold font-mono">http://</code> with <code className="text-slate-300 bg-slate-900 px-1 font-bold font-mono">hxxp://</code> and encapsulate period boundaries with <code className="text-slate-300 bg-slate-900 px-1 font-bold font-mono">[.]</code> brackets. Maintain strict airgapping when copying reassembled URLs.
                  </div>
                </div>
              </div>
            )}

            {/* Regex system */}
            {activeTool === "regex" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-201">REGULAR EXPRESSIONS DISSECTOR</span>
                  <button onClick={handleTestRegex} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">MATCH PATTERN</button>
                </div>

                <div className="font-mono text-xs space-y-3">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="col-span-2 space-y-1">
                      <span className="text-slate-500 block text-[9px] uppercase">TARGET RAW TEXT BLOB</span>
                      <textarea
                        placeholder="Paste testing payload (e.g. log errors or emails list)..."
                        value={regexInput}
                        onChange={(e) => setRegexInput(e.target.value)}
                        className="w-full h-32 bg-slate-950 border border-slate-900 rounded p-2 text-slate-300 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-550 block text-[9px] uppercase font-semibold">REGEX COMBI PATTERN</span>
                      <input
                        type="text"
                        placeholder="e.g. \\d{3}-\\d{3}-\\d{4} or [a-z]+..."
                        value={regexPattern}
                        onChange={(e) => setRegexPattern(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-900 rounded p-2 text-slate-300 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="bg-slate-950 border border-slate-900 rounded p-2.5">
                    <span className="text-[9px] text-slate-500 block uppercase font-bold mb-1">INDEX MATCHED RECORDS</span>
                    <div className="max-h-24 overflow-y-auto space-y-1 text-emerald-400 text-[10px]">
                      {regexMatches.length === 0 ? (
                        <span className="text-slate-600 block">Matches indexes will display...</span>
                      ) : (
                        regexMatches.map((m, i) => (
                          <div key={i} className="p-1 bg-slate-900 rounded border border-slate-850 truncate">{m}</div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* JSON Formatter */}
            {activeTool === "json" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-205">JSON BEAUTIFIER / SCANNER</span>
                  <button onClick={handleFormatJson} className="bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-[11px] px-3 py-1 rounded font-mono cursor-pointer font-bold">BEAUTIFY JSON</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px] uppercase font-bold">RAW CRUSHED STRINGS</span>
                    <textarea
                      placeholder='{"vendor":"cisco","score":0.93,"targets":["192.168.1.1"]}'
                      value={jsonInput}
                      onChange={(e) => setJsonInput(e.target.value)}
                      className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-slate-300 focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-550 block text-[9px] uppercase font-bold">FORMATTED OUTPUT</span>
                    <pre className="w-full h-40 bg-slate-950 border border-slate-900 rounded p-3 text-emerald-400 overflow-y-auto whitespace-pre-wrap select-all">
                      {jsonOutput || "Indented payload will show..."}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {/* Epoch unix Timestamp */}
            {activeTool === "epoch" && (
              <div className="space-y-4 font-mono text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-mono font-bold text-slate-201">EPOCH TIME SEC CONVERTER</span>
                  <button onClick={handleConvertEpoch} className="bg-slate-900 border border-slate-800 text-slate-350 hover:text-white px-3 py-1 rounded font-mono cursor-pointer font-bold">PARSE TIMESTAMP</button>
                </div>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <span className="text-slate-500 block text-[9px]">UNIX EPOCH VALUE (Seconds or Milliseconds)</span>
                    <input
                      type="text"
                      placeholder="e.g. 1778848143 or 1465888250000..."
                      value={epochInput}
                      onChange={(e) => setEpochInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleConvertEpoch()}
                      className="w-full bg-slate-950 border border-slate-900 rounded p-2 text-slate-300 focus:outline-none"
                    />
                  </div>

                  <div className="bg-slate-950 border border-slate-905 p-3 rounded text-center">
                    <span className="text-[9px] text-slate-550 block uppercase mb-1 font-bold">UTC TIME SPECIFICATIONS</span>
                    <pre className="text-emerald-400 text-xs font-bold">{epochOutput || "Standard UTC stamp representation will show..."}</pre>
                  </div>
                </div>
              </div>
            )}

            {/* Steganography Tool */}
            {activeTool === "steg" && (
              <div className="space-y-5 font-mono text-xs animate-fade-in pb-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-3">
                  <div>
                    <span className="text-xs font-mono font-bold text-slate-100 uppercase block">Steganography Decoder & Metadata Scraper</span>
                    <span className="text-[10px] text-slate-500 mt-0.5 block">Expose invisible zero-width sequences, trailing binary EOF shellcodes, & embedded EXIF comments</span>
                  </div>
                  <button
                    onClick={loadStegSample}
                    className="bg-amber-950/30 hover:bg-amber-900/40 border border-amber-900 text-amber-400 text-[10px] px-3 py-1.5 rounded transition uppercase font-bold cursor-pointer shrink-0"
                  >
                    Load Steg Lab Sample
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Left Controls */}
                  <div className="space-y-4">
                    {/* Text Payload Input */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-[9px] text-slate-500 uppercase font-bold">Trace String Payload (Contains Hidden Zero Width Spaces)</span>
                        {stegTextInput && (
                          <button
                            onClick={() => {
                              setStegTextInput("");
                              setStegTextResult(prev => ({...prev, zeroWidthDetected: false, zeroWidthMessage: ""}));
                            }}
                            className="text-[9px] text-red-400 hover:underline cursor-pointer font-bold"
                          >
                            CLEAR
                          </button>
                        )}
                      </div>
                      <textarea
                        placeholder="Paste suspicious logs, suspect messages, or system reports down here to check for zero-width spaces..."
                        value={stegTextInput}
                        onChange={(e) => setStegTextInput(e.target.value)}
                        className="w-full h-28 bg-slate-950 border border-slate-900 rounded p-3 text-slate-300 focus:outline-none focus:border-red-500 text-xs"
                      />
                    </div>

                    {/* File Attachment Carrier */}
                    <div className="space-y-2">
                      <span className="text-[9px] text-slate-500 uppercase font-bold block">Attached File Carrier (Scan EXIF / Appended Hex bytes)</span>
                      
                      <div className="border border-dashed border-slate-800 hover:border-red-500/70 rounded p-4 bg-slate-950/40 transition flex flex-col items-center justify-center text-center cursor-pointer relative">
                        <input
                          id="stego-file-input"
                          type="file"
                          accept="image/*,text/plain"
                          onChange={handleStegFileUpload}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        />
                        <Image className="w-8 h-8 text-slate-650 mb-2" />
                        <span className="text-[11px] text-slate-350 font-bold block mb-0.5">
                          {stegImageName ? stegImageName : "Upload Carrier Image or Text File"}
                        </span>
                        <span className="text-[9px] text-slate-550 block">PNG, JPG, TIFF, or TXT up to 10MB</span>
                        {stegImageFile && (
                          <span className="mt-2 text-[9px] bg-emerald-950 border border-emerald-900 text-emerald-400 px-2 py-0.5 rounded uppercase font-bold">
                            Carrier Loaded
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={handleRunStegAnalysis}
                      disabled={!stegTextInput && !stegImageFile}
                      className="w-full bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400 font-bold uppercase p-2.5 rounded transition text-[11px] disabled:opacity-50 cursor-pointer"
                    >
                      EXECUTE MATRIX ANALYZER
                    </button>
                  </div>

                  {/* Right Results Analysis */}
                  <div className="space-y-3">
                    <span className="text-[9px] text-slate-500 uppercase font-bold block">Extraction Logs & Payload Dumps</span>
                    
                    {!stegTextResult.analyzed ? (
                      <div className="bg-slate-950 border border-slate-900 p-8 text-center rounded flex flex-col items-center justify-center text-slate-600 h-[320px]">
                        <FileSearch className="w-8 h-8 text-slate-800 mb-2" />
                        <span className="text-xs font-bold uppercase tracking-wider block mb-1">Analyzer Idle</span>
                        <p className="text-[10px] text-slate-500 leading-normal max-w-xs">Load a lab sample file or dump a custom payload into the analysis form on the left to extract latent signals.</p>
                      </div>
                    ) : (
                      <div className="space-y-3 h-[320px] overflow-y-auto pr-1">
                        
                        {/* 1. Zero width extractor */}
                        <div className="bg-slate-950 border border-slate-900 p-3 rounded space-y-1">
                          <span className="text-[9px] text-slate-500 block uppercase font-bold">Zero-Width Hidden Messages</span>
                          {stegTextResult.zeroWidthDetected ? (
                            <div className="mt-1 space-y-1.5 p-2 bg-red-955/20 border border-red-900/40 rounded">
                              <span className="text-[8.5px] bg-red-950 text-red-400 px-1.5 py-0.2 rounded font-bold border border-red-950 uppercase inline-block">HIDDEN ENCODING FOUND</span>
                              <pre className="text-emerald-400 font-bold text-xs select-all break-all block mt-0.5">{stegTextResult.zeroWidthMessage}</pre>
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[10px] italic block">No hidden zero-width space characters found.</span>
                          )}
                        </div>

                        {/* 2. EXIF comment viewer */}
                        <div className="bg-slate-950 border border-slate-900 p-3 rounded space-y-1.5">
                          <span className="text-[9px] text-slate-500 block uppercase font-bold">Scanned EXIF & File Headers</span>
                          {stegTextResult.exifTags && stegTextResult.exifTags.length > 0 ? (
                            <div className="text-[10px] space-y-1">
                              {stegTextResult.exifTags.map((tag, id) => (
                                <div key={id} className="flex justify-between border-b border-slate-900/50 pb-1 text-slate-400">
                                  <span className="text-slate-500 uppercase">{tag.name}:</span>
                                  <span className="text-slate-200 truncate max-w-[180px] font-bold">{tag.value}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[10px] italic block">EXIF fields clean or unpopulated.</span>
                          )}
                        </div>

                        {/* 3. LSB Pixel extracts */}
                        <div className="bg-slate-950 border border-slate-900 p-3 rounded space-y-1">
                          <span className="text-[9px] text-slate-500 block uppercase font-bold">LSB Byte Matrix extraction</span>
                          <pre className="text-slate-355 text-[10px] leading-relaxed select-all break-all bg-slate-950 border border-slate-900/60 p-1.5 rounded">{stegTextResult.lsbExtractedText}</pre>
                        </div>

                        {/* 4. Appended IOC payload scanner */}
                        <div className="bg-slate-950 border border-slate-900 p-3 rounded space-y-1">
                          <span className="text-[9px] text-slate-500 block uppercase font-bold">Appended Payload Shell (EOF Stream)</span>
                          <div className="space-y-1 mt-1">
                            {stegTextResult.appendedIocs.map((ioc, idx) => (
                              <div key={idx} className="flex items-center gap-1.5 text-orange-400 font-semibold text-[10px]">
                                <ShieldAlert className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                                <span>{ioc}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-900 select-none text-[10px] font-mono text-slate-650 flex justify-between">
            <span>OFFLINE BROWSING OPERATIONS -- SAFE</span>
            <span>SEC CHEF // OK</span>
          </div>
        </div>
      </div>
    </div>
  );
}
