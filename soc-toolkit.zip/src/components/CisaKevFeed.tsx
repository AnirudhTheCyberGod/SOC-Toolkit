/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import {
  ShieldAlert,
  ExternalLink,
  Copy,
  Check,
  RotateCw,
  Search,
  Filter,
  Download,
  AlertTriangle,
  Clock,
  Building,
  Calendar,
  Layers,
  ChevronDown,
  ChevronUp,
  FileCode,
  Tag,
  Flame,
  AlertOctagon
} from "lucide-react";

export interface CisaVulnerability {
  cveID: string;
  vendorProject: string;
  product: string;
  vulnerabilityName: string;
  dateAdded: string;
  shortDescription: string;
  requiredAction: string;
  dueDate: string;
  knownRansomwareCampaignUse: string;
  notes: string;
  cwes?: string[];
}

interface CisaKevFeedProps {
  onPivotToCve?: (cve: string) => void;
  onNavigateToKql?: (cve: string) => void;
}

export default function CisaKevFeed({ onPivotToCve, onNavigateToKql }: CisaKevFeedProps) {
  const [vulns, setVulns] = useState<CisaVulnerability[]>([]);
  const [stats, setStats] = useState<{
    total: number;
    ransomwareKnown: number;
    uniqueVendors: number;
    recentCount: number;
  }>({ total: 0, ransomwareKnown: 0, uniqueVendors: 0, recentCount: 0 });
  const [catalogVersion, setCatalogVersion] = useState("");
  const [dateReleased, setDateReleased] = useState("");
  const [cachedAt, setCachedAt] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState("");
  const [ransomwareOnly, setRansomwareOnly] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState("all");
  const [dateFilter, setDateFilter] = useState<"all" | "30days" | "90days">("all");
  const [page, setPage] = useState(1);
  const pageSize = 25;

  const [expandedCve, setExpandedCve] = useState<string | null>(null);
  const [copiedValue, setCopiedValue] = useState<string | null>(null);

  const fetchKevCatalog = async (forceRefresh = false) => {
    if (forceRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      const url = forceRefresh
        ? "/api/feeds/cisa-kev?refresh=true&limit=500"
        : "/api/feeds/cisa-kev?limit=500";
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`CISA server returned HTTP ${res.status}`);
      }
      const data = await res.json();
      setVulns(data.vulnerabilities || []);
      if (data.stats) setStats(data.stats);
      setCatalogVersion(data.catalogVersion || "1.0");
      setDateReleased(data.dateReleased || "");
      setCachedAt(data.cachedAt || new Date().toISOString());
    } catch (err: any) {
      console.error("Failed to load CISA KEV catalog:", err);
      setError(err.message || "Failed to connect to CISA KEV catalog endpoint.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchKevCatalog();
  }, []);

  const handleCopy = (val: string) => {
    navigator.clipboard.writeText(val);
    setCopiedValue(val);
    setTimeout(() => setCopiedValue(null), 2000);
  };

  // Top vendors for quick filter buttons
  const topVendors = useMemo(() => {
    const counts: Record<string, number> = {};
    vulns.forEach((v) => {
      if (v.vendorProject) {
        counts[v.vendorProject] = (counts[v.vendorProject] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([vendor]) => vendor);
  }, [vulns]);

  // Filtered Vulnerabilities
  const filteredVulns = useMemo(() => {
    let list = vulns;

    if (ransomwareOnly) {
      list = list.filter((v) => v.knownRansomwareCampaignUse === "Known");
    }

    if (selectedVendor !== "all") {
      list = list.filter((v) => v.vendorProject?.toLowerCase() === selectedVendor.toLowerCase());
    }

    if (dateFilter !== "all") {
      const days = dateFilter === "30days" ? 30 : 90;
      const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
      list = list.filter((v) => v.dateAdded && v.dateAdded >= cutoff);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (v) =>
          v.cveID.toLowerCase().includes(q) ||
          v.vendorProject.toLowerCase().includes(q) ||
          v.product.toLowerCase().includes(q) ||
          v.vulnerabilityName.toLowerCase().includes(q) ||
          v.shortDescription.toLowerCase().includes(q)
      );
    }

    return list;
  }, [vulns, ransomwareOnly, selectedVendor, dateFilter, searchQuery]);

  // Paginated records
  const paginatedVulns = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredVulns.slice(start, start + pageSize);
  }, [filteredVulns, page]);

  const totalPages = Math.ceil(filteredVulns.length / pageSize) || 1;

  // Export to CSV
  const handleExportCsv = () => {
    let csv = "CVE ID,Vendor,Product,Vulnerability Name,Date Added,Due Date,Known Ransomware Campaign Use,Required Action\n";
    filteredVulns.forEach((v) => {
      csv += `"${v.cveID}","${(v.vendorProject || "").replace(/"/g, '""')}","${(v.product || "").replace(/"/g, '""')}","${(v.vulnerabilityName || "").replace(/"/g, '""')}","${v.dateAdded}","${v.dueDate}","${v.knownRansomwareCampaignUse}","${(v.requiredAction || "").replace(/"/g, '""')}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cisa_kev_catalog_${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6" id="cisa-kev-view">
      {/* CISA Catalog Header Banner */}
      <div className="bg-slate-950/70 border border-slate-900 rounded p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              <h3 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-red-500" />
                CISA KNOWN EXPLOITED VULNERABILITIES (KEV) CATALOG
              </h3>
            </div>
            <p className="text-xs text-slate-400 font-mono max-w-3xl leading-relaxed">
              Official United States Cybersecurity and Infrastructure Security Agency (CISA) authoritative catalog
              of security vulnerabilities actively exploited in the wild. Federal agencies (BOD 22-01) and security
              operations teams must remediate listed flaws before established deadlines.
            </p>
            <div className="flex flex-wrap items-center gap-2 mt-2.5 text-[10px] font-mono">
              <span className="text-slate-500">OFFICIAL REPOSITORY:</span>
              <a
                href="https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
                target="_blank"
                rel="noreferrer"
                className="bg-slate-900 text-blue-400 border border-slate-800 px-2 py-0.5 rounded flex items-center gap-1 hover:underline"
              >
                known_exploited_vulnerabilities.json
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              {catalogVersion && (
                <span className="bg-slate-900 text-slate-400 border border-slate-800 px-2 py-0.5 rounded ml-1">
                  VERSION: {catalogVersion}
                </span>
              )}
              {cachedAt && (
                <span className="text-slate-500 flex items-center gap-1 ml-2">
                  <Clock className="w-3 h-3" />
                  Synced: {new Date(cachedAt).toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 px-3 py-2 rounded text-xs font-mono font-bold transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              EXPORT CSV
            </button>

            <button
              onClick={() => fetchKevCatalog(true)}
              disabled={refreshing || loading}
              className="flex items-center gap-1.5 bg-red-950 hover:bg-red-900 border border-red-800/80 text-red-300 hover:text-white px-3.5 py-2 rounded text-xs font-mono font-bold transition cursor-pointer disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
              {refreshing ? "SYNCING CISA..." : "REFRESH CATALOG"}
            </button>
          </div>
        </div>

        {/* Aggregate KPI Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-900/80">
          <div className="bg-slate-900/40 border border-slate-850/80 p-3 rounded">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Total Exploited CVEs</span>
            <span className="text-xl font-mono font-bold text-slate-100">{stats.total || vulns.length}</span>
            <span className="text-[9px] font-mono text-slate-500 block mt-0.5">Authoritative CISA Catalog</span>
          </div>

          <div className="bg-slate-900/40 border border-slate-850/80 p-3 rounded">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Known Ransomware Use</span>
            <span className="text-xl font-mono font-bold text-red-400 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-red-500 animate-pulse" />
              {stats.ransomwareKnown}
            </span>
            <span className="text-[9px] font-mono text-red-400/80 block mt-0.5">High Ransom Threat Impact</span>
          </div>

          <div className="bg-slate-900/40 border border-slate-850/80 p-3 rounded">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Added in Last 30 Days</span>
            <span className="text-xl font-mono font-bold text-amber-400">{stats.recentCount}</span>
            <span className="text-[9px] font-mono text-slate-500 block mt-0.5">Active Urgent Zero-Days</span>
          </div>

          <div className="bg-slate-900/40 border border-slate-850/80 p-3 rounded">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Impacted Vendors</span>
            <span className="text-xl font-mono font-bold text-blue-400">{stats.uniqueVendors}</span>
            <span className="text-[9px] font-mono text-slate-500 block mt-0.5">Global Technology Stacks</span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-950/60 border border-slate-900 rounded p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Filter by CVE ID (e.g. CVE-2026-), Vendor (e.g. Microsoft, Google), Product, or keyword..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setPage(1);
              }}
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono pl-9 pr-3 py-2 rounded focus:outline-none focus:border-red-500 transition"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            <button
              onClick={() => {
                setRansomwareOnly(!ransomwareOnly);
                setPage(1);
              }}
              className={`px-3 py-2 rounded border transition cursor-pointer flex items-center gap-1.5 ${
                ransomwareOnly
                  ? "bg-red-950 border-red-800 text-red-300 font-bold"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-500" />
              KNOWN RANSOMWARE USE ({stats.ransomwareKnown})
            </button>

            <select
              value={dateFilter}
              onChange={(e: any) => {
                setDateFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono px-3 py-2 rounded focus:outline-none focus:border-red-500 cursor-pointer"
            >
              <option value="all">ALL TIME</option>
              <option value="30days">ADDED LAST 30 DAYS</option>
              <option value="90days">ADDED LAST 90 DAYS</option>
            </select>
          </div>
        </div>

        {/* Top Vendor Quick Filters */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px] font-mono">
          <span className="text-slate-500 mr-1">TOP VENDORS:</span>
          <button
            onClick={() => {
              setSelectedVendor("all");
              setPage(1);
            }}
            className={`px-2 py-0.5 rounded border transition cursor-pointer ${
              selectedVendor === "all"
                ? "bg-blue-950 border-blue-800 text-blue-300 font-bold"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            ALL VENDORS
          </button>
          {topVendors.map((v) => (
            <button
              key={v}
              onClick={() => {
                setSelectedVendor(v);
                setPage(1);
              }}
              className={`px-2 py-0.5 rounded border transition cursor-pointer ${
                selectedVendor.toLowerCase() === v.toLowerCase()
                  ? "bg-blue-950 border-blue-800 text-blue-300 font-bold"
                  : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      {/* Loading & Error States */}
      {loading && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-12 text-center font-mono">
          <RotateCw className="w-8 h-8 text-red-500 animate-spin mx-auto mb-3" />
          <p className="text-sm text-slate-200 font-bold">LOADING CISA KNOWN EXPLOITED VULNERABILITIES CATALOG...</p>
          <p className="text-xs text-slate-500 mt-1">
            Parsing 1,695+ CVE records, calculating BOD 22-01 remediation deadlines and ransomware flags.
          </p>
        </div>
      )}

      {error && (
        <div className="bg-red-950/30 border border-red-800 rounded p-4 flex items-start gap-3 text-xs font-mono">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-red-300 font-bold">Failed to load CISA KEV catalog</h4>
            <p className="text-slate-400 mt-1">{error}</p>
            <button
              onClick={() => fetchKevCatalog(true)}
              className="mt-2 text-red-400 hover:text-red-300 underline cursor-pointer"
            >
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* Vulnerabilities Table / Cards */}
      {!loading && !error && filteredVulns.length === 0 && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-8 text-center font-mono">
          <ShieldAlert className="w-6 h-6 text-slate-600 mx-auto mb-2" />
          <p className="text-sm text-slate-300 font-bold">No vulnerabilities match your search query.</p>
          <p className="text-xs text-slate-500 mt-1">Try resetting the vendor or keyword filter.</p>
        </div>
      )}

      {!loading && !error && filteredVulns.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span>
              Showing {paginatedVulns.length} of {filteredVulns.length} vulnerabilities
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(p - 1, 1))}
                disabled={page === 1}
                className="px-2 py-1 bg-slate-900 border border-slate-800 rounded disabled:opacity-40 cursor-pointer"
              >
                Prev
              </button>
              <span>
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(p + 1, totalPages))}
                disabled={page === totalPages}
                className="px-2 py-1 bg-slate-900 border border-slate-800 rounded disabled:opacity-40 cursor-pointer"
              >
                Next
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {paginatedVulns.map((v) => {
              const isExpanded = expandedCve === v.cveID;
              const isRansomware = v.knownRansomwareCampaignUse === "Known";

              return (
                <div
                  key={v.cveID}
                  className={`bg-slate-950/70 border rounded transition overflow-hidden ${
                    isRansomware ? "border-red-900/60 hover:border-red-700" : "border-slate-900 hover:border-slate-800"
                  }`}
                >
                  <div className="p-4 sm:p-5">
                    <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                      <div className="space-y-2 flex-1 min-w-0">
                        {/* CVE Identifier and Severity Badges */}
                        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                          <span className="text-sm font-bold text-red-400 bg-red-950/60 border border-red-800 px-2.5 py-0.5 rounded flex items-center gap-1.5">
                            <ShieldAlert className="w-3.5 h-3.5 text-red-500" />
                            {v.cveID}
                          </span>

                          <button
                            onClick={() => handleCopy(v.cveID)}
                            className="p-1 hover:text-white text-slate-500 cursor-pointer"
                            title="Copy CVE ID"
                          >
                            {copiedValue === v.cveID ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <span className="bg-slate-900 text-blue-400 border border-slate-800 px-2 py-0.5 rounded font-bold">
                            {v.vendorProject}
                          </span>
                          <span className="bg-slate-900 text-slate-300 border border-slate-800 px-2 py-0.5 rounded">
                            {v.product}
                          </span>

                          {isRansomware && (
                            <span className="bg-red-950 text-red-300 border border-red-800 px-2 py-0.5 rounded font-bold flex items-center gap-1 text-[11px] animate-pulse">
                              <Flame className="w-3 h-3 text-red-500" />
                              KNOWN RANSOMWARE CAMPAIGN USE
                            </span>
                          )}

                          <span className="text-[10px] text-slate-500 ml-auto flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Added: {v.dateAdded}
                          </span>
                        </div>

                        {/* Vulnerability Title */}
                        <h4 className="text-sm font-mono font-bold text-slate-200">
                          {v.vulnerabilityName}
                        </h4>

                        {/* Short Description */}
                        <p className="text-xs text-slate-400 font-sans leading-relaxed">
                          {v.shortDescription}
                        </p>

                        {/* Remediation Deadline & Required Action */}
                        <div className="pt-2 border-t border-slate-900 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
                          <div className="flex items-center gap-1.5 text-amber-400">
                            <Clock className="w-3.5 h-3.5" />
                            <span>CISA Remediation Due Date:</span>
                            <span className="font-bold underline">{v.dueDate}</span>
                          </div>

                          <span className="text-slate-400 line-clamp-1 max-w-md">
                            Action: <span className="text-slate-200">{v.requiredAction}</span>
                          </span>
                        </div>
                      </div>

                      {/* Right-hand actions */}
                      <div className="flex lg:flex-col items-center lg:items-end gap-2 shrink-0 pt-2 lg:pt-0">
                        {onNavigateToKql && (
                          <button
                            onClick={() => onNavigateToKql(v.cveID)}
                            className="flex items-center gap-1 px-2.5 py-1 bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded text-[10px] font-mono font-bold transition cursor-pointer"
                            title={`Generate Sentinel & Defender KQL Hunt Rules for ${v.cveID}`}
                          >
                            <FileCode className="w-3 h-3 text-emerald-400" />
                            KQL HUNT
                          </button>
                        )}

                        <button
                          onClick={() => setExpandedCve(isExpanded ? null : v.cveID)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded text-xs font-mono font-bold transition cursor-pointer"
                        >
                          {isExpanded ? (
                            <>
                              <ChevronUp className="w-3 h-3" /> LESS
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-3 h-3" /> DETAILS
                            </>
                          )}
                        </button>

                        <a
                          href={`https://nvd.nist.gov/vuln/detail/${v.cveID}`}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 px-2.5 py-1 bg-slate-900/60 hover:bg-slate-850 text-slate-400 hover:text-slate-200 border border-slate-850 rounded text-[10px] font-mono transition"
                        >
                          NVD NIST
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Details Drawer */}
                  {isExpanded && (
                    <div className="border-t border-slate-900 bg-slate-950 p-4 space-y-3 font-mono text-xs">
                      <div>
                        <span className="text-slate-500 uppercase block text-[10px] font-bold mb-1">
                          CISA MANDATED ACTION & VENDOR GUIDANCE
                        </span>
                        <p className="text-slate-300 font-sans text-xs bg-slate-900/50 p-3 rounded border border-slate-850">
                          {v.requiredAction}
                        </p>
                      </div>

                      {v.notes && (
                        <div>
                          <span className="text-slate-500 uppercase block text-[10px] font-bold mb-1">
                            OFFICIAL ADVISORY LINKS & NOTES
                          </span>
                          <p className="text-slate-400 font-mono text-[11px] bg-slate-900/50 p-2.5 rounded border border-slate-850 break-all">
                            {v.notes}
                          </p>
                        </div>
                      )}

                      {v.cwes && v.cwes.length > 0 && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-500 uppercase text-[10px] font-bold">CWE CLASSIFICATION:</span>
                          <div className="flex flex-wrap gap-1">
                            {v.cwes.map((cwe, idx) => (
                              <span
                                key={idx}
                                className="bg-slate-900 text-slate-300 border border-slate-800 px-1.5 py-0.5 rounded text-[10px]"
                              >
                                {cwe}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Bottom Pagination */}
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-2 px-1">
            <span>
              Page {page} of {totalPages} ({filteredVulns.length} total vulnerabilities)
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setPage((p) => Math.max(p - 1, 1));
                  window.scrollTo({ top: 400, behavior: "smooth" });
                }}
                disabled={page === 1}
                className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded disabled:opacity-40 cursor-pointer"
              >
                Prev
              </button>
              <button
                onClick={() => {
                  setPage((p) => Math.min(p + 1, totalPages));
                  window.scrollTo({ top: 400, behavior: "smooth" });
                }}
                disabled={page === totalPages}
                className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded disabled:opacity-40 cursor-pointer"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
