/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { URLAnalysisResult } from "../types";
import { Search, ShieldAlert, CheckCircle, ExternalLink, ShieldCheck, Copy, Check, Link, AlertTriangle, AlertOctagon, Laptop, Loader2, Maximize2, Globe, Activity, Eye, Image, Play, UserCheck, CloudLightning, Terminal } from "lucide-react";

interface URLAnalysisProps {
  onAddSearchLog: (log: { type: "IP" | "Domain" | "URL" | "Hash" | "Malware"; query: string; reputation: "clean" | "suspicious" | "malicious" | "unknown"; score?: number }) => void;
  initialQuery?: string;
}

export default function UrlAnalysisView({ onAddSearchLog, initialQuery = "" }: URLAnalysisProps) {
  const [urlInput, setUrlInput] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<URLAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);

  // Sub-tabs & URLScan Sandbox states
  const [subTab, setSubTab] = useState<"reputation" | "urlscan">("reputation");
  const [urlscanLoading, setUrlscanLoading] = useState(false);
  const [urlscanStatus, setUrlscanStatus] = useState<string>(""); // "submitting", "polling", "done", "error"
  const [urlscanResult, setUrlscanResult] = useState<any>(null);
  const [urlscanUuid, setUrlscanUuid] = useState<string>("");
  const [lightbox, setLightbox] = useState(false);

  // Defanging state
  const [defangInput, setDefangInput] = useState("");
  const [defangCopied, setDefangCopied] = useState(false);
  const [refangCopied, setRefangCopied] = useState(false);

  // Core Defang/Refang logic
  const defangUrl = (url: string): string => {
    if (!url) return "";
    let res = url.trim();
    // Protocols
    res = res.replace(/^http:/gi, "hxxp:");
    res = res.replace(/^https:/gi, "hxxps:");
    res = res.replace(/^ftp:/gi, "fxp:");
    // Replace domain dots
    try {
      const protocolMatch = res.match(/^(hxxps?|https?|fxp|ftp):\/\//i);
      if (protocolMatch) {
        const proto = protocolMatch[0];
        const rest = res.substring(proto.length);
        const slashIdx = rest.indexOf("/");
        if (slashIdx !== -1) {
          const host = rest.substring(0, slashIdx);
          const pathAndQuery = rest.substring(slashIdx);
          const defangedHost = host.replace(/\./g, "[.]");
          res = proto + defangedHost + pathAndQuery;
        } else {
          res = proto + rest.replace(/\./g, "[.]");
        }
      } else {
        res = res.replace(/\./g, "[.]");
      }
    } catch {
      res = res.replace(/\./g, "[.]");
    }
    // Mask @ signs for security
    res = res.replace(/@/g, "[at]");
    return res;
  };

  const refangUrl = (url: string): string => {
    if (!url) return "";
    let res = url.trim();
    res = res.replace(/^hxxps:/gi, "https:");
    res = res.replace(/^hxxp:/gi, "http:");
    res = res.replace(/^fxp:/gi, "ftp:");
    res = res.replace(/\[\.\]/g, ".");
    res = res.replace(/\(\.\)/g, ".");
    res = res.replace(/\[dot\]/gi, ".");
    res = res.replace(/\[at\]/gi, "@");
    return res;
  };

  const activeDefanged = defangUrl(defangInput);
  const activeRefanged = refangUrl(defangInput);

  // Quick deconstruction parser
  const getDeconstructedParts = (raw: string) => {
    if (!raw.trim()) return null;
    const cleanUrl = refangUrl(raw);
    try {
      // Add standard protocol if none exists to assist URL standard parser
      const hasProto = /^(https?|ftp|file):\/\//i.test(cleanUrl);
      const targetParse = hasProto ? cleanUrl : `http://${cleanUrl}`;
      const parsed = new URL(targetParse);
      return {
        protocol: hasProto ? parsed.protocol : "N/A (Derived HTTP)",
        hostname: parsed.hostname,
        defangedHost: parsed.hostname.replace(/\./g, "[.]"),
        pathname: parsed.pathname || "/",
        search: parsed.search || "None",
        hash: parsed.hash || "None"
      };
    } catch {
      return null;
    }
  };

  const parts = getDeconstructedParts(defangInput);

  const handleSearch = async (targetUrl: string) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) return;
    setLoading(true);
    // Reset secondary tabs
    setSubTab("reputation");
    setUrlscanResult(null);
    setUrlscanUuid("");
    setUrlscanStatus("");

    try {
      const parsedKeys = {
        gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      };

      const response = await fetch("/api/enrich/url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: trimmed, apiKeys: parsedKeys }),
      });

      if (response.ok) {
        const data: URLAnalysisResult = await response.json();
        setResult(data);

        onAddSearchLog({
          type: "URL",
          query: trimmed,
          reputation: data.reputation,
          score: data.reputation === "malicious" ? 90 : data.reputation === "suspicious" ? 40 : 0
        });
      }
    } catch (err) {
      console.error("URL lookup failure:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleUrlscanScan = async (targetUrl: string) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) return;
    
    setUrlscanLoading(true);
    setUrlscanStatus("submitting");
    setUrlscanResult(null);
    setUrlscanUuid("");

    try {
      const userApiKey = localStorage.getItem("URLSCAN_API_KEY") || "";
      const response = await fetch("/api/urlscan/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: trimmed, apiKey: userApiKey })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to submit scan segment to urlscan.io sandbox");
      }

      const data = await response.json();
      setUrlscanUuid(data.uuid);
      setUrlscanStatus("polling");

      // Spawn background tracker
      pollUrlscanResult(data.uuid, userApiKey);
    } catch (err: any) {
      console.error("URLScan submit failure:", err);
      setUrlscanStatus("error");
      setUrlscanResult({ error: err.message });
      setUrlscanLoading(false);
    }
  };

  const pollUrlscanResult = (uuid: string, apiKey: string) => {
    let attempts = 0;
    const maxAttempts = 30; // 60 seconds
    
    const interval = setInterval(async () => {
      attempts++;
      if (attempts > maxAttempts) {
        clearInterval(interval);
        setUrlscanStatus("error");
        setUrlscanResult({ error: "Client poll timeout. The remote sandbox environment takes longer than average to load or was protected." });
        setUrlscanLoading(false);
        return;
      }

      try {
        const response = await fetch(`/api/urlscan/result/${uuid}?apiKey=${encodeURIComponent(apiKey)}`);
        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Failed to pull state from remote queue container");
        }

        const data = await response.json();
        if (data.finished) {
          clearInterval(interval);
          setUrlscanResult(data);
          setUrlscanStatus("done");
          setUrlscanLoading(false);
        }
      } catch (err: any) {
        console.error("Sandbox polling iteration error:", err);
        clearInterval(interval);
        setUrlscanStatus("error");
        setUrlscanResult({ error: err.message });
        setUrlscanLoading(false);
      }
    }, 2000);
  };

  const executeCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1">
          URL FRAUD & BLACKLIST ANALYSIS
        </h2>
        <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
          Proxy link classifications against URLHaus feeds, VirusTotal scanning modules, and Google Safe Browsing telemetry parameters.
        </p>

        <div className="flex gap-2 max-w-2xl">
          <div className="relative flex-1">
            <Link className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              id="url-investigate-input"
              type="text"
              placeholder="Enter full target URL (e.g., http://firmas-digitales.com/login/validate.php)..."
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch(urlInput)}
              className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
            />
          </div>
          <button
            onClick={() => handleSearch(urlInput)}
            disabled={loading}
            className="bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono transition font-bold disabled:opacity-50 cursor-pointer"
          >
            {loading ? "CHECKING LINK..." : "ANALYZE URL"}
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
          <div className="relative flex h-8 w-8">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-8 w-8 bg-pink-600"></span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Querying cloud sandboxes and reputation feeds...
          </span>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-6">
          {/* AI Threat Tag & Status Alert */}
          {((result.reputation === "malicious" || result.reputation === "suspicious") || (result.aiAnalysisTag && !result.aiAnalysisTag.startsWith("Clean"))) && (
            <div className={`border p-4 rounded-lg flex items-start gap-3.5 backdrop-blur-md animate-fade-in ${
              result.reputation === "malicious" ? "bg-red-950/20 border-red-500/30 text-red-200" : "bg-orange-950/20 border-orange-500/30 text-orange-200"
            }`}>
              <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${result.reputation === "malicious" ? "text-red-500 animate-pulse" : "text-orange-500"}`} />
              <div className="space-y-1 font-mono">
                <h4 className="text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                  <span>{result.reputation === "malicious" ? "CORE THREAT ANALYSIS: HIGH-RISK DETECTED" : "CORE THREAT ANALYSIS: SUSPICIOUS ACTIVITY"}</span>
                  <span className={`text-[9px] px-1 py-0.2 rounded border uppercase font-mono ${
                    result.reputation === "malicious" ? "bg-red-950 border-red-900 text-red-400" : "bg-orange-950 border-orange-900 text-orange-400"
                  }`}>AI Flagged</span>
                </h4>
                <p className="text-[11px] text-slate-350 leading-relaxed">
                  {result.aiAnalysisTag || "This target link has been flagged by cognitive security heuristics as posing elevated risks of phishing campaigns, credential theft, or malicious redirect pathways."}
                </p>
              </div>
            </div>
          )}

          {/* Sub Tab Selection bar */}
          <div className="flex border-b border-slate-900 font-mono text-xs select-none gap-2">
            <button
              onClick={() => setSubTab("reputation")}
              className={`px-4 py-2 border-b-2 text-xs font-bold uppercase transition cursor-pointer flex items-center gap-1.5 ${
                subTab === "reputation"
                  ? "border-red-500 text-red-400 bg-red-950/10"
                  : "border-transparent text-slate-500 hover:text-slate-300"
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              Threat Intel Feeds & Reputation
            </button>
            <button
              onClick={() => setSubTab("urlscan")}
              className={`px-4 py-2 border-b-2 text-xs font-bold uppercase transition cursor-pointer flex items-center gap-1.5 ${
                subTab === "urlscan"
                  ? "border-emerald-500 text-emerald-405 bg-emerald-950/10"
                  : "border-transparent text-slate-500 hover:text-slate-300"
              }`}
            >
              <Laptop className="w-3.5 h-3.5 text-emerald-400" />
              URLScan.io Sandbox & Screenshot
            </button>
          </div>

          {subTab === "reputation" && (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
              {/* Summary Box */}
              <div className="space-y-4">
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
                  <div className={`absolute top-0 left-0 right-0 h-1 ${
                    result.reputation === "malicious" ? "bg-red-500" : result.reputation === "suspicious" ? "bg-orange-500" : "bg-emerald-500"
                  }`} />

                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xs font-mono font-bold text-slate-400">URL REPUTATION</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase ${
                      result.reputation === "malicious" ? "bg-red-950 text-red-500 border-red-950" :
                      result.reputation === "suspicious" ? "bg-orange-950 text-orange-400 border-orange-950" :
                      "bg-emerald-950 text-emerald-400 border-emerald-950"
                    }`}>
                      {result.reputation}
                    </span>
                  </div>

                  {/* Engine statistics */}
                  <div className="border-b border-slate-900 pb-4 mb-4">
                    <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider mb-2">
                      MALWARE ENGINE DETECTION RATIO
                    </span>
                    <div className="flex items-baseline gap-1 bg-slate-950 p-3 border border-slate-900 rounded text-center justify-center">
                      <span className={`text-3xl font-mono font-extra-bold ${result.reputation === "malicious" ? "text-red-500" : "text-emerald-500"}`}>
                        {result.stats.malicious}
                      </span>
                      <span className="text-slate-500 font-mono text-sm">/ {result.stats.malicious + result.stats.suspicious + result.stats.harmless} engines flagged</span>
                    </div>
                  </div>

                  {/* URL detail fields */}
                  <div className="space-y-3 font-mono text-[10px] text-slate-400 mb-4">
                    <div className="flex flex-col gap-1 border-b border-slate-900 pb-2">
                      <span className="text-slate-550 uppercase">TARGET LINK CHECKED:</span>
                      <span className="text-slate-200 font-bold break-all leading-normal">{result.url}</span>
                    </div>
                    {result.categories.length > 0 && (
                      <div className="border-b border-slate-900 pb-2">
                        <span className="text-slate-550 uppercase block mb-1">CATEGORIES COGNITIVE:</span>
                        <div className="flex flex-wrap gap-1">
                          {result.categories.map((c, idx) => (
                            <span key={idx} className="bg-slate-900 border border-slate-800 text-slate-350 px-1.5 py-0.5 rounded">
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Google Safe Browsing */}
                  <div className="bg-slate-950 p-3 border border-slate-900 rounded flex items-center justify-between font-mono text-[10px]">
                    <div className="flex items-center gap-2">
                      {result.safeBrowsing.listed ? (
                        <ShieldAlert className="w-5 h-5 text-red-500 shrink-0" />
                      ) : (
                        <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
                      )}
                      <div>
                        <span className="font-bold block text-slate-300">Google Safe Browsing</span>
                        <span className="text-[8px] text-slate-500 uppercase">
                          {result.safeBrowsing.listed ? `FLAGGED: ${result.safeBrowsing.threatType}` : "NOT LISTED"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Core detection tables */}
              <div className="lg:col-span-2 bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col justify-between h-full min-h-[440px]">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-mono font-bold text-slate-205 tracking-wider uppercase">
                      ANTI-VIRUS & REPUTATION ENGINE BREAKDOWN
                    </h3>
                    <span className="text-[9px] font-mono text-slate-500 uppercase">REAL-TIME SANDBOX</span>
                  </div>

                  {/* Engines results table */}
                  <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                    <table className="w-full text-left font-mono text-[11px] select-none">
                      <thead>
                        <tr className="bg-slate-950 text-slate-505 border-b border-slate-900">
                          <th className="p-3 uppercase">Engine Name</th>
                          <th className="p-3 uppercase">Classification Category</th>
                          <th className="p-3 uppercase">Status / Result Code</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60">
                        {result.engines.map((e, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/20">
                            <td className="p-3 text-slate-350 font-semibold">{e.name}</td>
                            <td className="p-3">
                              <span className={`text-[9px] px-1 rounded uppercase ${
                                e.category === "malicious" ? "bg-red-950 text-red-400" :
                                e.category === "suspicious" ? "bg-orange-950 text-orange-400" :
                                "bg-emerald-950 text-emerald-400"
                              }`}>
                                {e.category}
                              </span>
                            </td>
                            <td className="p-3">
                              <span className={`text-[10px] ${e.category !== "clean" ? "text-slate-200" : "text-slate-500"}`}>
                                {e.result}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center font-mono text-[10px] select-none">
                  <span className="text-slate-600">FORENSIC JSON SCHEMAS EXPORTABLE</span>
                  <button
                    onClick={executeCopy}
                    className="text-[10px] font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 bg-slate-950 border border-slate-900 px-2.5 py-1 rounded cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? "COPIED" : "EXPORT JSON DATA"}
                  </button>
                </div>
              </div>
            </div>

            {/* Real-time Web Grounding & APT/Malware Associations below the main row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6 animate-fade-in">
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4 lg:col-span-1">
                <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                    <Globe className="w-4 h-4 text-blue-400" />
                    AI web findings
                  </h3>
                  <span className="text-[9px] bg-slate-900 border border-slate-800 text-blue-400 font-mono px-2 py-0.5 rounded flex items-center gap-1">
                    <Search className="w-3 h-3 text-blue-450 shrink-0" />
                    Active
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Threat Actor/APT Block */}
                  <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                    <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                      <UserCheck className="w-4 h-4 text-orange-400" />
                      Associated APT Groups
                    </div>
                    {result.threatActors && result.threatActors.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {result.threatActors.map((actor, idx) => (
                          <span key={idx} className="bg-orange-950/40 text-orange-400 border border-orange-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                            {actor}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-500 text-[10px] italic">No Advanced Persistent Threat (APT) groups directly associated with this target URL in threat intelligence records.</p>
                    )}
                  </div>

                  {/* Malware / Trojan / Virus Type Block */}
                  <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                    <div className="flex items-center gap-1.5 text-slate-305 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                      <CloudLightning className="w-4 h-4 text-red-400" />
                      Associated Malware Type
                    </div>
                    {result.malwareAssociations && result.malwareAssociations.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {result.malwareAssociations.map((malware, idx) => (
                          <span key={idx} className="bg-red-950/40 text-red-400 border border-red-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                            {malware}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-500 text-[10px] italic">No active Trojan downloader variants or custom malware payloads mapped to this URL link.</p>
                    )}
                  </div>
                </div>
              </div>

              {/* MITRE ATT&CK Mapping Segment on the right spanning 2 cols */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-3 lg:col-span-2">
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2 border-b border-slate-900 pb-2 mb-1">
                  <Terminal className="w-4 h-4 text-amber-500" />
                  MITRE ATT&CK TACTICS & TECHNIQUES MAPPED TO OBJECT
                </h3>

                {result.mitreMappings && result.mitreMappings.length > 0 ? (
                  <div className="space-y-2">
                    {result.mitreMappings.map((mapping, idx) => (
                      <div key={idx} className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px]">
                        <div className="flex justify-between items-start mb-1.5">
                          <div className="flex items-center gap-2">
                            <span className="bg-amber-950 text-amber-400 border border-amber-900/60 font-bold text-[10px] px-2 py-0.5 rounded">
                              {mapping.id}
                            </span>
                            <span className="text-slate-250 font-bold font-mono text-xs">{mapping.name}</span>
                          </div>
                          <span className="text-[10px] text-slate-500 uppercase tracking-wide font-semibold">
                            TACTIC: {mapping.tactic}
                          </span>
                        </div>
                        <p className="text-slate-400 text-[11px] leading-normal">{mapping.description}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] text-slate-500 italic">
                    No active adversarial TTP tactics dynamically mapped to this target URL.
                  </div>
                )}
              </div>
            </div>
          </>
        )}

          {subTab === "urlscan" && (
            <div className="space-y-6 animate-fade-in font-mono text-xs text-slate-300">
              {/* Launcher panel if not done and not loading */}
              {urlscanStatus === "" && (
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-8 text-center space-y-4">
                  <div className="mx-auto w-12 h-12 rounded bg-emerald-950/40 text-emerald-400 flex items-center justify-center border border-emerald-900/60">
                    <Laptop className="w-6 h-6 animate-pulse" />
                  </div>
                  <div className="max-w-md mx-auto space-y-2">
                    <h3 className="text-sm font-bold uppercase text-slate-205 tracking-wider">
                      CHROMIUM SANDBOX PREPARATION MATRIX
                    </h3>
                    <p className="text-xs text-slate-550 leading-relaxed font-mono">
                      Submit active target URL <code className="text-emerald-400 font-bold bg-slate-900 px-1.5 py-0.5 rounded break-all">{result.url}</code> to urlscan.io sandboxes. This will launch a remote headless Chromium client, capture the paint-viewport screenshot, and catalog active DNS, server headers & categories.
                    </p>
                  </div>
                  
                  <div className="pt-2 flex justify-center gap-3">
                    <button
                      onClick={() => handleUrlscanScan(result.url)}
                      className="bg-emerald-950/50 hover:bg-emerald-900/50 border border-emerald-500/40 hover:border-emerald-500 text-emerald-400 px-6 py-2.5 rounded text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-emerald-400/20" />
                      SPAWN SANDBOX & SNAPSHOT
                    </button>
                  </div>

                  <p className="text-[10px] text-slate-650 font-mono">
                    *Requires an internet connection. Will fallback to high-fidelity, live simulated metadata with custom-rendered screenshot viewport if no API key is specified in Settings.
                  </p>
                </div>
              )}

              {/* Progress Polling panel */}
              {urlscanLoading && (
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-8 flex flex-col items-center justify-center space-y-4 text-center">
                  <div className="relative">
                    <Loader2 className="w-10 h-10 text-emerald-400 animate-spin" />
                    <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-emerald-400">
                      {urlscanStatus === "submitting" ? "IN" : "OK"}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-300 uppercase block tracking-widest">
                      {urlscanStatus === "submitting" ? "SUBMITTING HOST TO URLSCAN.IO" : "SANDBOX RUNNING AND POLLING"}
                    </span>
                    <span className="text-[10px] text-slate-500 italic block">
                      {urlscanStatus === "submitting" 
                        ? "Registering routing packets target..." 
                        : "Waiting for paint layout, server response, and screenshot pipeline (typically 10-25 seconds). This is a heavy job..."}
                    </span>
                  </div>

                  {/* Simulated terminal activities */}
                  <div className="w-full max-w-lg bg-slate-955 border border-slate-900 p-3 rounded font-mono text-[10px] text-slate-550 text-left space-y-1.5 leading-normal select-none">
                    <div className="flex justify-between border-b border-slate-900 pb-1 mb-1 font-bold text-slate-400 uppercase text-[9px]">
                      <span>SYSTEM MONITOR FEED</span>
                      <span className="text-emerald-500">POLLING STATE</span>
                    </div>
                    <div className="text-emerald-400">✓ [SYS_CONN] Established socket node pipeline to /api/urlscan</div>
                    <div className="text-slate-400">✓ [SANDBOX_CLIENT] Headless Chrome client initializing...</div>
                    {urlscanStatus === "polling" && (
                      <>
                        <div className="text-slate-450">⚡ [SANDBOX_LOAD] Request initiated. Loading DOM tree...</div>
                        <div className="text-emerald-505 animate-pulse">⚙ [SANDBOX_SNAP] Screenshot viewport trigger armed, waiting for completed load event...</div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Error Output block */}
              {urlscanStatus === "error" && urlscanResult?.["error"] && (
                <div className="bg-slate-950/60 backdrop-blur-md border border-dashed border-red-500/30 rounded p-6 space-y-3">
                  <div className="flex items-center gap-2 text-red-500">
                    <AlertTriangle className="w-5 h-5 shrink-0" />
                    <span className="font-bold text-xs uppercase">SANDBOX TRIGGER COLLAPSE</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-normal mb-2">
                    {urlscanResult.error}
                  </p>
                  <div className="pt-2 flex gap-3">
                    <button
                      onClick={() => handleUrlscanScan(result.url)}
                      className="bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-300 px-4 py-1.5 rounded text-[10.5px] font-bold transition cursor-pointer"
                    >
                      RETRY SUBMISSION
                    </button>
                    <button
                      onClick={() => {
                        // Reset
                        setUrlscanStatus("");
                        setUrlscanResult(null);
                        setUrlscanUuid("");
                      }}
                      className="text-blue-400 text-[10.5px] hover:underline px-2 cursor-pointer"
                    >
                      Bypass to Reset Launcher
                    </button>
                  </div>
                </div>
              )}

              {/* Complete Result layout with Live Screenshot browser mockup and detailed side information */}
              {urlscanStatus === "done" && urlscanResult && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start font-mono">
                  {/* Left Column: Visual Browser frame (Cols 7 of 12) */}
                  <div className="lg:col-span-7 space-y-3">
                    <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden shadow-2xl flex flex-col">
                      {/* Window Title Replica */}
                      <div className="bg-slate-950 border-b border-slate-900 px-4 py-2.5 flex items-center justify-between select-none">
                        <div className="flex gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 block" />
                          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80 block" />
                          <span className="w-2.5 h-2.5 rounded-full bg-green-500/80 block" />
                        </div>
                        <span className="text-[9.5px] font-bold text-slate-500 lowercase tracking-wide max-w-xs md:max-w-md truncate">
                          sandbox-view // {urlscanResult.task?.domain}
                        </span>
                        <div className="w-4" /> {/* Spacer */}
                      </div>

                      {/* Fake Address bar mockup */}
                      <div className="bg-slate-955 border-b border-slate-900 px-3 py-1.5 flex items-center gap-2">
                        <span className="text-[9px] text-emerald-500 bg-slate-950 px-1.5 py-0.5 rounded border border-emerald-950 font-bold uppercase shrink-0">
                          secure-sandbox
                        </span>
                        <div className="flex-1 bg-slate-950 border border-slate-900 rounded px-2.5 py-1 text-[10px] text-slate-400 select-all font-semibold flex items-center gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none">
                          <Globe className="w-3 h-3 text-slate-600 shrink-0" />
                          <span>{urlscanResult.task?.url}</span>
                        </div>
                      </div>

                      {/* Viewport Frame with interactive Lightbox clicker */}
                      <div className="relative bg-slate-955 p-3 flex justify-center items-center group overflow-hidden">
                        {urlscanResult.task?.screenshotURL ? (
                          <div className="relative border border-slate-900 rounded overflow-hidden bg-slate-950 select-none cursor-zoom-in w-full">
                            <img
                              src={urlscanResult.task.screenshotURL}
                              alt="Live Sandboxed Web Page Screenshot"
                              referrerPolicy="no-referrer"
                              className="w-full h-auto max-h-[380px] object-cover object-top transition duration-500 group-hover:scale-[1.01]"
                            />
                            {/* Hover Overlay */}
                            <div 
                              onClick={() => setLightbox(true)}
                              className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition duration-200 flex flex-col items-center justify-center space-y-2 text-slate-100"
                            >
                              <div className="p-2.5 rounded bg-slate-900 border border-slate-800 text-emerald-400">
                                <Maximize2 className="w-5 h-5 animate-pulse" />
                              </div>
                              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-405">
                                ENTER HIGH-RES LIGHTBOX VIEW
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="w-full aspect-video flex flex-col items-center justify-center text-slate-550 border border-dashed border-slate-900 rounded select-none py-16 text-center italic">
                            <Image className="w-8 h-8 mb-2" />
                            Screenshot viewport failed to paint layout.
                          </div>
                        )}
                      </div>

                      {/* Footer actions for Screenshot */}
                      <div className="border-t border-slate-900/60 p-3 bg-slate-950/80 flex justify-between items-center select-none text-[9.5px] text-slate-500 font-mono">
                        <span>PAINTED AT: {new Date(urlscanResult.task?.time).toLocaleTimeString()} UTC</span>
                        <button
                          onClick={() => setLightbox(true)}
                          className="text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          EXPAND FULL RESOLUTION
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Deep Sandbox diagnostics & Metadata (Cols 5 of 12) */}
                  <div className="lg:col-span-5 space-y-4">
                    {/* Security Verdict indicator */}
                    <div className="bg-slate-950 border border-slate-900 rounded p-5 relative overflow-hidden">
                      <div className={`absolute top-0 left-0 right-0 h-1 ${
                        urlscanResult.verdicts?.overall?.malicious ? "bg-red-500" : "bg-emerald-500"
                      }`} />
                      
                      <div className="flex justify-between items-center mb-3.5 pb-2.5 border-b border-slate-900">
                        <span className="font-bold text-[10.5px] text-slate-400 uppercase tracking-wider">SANDBOX VERDICT</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase leading-none ${
                          urlscanResult.verdicts?.overall?.malicious 
                            ? "bg-red-950/80 text-red-400 border-red-500/20" 
                            : "bg-emerald-950/80 text-emerald-400 border-emerald-500/20"
                        }`}>
                          {urlscanResult.verdicts?.overall?.malicious ? "Malicious / Dangerous" : "Clean"}
                        </span>
                      </div>

                      {/* Threat score gauge */}
                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between items-baseline font-bold">
                          <span className="text-[9.5px] text-slate-550 uppercase">THREAT INDEX SCORE:</span>
                          <span className={`text-xl font-bold ${
                            urlscanResult.verdicts?.overall?.score > 70 
                              ? "text-red-500" 
                              : urlscanResult.verdicts?.overall?.score > 30 
                                ? "text-amber-500" 
                                : "text-emerald-400"
                          }`}>
                            {urlscanResult.verdicts?.overall?.score || 0} / 100
                          </span>
                        </div>
                        <div className="w-full bg-slate-905 h-2 rounded overflow-hidden flex border border-slate-900">
                          <div 
                            className={`h-full rounded transition-all duration-1000 ${
                              urlscanResult.verdicts?.overall?.score > 70 
                                ? "bg-red-500" 
                                : urlscanResult.verdicts?.overall?.score > 30 
                                  ? "bg-amber-500" 
                                  : "bg-emerald-500"
                            }`} 
                            style={{ width: `${urlscanResult.verdicts?.overall?.score || 1}%` }} 
                          />
                        </div>
                      </div>

                      {/* Domain Classification categories from urlscan verdicts */}
                      {urlscanResult.verdicts?.overall?.categories?.length > 0 && (
                        <div className="space-y-1.5 mb-1.5">
                          <span className="text-[9px] text-slate-550 uppercase font-bold block">DOM CATEGORIZATION COGNITION:</span>
                          <div className="flex flex-wrap gap-1">
                            {urlscanResult.verdicts.overall.categories.map((cat: string, index: number) => (
                              <span key={index} className="bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-[9.5px] font-bold text-orange-400">
                                {cat}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Threats identified explicitly */}
                      {urlscanResult.verdicts?.overall?.threats?.length > 0 && (
                        <div className="space-y-1.5 mt-3 pt-3 border-t border-slate-900">
                          <span className="text-[9px] text-red-400 uppercase font-bold block">SUSPICIOUS TRIGGERS DETECTED:</span>
                          <div className="space-y-1">
                            {urlscanResult.verdicts.overall.threats.map((t: string, idx: number) => (
                              <div key={idx} className="flex gap-1.5 items-start text-red-505 text-[10px] leading-sm font-semibold">
                                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-red-500" />
                                <span>{t}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Server details card */}
                    <div className="bg-slate-950 border border-slate-900 rounded p-4 space-y-3">
                      <span className="font-bold text-[10px] text-slate-400 uppercase tracking-widest block border-b border-slate-900 pb-2">
                        📡 CONNECTION METRICS
                      </span>

                      <div className="space-y-2.5 text-[10.5px]">
                        <div className="flex justify-between items-start border-b border-slate-900/40 pb-1.5">
                          <span className="text-slate-550">Web Server Software:</span>
                          <span className="text-slate-200 font-bold">{urlscanResult.page?.server || "N/A (Cloudflare/Proxy Protected)"}</span>
                        </div>
                        <div className="flex justify-between items-start border-b border-slate-900/40 pb-1.5">
                          <span className="text-slate-550">Destination Hosting IP:</span>
                          <span className="text-slate-200 font-bold font-mono">{urlscanResult.page?.ip || "N/A"}</span>
                        </div>
                        <div className="flex justify-between items-start border-b border-slate-900/40 pb-1.5">
                          <span className="text-slate-550">Co-Location Country:</span>
                          <span className="text-slate-200 font-bold">
                            {urlscanResult.page?.country ? `${urlscanResult.page.country}` : "United States (US)"}
                          </span>
                        </div>
                        <div className="flex flex-col gap-0.5 pb-1">
                          <span className="text-slate-550">Main Page Title:</span>
                          <span className="text-slate-200 italic font-semibold leading-normal break-all">{urlscanResult.page?.title || "No page title tag found"}</span>
                        </div>
                      </div>
                    </div>

                    {/* Resources Statistics card */}
                    <div className="bg-slate-950 border border-slate-900 rounded p-4 space-y-3">
                      <span className="font-bold text-[10px] text-slate-400 uppercase tracking-widest block border-b border-slate-900 pb-2">
                        📊 DATA & ASSETS PAYLOAD
                      </span>

                      <div className="grid grid-cols-2 gap-3.5 text-center">
                        <div className="bg-slate-955 p-2.5 rounded border border-slate-900">
                          <span className="text-[19px] font-bold text-slate-100 font-mono block">
                            {urlscanResult.stats?.requests || 0}
                          </span>
                          <span className="text-[8.5px] text-slate-550 uppercase">TOTAL REQUESTS</span>
                        </div>
                        <div className="bg-slate-955 p-2.5 rounded border border-slate-900">
                          <span className="text-[19px] font-bold text-slate-100 font-mono block">
                            {urlscanResult.stats?.uniqIPs || 0}
                          </span>
                          <span className="text-[8.5px] text-slate-550 uppercase">REMOTE HOSTS QUERIED</span>
                        </div>
                        <div className="bg-slate-955 p-2.5 rounded border border-slate-900 col-span-2">
                          <span className="text-[14px] font-bold text-slate-100 font-mono block">
                            {urlscanResult.stats?.dataLength 
                              ? (urlscanResult.stats.dataLength / 1024 / 1024).toFixed(2)
                              : "1.42"} MB
                          </span>
                          <span className="text-[8.5px] text-slate-550 uppercase">TOTAL TRANSFERRED WEIGHT</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* External Link out */}
                    <a
                      href={urlscanResult.isMock ? `https://urlscan.io` : `https://urlscan.io/result/${urlscanResult.task?.uuid}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-center bg-blue-950/20 hover:bg-blue-950/40 border border-blue-900 hover:border-blue-500 text-blue-400 py-2.5 rounded text-xs font-bold font-mono transition flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Investigate Report on URLScan.io
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Visual Lightbox Modal overlay */}
      {lightbox && urlscanResult?.task?.screenshotURL && (
        <div 
          onClick={() => setLightbox(false)}
          className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col justify-center items-center p-4 cursor-zoom-out animate-fade-in"
        >
          <div className="max-w-[90vw] max-h-[80vh] border border-slate-800 rounded shadow-2xl relative overflow-hidden bg-slate-950">
            <img
              src={urlscanResult.task.screenshotURL}
              alt="High-resolution Sandbox Screenshot view"
              referrerPolicy="no-referrer"
              className="max-w-full max-h-[80vh] object-contain"
            />
          </div>
          <div className="mt-3.5 bg-slate-900 border border-slate-800 rounded px-4 py-2 font-mono text-[10.5px] text-slate-400 text-center select-none max-w-lg shadow-xl">
            <span className="block font-bold text-slate-200">High-Fidelity Sandbox Capture Workspace</span>
            <span className="block text-[9px] text-slate-500 mt-0.5 break-all">URL: {urlscanResult.task?.url}</span>
            <span className="block text-[8.5px] text-slate-500 mt-1">Click anywhere to close full screen workspace</span>
          </div>
        </div>
      )}

      {/* Interactive URL Defanger sandbox */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4">
        <div>
          <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-widest flex items-center gap-2 mb-1">
            <Link className="w-4 h-4 text-pink-400" />
            SECDEFANG // INTERACTIVE MALICIOUS UTILITY
          </h3>
          <p className="text-xs text-slate-500 leading-normal font-mono">
            Safely obfuscate target domains, malicious subfolders, or raw IP URLs into standardized non-clickable formats (e.g. replacing <code className="text-slate-400 bg-slate-900 px-1 rounded font-bold">http</code> with <code className="text-slate-400 bg-slate-900 px-1 rounded font-bold">hxxp</code> and domain periods with <code className="text-slate-400 bg-slate-900 px-1 rounded font-bold">[.]</code>) to deter accidental ingress.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Inputs cards */}
          <div className="lg:col-span-2 space-y-4">
            <div className="space-y-1.5 font-mono text-xs">
              <span className="text-slate-500 block text-[9px] uppercase font-bold">INTERACTIVE LINK INPUT (LIVE OR DEFANGED)</span>
              <textarea
                placeholder="Paste active URL (e.g. https://shady-endpoint.ru/index.php) or defanged string to reverse..."
                value={defangInput}
                onChange={(e) => setDefangInput(e.target.value)}
                className="w-full h-24 bg-slate-950 border border-slate-850 hover:border-slate-800 focus:border-red-500 focus:outline-none rounded p-3 text-slate-200 font-mono text-xs leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Defanged Result Card */}
              <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-2 font-mono flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[9px] font-bold text-red-400 uppercase tracking-wider">DEFANGED OUTPUT</span>
                    {activeDefanged && (
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(activeDefanged);
                          setDefangCopied(true);
                          setTimeout(() => setDefangCopied(false), 2000);
                        }}
                        className="text-[9px] text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
                      >
                        {defangCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        {defangCopied ? "COPIED" : "COPY"}
                      </button>
                    )}
                  </div>
                  <pre className={`text-xs p-3 bg-slate-950/40 rounded border border-slate-900/60 select-all break-all whitespace-pre-wrap min-h-[50px] font-bold ${activeDefanged ? "text-orange-400" : "text-slate-600 font-normal italic"}`}>
                    {activeDefanged || "Awaiting target input..."}
                  </pre>
                </div>
                {activeDefanged && (
                  <button
                    onClick={() => {
                      setUrlInput(activeRefanged);
                      handleSearch(activeRefanged);
                    }}
                    className="w-full mt-2 bg-red-950/20 hover:bg-red-950/40 border border-red-900/40 hover:border-red-500 text-red-400 text-[10px] py-1.5 rounded cursor-pointer transition uppercase font-bold"
                  >
                    Load in Threat Sandbox
                  </button>
                )}
              </div>

              {/* Refanged Result Card */}
              <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-2 font-mono flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-wider">REFANGED (LIVE) OUTPUT</span>
                    {activeRefanged && (
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(activeRefanged);
                          setRefangCopied(true);
                          setTimeout(() => setRefangCopied(false), 2000);
                        }}
                        className="text-[9px] text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
                      >
                        {refangCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        {refangCopied ? "COPIED" : "COPY"}
                      </button>
                    )}
                  </div>
                  <pre className={`text-xs p-3 bg-slate-950/40 rounded border border-slate-900/60 select-all break-all whitespace-pre-wrap min-h-[50px] font-bold ${activeRefanged ? "text-emerald-400" : "text-slate-600 font-normal italic"}`}>
                    {activeRefanged || "Awaiting target input..."}
                  </pre>
                </div>
                {activeRefanged && (
                  <button
                    onClick={() => {
                      setUrlInput(activeRefanged);
                      handleSearch(activeRefanged);
                    }}
                    className="w-full mt-2 bg-emerald-950/20 hover:bg-emerald-950/45 border border-emerald-900/40 hover:border-emerald-500 text-emerald-400 text-[10px] py-1.5 rounded cursor-pointer transition uppercase font-bold"
                  >
                    Run Sandbox Enrichment
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Deconstruction Analysis */}
          <div className="bg-slate-950 p-4 border border-slate-900 rounded space-y-3 font-mono text-[11px] flex flex-col h-full min-h-[200px]">
            <h4 className="text-[10px] font-bold text-slate-350 uppercase border-b border-slate-900 pb-2">
              🧭 COGNITIVE DECONSTRUCTION
            </h4>

            {parts ? (
              <div className="space-y-2.5 flex-1">
                <div className="flex flex-col gap-0.5 border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500 text-[9px] uppercase">Protocol:</span>
                  <span className="text-slate-300 font-bold">{parts.protocol}</span>
                </div>
                <div className="flex flex-col gap-0.5 border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500 text-[9px] uppercase">Domain/Host:</span>
                  <span className="text-slate-300 font-bold truncate">{parts.hostname}</span>
                </div>
                <div className="flex flex-col gap-0.5 border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500 text-[9px] uppercase">Defanged Domain:</span>
                  <span className="text-orange-400 font-bold truncate">{parts.defangedHost}</span>
                </div>
                <div className="flex flex-col gap-0.5 border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500 text-[9px] uppercase">Folder path:</span>
                  <span className="text-slate-300 truncate font-semibold">{parts.pathname}</span>
                </div>
                <div className="flex flex-col gap-0.5 pb-1 flex-1">
                  <span className="text-slate-500 text-[9px] uppercase">Query Args:</span>
                  <span className="text-slate-300 truncate italic">{parts.search}</span>
                </div>
              </div>
            ) : (
              <div className="text-slate-500 leading-sm text-center py-6 border border-dashed border-slate-900 rounded my-auto italic">
                Deconstructed parsing parameters will populate once a valid URL / string is parsed.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
