/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Key, 
  Save, 
  Check, 
  KeyRound, 
  Info, 
  Eye, 
  EyeOff, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  ShieldAlert, 
  RefreshCw, 
  UserCheck, 
  AlertCircle,
  X
} from "lucide-react";

export default function SettingsView() {
  // Admin auth states
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminToken, setAdminToken] = useState<string>(() => localStorage.getItem("THREATNEXUS_ADMIN_TOKEN") || "");
  const [adminEmail, setAdminEmail] = useState("akthehacker8@gmail.com");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showPasscodeModal, setShowPasscodeModal] = useState(false);
  
  // Auth inputs
  const [inputPasscode, setInputPasscode] = useState("");
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  // Change passcode inputs
  const [currentPasscode, setCurrentPasscode] = useState("");
  const [newPasscode, setNewPasscode] = useState("");
  const [passcodeMsg, setPasscodeMsg] = useState<{ text: string; isError: boolean } | null>(null);
  const [passcodeLoading, setPasscodeLoading] = useState(false);

  // Key form states (Admin view)
  const [vtKey, setVtKey] = useState("");
  const [abuseKey, setAbuseKey] = useState("");
  const [greyNoiseKey, setGreyNoiseKey] = useState("");
  const [shodanKey, setShodanKey] = useState("");
  const [urlscanKey, setUrlscanKey] = useState("");
  const [geminiKey, setGeminiKey] = useState("");
  const [ipinfoKey, setIpinfoKey] = useState("");
  const [ip2proxyKey, setIp2proxyKey] = useState("");
  const [ipqsKey, setIpqsKey] = useState("");
  const [whoisJsonKey, setWhoisJsonKey] = useState("");
  
  // Status and masked keys (Team view)
  const [maskedKeys, setMaskedKeys] = useState<Record<string, string>>({});
  const [isConfigured, setIsConfigured] = useState<Record<string, boolean>>({});

  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [loadingSync, setLoadingSync] = useState(false);

  // Visibility states for individual keys (Admin only)
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});

  const toggleShowKey = (key: string) => {
    setShowKeys((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Fetch settings from server
  const fetchSettings = (tokenToUse?: string) => {
    setLoadingSync(true);
    const effectiveToken = tokenToUse !== undefined ? tokenToUse : adminToken;
    const headers: Record<string, string> = {};
    if (effectiveToken) {
      headers["Authorization"] = `Bearer ${effectiveToken}`;
    }

    fetch("/api/settings", { headers })
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error("Failed to fetch settings");
      })
      .then((data) => {
        if (!data) return;
        setIsAdmin(!!data.isAdmin);
        if (data.adminEmail) setAdminEmail(data.adminEmail);
        if (data.isConfigured) setIsConfigured(data.isConfigured);

        if (data.isAdmin && data.keys) {
          // Admin mode: populate actual key fields
          setVtKey(data.keys.VT_API_KEY || "");
          setAbuseKey(data.keys.ABUSEIPDB_API_KEY || "");
          setGreyNoiseKey(data.keys.GREYNOISE_API_KEY || "");
          setShodanKey(data.keys.SHODAN_API_KEY || "");
          setUrlscanKey(data.keys.URLSCAN_API_KEY || "");
          setGeminiKey(data.keys.GEMINI_API_KEY || "");
          setIpinfoKey(data.keys.IPINFO_API_KEY || "");
          setIp2proxyKey(data.keys.IP2PROXY_API_KEY || "");
          setIpqsKey(data.keys.IPQUALITYSCORE_API_KEY || "");
          setWhoisJsonKey(data.keys.WHOISJSON_API_KEY || "");
        } else {
          // Team mode: populate masked keys & sanitize localStorage to prevent client leaks
          if (data.maskedKeys) setMaskedKeys(data.maskedKeys);
          // Purge sensitive keys from browser storage
          const sensitiveKeys = [
            "VT_API_KEY", "ABUSEIPDB_API_KEY", "GREYNOISE_API_KEY", "SHODAN_API_KEY",
            "URLSCAN_API_KEY", "GEMINI_API_KEY", "IPINFO_API_KEY", "IP2PROXY_API_KEY",
            "IPQUALITYSCORE_API_KEY", "WHOISJSON_API_KEY"
          ];
          sensitiveKeys.forEach((k) => localStorage.removeItem(k));
        }
      })
      .catch((err) => {
        console.error("Failed to load server settings in SettingsView:", err);
      })
      .finally(() => setLoadingSync(false));
  };

  useEffect(() => {
    fetchSettings();
  }, [adminToken]);

  // Handle Admin Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputPasscode.trim()) {
      setAuthError("Please enter your admin passcode");
      return;
    }

    setAuthLoading(true);
    setAuthError("");

    try {
      const res = await fetch("/api/settings/admin-auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode: inputPasscode.trim() })
      });

      const data = await res.json();
      if (res.ok && data.token) {
        localStorage.setItem("THREATNEXUS_ADMIN_TOKEN", data.token);
        setAdminToken(data.token);
        setIsAdmin(true);
        setShowAuthModal(false);
        setInputPasscode("");
        fetchSettings(data.token);
      } else {
        setAuthError(data.error || "Invalid administrator passcode");
      }
    } catch (err) {
      setAuthError("Failed to authenticate. Please check server connection.");
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle Logout from Admin mode
  const handleLockAdmin = () => {
    localStorage.removeItem("THREATNEXUS_ADMIN_TOKEN");
    setAdminToken("");
    setIsAdmin(false);
    setVtKey("");
    setAbuseKey("");
    setGreyNoiseKey("");
    setShodanKey("");
    setUrlscanKey("");
    setGeminiKey("");
    setIpinfoKey("");
    setIp2proxyKey("");
    setIpqsKey("");
    setWhoisJsonKey("");
    fetchSettings("");
  };

  // Handle Change Passcode
  const handleChangePasscode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPasscode.trim() || !newPasscode.trim()) {
      setPasscodeMsg({ text: "Both current and new passcodes are required", isError: true });
      return;
    }
    if (newPasscode.trim().length < 6) {
      setPasscodeMsg({ text: "New passcode must be at least 6 characters", isError: true });
      return;
    }

    setPasscodeLoading(true);
    setPasscodeMsg(null);

    try {
      const res = await fetch("/api/settings/change-passcode", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          currentPasscode: currentPasscode.trim(),
          newPasscode: newPasscode.trim()
        })
      });

      const data = await res.json();
      if (res.ok) {
        setPasscodeMsg({ text: "Passcode updated successfully! Store your new passcode securely.", isError: false });
        setCurrentPasscode("");
        setNewPasscode("");
        setTimeout(() => {
          setShowPasscodeModal(false);
          setPasscodeMsg(null);
        }, 2200);
      } else {
        setPasscodeMsg({ text: data.error || "Failed to update passcode", isError: true });
      }
    } catch (err) {
      setPasscodeMsg({ text: "Connection error updating passcode", isError: true });
    } finally {
      setPasscodeLoading(false);
    }
  };

  // Handle Save (Admin only)
  const handleSave = () => {
    setSaveError("");
    const vt = vtKey.trim();
    const abuse = abuseKey.trim();
    const grey = greyNoiseKey.trim();
    const shodan = shodanKey.trim();
    const urlscan = urlscanKey.trim();
    const gemini = geminiKey.trim();
    const ipinfo = ipinfoKey.trim();
    const ip2proxy = ip2proxyKey.trim();
    const ipqs = ipqsKey.trim();
    const whois = whoisJsonKey.trim();

    fetch("/api/settings", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        VT_API_KEY: vt,
        ABUSEIPDB_API_KEY: abuse,
        GREYNOISE_API_KEY: grey,
        SHODAN_API_KEY: shodan,
        URLSCAN_API_KEY: urlscan,
        GEMINI_API_KEY: gemini,
        IPINFO_API_KEY: ipinfo,
        IP2PROXY_API_KEY: ip2proxy,
        IPQUALITYSCORE_API_KEY: ipqs,
        WHOISJSON_API_KEY: whois,
      }),
    })
      .then(async (res) => {
        if (res.ok) {
          setSaved(true);
          setTimeout(() => setSaved(false), 2500);
          fetchSettings();
        } else {
          const err = await res.json();
          setSaveError(err.error || "Unauthorized: Admin privileges required to edit keys");
        }
      })
      .catch((err) => {
        console.error("Failed to sync keys to server:", err);
        setSaveError("Network error saving configuration");
      });
  };

  const servicesList = [
    { key: "GEMINI_API_KEY", label: "Google Gemini AI Core", desc: "Powers deep generative analysis, MITRE ATT&CK correlation, and incident report generation", category: "Core Intelligence", color: "border-emerald-500/30 text-emerald-400" },
    { key: "VT_API_KEY", label: "VirusTotal Enterprise", desc: "Live multi-engine malware signature detection, sandbox analysis, and IOC graphs", category: "Threat Scanner", color: "border-blue-500/30 text-blue-400" },
    { key: "ABUSEIPDB_API_KEY", label: "AbuseIPDB Global Network", desc: "Crowdsourced malicious IP reporting, abuse confidence scoring, and ISP telemetry", category: "Reputation Feed", color: "border-amber-500/30 text-amber-400" },
    { key: "GREYNOISE_API_KEY", label: "GreyNoise Visualizer", desc: "Mass scanner categorization, benign internet noise filtering, and malicious intent feeds", category: "Scanner Filter", color: "border-purple-500/30 text-purple-400" },
    { key: "SHODAN_API_KEY", label: "Shodan Search Engine", desc: "Open port scanning, active CVE telemetry, and server banners", category: "Surface Intel", color: "border-red-500/30 text-red-400" },
    { key: "WHOISJSON_API_KEY", label: "WhoisJSON Diagnostics", desc: "Real-time domain registrar lookups, domain ages, and nameserver mappings", category: "WHOIS Registry", color: "border-cyan-500/30 text-cyan-400" },
    { key: "URLSCAN_API_KEY", label: "URLScan.io Sandbox", desc: "Automated browser sandbox captures, DOM inspections, and phishing detection", category: "URL Sandbox", color: "border-indigo-500/30 text-indigo-400" },
    { key: "IPINFO_API_KEY", label: "IPInfo Geolocation & Privacy", desc: "Residential proxy detection, VPN/Tor gateway tracking, and ASN routing records", category: "Network IP", color: "border-teal-500/30 text-teal-400" },
    { key: "IP2PROXY_API_KEY", label: "IP2Proxy Proxy Defense", desc: "Data center proxy identification and fraud proxy database verification", category: "Fraud Defense", color: "border-rose-500/30 text-rose-400" },
    { key: "IPQUALITYSCORE_API_KEY", label: "IPQualityScore Fraud Score", desc: "Machine learning bot scoring, high-risk ISP detection, and abuse velocity metrics", category: "Fraud Scoring", color: "border-orange-500/30 text-orange-400" }
  ];

  return (
    <div className="space-y-6 max-w-4xl animate-fade-in pb-12 font-mono">
      {/* Header Banner */}
      <div className="bg-slate-950/80 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Key className="w-4 h-4 text-emerald-400 animate-pulse" />
            <h2 className="text-sm font-bold text-slate-100 tracking-wider uppercase">
              SECURITY CREDENTIALS & INTELLIGENCE VAULT
            </h2>
            {isAdmin ? (
              <span className="bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> ADMIN UNLOCKED
              </span>
            ) : (
              <span className="bg-blue-500/15 border border-blue-500/40 text-blue-400 text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <Lock className="w-3 h-3" /> PROTECTED TEAM MODE
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400">
            {isAdmin 
              ? `Logged in as Master Administrator (${adminEmail}). Plaintext keys are visible and editable by you only.`
              : `ThreatNexus is running in Shared Team Mode. All configured intelligence engines are executing server-side for your team without exposing private credentials.`}
          </p>
        </div>

        {/* Action Button: Unlock Admin or Lock Vault */}
        <div className="shrink-0 flex items-center gap-2">
          {isAdmin ? (
            <>
              <button
                type="button"
                onClick={() => setShowPasscodeModal(true)}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white px-3 py-2 rounded text-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                CHANGE PASSCODE
              </button>
              <button
                type="button"
                onClick={handleLockAdmin}
                className="bg-red-950/40 hover:bg-red-900/60 border border-red-800/60 text-red-300 hover:text-white px-3.5 py-2 rounded text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-red-400" />
                LOCK VAULT
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/50 hover:border-emerald-400 text-emerald-300 hover:text-white px-4 py-2 rounded text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-950/30 cursor-pointer"
            >
              <Unlock className="w-4 h-4 text-emerald-400 animate-pulse" />
              ADMINISTRATOR UNLOCK
            </button>
          )}
        </div>
      </div>

      {/* Mode 1: Protected Team Mode (Masked & Cloaked View) */}
      {!isAdmin && (
        <div className="space-y-6">
          {/* Security Architecture Callout */}
          <div className="bg-blue-950/20 border border-blue-900/40 rounded p-4 text-xs space-y-2">
            <div className="flex items-center gap-2 text-blue-400 font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>ENTERPRISE KEY CLOAKING IN EFFECT</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[11.5px]">
              To protect organizational secrets when sharing ThreatNexus with SOC analysts or hackathon evaluators, 
              <strong> plaintext API credentials are never transmitted to team client browsers or written into localStorage</strong>. 
              All intelligence requests (IP enrichment, domain forensics, virus scans, AI logs, and reports) execute securely through the backend container using your pre-authorized server vault.
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-1 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping" />
                <span>Backend Vault: <strong className="text-emerald-400">Online & Enforcing</strong></span>
              </span>
              <span className="flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-slate-500" />
                <span>Client Exposure: <strong className="text-slate-300">0% (Completely Hidden)</strong></span>
              </span>
              <span className="flex items-center gap-1.5">
                <UserCheck className="w-3 h-3 text-cyan-400" />
                <span>Admin Owner: <strong className="text-cyan-400">{adminEmail}</strong></span>
              </span>
            </div>
          </div>

          {/* Configured Intelligence Engines Matrix */}
          <div className="bg-slate-955/70 backdrop-blur-md border border-slate-900 rounded p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-900 pb-3">
              <div>
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                  CONFIGURED INTELLIGENCE ENGINES ({servicesList.filter(s => isConfigured[s.key]).length}/{servicesList.length} ACTIVE)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Real-time status of backend service credentials available to your investigation team
                </p>
              </div>
              <button
                type="button"
                onClick={() => fetchSettings()}
                className="text-slate-500 hover:text-slate-300 text-xs flex items-center gap-1 transition cursor-pointer"
                title="Refresh status"
              >
                <RefreshCw className={`w-3 h-3 ${loadingSync ? "animate-spin text-emerald-400" : ""}`} />
                <span>Refresh</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {servicesList.map((svc) => {
                const configured = isConfigured[svc.key];
                return (
                  <div 
                    key={svc.key}
                    className={`p-3.5 rounded border ${configured ? "bg-slate-900/40 border-slate-800" : "bg-slate-950/30 border-slate-900"} flex flex-col justify-between gap-2.5 transition`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                          {svc.label}
                        </span>
                        {configured ? (
                          <span className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9.5px] px-2 py-0.5 rounded font-bold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            ACTIVE
                          </span>
                        ) : (
                          <span className="bg-slate-800 text-slate-500 text-[9.5px] px-2 py-0.5 rounded font-mono">
                            FALLBACK MODE
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal line-clamp-2">
                        {svc.desc}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-900/80 flex items-center justify-between text-[10px]">
                      <div className="flex items-center gap-1 text-slate-400 font-mono">
                        <Lock className="w-2.5 h-2.5 text-slate-500" />
                        <span>Key:</span>
                        <code className="text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800 font-mono">
                          {(() => {
                            const item = maskedKeys[svc.key];
                            if (!item) return configured ? "••••••••••••••••••••" : "Not Configured";
                            if (typeof item === "object") return (item as any).preview || (configured ? "••••••••••••••••••••" : "Not Configured");
                            return item;
                          })()}
                        </code>
                      </div>
                      <span className="text-[9px] text-slate-600 uppercase tracking-wider">
                        {svc.category}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Admin Unlock Prompt */}
          <div className="bg-slate-955/50 border border-dashed border-slate-800 rounded p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center shrink-0">
                <Lock className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200">Are you the platform administrator?</h4>
                <p className="text-[11px] text-slate-500">
                  Unlock the admin console with your master passcode to edit or add new API keys.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="bg-emerald-900/30 hover:bg-emerald-900/50 border border-emerald-700/50 text-emerald-300 text-xs px-4 py-2 rounded font-bold transition shrink-0 cursor-pointer"
            >
              Enter Admin Passcode
            </button>
          </div>
        </div>
      )}

      {/* Mode 2: Administrator Edit Mode (Full Configuration Console) */}
      {isAdmin && (
        <div className="bg-slate-955/70 backdrop-blur-md border border-slate-900 rounded p-5 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-900 pb-3">
            <div>
              <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <Key className="w-4 h-4" />
                MASTER API CREDENTIAL MANAGEMENT CONSOLE
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Update credentials below. Values are securely written into the server vault (`api-keys.json`) and instantly inherited by all team sessions.
              </p>
            </div>
            <span className="text-[10px] text-emerald-400/80 bg-emerald-950/40 border border-emerald-900/60 px-2 py-1 rounded">
              VAULT WRITE PERMISSION: GRANTED
            </span>
          </div>

          {saveError && (
            <div className="bg-red-950/30 border border-red-900 text-red-400 p-3 rounded text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{saveError}</span>
            </div>
          )}

          <div className="space-y-4 text-xs">
            {/* Gemini API Key */}
            <div className="space-y-1">
              <label className="text-emerald-400 font-bold block flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5" />
                GEMINI CORE ENRICHMENT KEY (PRIMARY AI REASONING)
              </label>
              <div className="relative">
                <input
                  type={showKeys["gemini"] ? "text" : "password"}
                  placeholder="GEMINI_API_KEY (e.g. AIzaSyD...)"
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-emerald-900/40 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-emerald-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("gemini")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                  title={showKeys["gemini"] ? "Hide key" : "Show key"}
                >
                  {showKeys["gemini"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-500 block leading-normal mt-0.5">
                Powers AI Log Analysis, Threat Graph clustering, MITRE correlation, and Technical Incident Reports.
              </span>
            </div>

            {/* WHOISJSON API Key */}
            <div className="space-y-1">
              <label className="text-blue-400 font-bold block flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5" />
                WHOISJSON.COM DIAGNOSTIC KEY
              </label>
              <div className="relative">
                <input
                  type={showKeys["whoisjson"] ? "text" : "password"}
                  placeholder="WHOISJSON_API_KEY (e.g. 1807d02d57cf...)"
                  value={whoisJsonKey}
                  onChange={(e) => setWhoisJsonKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-blue-900/40 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-blue-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("whoisjson")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                  title={showKeys["whoisjson"] ? "Hide key" : "Show key"}
                >
                  {showKeys["whoisjson"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-500 block leading-normal mt-0.5">
                Queries authentic registrar database indices for live domain ages, expiration, and authoritative nameservers.
              </span>
            </div>

            {/* VirusTotal */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">VIRUSTOTAL INTELLIGENCE KEY</label>
              <div className="relative">
                <input
                  type={showKeys["virustotal"] ? "text" : "password"}
                  placeholder="VT_API_KEY (e.g. 54f85e92acdecd23e...)"
                  value={vtKey}
                  onChange={(e) => setVtKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("virustotal")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["virustotal"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* AbuseIPDB */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">ABUSEIPDB REPUTATION KEY</label>
              <div className="relative">
                <input
                  type={showKeys["abuseipdb"] ? "text" : "password"}
                  placeholder="ABUSEIPDB_API_KEY (e.g. adfbeff320a4be3281...)"
                  value={abuseKey}
                  onChange={(e) => setAbuseKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("abuseipdb")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["abuseipdb"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* GreyNoise */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">GREYNOISE SHIELDS FEED KEY</label>
              <div className="relative">
                <input
                  type={showKeys["greynoise"] ? "text" : "password"}
                  placeholder="GREYNOISE_API_KEY (e.g. gnk_4f8490fae120d...)"
                  value={greyNoiseKey}
                  onChange={(e) => setGreyNoiseKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("greynoise")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["greynoise"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Shodan */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">SHODAN PORTAL QUERY KEY</label>
              <div className="relative">
                <input
                  type={showKeys["shodan"] ? "text" : "password"}
                  placeholder="SHODAN_API_KEY (e.g. shodan_84e3d2c94a9ea...)"
                  value={shodanKey}
                  onChange={(e) => setShodanKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("shodan")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["shodan"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* URLScan */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">URLSCAN.IO SANDBOX KEY (OPTIONAL)</label>
              <div className="relative">
                <input
                  type={showKeys["urlscan"] ? "text" : "password"}
                  placeholder="URLSCAN_API_KEY (e.g. 78ec4512-bcde-4ea2-9012-...)"
                  value={urlscanKey}
                  onChange={(e) => setUrlscanKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("urlscan")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["urlscan"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* IPInfo Privacy Key */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">IPINFO PRIVACY DETECTOR TOKEN</label>
              <div className="relative">
                <input
                  type={showKeys["ipinfo"] ? "text" : "password"}
                  placeholder="IPINFO_TOKEN (e.g. 1a2b3c4d5e...)"
                  value={ipinfoKey}
                  onChange={(e) => setIpinfoKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("ipinfo")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["ipinfo"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* IP2Proxy Key */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">IP2PROXY WEB SERVICE KEY</label>
              <div className="relative">
                <input
                  type={showKeys["ip2proxy"] ? "text" : "password"}
                  placeholder="IP2PROXY_API_KEY (e.g. PX11_Key...)"
                  value={ip2proxyKey}
                  onChange={(e) => setIp2proxyKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("ip2proxy")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["ip2proxy"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* IPQualityScore Key */}
            <div className="space-y-1">
              <label className="text-slate-300 font-bold block">IPQUALITYSCORE DETECTION KEY</label>
              <div className="relative">
                <input
                  type={showKeys["ipqs"] ? "text" : "password"}
                  placeholder="IPQS_API_KEY (e.g. xYz123_Key...)"
                  value={ipqsKey}
                  onChange={(e) => setIpqsKey(e.target.value)}
                  className="w-full bg-slate-1000 border border-slate-900 rounded pl-3 pr-10 py-2 text-slate-300 focus:outline-none focus:border-red-500 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => toggleShowKey("ipqs")}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  {showKeys["ipqs"] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-900 flex flex-col sm:flex-row justify-between items-center gap-3">
            <span className="text-slate-500 text-[10.5px]">
              {loadingSync ? "SYNCHRONIZING SERVER VAULT..." : "VAULT ENCRYPTION // ACTIVE"}
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleLockAdmin}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-3.5 py-2.5 rounded text-xs transition cursor-pointer"
              >
                Cancel & Lock
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/50 hover:border-emerald-400 text-emerald-300 hover:text-white px-5 py-2.5 rounded text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/40"
              >
                {saved ? <Check className="w-4 h-4 text-emerald-400 animate-pulse" /> : <Save className="w-4 h-4" />}
                {saved ? "CREDENTIALS COMMITTED" : "SAVE & COMMIT TO VAULT"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Admin Passcode Login */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-emerald-900/60 rounded-lg max-w-md w-full p-6 shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-900 pb-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <ShieldCheck className="w-5 h-5" />
                <span>ADMINISTRATOR AUTHENTICATION</span>
              </div>
              <button 
                type="button"
                onClick={() => { setShowAuthModal(false); setAuthError(""); }}
                className="text-slate-500 hover:text-slate-300 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Enter your master administrator passcode to reveal raw API keys and configure threat intelligence integrations.
            </p>

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">
                  MASTER PASSCODE
                </label>
                <input
                  type="password"
                  autoFocus
                  value={inputPasscode}
                  onChange={(e) => setInputPasscode(e.target.value)}
                  placeholder="Enter administrator passcode..."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2.5 text-slate-200 text-xs focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              {authError && (
                <div className="bg-red-950/40 border border-red-900/60 text-red-400 text-xs p-2.5 rounded flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => { setShowAuthModal(false); setAuthError(""); }}
                  className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-4 py-2 rounded text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={authLoading}
                  className="bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 hover:text-white px-5 py-2 rounded text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {authLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Unlock className="w-3.5 h-3.5" />}
                  {authLoading ? "Verifying..." : "Unlock Vault"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Change Master Passcode */}
      {showPasscodeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-955 border border-amber-900/60 rounded-lg max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-900 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <KeyRound className="w-5 h-5" />
                <span>ROTATE ADMIN PASSCODE</span>
              </div>
              <button 
                type="button"
                onClick={() => { setShowPasscodeModal(false); setPasscodeMsg(null); }}
                className="text-slate-500 hover:text-slate-300 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Update your master administrator passcode for ThreatNexus.
            </p>

            <form onSubmit={handleChangePasscode} className="space-y-3.5">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 block">CURRENT PASSCODE</label>
                <input
                  type="password"
                  value={currentPasscode}
                  onChange={(e) => setCurrentPasscode(e.target.value)}
                  placeholder="Current passcode..."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 block">NEW PASSCODE (MIN 6 CHARS)</label>
                <input
                  type="password"
                  value={newPasscode}
                  onChange={(e) => setNewPasscode(e.target.value)}
                  placeholder="New passcode..."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              {passcodeMsg && (
                <div className={`p-2.5 rounded text-xs flex items-center gap-2 ${passcodeMsg.isError ? "bg-red-950/40 border border-red-900/60 text-red-400" : "bg-emerald-950/40 border border-emerald-900/60 text-emerald-400"}`}>
                  {passcodeMsg.isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <Check className="w-4 h-4 shrink-0" />}
                  <span>{passcodeMsg.text}</span>
                </div>
              )}

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => { setShowPasscodeModal(false); setPasscodeMsg(null); }}
                  className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 px-4 py-2 rounded text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={passcodeLoading}
                  className="bg-amber-950/60 hover:bg-amber-900 border border-amber-500/50 text-amber-300 hover:text-white px-5 py-2 rounded text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {passcodeLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  {passcodeLoading ? "Saving..." : "Update Passcode"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
