/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { RansomwareVictim, RansomwareGroup } from "../types";
import { Search, ShieldAlert, Calendar, LayoutGrid, Award, Server, Activity, Filter, HelpCircle, Loader2 } from "lucide-react";

export default function RansomwareView() {
  const [victims, setVictims] = useState<RansomwareVictim[]>([]);
  const [groups, setGroups] = useState<RansomwareGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("All");

  const fetchRansomData = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/ransomware");
      if (response.ok) {
        const data = await response.json();
        setVictims(data.victims || []);
        setGroups(data.groups || []);
      }
    } catch (err) {
      console.error("Ransomware sync lookup error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRansomData();
  }, []);

  const filteredVictims = victims.filter((v) => {
    const matchesSearch =
      v.victim_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.country.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGroup = selectedGroup === "All" || v.group_name === selectedGroup;
    return matchesSearch && matchesGroup;
  });

  return (
    <div className="space-y-6">
      {/* Title block */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-red-500 animate-pulse" />
          RANSOMWARE INTELLIGENCE TRACKS
        </h2>
        <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
          Scraping live leak posts on dark web negotiation channels from LockBit, Play, Clop, and BlackCat (ALPHV).
        </p>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 max-w-4xl">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              id="ransomware-victim-search"
              type="text"
              placeholder="Search victim groups, country, or industry sectors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-9 pr-4 py-2 text-xs font-mono text-slate-201 placeholder-slate-650"
            />
          </div>

          {/* Group filtering drop */}
          <div className="flex gap-2 items-center font-mono text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span>FILTER BY GANG:</span>
            <select
              value={selectedGroup}
              onChange={(e) => setSelectedGroup(e.target.value)}
              className="bg-slate-950 border border-slate-900 rounded text-slate-300 text-[11px] px-2 py-1 font-mono hover:border-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="All">ALL RANSOM GROUPS</option>
              {groups.map((g, idx) => (
                <option key={idx} value={g.name}>
                  {g.name.toUpperCase()}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {loading && (
        <div className="text-center py-12 font-mono text-xs text-slate-500 flex flex-col items-center gap-2">
          <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          Synchronizing ransomware leak directories...
        </div>
      )}

      {!loading && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Victims List (Large table) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
              <h3 className="text-xs font-mono font-bold text-slate-205 tracking-wider uppercase mb-3 flex items-center gap-2">
                <Server className="w-3.5 h-3.5 text-red-500" />
                LATEST LEAKED OR DISCOVERED VICTIMS
              </h3>

              <div className="bg-slate-950 border border-slate-900 rounded overflow-x-auto">
                <table className="w-full text-left font-mono text-[11px] select-all min-w-[500px]">
                  <thead>
                    <tr className="bg-slate-955 text-slate-500 border-b border-slate-900">
                      <th className="p-3">VICTIM ORGANIZATION</th>
                      <th className="p-3">RANSOM GANG</th>
                      <th className="p-3">INDUSTRY</th>
                      <th className="p-3">COUNTRY</th>
                      <th className="p-3 text-right">DISCOVERED</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900/60">
                    {filteredVictims.map((vic, idx) => (
                      <tr key={vic.id || idx} className="hover:bg-slate-900/10">
                        <td className="p-3 font-semibold text-slate-300 break-words max-w-[150px]">
                          {vic.victim_name}
                        </td>
                        <td className="p-3 font-bold text-red-400 font-mono">
                          {vic.group_name}
                        </td>
                        <td className="p-3 text-slate-400 truncate max-w-[120px]" title={vic.industry}>
                          {vic.industry}
                        </td>
                        <td className="p-3 text-slate-400">
                          {vic.country}
                        </td>
                        <td className="p-3 text-right text-slate-505 font-medium">
                          {vic.discovered}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Groups Summary Metrics */}
          <div className="space-y-4">
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-3 flex items-center gap-2 col-span-3">
                  <Award className="w-4 h-4 text-rose-500" />
                  RANSOMWARE LEADERBOARDS
                </h3>
                <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                  <table className="w-full text-left font-mono text-[10px] select-none">
                    <thead>
                      <tr className="bg-slate-955 text-slate-505 border-b border-slate-900">
                        <th className="p-2.5">GANG NAME</th>
                        <th className="p-2.5 text-right">TOTAL LEAKED</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900/50">
                      {groups.slice(0, 6).map((grp, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/10">
                          <td className="p-2.5 font-bold text-slate-300 flex items-center gap-2">
                            <span className="text-[9px] text-slate-500">#{idx + 1}</span>
                            {grp.name}
                          </td>
                          <td className="p-2.5 text-right font-semibold text-coral text-red-400">
                            {grp.victim_count || 0}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-900 mt-4 text-center font-mono text-[9px] text-slate-600">
                <span>Data proxy mapping of Tor onion directories trackers.</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
