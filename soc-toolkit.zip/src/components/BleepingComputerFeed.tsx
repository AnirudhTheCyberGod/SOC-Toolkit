/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import {
  Rss,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  RotateCw,
  Search,
  Filter,
  ShieldAlert,
  Globe,
  Hash,
  FileCode,
  Link as LinkIcon,
  Server,
  ArrowRight,
  Download,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Tag,
  Clock,
  Layers,
  Send
} from "lucide-react";

export interface BleepingIocs {
  cves: string[];
  hashes: string[];
  ips: string[];
  domains: string[];
  urls: string[];
  files: string[];
}

export interface BleepingArticle {
  id: string;
  title: string;
  link: string;
  pubDate: string;
  creator: string;
  categories: string[];
  summary: string;
  hasIocSection: boolean;
  totalIocs: number;
  iocs: BleepingIocs;
}

interface BleepingComputerFeedProps {
  onPivotToIp?: (ip: string) => void;
  onPivotToDomain?: (domain: string) => void;
  onPivotToUrl?: (url: string) => void;
  onPivotToHash?: (hash: string) => void;
  onSendToBulk?: (iocsText: string) => void;
  onNavigateToKql?: (context: {
    title: string;
    cves: string[];
    ips: string[];
    domains: string[];
    urls: string[];
    hashes: string[];
    files: string[];
  }) => void;
}

export default function BleepingComputerFeed({
  onPivotToIp,
  onPivotToDomain,
  onPivotToUrl,
  onPivotToHash,
  onSendToBulk,
  onNavigateToKql
}: BleepingComputerFeedProps) {
  const [articles, setArticles] = useState<BleepingArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cachedAt, setCachedAt] = useState<string>("");

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState("");
  const [hasIocsOnly, setHasIocsOnly] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // Selected article for deep inspection / AI extraction
  const [expandedArticleId, setExpandedArticleId] = useState<string | null>(null);
  const [copiedValue, setCopiedValue] = useState<string | null>(null);

  // AI Extraction State
  const [aiExtractingId, setAiExtractingId] = useState<string | null>(null);
  const [aiAnalysisMap, setAiAnalysisMap] = useState<Record<string, any>>({});
  const [aiErrorMap, setAiErrorMap] = useState<Record<string, string>>({});

  const fetchFeed = async (forceRefresh = false) => {
    if (forceRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      const url = forceRefresh ? "/api/feeds/bleepingcomputer?refresh=true" : "/api/feeds/bleepingcomputer";
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }
      const data = await res.json();
      setArticles(data.articles || []);
      setCachedAt(data.cachedAt || new Date().toISOString());
    } catch (err: any) {
      console.error("Failed to load BleepingComputer feed:", err);
      setError(err.message || "Failed to connect to BleepingComputer RSS feed.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFeed();
  }, []);

  const handleCopy = (val: string) => {
    navigator.clipboard.writeText(val);
    setCopiedValue(val);
    setTimeout(() => setCopiedValue(null), 2000);
  };

  // Run Gemini AI deep CTI extraction on an article
  const handleRunAiExtraction = async (article: BleepingArticle) => {
    setAiExtractingId(article.id);
    setAiErrorMap((prev) => ({ ...prev, [article.id]: "" }));

    try {
      const res = await fetch("/api/feeds/bleepingcomputer/ai-extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          articleUrl: article.link,
          articleTitle: article.title,
          articleSummary: article.summary
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "AI extraction failed");
      }

      setAiAnalysisMap((prev) => ({ ...prev, [article.id]: data.analysis }));
    } catch (err: any) {
      console.error("AI extraction error:", err);
      setAiErrorMap((prev) => ({ ...prev, [article.id]: err.message || "Extraction failed" }));
    } finally {
      setAiExtractingId(null);
    }
  };

  // Export article indicators to CSV or STIX-compatible JSON
  const handleExportIocs = (article: BleepingArticle, format: "csv" | "json") => {
    const allIndicators: { type: string; value: string }[] = [];
    article.iocs.cves.forEach((v) => allIndicators.push({ type: "CVE", value: v }));
    article.iocs.ips.forEach((v) => allIndicators.push({ type: "IP", value: v }));
    article.iocs.domains.forEach((v) => allIndicators.push({ type: "Domain", value: v }));
    article.iocs.urls.forEach((v) => allIndicators.push({ type: "URL", value: v }));
    article.iocs.hashes.forEach((v) => allIndicators.push({ type: "Hash", value: v }));
    article.iocs.files.forEach((v) => allIndicators.push({ type: "File", value: v }));

    let content = "";
    let filename = `bleepingcomputer_iocs_${article.id}.${format}`;

    if (format === "csv") {
      content = "Type,Indicator,Article Title,Article URL\n";
      allIndicators.forEach((item) => {
        content += `"${item.type}","${item.value}","${article.title.replace(/"/g, '""')}","${article.link}"\n`;
      });
    } else {
      const stixObj = {
        type: "bundle",
        id: `bundle--${article.id}`,
        spec_version: "2.1",
        description: `IOCs extracted from BleepingComputer article: ${article.title}`,
        source: article.link,
        published: article.pubDate,
        indicators: allIndicators
      };
      content = JSON.stringify(stixObj, null, 2);
    }

    const blob = new Blob([content], { type: format === "csv" ? "text/csv" : "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Send all IOCs from an article into the Bulk Scanner
  const handleSendToBulkScanner = (article: BleepingArticle) => {
    const list = [
      ...article.iocs.ips,
      ...article.iocs.domains,
      ...article.iocs.hashes,
      ...article.iocs.urls
    ].join("\n");

    if (onSendToBulk && list) {
      onSendToBulk(list);
    }
  };

  // Categories list
  const allCategories = useMemo(() => {
    const set = new Set<string>();
    articles.forEach((a) => {
      a.categories.forEach((c) => set.add(c));
    });
    return Array.from(set);
  }, [articles]);

  // Filtered articles
  const filteredArticles = useMemo(() => {
    let list = articles;

    if (hasIocsOnly) {
      list = list.filter((a) => a.totalIocs > 0 || a.hasIocSection);
    }

    if (selectedCategory !== "all") {
      list = list.filter((a) => a.categories.includes(selectedCategory));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((a) =>
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.iocs.cves.some((c) => c.toLowerCase().includes(q)) ||
        a.iocs.ips.some((ip) => ip.includes(q)) ||
        a.iocs.domains.some((d) => d.toLowerCase().includes(q)) ||
        a.iocs.hashes.some((h) => h.toLowerCase().includes(q)) ||
        a.iocs.files.some((f) => f.toLowerCase().includes(q))
      );
    }

    return list;
  }, [articles, hasIocsOnly, selectedCategory, searchQuery]);

  // Aggregate indicators metrics
  const totalStats = useMemo(() => {
    let cveCount = 0;
    let ipCount = 0;
    let domainCount = 0;
    let hashCount = 0;
    let fileCount = 0;
    let articlesWithIocs = 0;

    articles.forEach((a) => {
      if (a.totalIocs > 0) articlesWithIocs++;
      cveCount += a.iocs.cves.length;
      ipCount += a.iocs.ips.length;
      domainCount += a.iocs.domains.length;
      hashCount += a.iocs.hashes.length;
      fileCount += a.iocs.files.length;
    });

    return {
      cveCount,
      ipCount,
      domainCount,
      hashCount,
      fileCount,
      totalIocs: cveCount + ipCount + domainCount + hashCount + fileCount,
      articlesWithIocs
    };
  }, [articles]);

  return (
    <div className="space-y-6" id="bleepingcomputer-ioc-view">
      {/* Live Pipeline Overview Banner */}
      <div className="bg-slate-950/70 border border-slate-900 rounded p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              <h3 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase flex items-center gap-2">
                <Rss className="w-4 h-4 text-red-500" />
                BLEEPINGCOMPUTER RSS & AUTOMATED IOC EXTRACTION ENGINE
              </h3>
            </div>
            <p className="text-xs text-slate-400 font-mono max-w-3xl leading-relaxed">
              Ingests live threat intelligence articles from BleepingComputer, parses the full article HTML,
              isolates the &ldquo;Indicators of Compromise&rdquo; section, and automatically extracts actionable IPs,
              Domains, URLs, Hashes, Malicious Files, and CVEs for immediate SOC investigation.
            </p>
            <div className="flex flex-wrap items-center gap-2 mt-2.5 text-[10px] font-mono">
              <span className="text-slate-500">FEED ENDPOINT:</span>
              <a
                href="https://www.bleepingcomputer.com/feed/"
                target="_blank"
                rel="noreferrer"
                className="bg-slate-900 text-blue-400 border border-slate-800 px-2 py-0.5 rounded flex items-center gap-1 hover:underline"
              >
                https://www.bleepingcomputer.com/feed/
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              {cachedAt && (
                <span className="text-slate-500 flex items-center gap-1 ml-2">
                  <Clock className="w-3 h-3" />
                  Synced: {new Date(cachedAt).toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => fetchFeed(true)}
              disabled={refreshing || loading}
              className="flex items-center gap-2 bg-red-950 hover:bg-red-900 border border-red-800/80 text-red-300 hover:text-white px-3.5 py-2 rounded text-xs font-mono font-bold transition cursor-pointer disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
              {refreshing ? "REFRESHING FEED..." : "SYNC RECENT ARTICLES"}
            </button>
          </div>
        </div>

        {/* Visual Extraction Pipeline Sequence */}
        <div className="mt-5 pt-4 border-t border-slate-900/80 grid grid-cols-2 md:grid-cols-5 gap-2 text-[10px] font-mono">
          <div className="bg-slate-900/60 border border-slate-850 p-2 rounded">
            <span className="text-slate-500 block text-[9px]">STEP 1 // INGEST</span>
            <span className="text-slate-200 font-bold flex items-center gap-1 mt-0.5">
              <Rss className="w-3 h-3 text-red-500" /> RSS Stream Ingestion
            </span>
          </div>
          <div className="bg-slate-900/60 border border-slate-850 p-2 rounded">
            <span className="text-slate-500 block text-[9px]">STEP 2 // PARSE</span>
            <span className="text-slate-200 font-bold flex items-center gap-1 mt-0.5">
              <ExternalLink className="w-3 h-3 text-blue-400" /> Fetch Article URLs
            </span>
          </div>
          <div className="bg-slate-900/60 border border-slate-850 p-2 rounded">
            <span className="text-slate-500 block text-[9px]">STEP 3 // LOCATE</span>
            <span className="text-slate-200 font-bold flex items-center gap-1 mt-0.5">
              <Search className="w-3 h-3 text-amber-400" /> Find IOC Sections
            </span>
          </div>
          <div className="bg-slate-900/60 border border-slate-850 p-2 rounded">
            <span className="text-slate-500 block text-[9px]">STEP 4 // HARVEST</span>
            <span className="text-slate-200 font-bold flex items-center gap-1 mt-0.5">
              <Layers className="w-3 h-3 text-emerald-400" /> Extract 6 IOC Types
            </span>
          </div>
          <div className="bg-slate-900/60 border border-slate-850 p-2 rounded col-span-2 md:col-span-1">
            <span className="text-slate-500 block text-[9px]">STEP 5 // ENRICH</span>
            <span className="text-slate-200 font-bold flex items-center gap-1 mt-0.5">
              <Sparkles className="w-3 h-3 text-purple-400" /> Pivot & AI Analysis
            </span>
          </div>
        </div>

        {/* Aggregate KPI Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Articles Ingested</span>
            <span className="text-lg font-mono font-bold text-slate-100">{articles.length}</span>
          </div>
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Articles with IOCs</span>
            <span className="text-lg font-mono font-bold text-amber-400">{totalStats.articlesWithIocs}</span>
          </div>
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Extracted CVEs</span>
            <span className="text-lg font-mono font-bold text-red-400">{totalStats.cveCount}</span>
          </div>
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Harvested IPs</span>
            <span className="text-lg font-mono font-bold text-blue-400">{totalStats.ipCount}</span>
          </div>
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Unique Domains</span>
            <span className="text-lg font-mono font-bold text-emerald-400">{totalStats.domainCount}</span>
          </div>
          <div className="bg-slate-900/40 border border-slate-850/80 p-2.5 rounded">
            <span className="text-[9px] font-mono text-slate-500 uppercase block">Hashes & Files</span>
            <span className="text-lg font-mono font-bold text-purple-400">
              {totalStats.hashCount + totalStats.fileCount}
            </span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-950/60 border border-slate-900 rounded p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search articles by title, CVE (e.g. CVE-2026-), IP, domain, hash, or malware name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono pl-9 pr-3 py-2 rounded focus:outline-none focus:border-red-500 transition"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            onClick={() => setHasIocsOnly(!hasIocsOnly)}
            className={`px-3 py-2 rounded border transition cursor-pointer flex items-center gap-1.5 ${
              hasIocsOnly
                ? "bg-red-950 border-red-800 text-red-300 font-bold"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <Filter className="w-3 h-3" />
            WITH EXTRACTED IOCS ONLY ({totalStats.articlesWithIocs})
          </button>

          {allCategories.length > 0 && (
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono px-3 py-2 rounded focus:outline-none focus:border-red-500 cursor-pointer"
            >
              <option value="all">ALL CATEGORIES ({articles.length})</option>
              {allCategories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Loading & Error States */}
      {loading && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-12 text-center font-mono">
          <RotateCw className="w-8 h-8 text-red-500 animate-spin mx-auto mb-3" />
          <p className="text-sm text-slate-200 font-bold">INGESTING BLEEPINGCOMPUTER RSS FEED...</p>
          <p className="text-xs text-slate-500 mt-1">
            Fetching articles, resolving Indicators of Compromise sections, and parsing regex tokens.
          </p>
        </div>
      )}

      {error && (
        <div className="bg-red-950/30 border border-red-800 rounded p-4 flex items-start gap-3 text-xs font-mono">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-red-300 font-bold">Failed to load live BleepingComputer RSS stream</h4>
            <p className="text-slate-400 mt-1">{error}</p>
            <button
              onClick={() => fetchFeed(true)}
              className="mt-2 text-red-400 hover:text-red-300 underline cursor-pointer"
            >
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* Articles Feed Stream */}
      {!loading && !error && filteredArticles.length === 0 && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-8 text-center font-mono">
          <ShieldAlert className="w-6 h-6 text-slate-600 mx-auto mb-2" />
          <p className="text-sm text-slate-300 font-bold">No articles match the active filter criteria.</p>
          <p className="text-xs text-slate-500 mt-1">Try clearing your search query or enabling all articles.</p>
        </div>
      )}

      {!loading && !error && filteredArticles.length > 0 && (
        <div className="space-y-4">
          {filteredArticles.map((article) => {
            const isExpanded = expandedArticleId === article.id;
            const aiAnalysis = aiAnalysisMap[article.id];
            const isAiLoading = aiExtractingId === article.id;
            const aiError = aiErrorMap[article.id];

            return (
              <div
                key={article.id}
                className="bg-slate-950/60 border border-slate-900 hover:border-slate-800 rounded transition overflow-hidden"
              >
                {/* Article Header Card */}
                <div className="p-4 sm:p-5">
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                    <div className="space-y-2 flex-1 min-w-0">
                      {/* Meta Tags */}
                      <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono">
                        <span className="bg-blue-950/50 text-blue-400 border border-blue-900/60 px-2 py-0.5 rounded font-bold">
                          {article.creator}
                        </span>
                        <span className="text-slate-500 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />
                          {article.pubDate}
                        </span>
                        {article.categories.map((c, i) => (
                          <span
                            key={i}
                            className="bg-slate-900 text-slate-400 border border-slate-800 px-1.5 py-0.5 rounded"
                          >
                            {c}
                          </span>
                        ))}
                        {article.hasIocSection && (
                          <span className="bg-emerald-950/60 text-emerald-400 border border-emerald-800/80 px-2 py-0.5 rounded font-bold flex items-center gap-1">
                            <Check className="w-2.5 h-2.5" /> IOC SECTION FOUND
                          </span>
                        )}
                      </div>

                      {/* Title */}
                      <h4 className="text-sm sm:text-base font-mono font-bold text-slate-100 hover:text-red-400 transition leading-snug">
                        <a href={article.link} target="_blank" rel="noreferrer" className="flex items-center gap-1.5">
                          {article.title}
                          <ExternalLink className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        </a>
                      </h4>

                      {/* Summary */}
                      <p className="text-xs text-slate-400 font-sans leading-relaxed line-clamp-2">
                        {article.summary}
                      </p>

                      {/* Indicator Badges Breakdown */}
                      <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-[10px]">
                        <span className="text-slate-500">EXTRACTED IOCS:</span>
                        {article.totalIocs === 0 ? (
                          <span className="text-slate-600 italic">None identified in article text</span>
                        ) : (
                          <>
                            {article.iocs.cves.length > 0 && (
                              <span className="bg-red-950/80 text-red-300 border border-red-800/80 px-2 py-0.5 rounded font-bold">
                                {article.iocs.cves.length} CVE{article.iocs.cves.length > 1 ? "s" : ""}
                              </span>
                            )}
                            {article.iocs.ips.length > 0 && (
                              <span className="bg-blue-950/80 text-blue-300 border border-blue-800/80 px-2 py-0.5 rounded font-bold">
                                {article.iocs.ips.length} IP{article.iocs.ips.length > 1 ? "s" : ""}
                              </span>
                            )}
                            {article.iocs.domains.length > 0 && (
                              <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-800/80 px-2 py-0.5 rounded font-bold">
                                {article.iocs.domains.length} Domain{article.iocs.domains.length > 1 ? "s" : ""}
                              </span>
                            )}
                            {article.iocs.hashes.length > 0 && (
                              <span className="bg-purple-950/80 text-purple-300 border border-purple-800/80 px-2 py-0.5 rounded font-bold">
                                {article.iocs.hashes.length} Hash{article.iocs.hashes.length > 1 ? "es" : ""}
                              </span>
                            )}
                            {article.iocs.files.length > 0 && (
                              <span className="bg-amber-950/80 text-amber-300 border border-amber-800/80 px-2 py-0.5 rounded font-bold">
                                {article.iocs.files.length} File{article.iocs.files.length > 1 ? "s" : ""}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex lg:flex-col items-center lg:items-end gap-2 shrink-0 pt-2 lg:pt-0">
                      <button
                        onClick={() => setExpandedArticleId(isExpanded ? null : article.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-bold transition cursor-pointer ${
                          isExpanded
                            ? "bg-red-950 text-red-300 border border-red-800"
                            : "bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800"
                        }`}
                      >
                        {isExpanded ? (
                          <>
                            <ChevronUp className="w-3.5 h-3.5" /> HIDE DETAILS
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-3.5 h-3.5" />
                            VIEW IOCS & ANALYSIS ({article.totalIocs})
                          </>
                        )}
                      </button>

                      {article.totalIocs > 0 && onSendToBulk && (
                        <button
                          onClick={() => handleSendToBulkScanner(article)}
                          className="flex items-center gap-1 text-[10px] font-mono text-slate-400 hover:text-slate-200 transition cursor-pointer"
                          title="Forward all extracted indicators into the Bulk IOC Scanner"
                        >
                          <Send className="w-2.5 h-2.5 text-red-400" />
                          SEND TO BULK SCANNER
                        </button>
                      )}

                      {onNavigateToKql && (article.totalIocs > 0 || article.iocs.cves.length > 0) && (
                        <button
                          onClick={() =>
                            onNavigateToKql({
                              title: article.title,
                              cves: article.iocs.cves,
                              ips: article.iocs.ips,
                              domains: article.iocs.domains,
                              urls: article.iocs.urls,
                              hashes: article.iocs.hashes,
                              files: article.iocs.files
                            })
                          }
                          className="flex items-center gap-1 text-[10px] font-mono text-emerald-400 hover:text-emerald-300 font-bold transition cursor-pointer"
                          title="Generate Sentinel & Defender KQL hunt rules with these extracted indicators"
                        >
                          <FileCode className="w-2.5 h-2.5 text-emerald-400" />
                          HUNT IN KQL
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Drawer: All Extracted IOCs & Deep AI Analysis */}
                {isExpanded && (
                  <div className="border-t border-slate-900 bg-slate-950/90 p-5 space-y-6">
                    {/* Top Action Bar for this Article */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-900">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleRunAiExtraction(article)}
                          disabled={isAiLoading}
                          className="flex items-center gap-1.5 bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-200 px-3 py-1.5 rounded text-xs font-mono font-bold transition cursor-pointer disabled:opacity-50"
                        >
                          <Sparkles className={`w-3.5 h-3.5 ${isAiLoading ? "animate-spin" : ""}`} />
                          {isAiLoading ? "AI EXTRACTING CTI..." : "RUN GEMINI DEEP THREAT EXTRACTION"}
                        </button>

                        {onNavigateToKql && (
                          <button
                            onClick={() =>
                              onNavigateToKql({
                                title: article.title,
                                cves: article.iocs.cves,
                                ips: article.iocs.ips,
                                domains: article.iocs.domains,
                                urls: article.iocs.urls,
                                hashes: article.iocs.hashes,
                                files: article.iocs.files
                              })
                            }
                            className="flex items-center gap-1.5 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 px-3 py-1.5 rounded text-xs font-mono font-bold transition cursor-pointer"
                            title="Open in KQL Threat Hunt Generator with these indicators preloaded"
                          >
                            <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                            GENERATE KQL HUNT RULES
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span className="text-slate-500">EXPORT:</span>
                        <button
                          onClick={() => handleExportIocs(article, "csv")}
                          className="px-2.5 py-1 bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded flex items-center gap-1 transition cursor-pointer"
                        >
                          <Download className="w-3 h-3" /> CSV
                        </button>
                        <button
                          onClick={() => handleExportIocs(article, "json")}
                          className="px-2.5 py-1 bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded flex items-center gap-1 transition cursor-pointer"
                        >
                          <FileCode className="w-3 h-3" /> STIX 2.1 JSON
                        </button>
                      </div>
                    </div>

                    {/* AI CTI Analysis Result Section */}
                    {aiAnalysis && (
                      <div className="bg-purple-950/20 border border-purple-900/60 rounded p-4 space-y-3 font-mono">
                        <div className="flex items-center justify-between">
                          <h5 className="text-xs font-bold text-purple-300 flex items-center gap-1.5 uppercase">
                            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                            GEMINI AI THREAT INTELLIGENCE SUMMARY
                          </h5>
                          {aiAnalysis.threatLevel && (
                            <span
                              className={`text-[9px] px-2 py-0.5 rounded font-bold border ${
                                aiAnalysis.threatLevel === "Critical"
                                  ? "bg-red-950 text-red-400 border-red-800"
                                  : aiAnalysis.threatLevel === "High"
                                  ? "bg-orange-950 text-orange-400 border-orange-800"
                                  : "bg-blue-950 text-blue-400 border-blue-800"
                              }`}
                            >
                              SEVERITY: {aiAnalysis.threatLevel}
                            </span>
                          )}
                        </div>

                        {aiAnalysis.attackChainSummary && (
                          <p className="text-xs text-slate-300 font-sans leading-relaxed">
                            {aiAnalysis.attackChainSummary}
                          </p>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                          {aiAnalysis.threatActors && aiAnalysis.threatActors.length > 0 && (
                            <div className="bg-slate-950/80 p-2.5 rounded border border-purple-950">
                              <span className="text-[10px] text-purple-400 block mb-1 font-bold">
                                ATTRIBUTED THREAT ACTORS
                              </span>
                              <div className="flex flex-wrap gap-1">
                                {aiAnalysis.threatActors.map((actor: string, i: number) => (
                                  <span
                                    key={i}
                                    className="bg-purple-950/60 text-purple-200 border border-purple-800 px-1.5 py-0.5 rounded text-[10px]"
                                  >
                                    {actor}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {aiAnalysis.malwareFamilies && aiAnalysis.malwareFamilies.length > 0 && (
                            <div className="bg-slate-950/80 p-2.5 rounded border border-purple-950">
                              <span className="text-[10px] text-purple-400 block mb-1 font-bold">
                                MALWARE FAMILIES / VARIANTS
                              </span>
                              <div className="flex flex-wrap gap-1">
                                {aiAnalysis.malwareFamilies.map((mal: string, i: number) => (
                                  <span
                                    key={i}
                                    className="bg-red-950/60 text-red-200 border border-red-800 px-1.5 py-0.5 rounded text-[10px]"
                                  >
                                    {mal}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        {aiAnalysis.socRemediationSteps && aiAnalysis.socRemediationSteps.length > 0 && (
                          <div className="bg-slate-950/80 p-2.5 rounded border border-purple-950">
                            <span className="text-[10px] text-purple-400 block mb-1 font-bold">
                              RECOMMENDED SOC CONTAINMENT ACTIONS
                            </span>
                            <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300 font-sans">
                              {aiAnalysis.socRemediationSteps.map((step: string, i: number) => (
                                <li key={i}>{step}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}

                    {aiError && (
                      <div className="bg-red-950/20 border border-red-800/60 p-3 rounded text-xs font-mono text-red-400 flex items-center gap-2">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        AI Extraction Notice: {aiError}
                      </div>
                    )}

                    {/* Granular IOC Tables */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {/* CVEs Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-red-400 flex items-center gap-1.5 uppercase">
                            <ShieldAlert className="w-3.5 h-3.5" /> CVE IDENTIFIERS ({article.iocs.cves.length})
                          </span>
                        </div>
                        {article.iocs.cves.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No CVEs mentioned</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.cves.map((cve, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-red-400 font-bold">{cve}</span>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleCopy(cve)}
                                    className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                    title="Copy CVE"
                                  >
                                    {copiedValue === cve ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                  <a
                                    href={`https://nvd.nist.gov/vuln/detail/${cve}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="p-1 hover:text-white text-slate-500"
                                    title="View on NIST NVD"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* IP Addresses Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-blue-400 flex items-center gap-1.5 uppercase">
                            <Server className="w-3.5 h-3.5" /> IP ADDRESSES ({article.iocs.ips.length})
                          </span>
                        </div>
                        {article.iocs.ips.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No external IPs extracted</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.ips.map((ip, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-blue-300 font-semibold">{ip}</span>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleCopy(ip)}
                                    className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                    title="Copy IP"
                                  >
                                    {copiedValue === ip ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                  {onPivotToIp && (
                                    <button
                                      onClick={() => onPivotToIp(ip)}
                                      className="px-1.5 py-0.5 bg-blue-950 text-blue-400 hover:text-blue-200 border border-blue-900 rounded text-[9px] font-bold cursor-pointer"
                                    >
                                      PIVOT
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Domains Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5 uppercase">
                            <Globe className="w-3.5 h-3.5" /> DOMAINS & HOSTS ({article.iocs.domains.length})
                          </span>
                        </div>
                        {article.iocs.domains.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No domains extracted</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.domains.map((domain, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-emerald-300 font-semibold truncate max-w-[150px]">
                                  {domain}
                                </span>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleCopy(domain)}
                                    className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                    title="Copy Domain"
                                  >
                                    {copiedValue === domain ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                  {onPivotToDomain && (
                                    <button
                                      onClick={() => onPivotToDomain(domain)}
                                      className="px-1.5 py-0.5 bg-emerald-950 text-emerald-400 hover:text-emerald-200 border border-emerald-900 rounded text-[9px] font-bold cursor-pointer"
                                    >
                                      PIVOT
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Hashes Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-purple-400 flex items-center gap-1.5 uppercase">
                            <Hash className="w-3.5 h-3.5" /> MALWARE HASHES ({article.iocs.hashes.length})
                          </span>
                        </div>
                        {article.iocs.hashes.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No hashes extracted</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.hashes.map((hashVal, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-purple-300 truncate max-w-[140px] font-mono text-[11px]">
                                  {hashVal}
                                </span>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleCopy(hashVal)}
                                    className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                    title="Copy Hash"
                                  >
                                    {copiedValue === hashVal ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                  {onPivotToHash && (
                                    <button
                                      onClick={() => onPivotToHash(hashVal)}
                                      className="px-1.5 py-0.5 bg-purple-950 text-purple-400 hover:text-purple-200 border border-purple-900 rounded text-[9px] font-bold cursor-pointer"
                                    >
                                      PIVOT
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Malicious Files Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-amber-400 flex items-center gap-1.5 uppercase">
                            <FileCode className="w-3.5 h-3.5" /> PAYLOAD FILES ({article.iocs.files.length})
                          </span>
                        </div>
                        {article.iocs.files.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No payload files found</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.files.map((file, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-amber-300 truncate max-w-[170px]">{file}</span>
                                <button
                                  onClick={() => handleCopy(file)}
                                  className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                  title="Copy File Name"
                                >
                                  {copiedValue === file ? (
                                    <Check className="w-3 h-3 text-emerald-400" />
                                  ) : (
                                    <Copy className="w-3 h-3" />
                                  )}
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* URLs Section */}
                      <div className="bg-slate-900/40 border border-slate-850 p-3.5 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5 uppercase">
                            <LinkIcon className="w-3.5 h-3.5" /> REFERENCED URLS ({article.iocs.urls.length})
                          </span>
                        </div>
                        {article.iocs.urls.length === 0 ? (
                          <p className="text-[11px] font-mono text-slate-600">No external URLs extracted</p>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {article.iocs.urls.map((urlVal, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 border border-slate-850 rounded text-xs font-mono"
                              >
                                <span className="text-cyan-300 truncate max-w-[150px]">{urlVal}</span>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleCopy(urlVal)}
                                    className="p-1 hover:text-white text-slate-500 cursor-pointer"
                                    title="Copy URL"
                                  >
                                    {copiedValue === urlVal ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                  {onPivotToUrl && (
                                    <button
                                      onClick={() => onPivotToUrl(urlVal)}
                                      className="px-1.5 py-0.5 bg-cyan-950 text-cyan-400 hover:text-cyan-200 border border-cyan-900 rounded text-[9px] font-bold cursor-pointer"
                                    >
                                      PIVOT
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
