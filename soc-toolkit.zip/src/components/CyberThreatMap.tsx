/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import {
  Globe,
  Shield,
  ShieldCheck,
  ShieldAlert,
  ExternalLink,
  Maximize2,
  Minimize2,
  RotateCcw,
  Lock,
  CheckCircle2,
  Copy,
  Check,
  FileCode,
  Layers,
  Cpu,
  Radio,
  Server,
  Info,
  ChevronRight
} from "lucide-react";
import { ActiveTab } from "../types";

interface CyberThreatMapProps {
  onNavigate?: (tab: ActiveTab) => void;
  onNavigateToKql?: (context: any) => void;
}

type MapMode = "kaspersky" | "offline-simulation" | "sentinel-integrity";

export default function CyberThreatMap({ onNavigate, onNavigateToKql }: CyberThreatMapProps) {
  const [mapMode, setMapMode] = useState<MapMode>("kaspersky");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [iframeKey, setIframeKey] = useState(Date.now());
  const [copiedKql, setCopiedKql] = useState(false);
  const [copiedTaxii, setCopiedTaxii] = useState(false);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [iframeError, setIframeError] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Reload iframe
  const handleReload = () => {
    setIframeLoaded(false);
    setIframeError(false);
    setIframeKey(Date.now());
  };

  // Canvas offline attack vector simulation
  useEffect(() => {
    if (mapMode !== "offline-simulation") return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 600);
    let height = (canvas.height = isFullscreen ? 620 : 380);

    interface Beam {
      srcIndex: number;
      destIndex: number;
      progress: number;
      speed: number;
      color: string;
      label: string;
    }

    let beams: Beam[] = [];

    const nodes = [
      { px: 0.15, py: 0.35, label: "Seattle SOC" },
      { px: 0.25, py: 0.45, label: "Austin Node" },
      { px: 0.30, py: 0.35, label: "New York Hub" },
      { px: 0.48, py: 0.32, label: "London Gateway" },
      { px: 0.54, py: 0.40, label: "Frankfurt DC" },
      { px: 0.78, py: 0.55, label: "Singapore POP" },
      { px: 0.85, py: 0.38, label: "Tokyo Center" },
      { px: 0.88, py: 0.65, label: "Sydney Sensor" }
    ];

    const generateBeam = () => {
      const srcIndex = Math.floor(Math.random() * nodes.length);
      let destIndex = Math.floor(Math.random() * nodes.length);
      while (destIndex === srcIndex) {
        destIndex = Math.floor(Math.random() * nodes.length);
      }

      const threatTypes = [
        { label: "OAS: Trojan.Win32", color: "#ef4444" },
        { label: "WAV: Exploit.JS.Agent", color: "#f97316" },
        { label: "IDS: Scan.Generic.Port", color: "#eab308" },
        { label: "BAD: Mirai.Botnet.C2", color: "#ec4899" },
        { label: "KAS: Phish.Credential", color: "#06b6d4" },
        { label: "MAV: Ransom.LockBit.Zip", color: "#dc2626" }
      ];
      const threat = threatTypes[Math.floor(Math.random() * threatTypes.length)];

      beams.push({
        srcIndex,
        destIndex,
        progress: 0,
        speed: 0.006 + Math.random() * 0.008,
        color: threat.color,
        label: threat.label
      });
    };

    for (let i = 0; i < 6; i++) {
      generateBeam();
    }

    const drawMap = () => {
      ctx.fillStyle = "rgba(2, 6, 23, 0.28)";
      ctx.fillRect(0, 0, width, height);

      // Grid line mesh
      ctx.strokeStyle = "rgba(30, 41, 59, 0.3)";
      ctx.lineWidth = 0.5;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw base nodes
      nodes.forEach((node) => {
        const nx = node.px * width;
        const ny = node.py * height;

        ctx.beginPath();
        ctx.arc(nx, ny, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(148, 163, 184, 0.4)";
        ctx.fill();

        ctx.fillStyle = "rgba(100, 116, 139, 0.7)";
        ctx.font = "8px monospace";
        ctx.fillText(node.label, nx + 6, ny + 3);
      });

      // Draw threat vectors (beams)
      beams.forEach((beam, index) => {
        beam.progress += beam.speed;

        const srcNode = nodes[beam.srcIndex];
        const destNode = nodes[beam.destIndex];

        const sx = srcNode.px * width;
        const sy = srcNode.py * height;
        const ex = destNode.px * width;
        const ey = destNode.py * height;

        const currentX = sx + (ex - sx) * beam.progress;
        const arcHeight = -45 * Math.sin(Math.PI * beam.progress);
        const currentY = sy + (ey - sy) * beam.progress + arcHeight;

        // Path arc
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        const cx = (sx + ex) / 2;
        const cy = (sy + ey) / 2 - 45;
        ctx.quadraticCurveTo(cx, cy, ex, ey);
        ctx.strokeStyle = `${beam.color}15`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Animated head trail
        ctx.beginPath();
        ctx.arc(currentX, currentY, 2.8, 0, Math.PI * 2);
        ctx.fillStyle = beam.color;
        ctx.shadowColor = beam.color;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;

        if (beam.progress > 0.3 && beam.progress < 0.7) {
          ctx.fillStyle = "rgba(226, 232, 240, 0.85)";
          ctx.font = "7px inline-block monospace";
          ctx.fillText(beam.label, currentX - 20, currentY - 8);
        }

        if (beam.progress >= 1) {
          ctx.beginPath();
          ctx.arc(ex, ey, 8, 0, Math.PI * 2);
          ctx.strokeStyle = `${beam.color}cc`;
          ctx.lineWidth = 1;
          ctx.stroke();

          beams.splice(index, 1);
          generateBeam();
        }
      });

      animationId = requestAnimationFrame(drawMap);
    };

    drawMap();

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = isFullscreen ? 620 : 380;
      drawMap();
    };

    window.addEventListener("resize", handleResize);
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, [mapMode, isFullscreen]);

  const sentinelKqlQuery = `// Microsoft Sentinel & Defender XDR: Real-Time Threat Intelligence Correlation Hunt
// Correlates incoming OSINT Indicators (IPs, Domains, Hashes) with Enterprise Telemetry
let LookbackTime = 3d;
let HighConfidenceTI = ThreatIntelligenceIndicator
| where TimeGenerated >= ago(LookbackTime)
| where isnotempty(NetworkIP) or isnotempty(DomainName) or isnotempty(FileHashValue)
| summarize LatestReport = arg_max(TimeGenerated, *) by IndicatorId;
// Vector 1: Endpoint Process Execution (Defender for Endpoint)
let ProcessHunt = DeviceProcessEvents
| where TimeGenerated >= ago(LookbackTime)
| join kind=inner (
    HighConfidenceTI
    | where isnotempty(FileHashValue)
    | project FileHashValue, ThreatType, Description, ConfidenceScore
) on $left.SHA256 == $right.FileHashValue
| project TimeGenerated, DeviceName, AccountName, FileName, FolderPath, ProcessCommandLine, ThreatType, Description, ConfidenceScore;
// Vector 2: Firewall & Proxy Traffic Ingestion (Sentinel CommonSecurityLog / Zscaler / Palo Alto)
let NetworkHunt = CommonSecurityLog
| where TimeGenerated >= ago(LookbackTime)
| join kind=inner (
    HighConfidenceTI
    | where isnotempty(NetworkIP)
    | project NetworkIP, ThreatType, Description
) on $left.DestinationIP == $right.NetworkIP
| project TimeGenerated, DeviceVendor, SourceIP, DestinationIP, DestinationPort, ThreatType, Activity;
// Vector 3: DNS Query Anomalies (DnsEvents / Sysmon Event 22)
let DnsHunt = DnsEvents
| where TimeGenerated >= ago(LookbackTime)
| join kind=inner (
    HighConfidenceTI
    | where isnotempty(DomainName)
    | project DomainName, ThreatType, Description
) on $left.Name == $right.DomainName
| project TimeGenerated, ClientIP, Name, ThreatType, Description;
union ProcessHunt, NetworkHunt, DnsHunt
| sort by TimeGenerated desc`;

  const taxiiJsonPayload = `{
  "type": "indicator",
  "spec_version": "2.1",
  "id": "indicator--8e2e2d2b-17d4-4cbf-938f-98ced22417b6",
  "created": "2026-09-06T00:00:00.000Z",
  "modified": "2026-09-06T00:00:00.000Z",
  "name": "OSINT-Enriched Threat Campaign Indicator",
  "description": "Ingested via SOC Analyst Toolkit with SHA-256 integrity validation",
  "indicator_types": ["malicious-activity", "compromised-infrastructure"],
  "pattern": "[ipv4-addr:value = '185.112.146.22' OR domain-name:value = 'update.micro-verify.net']",
  "pattern_type": "stix",
  "valid_from": "2026-09-06T00:00:00.000Z",
  "confidence": 85,
  "labels": ["osint", "cisa-kev", "kaspersky-ksn", "sentinel-ready"]
}`;

  const copyToClipboard = (text: string, type: "kql" | "taxii") => {
    navigator.clipboard.writeText(text);
    if (type === "kql") {
      setCopiedKql(true);
      setTimeout(() => setCopiedKql(false), 2200);
    } else {
      setCopiedTaxii(true);
      setTimeout(() => setCopiedTaxii(false), 2200);
    }
  };

  return (
    <div
      id="cyber-threat-map-container"
      className={`bg-slate-950/70 backdrop-blur-md border border-slate-900 rounded-lg flex flex-col transition-all duration-300 ${
        isFullscreen
          ? "fixed inset-3 z-50 shadow-2xl bg-slate-1000 border-red-900/60 p-5 overflow-y-auto"
          : "p-4 space-y-3"
      }`}
    >
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-900">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-red-950/60 border border-red-800/80 rounded">
            <Globe className="w-4 h-4 text-red-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">
                GLOBAL CYBERTHREAT REAL-TIME MAP
              </h2>
              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2 py-0.5 rounded flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SOURCE: KASPERSKY (KSN)
              </span>
            </div>
            <p className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5 mt-0.5">
              <span>Telemetry: Kaspersky Security Network Global Threat Feed</span>
              <span className="text-slate-600">•</span>
              <a
                href="https://cybermap.kaspersky.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-400 hover:text-red-300 underline inline-flex items-center gap-0.5"
                title="Open official Kaspersky Cybermap portal in new window"
              >
                cybermap.kaspersky.com <ExternalLink className="w-2.5 h-2.5 ml-0.5" />
              </a>
            </p>
          </div>
        </div>

        {/* View Switchers & Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="bg-slate-900 border border-slate-800 p-0.5 rounded flex items-center text-[10px] font-mono">
            <button
              onClick={() => setMapMode("kaspersky")}
              className={`px-2.5 py-1 rounded font-bold transition flex items-center gap-1 cursor-pointer ${
                mapMode === "kaspersky"
                  ? "bg-red-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="Interactive 3D real-time cyber attacks from Kaspersky Security Network"
            >
              <Radio className="w-3 h-3" />
              KASPERSKY LIVE
            </button>
            <button
              onClick={() => setMapMode("offline-simulation")}
              className={`px-2.5 py-1 rounded font-bold transition flex items-center gap-1 cursor-pointer ${
                mapMode === "offline-simulation"
                  ? "bg-red-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="Air-gapped zero-egress local canvas simulation (no external network calls)"
            >
              <Cpu className="w-3 h-3" />
              LOCAL / AIR-GAPPED
            </button>
            <button
              onClick={() => setMapMode("sentinel-integrity")}
              className={`px-2.5 py-1 rounded font-bold transition flex items-center gap-1 cursor-pointer ${
                mapMode === "sentinel-integrity"
                  ? "bg-emerald-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="OSINT Data Integrity, Sandboxing Security, and Microsoft Sentinel Integration"
            >
              <ShieldCheck className="w-3 h-3" />
              SENTINEL & INTEGRITY
            </button>
          </div>

          {mapMode === "kaspersky" && (
            <button
              onClick={handleReload}
              className="p-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white rounded transition cursor-pointer"
              title="Reload live map stream"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}

          <a
            href="https://cybermap.kaspersky.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white rounded transition cursor-pointer"
            title="Open official Kaspersky Cybermap portal in dedicated window"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white rounded transition cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Expand Fullscreen"}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Mode 1: Kaspersky Live Stream */}
      {mapMode === "kaspersky" && (
        <div className="space-y-2.5">
          <div
            className={`relative bg-slate-1000 border border-slate-900 rounded overflow-hidden transition-all ${
              isFullscreen ? "h-[580px]" : "h-[390px] sm:h-[430px]"
            }`}
          >
            {/* Loading state indicator */}
            {!iframeLoaded && !iframeError && (
              <div className="absolute inset-0 bg-slate-1000 flex flex-col items-center justify-center gap-3 z-10">
                <div className="relative">
                  <Globe className="w-10 h-10 text-red-500 animate-spin-slow opacity-80" />
                  <div className="absolute inset-0 rounded-full border-2 border-red-500/40 border-t-red-500 animate-spin"></div>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                    CONNECTING TO KASPERSKY CYBERMAP TELEMETRY...
                  </p>
                  <p className="text-[10px] font-mono text-slate-500">
                    Loading interactive WebGL threat visualizer from cybermap.kaspersky.com
                  </p>
                </div>
              </div>
            )}

            {/* Embedded Kaspersky Widget with strict sandbox isolation */}
            <iframe
              key={iframeKey}
              src="https://cybermap.kaspersky.com/en/widget/dynamic/dark"
              title="Kaspersky Cyberthreat Real-Time Map"
              width="100%"
              height="100%"
              className="w-full h-full border-0 bg-slate-1000"
              sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
              referrerPolicy="no-referrer"
              loading="lazy"
              onLoad={() => setIframeLoaded(true)}
              onError={() => {
                setIframeLoaded(true);
                setIframeError(true);
              }}
            />

            {/* In-frame security badge overlay */}
            <div className="absolute top-2.5 left-2.5 z-20 flex items-center gap-1.5 bg-slate-950/85 backdrop-blur-md border border-slate-800 px-2 py-1 rounded text-[9px] font-mono text-slate-300 pointer-events-none">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>SANDBOXED IFRAME • ZERO CREDENTIAL EGRESS</span>
            </div>

            {/* Attribution overlay */}
            <div className="absolute bottom-2.5 right-2.5 z-20 hidden sm:flex items-center gap-1.5 bg-slate-950/90 backdrop-blur-md border border-slate-850 px-2.5 py-1 rounded text-[9px] font-mono text-slate-400">
              <span>Source:</span>
              <a
                href="https://cybermap.kaspersky.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-400 hover:text-red-300 font-bold underline flex items-center gap-1"
              >
                Kaspersky Security Network (KSN)
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </div>

          {/* Fallback Banner if network restrictions apply */}
          {iframeError && (
            <div className="p-3 bg-red-955/60 border border-red-800 rounded flex items-start gap-2.5 text-xs font-mono text-red-200">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">Kaspersky Cybermap External Frame Blocked by Network Policy or CSP</p>
                <p className="text-[11px] text-red-300">
                  Some corporate proxies, firewalls, or strict ad-blockers restrict external Russian/Kaspersky domains.
                  You can click below to switch to the <strong>Local Air-Gapped Simulation</strong> or open the map directly in a new tab.
                </p>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => setMapMode("offline-simulation")}
                    className="px-2.5 py-1 bg-red-900/80 hover:bg-red-800 text-white rounded text-[10px] font-bold"
                  >
                    Switch to Local Simulation
                  </button>
                  <a
                    href="https://cybermap.kaspersky.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded text-[10px] font-bold"
                  >
                    Open cybermap.kaspersky.com in New Tab
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* Telemetry Legend & Threat Subsystems */}
          <div className="bg-slate-950 border border-slate-900 p-2.5 rounded-lg flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono">
            <div className="flex items-center gap-1.5 text-slate-400 font-bold">
              <Info className="w-3.5 h-3.5 text-red-400" />
              <span>KSN DETECTION SUBSYSTEMS:</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="On-Access Scan: Real-time malware protection">
                <strong className="text-red-400">OAS:</strong> File System
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="On-Demand Scan: Manual/scheduled scans">
                <strong className="text-orange-400">ODS:</strong> On-Demand
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Mail Anti-Virus: Inbound & outbound email threats">
                <strong className="text-amber-400">MAV:</strong> Mail Filter
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Web Anti-Virus: Malicious URLs, drive-by scripts">
                <strong className="text-emerald-400">WAV:</strong> Web Threats
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Intrusion Detection System / Network Attack Blocker">
                <strong className="text-cyan-400">IDS:</strong> Network Attacks
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Botnet Activity Detection: Zombie nodes & C2 communication">
                <strong className="text-pink-400">BAD:</strong> Botnets
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Vulnerability Scan: Known unpatched CVEs">
                <strong className="text-purple-400">VUL:</strong> Vulnerabilities
              </span>
              <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300" title="Kaspersky Anti-Spam: Phishing & junk mail campaigns">
                <strong className="text-blue-400">KAS:</strong> Anti-Spam
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main Mode 2: Air-gapped / Local Canvas Attack Vector Simulation */}
      {mapMode === "offline-simulation" && (
        <div className="space-y-2.5">
          <div
            className={`relative bg-slate-1000 border border-slate-900 rounded overflow-hidden ${
              isFullscreen ? "h-[580px]" : "h-[390px] sm:h-[430px]"
            }`}
          >
            <canvas ref={canvasRef} className="block w-full h-full" />
            <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 bg-slate-950/85 backdrop-blur-md border border-slate-800 px-2 py-1 rounded text-[9px] font-mono text-emerald-400 font-bold">
              <ShieldCheck className="w-3 h-3" />
              AIR-GAPPED COMPLIANCE MODE • ZERO EXTERNAL NETWORK CALLS
            </div>
            <div className="absolute bottom-2 left-2 flex gap-1.5 flex-wrap max-w-sm">
              <span className="text-[8px] bg-slate-950/90 text-slate-300 border border-slate-850 px-1.5 py-0.5 rounded font-mono">
                RED: High Risk Command Target
              </span>
              <span className="text-[8px] bg-slate-950/90 text-slate-300 border border-slate-850 px-1.5 py-0.5 rounded font-mono">
                ORANGE: Infiltration scan
              </span>
              <span className="text-[8px] bg-slate-950/90 text-slate-300 border border-slate-850 px-1.5 py-0.5 rounded font-mono">
                CYAN: Phishing & Credential Theft
              </span>
            </div>
          </div>
          <p className="text-[10px] font-mono text-slate-500">
            Air-Gapped Simulation mode renders vector arcs client-side using pure HTML5 Canvas. No third-party network egress or external DNS resolution occurs. Ideal for defense contractors, SCADA/ICS networks, and classified SOC environments.
          </p>
        </div>
      )}

      {/* Main Mode 3: OSINT Data Integrity & Microsoft Sentinel Integration */}
      {mapMode === "sentinel-integrity" && (
        <div className="space-y-4 py-1">
          {/* OSINT Integrity & Sandboxing Posture Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-emerald-400 font-mono text-xs font-bold">
                <Lock className="w-4 h-4 text-emerald-400" />
                Iframe Sandboxing & Isolation
              </div>
              <p className="text-[10px] font-mono text-slate-400 leading-relaxed">
                The Kaspersky live widget runs with strict HTML5 <code>sandbox="allow-scripts allow-same-origin allow-popups allow-forms"</code> and <code>referrerPolicy="no-referrer"</code>. No cookies, auth tokens, internal SOC logs, or private API keys can be accessed or exfiltrated.
              </p>
              <div className="flex items-center gap-1 text-[9px] font-mono text-emerald-400 font-bold pt-1">
                <CheckCircle2 className="w-3 h-3" /> Zero Token / Secret Egress
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-blue-400 font-mono text-xs font-bold">
                <Shield className="w-4 h-4 text-blue-400" />
                OSINT Integrity & Anti-Poisoning
              </div>
              <p className="text-[10px] font-mono text-slate-400 leading-relaxed">
                External threat data from OSINT sources (CISA KEV, AbuseIPDB, URLhaus, Kaspersky KSN) is normalized, validated against RFC 1918 private subnets, and tagged with source provenance before ingestion into local storage or analytics.
              </p>
              <div className="flex items-center gap-1 text-[9px] font-mono text-blue-400 font-bold pt-1">
                <CheckCircle2 className="w-3 h-3" /> RFC 1918 Private IP Filtering
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-purple-400 font-mono text-xs font-bold">
                <Server className="w-4 h-4 text-purple-400" />
                Microsoft Sentinel Ready
              </div>
              <p className="text-[10px] font-mono text-slate-400 leading-relaxed">
                Seamlessly bridges OSINT threat indicators into Microsoft Sentinel via STIX/TAXII 2.1 or Microsoft Graph Security Threat Intelligence API (<code>/security/tiIndicators</code>) for automated correlation against MDE and firewall logs.
              </p>
              <div className="flex items-center gap-1 text-[9px] font-mono text-purple-400 font-bold pt-1">
                <CheckCircle2 className="w-3 h-3" /> STIX 2.1 & Graph API Schema
              </div>
            </div>
          </div>

          {/* Microsoft Sentinel KQL Correlation Hunt */}
          <div className="bg-slate-950 border border-slate-900 rounded-lg p-3.5 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-mono font-bold text-slate-100">
                  MICROSOFT SENTINEL MULTI-VECTOR THREAT HUNT (KQL)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(sentinelKqlQuery, "kql")}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded text-[10px] font-mono font-bold transition cursor-pointer"
                >
                  {copiedKql ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedKql ? "COPIED KQL!" : "COPY KQL"}
                </button>
                {onNavigate && (
                  <button
                    onClick={() => {
                      if (onNavigateToKql) {
                        onNavigateToKql({
                          title: "Kaspersky & OSINT Global Threat Correlation Hunt",
                          cves: ["CVE-2024-3400", "CVE-2023-46805"],
                          ips: ["185.112.146.22", "45.192.12.8"],
                          domains: ["update.micro-verify.net"],
                          hashes: ["e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"]
                        });
                      } else {
                        onNavigate(ActiveTab.KqlPlayground);
                      }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 rounded text-[10px] font-mono font-bold transition cursor-pointer"
                  >
                    OPEN IN KQL GENERATOR <ChevronRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            <p className="text-[10px] font-mono text-slate-400">
              This KQL correlation hunts across Defender for Endpoint (<code>DeviceProcessEvents</code>), Sentinel Firewall/Proxy (<code>CommonSecurityLog</code>), and DNS (<code>DnsEvents</code>) against active high-confidence threat indicators.
            </p>

            <pre className="bg-slate-1000 border border-slate-900 p-3 rounded text-[10px] font-mono text-slate-300 overflow-x-auto max-h-[160px] scrollbar-thin">
              {sentinelKqlQuery}
            </pre>
          </div>

          {/* STIX 2.1 / Microsoft Sentinel Ingestion Format */}
          <div className="bg-slate-950 border border-slate-900 rounded-lg p-3.5 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-mono font-bold text-slate-100">
                  SENTINEL THREAT INTELLIGENCE INGESTION PAYLOAD (STIX 2.1 / GRAPH API)
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(taxiiJsonPayload, "taxii")}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded text-[10px] font-mono font-bold transition cursor-pointer"
              >
                {copiedTaxii ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedTaxii ? "COPIED JSON!" : "COPY PAYLOAD"}
              </button>
            </div>

            <p className="text-[10px] font-mono text-slate-400">
              Format for pushing OSINT findings into Microsoft Sentinel via the Threat Intelligence Platforms (TAXII) data connector or Microsoft Graph Security API (<code>POST https://graph.microsoft.com/v1.0/security/tiIndicators</code>).
            </p>

            <pre className="bg-slate-1000 border border-slate-900 p-3 rounded text-[10px] font-mono text-purple-300/90 overflow-x-auto max-h-[140px] scrollbar-thin">
              {taxiiJsonPayload}
            </pre>
          </div>

          {/* Sentinel Enterprise Deployment Security Checklist */}
          <div className="bg-slate-950 border border-slate-900 rounded-lg p-3.5 space-y-2.5">
            <h4 className="text-xs font-mono font-bold text-slate-200 uppercase flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              DEPLOYMENT & SENTINEL INTEGRATION SECURITY CHECKLIST
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] font-mono">
              <div className="flex items-start gap-2 p-2 bg-slate-1000 border border-slate-900 rounded">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-200 block">Strict Content Security Policy (CSP)</strong>
                  <span className="text-slate-500">Iframe frame-ancestors and connect-src restricted to authorized domains.</span>
                </div>
              </div>
              <div className="flex items-start gap-2 p-2 bg-slate-1000 border border-slate-900 rounded">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-200 block">Entra ID (Azure AD) RBAC Gate</strong>
                  <span className="text-slate-500">Enforce Least-Privilege Analyst / Responder roles before indicator deployment.</span>
                </div>
              </div>
              <div className="flex items-start gap-2 p-2 bg-slate-1000 border border-slate-900 rounded">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-200 block">Managed Identity for Azure Key Vault</strong>
                  <span className="text-slate-500">No raw API secrets or Sentinel Workspace Keys stored in client code.</span>
                </div>
              </div>
              <div className="flex items-start gap-2 p-2 bg-slate-1000 border border-slate-900 rounded">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-200 block">Threat Intel Deduplication & TTL</strong>
                  <span className="text-slate-500">Auto-expire ephemeral OSINT indicators after 30 days to prevent rule fatigue.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
