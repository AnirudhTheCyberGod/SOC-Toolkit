/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { SearchLog, ApiStatus, ActiveTab } from "../types";
import CyberThreatMap from "./CyberThreatMap";
import {
  ShieldAlert,
  HelpCircle,
  Clock,
  Terminal,
  Activity,
  Globe,
  Database,
  Wifi,
  Skull,
  TrendingUp,
  ExternalLink,
  Search,
  Compass,
  Cpu,
  Layers,
  ArrowRight
} from "lucide-react";

interface DashboardProps {
  searchLogs: SearchLog[];
  onSelectQuery: (type: "IP" | "Domain" | "URL" | "Hash" | "Malware", value: string) => void;
  apiStatus: ApiStatus[];
  onNavigate: (tab: ActiveTab) => void;
  onNavigateToKql?: (context: any) => void;
}

// Registry of all tools/options inside the Security Suite for search/navigation indexing
const TOOLS_REGISTRY = [
  {
    tab: ActiveTab.IPInvest,
    name: "IP Forensic Investigator",
    description: "Geolocate IP blocks, evaluate autonomous networks (ASN), check abuse reporting history.",
    keywords: ["ip", "ip address", "reputation", "geolocate", "enrich", "abuseipdb", "whois", "network"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.DomainInvest,
    name: "Domain Reputation & DGA Analyzer",
    description: "Evaluate active domains, fetch registry expiration maps, analyze lexical entropy and DGA models.",
    keywords: ["domain", "whois", "dga", "dns", "url", "entropy", "subdomain"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.URLAnalysis,
    name: "URL Link Forensic Analyzer",
    description: "Deep-dissect suspicious emails, url routing hops, nested query params and unshorten triggers safely.",
    keywords: ["url", "link", "redirect", "unshorten", "query", "phishing link"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.UrlScreenshot,
    name: "URL Sandbox Screenshot",
    description: "Render automated safe visuals from suspicious websites via backend sandbox engines securely.",
    keywords: ["screenshot", "browser", "capture", "viewport", "preview", "render", "url"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.HashAnalysis,
    name: "File Hash Database",
    description: "Cross-examine malware MD5, SHA-1 and SHA-256 signatures across unified VirusTotal databases.",
    keywords: ["hash", "md5", "sha256", "sha1", "virustotal", "signature", "ioc"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.FileAnalysis,
    name: "File Core Sandbox",
    description: "Upload payloads statically to inspect macro streams, entropy levels and architectural PE markers.",
    keywords: ["file", "upload", "analyzer", "pdf", "docx", "exe", "payload", "static analysis"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.HeaderAnalysis,
    name: "Email Header Analyzer",
    description: "Parse raw EML metrics, decrypt SPF/DKIM authentication strings, map transit hops.",
    keywords: ["email", "header", "dkim", "spf", "dmarc", "hops", "relay", "msg", "eml"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.MalwareAnalysis,
    name: "Malware Dynamic Emulator",
    description: "Simulate malware execution loops, unpack internal PE strings, audit runtime Win32 API calls.",
    keywords: ["malware", "sandbox", "emulator", "unpack", "process", "dyn", "strings"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.Whois,
    name: "Active WHOIS Terminal",
    description: "Open an online virtual terminal to query active DNS, CNAME, TXT and MX records.",
    keywords: ["whois", "terminal", "nslookup", "dns query", "cname", "txt", "mx"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.KqlPlayground,
    name: "KQL Threat Hunt Generator (TI Feed Integrated)",
    description: "Generate Sentinel & Defender hunting queries dynamically from CISA KEV CVEs, BleepingComputer IOCs, or custom threat indicators.",
    keywords: ["kql", "sentinel", "query", "microsoft", "defender", "kusto", "detections", "hunt", "cve", "ioc generator", "cisa kev"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.ThreatIntel,
    name: "Threat Intel & Live Feeds (BleepingComputer + CISA KEV)",
    description: "Real-time BleepingComputer RSS feed with automated IOC extraction & CISA Known Exploited Vulnerabilities catalog.",
    keywords: ["bleepingcomputer", "cisa", "kev", "rss", "zero-day", "cve", "apt", "critical cve", "ioc feed", "mitigation", "advisory", "actor"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.Dashboard,
    name: "Kaspersky Cyberthreat Real-Time Map & Sentinel Integrity",
    description: "Interactive 3D real-time cyber attack map sourced from Kaspersky OSINT, with air-gapped simulation mode and Sentinel integrity security guidelines.",
    keywords: ["kaspersky", "cybermap", "attack map", "threat map", "sentinel", "osint", "integrity", "live map", "simulation"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.Ransomware,
    name: "Ransomware Onion-Leak Trackers",
    description: "Observe leak logs and victim updates gathered across active darknet gang negotiators.",
    keywords: ["ransomware", "onion", "gang", "leak", "victim", "lockbit", "play"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.LogAnalyzer,
    name: "AI Log Analyzer & Timeline Builder",
    description: "Parse multi-format raw security logs, correlate MITRE tactics, extract IOCs, and generate Sigma rules.",
    keywords: ["log", "logs", "evtx", "syslog", "timeline", "incident", "parser", "mitre", "sigma", "ai"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.ThreatGraph,
    name: "Interactive Threat Graph & Link Analysis",
    description: "Interactive graph visualizer mapping connected adversary nodes, C2 IPs, lookalike domains, and malware payloads.",
    keywords: ["graph", "visualizer", "link analysis", "topology", "threat graph", "network", "node", "c2"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.Homograph,
    name: "Homograph & Typosquatting Detector",
    description: "Detect IDN Unicode confusable spoofing and probe live resolving typosquatting lookalike permutations.",
    keywords: ["homograph", "homoglyph", "typosquatting", "combosquatting", "idn", "punycode", "phishing", "domain lookalike"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.IncidentReport,
    name: "Incident Report Exporter (DFIR & Executive)",
    description: "One-click generation of structured executive summaries and technical DFIR incident reports in PDF and Markdown.",
    keywords: ["report", "incident report", "dfir", "executive summary", "pdf", "markdown", "compliance", "gdpr", "export"],
    category: "Investigative Tools"
  },
  {
    tab: ActiveTab.Mitre,
    name: "MITRE ATT&CK Matrix Mapping",
    description: "Browse unified TTP patterns and match mitigation tactics instantly.",
    keywords: ["mitre", "attack", "tactic", "technique", "mitigation", "matrix"],
    category: "Threat intelligence"
  },
  {
    tab: ActiveTab.MacLookup,
    name: "MAC Address OUI Resolver",
    description: "Check physical network hardware manufacturers against IEEE registration logs.",
    keywords: ["mac", "oui", "hardware", "vendor", "ethernet", "network", "resolve"],
    category: "Utilities & Settings"
  },
  {
    tab: ActiveTab.Utilities,
    name: "SOC Utilities Core",
    description: "Translate base64 formats, compute percent domains, evaluate IP subnet ranges.",
    keywords: ["utilities", "base64", "decode", "percent", "cyberchef", "subnet calculator"],
    category: "Utilities & Settings"
  },
  {
    tab: ActiveTab.Settings,
    name: "API Keystore Settings",
    description: "Inject third-party API keys securely to enable external Shodan, VT and GreyNoise lookups.",
    keywords: ["settings", "api keys", "virustotal", "credentials", "abuseipdb", "configuration"],
    category: "Utilities & Settings"
  }
];

export default function DashboardView({ searchLogs, onSelectQuery, apiStatus, onNavigate, onNavigateToKql }: DashboardProps) {
  // Real-time dynamic threat feeds state
  const [activeFeeds, setActiveFeeds] = useState<any[]>([
    { id: 1, source: "CISA KEV", event: "CVE-2026-3241 Local Privilege Escalation Added", time: "5m ago", severity: "High" },
    { id: 2, source: "AbuseIPDB", event: "Brute force reporting peak on AS14061 subnets", time: "12m ago", severity: "Medium" },
    { id: 3, source: "URLhaus", event: "Active Emotet .dll loader URLs flagged", time: "22m ago", severity: "High" },
    { id: 4, source: "Twitter (X) Security", event: "New ransom group 'LockBit-V4' claim post", time: "43m ago", severity: "Low" },
    { id: 5, source: "GreyNoise", event: "Mass scanning for Ivanti VPN port 8443 observed", time: "1h ago", severity: "Critical" }
  ]);

  // Search filter query parameter for the SOC Toolkit search box
  const [toolkitQuery, setToolkitQuery] = useState("");

  // Periodically poll /api/live-feeds to synchronize threat metrics in real time
  const fetchLiveThreatFeeds = async () => {
    try {
      const response = await fetch("/api/live-feeds");
      if (response.ok) {
        const data = await response.json();
        setActiveFeeds(data);
      }
    } catch (err) {
      console.log("Telemetry sync silent pause: ", err);
    }
  };

  useEffect(() => {
    fetchLiveThreatFeeds();
    // Poll threat intelligence feed in real-time every 4 seconds
    const interval = setInterval(fetchLiveThreatFeeds, 4000);
    return () => clearInterval(interval);
  }, []);

  // Filter tools matching the search box query
  const matchingTools = TOOLS_REGISTRY.filter((tool) => {
    if (!toolkitQuery.trim()) return false; // Hide matched cards if query is empty
    const t = toolkitQuery.toLowerCase();
    return (
      tool.name.toLowerCase().includes(t) ||
      tool.description.toLowerCase().includes(t) ||
      tool.category.toLowerCase().includes(t) ||
      tool.keywords.some((kw) => kw.includes(t))
    );
  });

  // Top list queries
  const topIps = [
    { ip: "185.112.146.22", count: 42, host: "DigitalOcean Customer Block", risk: 78 },
    { ip: "45.192.12.8", count: 31, host: "Chongqing Unicom", risk: 94 },
    { ip: "8.8.8.8", count: 24, host: "Google DNS", risk: 0 },
    { ip: "103.114.160.221", count: 18, host: "VN Express", risk: 85 }
  ];

  const topDomains = [
    { domain: "update.micro-verify.net", count: 29, status: "malicious" },
    { domain: "starlightcrypto-verify.net", count: 21, status: "malicious" },
    { domain: "github.com", count: 15, status: "clean" },
    { domain: "firmas-digitales.com", count: 12, status: "suspicious" }
  ];

  return (
    <div className="space-y-6">
      {/* Overview stats block */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div id="stat-card-total" className="bg-slate-950/60 backdrop-blur-md border border-slate-900/80 p-5 rounded relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-red-500/5 rounded-full blur-xl"></div>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono tracking-wider text-slate-500">TOTAL IOC ENRICHED</span>
            <Database className="w-4 h-4 text-slate-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-mono font-bold text-slate-200">
              {searchLogs.length + 104}
            </span>
            <span className="text-[9px] font-mono text-emerald-500 font-semibold flex items-center">
              ▲ +12%
            </span>
          </div>
          <p className="text-[9px] font-mono text-slate-600 mt-1">
            Tracking local lookup volume
          </p>
        </div>

        <div id="stat-card-top-ip" className="bg-slate-950/60 backdrop-blur-md border border-slate-900/80 p-5 rounded relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-red-500/5 rounded-full blur-xl"></div>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono tracking-wider text-slate-500">PEAK RISK ASSESS</span>
            <ShieldAlert className="w-4 h-4 text-red-500" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-mono font-bold text-red-400">94/100</span>
            <span className="text-[9px] font-mono text-red-500 font-semibold">
              CRITICAL
            </span>
          </div>
          <p className="text-[9px] font-mono text-slate-600 mt-1">
            Max threat score indexed
          </p>
        </div>

        <div id="stat-card-api-status" className="bg-slate-950/60 backdrop-blur-md border border-slate-900/80 p-5 rounded relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-red-500/5 rounded-full blur-xl"></div>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono tracking-wider text-slate-500">INTELLIGENCE ENGINES</span>
            <Wifi className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-mono font-bold text-emerald-400">
              {apiStatus.filter(e => e.status === "configured").length} / {apiStatus.length}
            </span>
            <span className="text-[9px] font-mono text-slate-400">
              KEYSTORED
            </span>
          </div>
          <p className="text-[9px] font-mono text-slate-600 mt-1 font-semibold">
            Using local credentials proxy
          </p>
        </div>
      </div>

      {/* SOC Toolkit Search Option Component */}
      <div className="bg-slate-950/70 backdrop-blur-md border border-slate-900 p-5 rounded-lg space-y-4">
        <div className="flex items-center gap-2.5">
          <Compass className="w-4.5 h-4.5 text-red-500 animate-spin-slow" />
          <div>
            <h2 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-widest">
              SOC CORE UTILITY LAUNCHPAD
            </h2>
            <p className="text-[10px] font-mono text-slate-500">
              Instantly resolve and jump to any analyzer, playground or configuration option inside the toolkit.
            </p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-500" />
          <input
            id="toolkit-core-search"
            type="text"
            placeholder="Type tool name, category or functionality (e.g. 'WHOIS', 'KQL', 'Screenshot', 'DGA', 'Hash', 'Decoder')..."
            value={toolkitQuery}
            onChange={(e) => setToolkitQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-10 pr-4 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-600"
          />
        </div>

        {/* Search Results Display Drawer */}
        {toolkitQuery.trim() && (
          <div className="border border-slate-900 bg-slate-1000 p-3.5 rounded-lg grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 animate-fade-in">
            <div className="col-span-full border-b border-slate-900 pb-1.5 flex justify-between items-center select-none">
              <span className="text-[9px] font-mono text-emerald-400 font-bold flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" /> FOUND {matchingTools.length} MATCHING COMPONENT SERVICES
              </span>
              <button
                onClick={() => setToolkitQuery("")}
                className="text-[9px] font-mono text-slate-500 hover:text-slate-300 font-bold transition"
              >
                CLOSE LAUNCHER
              </button>
            </div>

            {matchingTools.length === 0 ? (
              <div className="col-span-full text-center py-6 text-[11px] font-mono text-slate-600">
                No matching toolkit modules detected. Try checking spelling or search other operational categories.
              </div>
            ) : (
              matchingTools.map((tool, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setToolkitQuery("");
                    onNavigate(tool.tab);
                  }}
                  className="bg-slate-950 border border-slate-900/80 p-3.5 rounded hover:border-red-900 hover:bg-red-955/5 cursor-pointer transition flex flex-col justify-between group"
                >
                  <div className="space-y-1.5">
                    <span className="text-[8px] font-mono text-slate-550 border border-slate-900 px-1.5 py-0.2 rounded uppercase bg-slate-1000">
                      {tool.category}
                    </span>
                    <h4 className="text-[11.5px] font-mono font-bold text-slate-205 group-hover:text-red-400 transition">
                      {tool.name}
                    </h4>
                    <p className="text-[10px] font-mono text-slate-500 leading-normal">
                      {tool.description}
                    </p>
                  </div>
                  <div className="pt-2 px-0.5 border-t border-slate-900/60 mt-2 flex justify-between items-center text-[9px] font-mono text-red-500 group-hover:text-red-400">
                    <span className="font-bold">LAUNCH UTILITY</span>
                    <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition" />
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Main Grid: Attack Map + Live Feed Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <CyberThreatMap onNavigate={onNavigate} onNavigateToKql={onNavigateToKql} />
        </div>

        {/* Global threat feeds synchronized in real time from backend */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col justify-between">
          <div>
            <h2 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-3 flex items-center gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-red-505 text-red-500" />
              GLOBAL INTEL RECENT FEED
            </h2>
            <div className="space-y-2.5 overflow-y-auto max-h-[310px] scrollbar-thin">
              {activeFeeds.map((feed) => (
                <div key={feed.id} className="p-2 bg-slate-950 border border-slate-900/60 rounded flex flex-col gap-1 hover:border-slate-850 transition">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-mono text-blue-400 uppercase font-semibold">
                      {feed.source}
                    </span>
                    <span className={`text-[8px] font-mono px-1 rounded ${
                      feed.severity === "Critical" ? "bg-red-955 text-red-400 border border-red-800" :
                      feed.severity === "High" ? "bg-orange-955 text-orange-400 border border-orange-850" :
                      "bg-slate-900 text-slate-400 border border-slate-700"
                    }`}>
                      {feed.severity}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-350 font-mono tracking-tight leading-sm">
                    {feed.event}
                  </p>
                  <span className="text-[8px] font-mono text-slate-500 flex items-center gap-1 mt-0.5">
                    <Clock className="w-2.5 h-2.5" />
                    {feed.time}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => onNavigate(ActiveTab.ThreatIntel)}
            className="w-full text-center mt-3 text-[10px] font-mono text-slate-500 hover:text-slate-350 transition p-1 border-t border-slate-900/60 pt-2.5 cursor-pointer font-bold uppercase"
          >
            BROADCAST / DEPLOY LIVE INTEL ALERTS
          </button>
        </div>
      </div>

      {/* Grid: Top IOC Query lists + Local search logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left: Top Queried Assets */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-4">
          <h2 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-3">
            TOP RECURRING PUBLIC IOCS
          </h2>
          <div className="space-y-4">
            <div>
              <span className="text-[9px] font-mono text-slate-550 block mb-1.5 tracking-widest uppercase">
                IP ADDRESS BLOCK LIST
              </span>
              <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                {topIps.map((ip, idx) => (
                  <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4 px-3 py-2.5 border-b border-slate-900 last:border-0 hover:bg-slate-900/40">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[9px] font-mono text-slate-550">#{idx + 1}</span>
                      <button
                        onClick={() => onSelectQuery("IP", ip.ip)}
                        className="text-xs font-mono text-slate-300 font-semibold hover:text-red-400 hover:underline text-left cursor-pointer truncate"
                      >
                        {ip.ip}
                      </button>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-3 min-w-0 sm:shrink-0">
                      <span className="text-[10px] font-mono text-slate-500 italic truncate max-w-[140px] sm:max-w-[120px]">
                        {ip.host}
                      </span>
                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold border ${
                        ip.risk > 80 ? "bg-red-955 text-red-450 border-red-900/40" : ip.risk > 0 ? "bg-orange-955 text-orange-455 border-orange-900/40" : "bg-emerald-955 text-emerald-455 border-emerald-900/40"
                      }`}>
                        {ip.risk}% Risk
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <span className="text-[9px] font-mono text-slate-550 block mb-1.5 tracking-widest uppercase">
                DOMAIN HOST MONITOR
              </span>
              <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                {topDomains.map((dom, idx) => (
                  <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4 px-3 py-2.5 border-b border-slate-900 last:border-0 hover:bg-slate-900/40">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[9px] font-mono text-slate-550">#{idx + 1}</span>
                      <button
                        onClick={() => onSelectQuery("Domain", dom.domain)}
                        className="text-xs font-mono text-slate-300 font-semibold hover:text-red-400 hover:underline text-left cursor-pointer truncate"
                      >
                        {dom.domain}
                      </button>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase font-bold border ${
                        dom.status === "malicious" ? "bg-red-955 text-red-400 border-red-900/40" :
                        dom.status === "suspicious" ? "bg-orange-955 text-orange-400 border-orange-900/40" :
                        "bg-emerald-955 text-emerald-400 border-emerald-900/40"
                      }`}>
                        {dom.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Recent Searches */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase">
              LOCAL ANALYSIS RECENT LOGS
            </h2>
            <span className="text-[9px] font-mono text-slate-550">PERSISTENT CACHE</span>
          </div>
          <div className="flex-1 bg-slate-950 border border-slate-900 rounded overflow-y-auto max-h-[290px]">
            {searchLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-center text-slate-600 h-full">
                <HelpCircle className="w-8 h-8 mb-2 opacity-40 text-slate-400" />
                <span className="text-xs font-mono">No forensic queries stored yet.</span>
                <span className="text-[9px] font-mono mt-1">Details will preserve upon live validation lookups.</span>
              </div>
            ) : (
              <div className="divide-y divide-slate-900">
                {searchLogs.slice().reverse().map((log) => (
                  <div key={log.id} className="p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-900/30 transition">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded uppercase font-bold border shrink-0 ${
                        log.type === "IP" ? "bg-blue-955 text-blue-400 border-blue-900/40" :
                        log.type === "Domain" ? "bg-purple-955 text-purple-400 border-purple-900/40" :
                        log.type === "URL" ? "bg-pink-955 text-pink-400 border-pink-900/40" :
                        "bg-orange-955 text-orange-400 border-orange-900/40"
                      }`}>
                        {log.type}
                      </span>
                      <button
                        onClick={() => onSelectQuery(log.type, log.query)}
                        className="text-[11px] font-mono text-slate-300 font-semibold truncate hover:text-red-400 hover:underline cursor-pointer text-left"
                      >
                        {log.query}
                      </button>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 sm:ml-2">
                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase font-bold border ${
                        log.reputation === "malicious" ? "bg-red-955 text-red-500 border-red-900/40" :
                        log.reputation === "suspicious" ? "bg-orange-955 text-orange-500 border-orange-900/40" :
                        log.reputation === "clean" ? "bg-emerald-955 text-emerald-500 border-emerald-900/40" :
                        "bg-slate-900 text-slate-400 border-slate-800"
                      }`}>
                        {log.reputation}
                      </span>
                      <span className="text-[9px] font-mono text-slate-500 font-semibold">
                        {log.timestamp}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <p className="text-[8px] font-mono text-slate-650 mt-2 italic text-center">
            Enrichment results are cached in local IndexedDB/LocalStorage proxies.
          </p>
        </div>
      </div>
    </div>
  );
}
