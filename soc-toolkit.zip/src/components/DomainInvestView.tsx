/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { DomainAnalysisResult } from "../types";
import {
  Search,
  Globe,
  Calendar,
  Layers,
  Database,
  Link2,
  Server,
  Terminal,
  Activity,
  AlertTriangle,
  Copy,
  Check,
  Tag,
  Binary,
  Cpu,
  HelpCircle,
  Sparkles,
  ShieldCheck,
  UserCheck,
  CloudLightning,
  Lock,
  FileBadge,
  AlertCircle,
  ShieldAlert
} from "lucide-react";

interface DomainInvestProps {
  onAddSearchLog: (log: { type: "IP" | "Domain" | "URL" | "Hash" | "Malware"; query: string; reputation: "clean" | "suspicious" | "malicious" | "unknown"; score?: number }) => void;
  initialQuery?: string;
}

export default function DomainInvestView({ onAddSearchLog, initialQuery = "" }: DomainInvestProps) {
  const [activeSubTab, setActiveSubTab] = useState<"whois" | "dga">("whois");
  const [domainInput, setDomainInput] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DomainAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);

  // SSL active state variables
  const [sslResult, setSslResult] = useState<any | null>(null);
  const [sslLoading, setSslLoading] = useState(false);
  const [sslError, setSslError] = useState<string | null>(null);

  // DGA exclusive parameters
  const [dgaInput, setDgaInput] = useState(initialQuery);
  const [dgaLoading, setDgaLoading] = useState(false);
  const [dgaResult, setDgaResult] = useState<any | null>(null);
  const [dgaError, setDgaError] = useState<string | null>(null);
  const [dgaCopied, setDgaCopied] = useState(false);

  const handleSearch = async (targetDomain: string) => {
    const trimmed = targetDomain.trim();
    if (!trimmed) return;
    setLoading(true);
    setSslLoading(true);
    setSslError(null);
    setSslResult(null);
    setResult(null);
    // Cascade values to DGA input in the background
    setDgaInput(trimmed);

    let cleanHost = trimmed.replace(/^(https?:\/\/)?(www\.)?/i, "").split("/")[0].split(":")[0];

    const parsedKeys = {
      virustotal: localStorage.getItem("VT_API_KEY") || "",
      gemini: localStorage.getItem("GEMINI_API_KEY") || "",
      whoisjson: localStorage.getItem("WHOISJSON_API_KEY") || "",
    };

    const domainPromise = fetch("/api/enrich/domain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: trimmed, apiKeys: parsedKeys }),
    }).then(async (res) => {
      if (res.ok) {
        const data: DomainAnalysisResult = await res.json();
        setResult(data);

        onAddSearchLog({
          type: "Domain",
          query: trimmed,
          reputation: data.reputation,
          score: data.reputation === "malicious" ? 85 : data.reputation === "suspicious" ? 45 : 0
        });
      } else {
        throw new Error("Domain profiling failed to complete.");
      }
    });

    const sslPromise = fetch("/api/ssl/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host: cleanHost }),
    }).then(async (res) => {
      if (res.ok) {
        const sslData = await res.json();
        setSslResult(sslData);
      } else {
        const errData = await res.json().catch(() => ({}));
        setSslError(errData.error || "Failed to establish SSL/TLS handshake.");
      }
    }).catch((err) => {
      setSslError(err.message || "Failed to query server SSL socket.");
    }).finally(() => {
      setSslLoading(false);
    });

    try {
      await Promise.allSettled([domainPromise, sslPromise]);
    } catch (err) {
      console.error("Domain lookup parallel failure:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDgaSearch = async (targetDomain: string) => {
    const trimmed = targetDomain.trim();
    if (!trimmed) {
      setDgaError("Please specify a domain to test.");
      return;
    }
    setDgaLoading(true);
    setDgaError(null);
    try {
      const response = await fetch("/api/dga/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: trimmed }),
      });

      if (!response.ok) {
        throw new Error("DGA Classifier error returned.");
      }

      const data = await response.json();
      setDgaResult(data);
    } catch (err: any) {
      console.error(err);
      setDgaError("Failed to communicate with DGA Machine Learning model.");
    } finally {
      setDgaLoading(false);
    }
  };

  const executeCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Sub-tab Selection */}
      <div className="flex border-b border-slate-900 gap-4 mb-2 select-none">
        <button
          onClick={() => setActiveSubTab("whois")}
          className={`pb-2.5 text-xs font-mono font-bold tracking-wider uppercase border-b-2 transition cursor-pointer ${
            activeSubTab === "whois"
              ? "border-red-500 text-red-400"
              : "border-transparent text-slate-500 hover:text-slate-300"
          }`}
        >
          WHOIS & DNS Correlation
        </button>
        <button
          onClick={() => setActiveSubTab("dga")}
          className={`pb-2.5 text-xs font-mono font-bold tracking-wider uppercase border-b-2 transition cursor-pointer ${
            activeSubTab === "dga"
              ? "border-amber-500 text-amber-400"
              : "border-transparent text-slate-500 hover:text-slate-300"
          }`}
        >
          DGA Machine Learning Analyzer
        </button>
      </div>

      {activeSubTab === "whois" && (
        <div className="space-y-6">
          {/* Search Console */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
            <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1">
              DOMAIN CORRELATION & DNS ENGINE
            </h2>
            <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
              Scrape active WHOIS registry records, DNS mapping nodes, category classifications, and correlated threat campaign listings.
            </p>

            <div className="flex gap-2 max-w-2xl">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  id="domain-investigate-input"
                  type="text"
                  placeholder="Enter domain name (e.g., firmas-digitales.com)..."
                  value={domainInput}
                  onChange={(e) => setDomainInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch(domainInput)}
                  className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
                />
              </div>
              <button
                onClick={() => handleSearch(domainInput)}
                disabled={loading}
                className="bg-red-950/40 hover:bg-red-900/40 border border-red-500/30 hover:border-red-500 text-red-400 px-5 py-2 rounded text-xs font-mono transition font-bold cursor-pointer disabled:opacity-50"
              >
                {loading ? "SEARCHING..." : "RUN WHOIS & DNS"}
              </button>
            </div>
          </div>

          {loading && (
            <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
              <div className="relative flex h-8 w-8">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-8 w-8 bg-cyan-600"></span>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Consulting domain registers and name resolution clusters...
              </span>
            </div>
          )}

          {result && !loading && (
            <div className="space-y-6 animate-fade-in">
              {/* AI Threat Tag & Status Alert */}
              {((result.reputation === "malicious" || result.reputation === "suspicious") || (result.aiAnalysisTag && !result.aiAnalysisTag.startsWith("Clean"))) && (
                <div className={`border p-4 rounded-lg flex items-start gap-3.5 backdrop-blur-md ${
                  result.reputation === "malicious" ? "bg-red-950/20 border-red-500/30 text-red-200" : "bg-orange-950/20 border-orange-500/30 text-orange-200"
                }`}>
                  <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${result.reputation === "malicious" ? "text-red-500 animate-pulse" : "text-orange-500"}`} />
                  <div className="space-y-1 font-mono">
                    <h4 className="text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                      <span>{result.reputation === "malicious" ? "CORE THREAT ANALYSIS: HIGH-RISK DETECTED" : "CORE THREAT ANALYSIS: SUSPICIOUS ACTIVITY"}</span>
                      <span className={`text-[9px] px-1 py-0.2 rounded border uppercase font-mono ${
                        result.reputation === "malicious" ? "bg-red-950 border-red-900 text-red-400" : "bg-orange-950 border-orange-900 text-orange-400"
                      }`}>AI Flagged</span>
                    </h4>
                    <p className="text-[11px] text-slate-350 leading-relaxed">
                      {result.aiAnalysisTag || "This domain has been flagged by cognitive security heuristics as posing elevated risks of credential theft, phishing campaigns, or malware delivery."}
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Summary Left side */}
              <div className="space-y-4">
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
                  <div className={`absolute top-0 left-0 right-0 h-1 ${
                    result.reputation === "malicious" ? "bg-red-500" : result.reputation === "suspicious" ? "bg-orange-500" : "bg-emerald-500"
                  }`} />

                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xs font-mono font-bold text-slate-400">REGISTRY DETAILS</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase ${
                      result.reputation === "malicious" ? "bg-red-950 text-red-500 border-red-950" :
                      result.reputation === "suspicious" ? "bg-orange-950 text-orange-550 border-orange-950" :
                      "bg-emerald-950 text-emerald-500 border-emerald-950"
                    }`}>
                      {result.reputation}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 border-b border-slate-900 pb-4 mb-4">
                    <Globe className="w-8 h-8 text-slate-500 animate-pulse" />
                    <div className="min-w-0">
                      <h3 className="text-sm font-mono font-bold text-slate-100 truncate">{result.domain}</h3>
                      <span className="text-[10px] font-mono text-slate-500 uppercase">Age: {result.age}</span>
                    </div>
                  </div>

                  {/* WHOIS specifics info */}
                  <div className="space-y-3 font-mono text-[11px] mb-4">
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-500">REGISTRAR:</span>
                      <span className="text-slate-350 truncate max-w-[170px] text-right font-semibold">{result.registrar}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-500">CREATED DATE:</span>
                      <span className="text-slate-350">{result.createdDate}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                      <span className="text-slate-500">EXPIRY DATE:</span>
                      <span className="text-slate-350">{result.expiryDate}</span>
                    </div>
                  </div>

                  {/* Nameservers list */}
                  <div>
                    <span className="text-[9px] font-mono text-slate-500 block mb-1 uppercase tracking-widest font-semibold">
                      Nameservers (DNS authority)
                    </span>
                    <div className="bg-slate-950 p-2 border border-slate-900 rounded font-mono text-[10px] text-slate-400 space-y-1">
                      {result.nameServers.map((ns, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <span className="w-1 h-1 bg-slate-500 rounded-full" />
                          <span>{ns}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Categorization list */}
                  <div className="mt-4">
                    <span className="text-[9px] font-mono text-slate-500 block mb-1.5 uppercase tracking-widest font-semibold">
                      Categories Assigned
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {result.categories.map((cat, idx) => (
                        <span key={idx} className="bg-slate-900 border border-slate-800 text-slate-350 text-[10px] px-1.5 py-0.5 rounded font-mono">
                          {cat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Details / DNS records */}
              <div className="lg:col-span-2 space-y-5">
                {/* DNS Records Table */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
                  <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-3 flex items-center gap-2">
                    <Server className="w-3.5 h-3.5 text-blue-500" />
                    ACTIVE DNS RESOLUTION RECORDS
                  </h3>
                  <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden">
                    <table className="w-full text-left font-mono text-[11px] select-none">
                      <thead>
                        <tr className="bg-slate-950 text-slate-500 border-b border-slate-900">
                          <th className="p-3">TYPE</th>
                          <th className="p-3">MAPPED DATA VALUE</th>
                          <th className="p-3 text-right">TTL</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60">
                        {result.dnsRecords.map((rec, i) => (
                          <tr key={i} className="hover:bg-slate-900/20">
                            <td className="p-3 font-semibold text-blue-400">{rec.type}</td>
                            <td className="p-3 text-slate-300 break-all">{rec.value}</td>
                            <td className="p-3 text-right text-slate-500">{rec.ttl}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* SSL Certificate Scraping Section */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-emerald-400" />
                      LIVE SCRAPED SSL/TLS CERTIFICATE DETAILS
                    </h3>
                    {sslResult && (
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase font-mono ${
                        sslResult.isValid && sslResult.daysRemaining > 0
                          ? "bg-emerald-950/20 text-emerald-400 border-emerald-900"
                          : "bg-red-950/20 text-red-500 border-red-900"
                      }`}>
                        {sslResult.isValid && sslResult.daysRemaining > 0 ? "VALID CERTIFICATE" : "VERIFICATION FAULT"}
                      </span>
                    )}
                  </div>
                  
                  {sslLoading && (
                    <div className="bg-slate-950/40 p-6 border border-slate-900 rounded font-mono text-[10px] text-slate-500 text-center flex flex-col items-center gap-2">
                      <div className="w-5 h-5 border-2 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
                      Scraping secure socket layers and certificate fingerprints...
                    </div>
                  )}

                  {sslError && !sslLoading && (
                    <div className="p-3 bg-red-950/20 border border-red-900/50 rounded font-mono text-[10px] text-red-400 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                      <span>{sslError}</span>
                    </div>
                  )}

                  {sslResult && !sslLoading && (
                    <div className="space-y-3.5 font-mono">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10.5px]">
                        <div className="p-2.5 bg-slate-950/80 border border-slate-900/80 rounded">
                          <span className="text-[9px] text-slate-550 block uppercase">COMMON NAME / SUBJECT</span>
                          <span className="text-slate-100 font-bold truncate block mt-0.5 select-all">{sslResult.peerCert.subject || "N/A"}</span>
                        </div>
                        <div className="p-2.5 bg-slate-950/80 border border-slate-900/80 rounded">
                          <span className="text-[9px] text-slate-550 block uppercase">ISSUER AUTHORITY</span>
                          <span className="text-slate-205 truncate block mt-0.5 font-semibold select-all">{sslResult.peerCert.issuer || "N/A"}</span>
                        </div>
                        <div className="p-2.5 bg-slate-950/80 border border-slate-900/80 rounded">
                          <span className="text-[9px] text-slate-550 block uppercase">CIPHER SUITE & STRENGTH</span>
                          <span className="text-emerald-400 font-bold block mt-0.5 select-all">
                            {sslResult.peerCert.protocol || "TLSv1.3"} ({sslResult.peerCert.bits || 256} BITS)
                          </span>
                        </div>
                        <div className="p-2.5 bg-slate-950/80 border border-slate-900/80 rounded">
                          <span className="text-[9px] text-slate-550 block uppercase">REGISTRATION SPAN</span>
                          <span className="text-slate-350 block mt-0.5 select-all">
                            {sslResult.daysRemaining} Days remaining (Expires {new Date(sslResult.peerCert.validTo).toLocaleDateString()})
                          </span>
                        </div>
                      </div>

                      {/* Fingerprints */}
                      <div className="p-2.5 bg-slate-950/85 border border-slate-1000 rounded text-[9.5px] space-y-1 border border-slate-900">
                        <div className="flex justify-between items-center border-b border-slate-900 pb-1">
                          <span className="text-slate-500">SHA256 FINGERPRINT:</span>
                          <span className="text-emerald-400 truncate font-bold uppercase tracking-tight ml-2 select-all font-mono">{sslResult.peerCert.fingerprint || "N/A"}</span>
                        </div>
                        <div className="flex justify-between items-center pt-1">
                          <span className="text-slate-500">SERIAL NUMBER:</span>
                          <span className="text-amber-500 truncate font-semibold ml-2 select-all">{sslResult.peerCert.serialNumber || "N/A"}</span>
                        </div>
                      </div>

                      {/* SANs list */}
                      {sslResult.peerCert.sans && sslResult.peerCert.sans.length > 0 && (
                        <div>
                          <span className="text-[8.5px] text-slate-500 block uppercase tracking-wide font-bold mb-1.5">
                            SUBJECT ALTERNATIVE NAMES (SANS)
                          </span>
                          <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto bg-slate-950 p-2 border border-slate-900 rounded">
                            {sslResult.peerCert.sans.slice(0, 15).map((san: string, idx: number) => (
                              <span key={idx} className="bg-slate-900/85 border border-slate-850 text-slate-400 text-[9px] px-1.5 py-0.5 rounded select-all font-mono">
                                {san}
                              </span>
                            ))}
                            {sslResult.peerCert.sans.length > 15 && (
                              <span className="text-[9px] text-slate-600 bg-slate-900/50 px-1.5 py-0.5 rounded">
                                + {sslResult.peerCert.sans.length - 15} more alternative domains
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Correlated IOC linkages / VT score */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* OTX Pulses / campaigns */}
                  <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wide mb-3 flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-purple-400" />
                      CORRELATED RECENT IOCS
                    </h3>
                    {result.relatedIocs.length === 0 ? (
                      <div className="p-6 text-center text-slate-600 text-[10px] bg-slate-950 border border-slate-900 rounded font-mono">
                        No related command hashes or malicious IPs mapped.
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {result.relatedIocs.map((ioc, idx) => (
                          <div key={idx} className="p-2 bg-slate-950 border border-slate-900/80 rounded flex items-center justify-between font-mono text-[10px] leading-none select-none">
                            <div className="min-w-0 flex items-center gap-2">
                              <span className="bg-slate-900 text-slate-400 border border-slate-800 px-1 rounded font-bold text-[8px] tracking-tight">
                                {ioc.type}
                              </span>
                              <span className="text-slate-300 truncate font-semibold" title={ioc.value}>
                                {ioc.value}
                              </span>
                            </div>
                            <span className="text-[8px] text-slate-500 shrink-0 ml-2 uppercase italic">
                              {ioc.relation}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Multi engine VT rating */}
                  <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wide mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                        Multi-Engine Malware Status
                      </h3>
                      <p className="text-[10px] font-mono text-slate-500 leading-sm mb-3">
                        Aggregated scores of anti-malware and social engineering scanners scanning domain web-headers.
                      </p>
                      <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-center">
                        <div className="p-2 bg-slate-950 border border-slate-900 rounded">
                          <span className="text-red-400 font-bold block">MALICIOUS</span>
                          <span className="text-lg mt-0.5 block">{result.vtDetections.malicious}</span>
                        </div>
                        <div className="p-2 bg-slate-950 border border-slate-900 rounded">
                          <span className="text-orange-400 font-bold block">SUSPECT</span>
                          <span className="text-lg mt-0.5 block">{result.vtDetections.suspicious}</span>
                        </div>
                        <div className="p-2 bg-slate-950 border border-slate-900 rounded">
                          <span className="text-emerald-400 font-bold block">CLEAN</span>
                          <span className="text-lg mt-0.5 block">{result.vtDetections.clean}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-2 border-t border-slate-900 flex justify-between items-center select-none">
                      <span className="text-[9px] font-mono text-slate-650">COGNITIVE SCHEMA DATA</span>
                      <button
                        onClick={executeCopy}
                        className="text-[9px] font-mono text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-950 border border-slate-900 px-2 py-0.5 rounded cursor-pointer"
                      >
                        {copied ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                        Copy JSON
                      </button>
                    </div>
                  </div>
                </div>

                {/* Real-time Web Grounding & APT/Malware Associations */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                      <Globe className="w-4 h-4 text-blue-400" />
                      AI web discovery & threat associations
                    </h3>
                    <span className="text-[9px] bg-slate-900 border border-slate-800 text-blue-400 font-mono px-2 py-0.5 rounded flex items-center gap-1">
                      <Search className="w-3 h-3 text-blue-450 shrink-0" />
                      Google Grounding Active
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Threat Actor/APT Block */}
                    <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                      <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                        <UserCheck className="w-4 h-4 text-orange-400" />
                        Associated APT & Threat Actor Groups
                      </div>
                      {result.threatActors && result.threatActors.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {result.threatActors.map((actor, idx) => (
                            <span key={idx} className="bg-orange-950/40 text-orange-400 border border-orange-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                              {actor}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-slate-500 text-[10px] italic">No Advanced Persistent Threat (APT) groups directly associated with this domain in security registers.</p>
                      )}
                    </div>

                    {/* Malware / Trojan / Virus Type Block */}
                    <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] leading-relaxed">
                      <div className="flex items-center gap-1.5 text-slate-305 font-bold border-b border-slate-900 pb-2 mb-2 uppercase text-[10px]">
                        <CloudLightning className="w-4 h-4 text-red-400" />
                        Associated Malware, Trojans & Viruses
                      </div>
                      {result.malwareAssociations && result.malwareAssociations.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {result.malwareAssociations.map((malware, idx) => (
                            <span key={idx} className="bg-red-950/40 text-red-400 border border-red-900/50 text-[10px] px-2.5 py-0.5 rounded font-bold">
                              {malware}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-slate-500 text-[10px] italic">No dynamic Trojan payloads or active ransomware kits associated with this domain.</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* MITRE ATT&CK Mapping Segment */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-3">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-widest flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-amber-500" />
                    MITRE ATT&CK TACTICS & TECHNIQUES MAPPED
                  </h3>

                  {result.mitreMappings && result.mitreMappings.length > 0 ? (
                    <div className="space-y-2">
                      {result.mitreMappings.map((mapping, idx) => (
                        <div key={idx} className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px]">
                          <div className="flex justify-between items-start mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className="bg-amber-950 text-amber-400 border border-amber-900/60 font-bold text-[10px] px-2 py-0.5 rounded">
                                {mapping.id}
                              </span>
                              <span className="text-slate-250 font-bold font-mono text-xs">{mapping.name}</span>
                            </div>
                            <span className="text-[10px] text-slate-500 uppercase tracking-wide font-semibold">
                              TACTIC: {mapping.tactic}
                            </span>
                          </div>
                          <p className="text-slate-400 text-[11px] leading-normal">{mapping.description}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-slate-950 p-4 border border-slate-900 rounded font-mono text-[11px] text-slate-500 italic">
                      No active TTP techniques dynamically mapped to this host domain.
                    </div>
                  )}
                </div>

              </div>
            </div>
          </div>
          )}
        </div>
      )}

      {activeSubTab === "dga" && (
        <div className="space-y-6 animate-fade-in">
          {/* DGA Header Console */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
            <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-400" />
              ALGORITHMIC DOMAIN CLASSIFIER (DGA DETECTOR)
            </h2>
            <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
              Run Shannon character entropy matrices, consonant pile distributions, and cognitive heuristic diagnostics to determine if a domain was crafted algorithmically by malicious malware command beacons (DGA).
            </p>

            <div className="space-y-3">
              <div className="flex gap-2 max-w-2xl">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <input
                    id="dga-investigate-input"
                    type="text"
                    placeholder="Enter domain name (e.g., qwxzrtpy-necurs-malware.biz) to analyze DGA..."
                    value={dgaInput}
                    onChange={(e) => setDgaInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleDgaSearch(dgaInput)}
                    className="w-full bg-slate-950 border border-slate-850 focus:border-amber-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
                  />
                </div>
                <button
                  onClick={() => handleDgaSearch(dgaInput)}
                  disabled={dgaLoading}
                  className="bg-amber-950/40 hover:bg-amber-900/40 border border-amber-500/30 hover:border-amber-500 text-amber-400 px-5 py-2 rounded text-xs font-mono transition font-bold cursor-pointer disabled:opacity-50"
                >
                  {dgaLoading ? "CLASSIFYING..." : "ANALYZE DGA"}
                </button>
              </div>

              {/* Quick Samples */}
              <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-[10px]">
                <span className="text-slate-600 uppercase font-semibold">Test Profiles:</span>
                {[
                  { label: "Benign (google.com)", domain: "google.com" },
                  { label: "Necurs DGA (qwxrtpy7.biz)", domain: "qwxrtpy7.biz" },
                  { label: "CryptoLocker (yvuelvscb.ru)", domain: "yvuelvscb.ru" },
                  { label: "Suppobox DGA (microsoftupdate33.net)", domain: "microsoftupdate33.net" }
                ].map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setDgaInput(sample.domain);
                      handleDgaSearch(sample.domain);
                    }}
                    className="bg-slate-900/60 hover:bg-slate-900 border border-slate-880 hover:border-slate-700 text-slate-400 hover:text-slate-200 px-2 py-0.5 rounded transition cursor-pointer"
                  >
                    {sample.label}
                  </button>
                ))}
              </div>

              {dgaError && (
                <div className="p-3 bg-red-950/20 border border-red-900/50 rounded text-xs font-mono text-red-100">
                  {dgaError}
                </div>
              )}
            </div>
          </div>

          {dgaLoading && (
            <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
              <div className="relative flex h-8 w-8">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-8 w-8 bg-amber-600"></span>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Running tokenized entropy passes and consulting intelligence classifier...
              </span>
            </div>
          )}

          {dgaResult && !dgaLoading && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Verdict Summary Panel */}
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
                <div className={`absolute top-0 left-0 right-0 h-1 ${
                  dgaResult.isDga ? "bg-red-500" : "bg-emerald-500"
                }`} />

                <div className="text-xs font-mono text-slate-550 uppercase tracking-widest mb-3">
                  CLASSIFICATION VERDICT
                </div>

                <div className={`p-4 rounded border font-mono mb-4 text-center ${
                  dgaResult.isDga
                    ? "bg-red-950/20 border-red-900/50 text-red-400"
                    : "bg-emerald-950/20 border-emerald-900/50 text-emerald-400"
                }`}>
                  <div className="text-lg font-extrabold uppercase tracking-wide">
                    {dgaResult.isDga ? "🚨 ALGORITHMIC / DGA" : "✅ BENIGN / HUMAN"}
                  </div>
                  <div className="text-[10px] uppercase mt-1 opacity-80">
                    Confidence: {dgaResult.probability}%
                  </div>
                </div>

                {/* Meter Progress bar */}
                <div className="space-y-1.5 mb-5 font-mono">
                  <div className="flex justify-between text-[11px] text-slate-400 font-semibold">
                    <span>DGA Likelihood Probability</span>
                    <span>{dgaResult.probability}%</span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-850">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        dgaResult.probability > 75 ? "bg-red-500" :
                        dgaResult.probability > 40 ? "bg-amber-500" :
                        "bg-emerald-500"
                      }`}
                      style={{ width: `${dgaResult.probability}%` }}
                    />
                  </div>
                </div>

                {/* Sub-structures */}
                <div className="space-y-3 font-mono text-[11px]">
                  <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                    <span className="text-slate-500">TARGET DOMAIN:</span>
                    <span className="text-slate-200 font-semibold truncate max-w-[150px]">{dgaResult.domain}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                    <span className="text-slate-500">CORRELATED FAMILY:</span>
                    <span className="text-slate-200 font-semibold bg-slate-900 px-1 py-0.5 rounded border border-slate-850">{dgaResult.family}</span>
                  </div>
                </div>

                {/* Indicators section */}
                <div className="mt-5">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-semibold block mb-2">
                    HEURISTIC INDICATORS PLOTTED
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {dgaResult.indicators.map((ind: string, idx: number) => (
                      <span
                        key={idx}
                        className={`text-[9px] font-mono px-2 py-0.5 rounded border ${
                          dgaResult.isDga
                            ? "bg-red-950/10 text-red-400/90 border-red-900/30"
                            : "bg-emerald-950/10 text-emerald-400/90 border-emerald-900/30"
                        }`}
                      >
                        {ind}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Technical breakdown */}
              <div className="lg:col-span-2 space-y-6">
                {/* Math Matrix Visual */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
                  <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-1.5 flex items-center gap-2">
                    <Binary className="w-4 h-4 text-amber-400" />
                    MATHEMATICAL ENTROPY & CHARACTER DISTRIBUTION MATRIX
                  </h3>
                  <p className="text-[10px] font-mono text-slate-500 mb-4">
                    Analytical metrics computed statically on target character chains. Normal human dictionary registrations favor high pronunciation vowels, while DGAs present steep random deviations.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
                    <div className="p-3 bg-slate-950 border border-slate-900 rounded text-center relative overflow-hidden">
                      <span className="text-[10px] text-slate-500 block mb-1">SHANNON ENTROPY</span>
                      <span className="text-2xl font-bold font-mono text-yellow-400">{dgaResult.entropy}</span>
                      <span className="text-[9px] text-slate-600 block mt-1">Normal: 2.0 - 3.8</span>
                    </div>
                    <div className="p-3 bg-slate-950 border border-slate-900 rounded text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">CONSONANT RATIO</span>
                      <span className="text-2xl font-bold font-mono text-blue-400">
                        {Math.round(dgaResult.consonantRatio * 100)}%
                      </span>
                      <span className="text-[9px] text-slate-600 block mt-1">Normal: 45% - 65%</span>
                    </div>
                    <div className="p-3 bg-slate-950 border border-slate-900 rounded text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">DOMAIN LENGTH</span>
                      <span className="text-2xl font-bold font-mono text-purple-400">{dgaResult.domain.split('.')[0].length}</span>
                      <span className="text-[9px] text-slate-600 block mt-1">Normal: 6 - 15 chars</span>
                    </div>
                  </div>
                </div>

                {/* AI Explanation Summary */}
                <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
                  <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-3 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    COGNITIVE FRAUD REASONING REPORT
                  </h3>
                  <div className="bg-slate-950 border border-slate-900 p-4 rounded text-[11px] font-mono leading-relaxed text-slate-300">
                    {dgaResult.explanation}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono select-none">
                    <span className="text-slate-600">DGA ENRICHMENT SHIELD</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(JSON.stringify(dgaResult, null, 2));
                        setDgaCopied(true);
                        setTimeout(() => setDgaCopied(false), 2000);
                      }}
                      className="text-[9px] font-mono text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-950 border border-slate-900 px-2 py-0.5 rounded cursor-pointer"
                    >
                      {dgaCopied ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                      Copy JSON Result
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
