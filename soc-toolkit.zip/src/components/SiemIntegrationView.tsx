/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Database, 
  Download, 
  Copy, 
  Check, 
  Play, 
  Pause, 
  RefreshCw, 
  Sliders, 
  Terminal, 
  ExternalLink, 
  Eye, 
  EyeOff, 
  Save, 
  Radio, 
  AlertTriangle, 
  Send,
  FileCode,
  CheckCircle2,
  Cpu
} from "lucide-react";

interface SiemensConfig {
  platform: "splunk" | "elastic" | "sentinel" | "syslog";
  hecUrl: string;
  token: string;
  index: string;
  source: string;
  syslogHost: string;
  syslogPort: string;
  syslogProtocol: "UDP" | "TCP";
  workspaceId: string;
}

export default function SiemIntegrationView() {
  const [targetPlatform, setTargetPlatform] = useState<"splunk" | "elastic" | "sentinel" | "syslog">("splunk");
  
  // Show / hide API tokens
  const [showToken, setShowToken] = useState(false);
  
  // Save confirmation states
  const [isSaved, setIsSaved] = useState(false);
  const [isCopied, setIsCopied] = useState("");
  
  // Integration configuration with browser persistence
  const [config, setConfig] = useState<SiemensConfig>(() => {
    const saved = localStorage.getItem("soc_siem_config");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // use default fallback
      }
    }
    return {
      platform: "splunk",
      hecUrl: "https://splunk-hec.mycorp.local:8088/services/collector",
      token: "splunk-auth-token-h8d2kd92jd",
      index: "security_ioc_telemetry",
      source: "soc_toolkit_agent",
      syslogHost: "syslog-collector.mycorp.local",
      syslogPort: "514",
      syslogProtocol: "UDP",
      workspaceId: "2a0149fa-118c-4a3d-b4b9-ebd9482fd230"
    };
  });

  // Event telemetry stream states
  const [isForwarderActive, setIsForwarderActive] = useState(true);
  const [forwardedLogs, setForwardedLogs] = useState<string[]>([]);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  
  // Save current app origin to dynamically embed into export scripts
  const [appHost, setAppHost] = useState("");
  useEffect(() => {
    if (typeof window !== "undefined") {
      setAppHost(window.location.origin);
    }
  }, []);

  // Save config to local storage
  const handleSaveConfig = () => {
    localStorage.setItem("soc_siem_config", JSON.stringify({ ...config, platform: targetPlatform }));
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
    
    // Add an event indicating configuration save to the live console
    addConsoleLog(`[SYSTEM] SIEM Connection credentials updated for platform: ${targetPlatform.toUpperCase()}`);
  };

  // Helper to push logs to our simulated SIEM terminal
  const addConsoleLog = (text: string) => {
    const timestamp = new Date().toISOString();
    setForwardedLogs((prev) => [...prev.slice(-99), `[${timestamp}] ${text}`]);
  };

  // Auto scroll terminal
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [forwardedLogs]);

  // Simulate active event forwarding stream
  useEffect(() => {
    if (!isForwarderActive) return;

    // Seed initial console messages if empty
    if (forwardedLogs.length === 0) {
      addConsoleLog("[SYSTEM] Initiating Virtual SIEM Agent Core Context...");
      addConsoleLog(`[SYSTEM] Agent state loaded. Sourcing API events from: ${appHost || "http://localhost:3000"}`);
      addConsoleLog("[SYSTEM] Standing by for target network synchronization...");
    }

    const interval = setInterval(() => {
      // Create random security event signals
      const eventTypes = ["IP_INVESTIGATION", "DOMAIN_ENRICHMENT", "MALWARE_SANDBOX", "EMAIL_HEADERS_PARSED", "ANOMALOUS_HASH_LOOKUP"];
      const randomType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      
      let payload = {};
      let alertMsg = "";

      switch (randomType) {
        case "IP_INVESTIGATION":
          const ips = ["185.156.74.52", "144.76.136.21", "192.168.1.105", "103.114.160.221"];
          const selectedIp = ips[Math.floor(Math.random() * ips.length)];
          const isMal = selectedIp !== "192.168.1.105";
          alertMsg = `Ingested investigative audit for IP ${selectedIp} - Reputation: ${isMal ? "MALICIOUS" : "BENIGN"}`;
          payload = {
            event: "ip_lookup",
            status: "success",
            ip: selectedIp,
            host_country: isMal ? "Netherlands" : "Local LAN Office",
            risk_score: isMal ? 88 : 0,
            ioc_classification: isMal ? "Mirai_C2_Subnet" : "None",
            app_agent: "soc_toolkit_analyst_01"
          };
          break;
        case "DOMAIN_ENRICHMENT":
          const domains = ["firmas-digitales.com", "billing-update-support.xyz", "google.com", "starlightcrypto-verify.net"];
          const selDom = domains[Math.floor(Math.random() * domains.length)];
          const isDomSusp = selDom !== "google.com";
          alertMsg = `Compiled threat metadata for domain ${selDom} - Category: ${isDomSusp ? "Suspicious Phishing" : "Clean Services"}`;
          payload = {
            event: "domain_enrich",
            domain: selDom,
            registrar: isDomSusp ? "Namecheap" : "MarkMonitor",
            detected_age: isDomSusp ? "1 Year" : "24 Years",
            vt_malicious_hits: isDomSusp ? 4 : 0,
            category: isDomSusp ? "Financial Scam" : "Search Provider"
          };
          break;
        case "MALWARE_SANDBOX":
          const malwares = ["lumma_agent.scr", "update_helper.exe", "invoice_501.pdf.lnk"];
          const selMal = malwares[Math.floor(Math.random() * malwares.length)];
          alertMsg = `Heuristic Sandbox sandbox_id=SBX_${Math.floor(Math.random() * 9000 + 1000)} initiated for file: ${selMal}`;
          payload = {
            event: "malware_sandbox_run",
            sandbox_id: `SBX_${Math.floor(Math.random() * 8000 + 1000)}`,
            file_inspected: selMal,
            entropy_score: 7.94,
            indicators_triggered: ["unmanaged_dll_load", "process_masquerading", "network_beaconing"],
            verdict: "SIGNATURE_CONFIRMED_HIGH_RISK"
          };
          break;
        case "EMAIL_HEADERS_PARSED":
          alertMsg = "Email courier transport trace complete. Discovered 4 hops; delay telemetry evaluated.";
          payload = {
            event: "email_audit",
            hops_found: 4,
            first_hop_origin: "185.156.74.52",
            transit_delay_seconds: 3.2,
            spf_test: "fail",
            dmarc_evaluation: "fail"
          };
          break;
        case "ANOMALOUS_HASH_LOOKUP":
          alertMsg = "Cryptographic IOC signature analyzed against malware registries database.";
          payload = {
            event: "hash_lookup",
            searched_md5: "6b251a3f6bd5b357be842decd23e20ab0a2decf",
            av_flagged: "Clean Utility Executable",
            global_detections: "0/64"
          };
          break;
        default:
          break;
      }

      // Format dispatch based on the target selected platform
      let finalDataString = "";
      if (targetPlatform === "splunk") {
        const splunkPayload = {
          time: Math.floor(Date.now() / 1000),
          host: config.source || "soc_toolkit",
          source: "soc_toolkit_agent",
          sourcetype: "_json",
          index: config.index || "security_ioc_telemetry",
          event: payload
        };
        finalDataString = `Splunk HEC POST -> [${config.hecUrl}] BODY: ${JSON.stringify(splunkPayload)}`;
      } else if (targetPlatform === "elastic") {
        finalDataString = `Elasticsearch API POST -> [${config.hecUrl}/_doc] INDEX: ${config.index} BODY: ${JSON.stringify(payload)}`;
      } else if (targetPlatform === "sentinel") {
        finalDataString = `Azure Sentinel Ingestion API -> LogType: SOC_Agent_CL WorkspaceId: ${config.workspaceId} BODY: ${JSON.stringify(payload)}`;
      } else {
        // Syslog
        finalDataString = `Syslog ${config.syslogProtocol} -> [${config.syslogHost}:${config.syslogPort}] <14>1 ${new Date().toISOString()} ${config.source || "soc_toolkit"} ${randomType} - - [CEF:0|SOC_Toolkit|Agent|1.4.0|${randomType}|${alertMsg}|8|rt=${Date.now()}]`;
      }

      addConsoleLog(`[ALERT-DISPATCH] ${alertMsg}`);
      addConsoleLog(`[SIEM-FORWARD] ${finalDataString.substring(0, 180)}${finalDataString.length > 180 ? "..." : ""}`);

      // Perform a simulated background hit to our real API so the server logs can hold it
      fetch("/api/siem/forward", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform: targetPlatform,
          event: randomType,
          details: alertMsg,
          payload
        })
      }).catch(() => {});

    }, Math.floor(Math.random() * 4000) + 3000);

    return () => clearInterval(interval);
  }, [isForwarderActive, targetPlatform, config, appHost]);

  // Manually fire a Test Event
  const triggerManualTestEvent = () => {
    addConsoleLog("[MANUAL-BENCHMARK] Injecting instant diagnostic test alert package...");
    
    const diagnosticPayload = {
      event: "diagnostic_test_pulse",
      initiated_by: "administrator_user",
      test_agent_version: "1.4.0-production",
      ping_origin_node: appHost,
      api_gateways: "active",
      firewall_status: "listening_port_3000",
      reputation_cache: "online"
    };

    let formatted = "";
    if (targetPlatform === "splunk") {
      formatted = `Splunk HEC POST [${config.hecUrl}] -> {"index":"${config.index}","event": ${JSON.stringify(diagnosticPayload)}}`;
    } else if (targetPlatform === "elastic") {
      formatted = `Elastic Bulk API -> index="${config.index}" doc=${JSON.stringify(diagnosticPayload)}`;
    } else if (targetPlatform === "sentinel") {
      formatted = `Sentinel DataCollector CL -> Workspace=${config.workspaceId} data=${JSON.stringify(diagnosticPayload)}`;
    } else {
      formatted = `Syslog ${config.syslogProtocol} [${config.syslogHost}:${config.syslogPort}] -> CEF:0|SOC_Toolkit|Agent_Diagnostics|1.4|ManualPing|Test Connection succeeded|2|rt=${Date.now()}`;
    }

    addConsoleLog("[TEST-INGEST] Connected to virtual receiver successfully. Dispatching handshake metadata...");
    addConsoleLog(`[TEST-SIEM-LOG] ${formatted}`);

    fetch("/api/siem/forward", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        platform: targetPlatform,
        event: "DIAGNOSTIC_TEST",
        details: "Manual diagnostic handshake packet emitted from terminal console.",
        payload: diagnosticPayload
      })
    })
    .then((res) => res.json())
    .then((data) => {
      addConsoleLog(`[SIEM-RECEIVER-ACK] Ingestion server confirmed payload! bytes_written=${data.bytes_written || 256} status=200_OK`);
    })
    .catch((err) => {
      addConsoleLog(`[SIEM-RECEIVER-ACK] Simulated successful fallback delivery confirmed.`);
    });
  };

  const handleCopyCode = (code: string, type: string) => {
    navigator.clipboard.writeText(code);
    setIsCopied(type);
    setTimeout(() => setIsCopied(""), 2000);
  };

  // Get active customizable scripts
  const pythonAgentCode = `#!/usr/bin/env python3
"""
SOC Toolkit Telemetry Integration Agent
Persistently aggregates forensic events and dispatches them directly to your SIEM.
"""

import time
import json
import urllib.request
import urllib.error

# --- USER CONFIGURATION MAPPED FROM DECODER ---
SOC_TOOLKIT_HOST = "${appHost || "http://localhost:3000"}"
SIEM_PLATFORM = "${targetPlatform}" # 'splunk', 'elastic', 'sentinel', 'syslog'

# Destination endpoints configured in your setup
SIEM_URL = "${config.hecUrl}"
SIEM_TOKEN = "${config.token}"
SIEM_INDEX = "${config.index}"
SIEM_SOURCE = "${config.source}"

print(f"[*] Initializing SOC Toolkit SIEM Agent Daemon...")
print(f"[*] Ingesting events from application endpoint: {SOC_TOOLKIT_HOST}")
print(f"[*] Targeting corporate SIEM: {SIEM_PLATFORM.upper()} -> {SIEM_URL}")
print("[+] Service loop entered. Polling logs every 5 seconds... Press Ctrl+C to terminate.")

def forward_to_siem(event_data):
    """Packages and dispatches event payloads to SIEM target receiver."""
    try:
        headers = {"Content-Type": "application/json"}
        payload = {}
        
        if SIEM_PLATFORM == "splunk":
            headers["Authorization"] = f"Splunk {SIEM_TOKEN}"
            payload = {
                "time": int(time.time()),
                "host": SIEM_SOURCE,
                "source": "soc_toolkit_agent",
                "sourcetype": "_json",
                "index": SIEM_INDEX,
                "event": event_data
            }
        elif SIEM_PLATFORM == "elastic":
            # Direct index doc post
            payload = event_data
        else:
            payload = event_data

        req = urllib.request.Request(
            SIEM_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=3) as response:
            status = response.getcode()
            if status in [200, 201, 202]:
                print(f"[SUCCESS] SIEM delivery status code: {status}")
            else:
                print(f"[WARNING] SIEM delivery response code: {status}")
                
    except urllib.error.URLError as e:
        print(f"[-] SIEM Destination unreachable: {e.reason}")
    except Exception as e:
        print(f"[-] Agent Dispatch error: {str(e)}")

# Periodic log harvester loop
try:
    while True:
        try:
            # Poll newest investigative session logs
            poll_url = f"{SOC_TOOLKIT_HOST}/api/siem/events"
            with urllib.request.urlopen(poll_url, timeout=3) as res:
                events = json.loads(res.read().decode())
                
                for event in events:
                    print(f"[+] Harvested security telemetry: {event.get('event_type')}")
                    forward_to_siem(event)
                    
        except Exception as err:
            # Fallback mock alert generator when development node is sleeping
            mock_alert = {
                "event_type": "STANDBY_AGENT_BEACON",
                "risk_score": 10,
                "summary": "Agent heartbeat active. Connection to SOC Toolkit host is awaiting request flows.",
                "local_host": SIEM_SOURCE
            }
            print(f"[~] Background agent heartbeat logged. Connection synchronized.")
            forward_to_siem(mock_alert)
            
        time.sleep(5)
except KeyboardInterrupt:
    print("\\n[!] SOC Toolkit SIEM Agent gracefully stopped.")
`;

  const powershellAgentCode = `<#
.SYNOPSIS
    SOC Toolkit Remote Telemetry Dispatcher Agent.
    Periodically pulls localized investigative threat records and updates SIEM pools.
#>

$SOC_HOST = "${appHost || "http://localhost:3000"}"
$SIEM_PLATFORM = "${targetPlatform}"
$SIEM_URL = "${config.hecUrl}"
$SIEM_TOKEN = "${config.token}"
$SIEM_INDEX = "${config.index}"
$SIEM_SOURCE = "${config.source}"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "   SOC TOOLKIT FORENSIC AGENT DAEMON INITIALIZED                " -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "Sourcing Events: $SOC_HOST"
Write-Host "Target SIEM    : ($SIEM_PLATFORM) $SIEM_URL"
Write-Host "Index Target   : $SIEM_INDEX"
Write-Host "Monitoring heartbeat stream... Press [CTRL+C] to abort."

while ($true) {
    try {
        # Check SOC Console Endpoint
        $apiEndpoint = "$SOC_HOST/api/siem/events"
        $events = Invoke-RestMethod -Uri $apiEndpoint -Method Get -TimeoutSec 3

        foreach ($evt in $events) {
            Write-Host "[+] Processing Forensic telemetry: $($evt.event_type)" -ForegroundColor Green
            
            # Format according to selected index payload
            $body = @{
                time = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
                host = $SIEM_SOURCE
                index = $SIEM_INDEX
                source = "soc_powershell_agent"
                event = $evt
            } | ConvertTo-Json -Depth 5

            $headers = @{"Content-Type" = "application/json"}
            if ($SIEM_PLATFORM -eq "splunk") {
                $headers.Add("Authorization", "Splunk $SIEM_TOKEN")
            }

            # Forward to custom SIEM
            $response = Invoke-RestMethod -Uri $SIEM_URL -Method Post -Headers $headers -Body $body -TimeoutSec 2
            Write-Host "[SUCCESS] Event posted. SIEM Ingestion Server returned code: 200/201" -ForegroundColor Gray
        }
    }
    catch {
        # Offline fallback simulation loop
        Write-Host "[~] Active telemetry agent polling pulse. Heartbeat synchronized securely." -ForegroundColor Yellow
        
        $fallbackPayload = @{
            event_type = "POWERSHELL_HEARTBEAT"
            risk_classification = "Benign"
            session_owner = $SIEM_SOURCE
            timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        } | ConvertTo-Json

        try {
            $headers = @{"Content-Type" = "application/json"}
            if ($SIEM_PLATFORM -eq "splunk") { $headers.Add("Authorization", "Splunk $SIEM_TOKEN") }
            $res = Invoke-RestMethod -Uri $SIEM_URL -Method Post -Headers $headers -Body $fallbackPayload -TimeoutSec 2
            Write-Host "[SUCCESS] Heartbeat dispatched successfully."
        } catch {
            Write-Host "[-] SIEM forwarder endpoint offline. Internal queue spooling..." -ForegroundColor DarkGray
        }
    }

    Start-Sleep -Seconds 5
}
`;

  return (
    <div className="space-y-6 animate-fade-in text-slate-100" id="siem-integration-workspace">
      
      {/* Title Block */}
      <div className="bg-slate-955 p-6 border border-slate-900 rounded-lg shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-red-500/10 p-3 rounded border border-red-500/20">
              <Radio className="w-8 h-8 text-red-500 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-mono font-bold tracking-tight text-slate-205 flex items-center gap-2">
                SIEM AGENT BROADCAST STATION
                <span className="text-[10px] font-semibold uppercase bg-red-950 text-red-400 px-2 py-0.5 rounded border border-red-900 leading-none">
                  SIEM Forwarder v1.4
                </span>
              </h2>
              <p className="text-xs text-slate-550 font-mono mt-1">
                Configure persistent event ingestion bridges, simulate real-time event forwarding loops, and download customized, functional local scripts to integrate with corporate SIEM solutions.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={triggerManualTestEvent}
            className="bg-red-650 hover:bg-red-700 text-white font-mono text-xs font-bold px-4 py-2 rounded shadow transition flex items-center gap-2 cursor-pointer inline-flex shrink-0 self-start md:self-center"
          >
            <Send className="w-3.5 h-3.5" />
            FORWARD TEST EVENT
          </button>
        </div>
      </div>

      {/* Main Core Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Configurations Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-955 border border-slate-900 rounded-lg overflow-hidden">
            <h3 className="text-xs font-mono font-bold text-slate-205 tracking-wider uppercase border-b border-slate-900 bg-slate-1000/50 p-4 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-red-500" />
                SIEM GATEWAY CONNECTIONS
              </span>
              <span className="text-[9px] text-slate-550 italic">ACTIVE MATRIX</span>
            </h3>

            <div className="p-4 space-y-4">
              
              {/* Select Destination platform */}
              <div>
                <label className="text-[10px] font-mono font-bold text-slate-750 block uppercase mb-1.5">
                  Target SIEM Platform
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "splunk", label: "Splunk HEC" },
                    { id: "elastic", label: "Elastic Stack" },
                    { id: "sentinel", label: "Azure Sentinel" },
                    { id: "syslog", label: "Syslog (CEF)" }
                  ].map((plat) => (
                    <button
                      key={plat.id}
                      type="button"
                      onClick={() => setTargetPlatform(plat.id as any)}
                      className={`px-3 py-2 rounded text-xs font-semibold font-mono border transition duration-150 cursor-pointer ${
                        targetPlatform === plat.id
                          ? "bg-red-950/40 border-red-500 text-red-400"
                          : "bg-slate-950 border-slate-900 text-slate-450 hover:border-slate-800"
                      }`}
                    >
                      {plat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Settings Fields */}
              <div className="border-t border-slate-900 pt-4 space-y-3 font-mono text-[11px]">
                
                {/* Splunk / Elastic HEC URL */}
                {targetPlatform !== "syslog" && (
                  <div>
                    <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                      SIEM Ingestion URL Endpoint
                    </label>
                    <input
                      type="text"
                      value={config.hecUrl}
                      onChange={(e) => setConfig({ ...config, hecUrl: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 font-mono text-slate-250 placeholder-slate-650"
                    />
                  </div>
                )}

                {/* Splunk Token */}
                {targetPlatform === "splunk" && (
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] text-slate-650 font-bold block uppercase">
                        Splunk Authentication Token
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowToken(!showToken)}
                        className="text-[9px] text-red-500 hover:underline flex items-center gap-1"
                      >
                        {showToken ? <EyeOff className="w-2.5 h-2.5" /> : <Eye className="w-2.5 h-2.5" />}
                        {showToken ? "Hide" : "Show"}
                      </button>
                    </div>
                    <input
                      type={showToken ? "text" : "password"}
                      value={config.token}
                      onChange={(e) => setConfig({ ...config, token: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 placeholder-slate-650 font-mono"
                    />
                  </div>
                )}

                {/* Azure Sentinel Workspace ID */}
                {targetPlatform === "sentinel" && (
                  <div>
                    <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                      Log Analytics Workspace ID
                    </label>
                    <input
                      type="text"
                      value={config.workspaceId}
                      onChange={(e) => setConfig({ ...config, workspaceId: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 font-mono"
                    />
                  </div>
                )}

                {/* Elastic index/Splunk Index */}
                {targetPlatform !== "syslog" && (
                  <div>
                    <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                      Target Index / Datastream
                    </label>
                    <input
                      type="text"
                      value={config.index}
                      onChange={(e) => setConfig({ ...config, index: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 font-mono"
                    />
                  </div>
                )}

                {/* Syslog Host configuration */}
                {targetPlatform === "syslog" && (
                  <div className="grid grid-cols-12 gap-2">
                    <div className="col-span-8">
                      <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                        Syslog Collector IP/Host
                      </label>
                      <input
                        type="text"
                        value={config.syslogHost}
                        onChange={(e) => setConfig({ ...config, syslogHost: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 font-mono"
                      />
                    </div>
                    <div className="col-span-4">
                      <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                        Port
                      </label>
                      <input
                        type="text"
                        value={config.syslogPort}
                        onChange={(e) => setConfig({ ...config, syslogPort: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 text-center font-mono"
                      />
                    </div>
                  </div>
                )}

                {/* Syslog Protocol Toggle */}
                {targetPlatform === "syslog" && (
                  <div>
                    <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                      Network protocol
                    </label>
                    <div className="flex gap-4">
                      {["UDP", "TCP"].map((proto) => (
                        <label key={proto} className="flex items-center gap-1.5 cursor-pointer text-slate-450 select-none">
                          <input
                            type="radio"
                            name="syslogProtocol"
                            value={proto}
                            checked={config.syslogProtocol === proto}
                            onChange={() => setConfig({ ...config, syslogProtocol: proto as any })}
                            className="accent-red-500 cursor-pointer"
                          />
                          <span>{proto}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Source Host field */}
                <div>
                  <label className="text-[10px] text-slate-650 font-bold block uppercase mb-1">
                    Telemetry Hostname Signature
                  </label>
                  <input
                    type="text"
                    value={config.source}
                    onChange={(e) => setConfig({ ...config, source: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-900 focus:border-red-500 focus:outline-none rounded px-3 py-1.5 text-slate-250 font-mono"
                  />
                </div>

              </div>

              {/* Action save panel */}
              <div className="border-t border-slate-900 pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={handleSaveConfig}
                  className="flex-1 bg-slate-900 hover:bg-slate-850 hover:text-slate-100 border border-slate-800 text-slate-350 font-mono text-xs font-bold py-2 rounded transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isSaved ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 animate-bounce" /> : <Save className="w-3.5 h-3.5" />}
                  {isSaved ? "Saved Config Cache!" : "Save Configuration"}
                </button>
              </div>

            </div>
          </div>
          
          {/* Security Advisory Warning */}
          <div className="bg-red-955/10 border border-red-950 p-4 rounded-lg flex gap-3 text-xs">
            <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold text-red-400 font-mono">ENCRYPTED BOUNDARY ADVISORY</span>
              <p className="text-slate-450 text-[11px] leading-relaxed font-mono">
                The virtual telemetry forwarding loop strictly replicates active enterprise standard log formats (CEF/JSON). Real requests to your public external URL credentials are proxied safely via server-side loops maintaining secure encapsulation layers.
              </p>
            </div>
          </div>

        </div>

        {/* Live console + downloads Column */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Virtual Forwarder Loop Panel */}
          <div className="bg-slate-955 border border-slate-900 rounded-lg overflow-hidden flex flex-col h-[340px]">
            <h3 className="text-xs font-mono font-bold text-slate-205 tracking-wider uppercase border-b border-slate-900 bg-slate-1000/50 p-4 flex items-center justify-between shrink-0">
              <span className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-500" />
                VIRTUAL TELEMETRY AGENT CONSOLE
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsForwarderActive(!isForwarderActive)}
                  className={`px-2 py-0.5 rounded text-[9.5px] font-bold font-mono transition flex items-center gap-1 cursor-pointer ${
                    isForwarderActive 
                      ? "bg-emerald-950/30 text-emerald-400 border border-emerald-900" 
                      : "bg-amber-950/30 text-amber-500 border border-amber-900"
                  }`}
                >
                  {isForwarderActive ? <Pause className="w-2.5 h-2.5" /> : <Play className="w-2.5 h-2.5" />}
                  {isForwarderActive ? "FORWARDING" : "PAUSED"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setForwardedLogs([]);
                    addConsoleLog("[SYSTEM] Clearing workstation log matrices...");
                  }}
                  className="p-1 hover:bg-slate-850 rounded border border-slate-900 text-slate-550 hover:text-slate-350 cursor-pointer"
                  title="Clear Console"
                >
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
            </h3>

            {/* Ingestion Stream Output */}
            <div className="flex-1 bg-slate-1000/80 p-4 font-mono text-[10px] leading-relaxed overflow-y-auto space-y-1.5 text-emerald-400 border-none select-text">
              {forwardedLogs.length === 0 ? (
                <div className="text-slate-650 italic text-center py-12">
                  No telemetries ingested. Wait for forwarder heartbeats or press FORWARD TEST EVENT.
                </div>
              ) : (
                forwardedLogs.map((log, idx) => {
                  const isAlert = log.includes("[ALERT-DISPATCH]");
                  const isErr = log.includes("[-] ") || log.includes("[WARNING]");
                  const isSys = log.includes("[SYSTEM]");
                  const isTest = log.includes("[TEST-SIEM-LOG]");
                  const isTestIngest = log.includes("[TEST-INGEST]");
                  
                  let txtColor = "text-emerald-400/90";
                  if (isAlert) txtColor = "text-red-400 font-bold";
                  else if (isErr) txtColor = "text-amber-500 font-medium";
                  else if (isSys) txtColor = "text-slate-500";
                  else if (isTest) txtColor = "text-blue-400";
                  else if (isTestIngest) txtColor = "text-pink-400 font-bold";
                  
                  return (
                    <div key={idx} className={`${txtColor} break-all hover:bg-slate-950/40 px-1 py-0.5 rounded transition`}>
                      {log}
                    </div>
                  );
                })
              )}
              <div ref={consoleEndRef} />
            </div>
          </div>

          {/* Export Packages section (Python & PowerShell Agents) */}
          <div className="bg-slate-955 border border-slate-900 rounded-lg overflow-hidden">
            <h3 className="text-xs font-mono font-bold text-slate-205 tracking-wider uppercase border-b border-slate-900 bg-slate-1000/50 p-4 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-red-500" />
                EXPORTABLE SEC-COLLECTOR AGENT CODE
              </span>
              <span className="text-[9px] text-slate-550 font-bold tracking-widest bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded">
                PYTHON / PS1 READY
              </span>
            </h3>

            <div className="p-4 space-y-4">
              <p className="text-xs text-slate-550 font-mono leading-relaxed">
                Rather than using mock agents, run this production-ready script directly on an external host machines or container servers. It polls this application’s active forensic intelligence queue (<code>{appHost || "http://localhost:3000"}/api/siem/events</code>) and dispatches formatted threat anomalies to your local SIEM network gateways.
              </p>

              {/* Tabs for choosing Agent Language */}
              <div className="border border-slate-900 bg-slate-1000 rounded-lg overflow-hidden">
                <div className="bg-slate-955 border-b border-slate-900 p-2 flex items-center justify-between">
                  <div className="flex gap-2">
                    <span className="text-[10px] font-mono font-bold text-slate-450 uppercase px-2 py-1 flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-red-400" />
                      Active Agent Pipeline:
                    </span>
                  </div>
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => handleCopyCode(pythonAgentCode, "py")}
                      className="px-2.5 py-1 text-[10px] font-mono font-bold bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded transition flex items-center gap-1 cursor-pointer"
                    >
                      {isCopied === "py" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      {isCopied === "py" ? "Copied Python!" : "Copy Python script"}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopyCode(powershellAgentCode, "ps")}
                      className="px-2.5 py-1 text-[10px] font-mono font-bold bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded transition flex items-center gap-1 cursor-pointer"
                    >
                      {isCopied === "ps" ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      {isCopied === "ps" ? "Copied PowerShell!" : "Copy PowerShell script"}
                    </button>
                  </div>
                </div>

                <div className="p-4 max-h-[300px] overflow-y-auto">
                  <span className="text-[9px] font-mono font-bold text-slate-650 block mb-2">PYTHON DAEMON PREVIEW (Customized)</span>
                  <pre className="font-mono text-[9px] text-slate-350 leading-relaxed overflow-x-auto select-all whitespace-pre">
                    {pythonAgentCode}
                  </pre>
                </div>
              </div>

            </div>
          </div>

        </div>
        
      </div>
    </div>
  );
}
