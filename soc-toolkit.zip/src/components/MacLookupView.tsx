/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Search,
  Cpu,
  ShieldAlert,
  HelpCircle,
  Copy,
  Check,
  Binary,
  Layers,
  Info,
  Server,
  Terminal,
  RefreshCw
} from "lucide-react";

interface MacAnalysisResult {
  macAddress: string;
  oui: string;
  vendor: string;
  assignment: string;
  macType: string;
  scope: string;
  isRandomized: boolean;
  securityReputation: string;
  securityNote: string;
  diagnosticDetails: string;
}

export default function MacLookupView() {
  const [macInput, setMacInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MacAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Common samples for quick validation
  const sampleMacs = [
    { label: "Apple", mac: "3c-a6-2f-5b-11-20" },
    { label: "Cisco Systems", mac: "00:00:0C:44:55:66" },
    { label: "VMware Controller", mac: "00:50:56:AB:CD:EF" },
    { label: "VirtualBox", mac: "08:00:27:12:34:56" },
    { label: "Randomized Address", mac: "AE:1A:11:FC:02:88" }
  ];

  const handleLookup = async (address: string) => {
    const trimmed = address.trim();
    if (!trimmed) {
      setError("Please key in a MAC address to check.");
      return;
    }

    // Clean hex check
    const hexOnly = trimmed.replace(/[^0-9A-Fa-f]/gi, "");
    if (hexOnly.length < 6) {
      setError("MAC Address must specify at least the first 6 hexadecimal characters (OUI segment).");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/mac/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mac: trimmed }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to resolve MAC address signature.");
      }

      const data: MacAnalysisResult = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during OUI database querying.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Binary decode utility for rendering first octet bits
  const getFirstOctetBits = () => {
    if (!result) return null;
    const clean = result.macAddress.replace(/[^0-9A-F]/gi, "");
    if (clean.length < 2) return null;
    const firstOctetHex = clean.substring(0, 2);
    const firstOctetVal = parseInt(firstOctetHex, 16);
    const binaryStr = firstOctetVal.toString(2).padStart(8, "0");
    return {
      hex: firstOctetHex,
      bits: binaryStr.split(""),
      val: firstOctetVal
    };
  };

  const octetBits = getFirstOctetBits();

  return (
    <div className="space-y-6">
      {/* Search Console */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-400" />
          MAC ADDRESS OUI RESOLVER & INTERFACE DECODER
        </h2>
        <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
          Deconstruct Layer-2 MAC hardware identifiers. Retrieve OUI manufacturer allocations, determine local address randomization indicators, and analyze unicast vs multicast Ethernet transmission tags.
        </p>

        <div className="space-y-3">
          <div className="flex gap-2 max-w-2xl">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input
                id="mac-address-input"
                type="text"
                placeholder="Enter MAC address (e.g., 3C:A6:2F:5B:11:20 or 0015.5Daa.bcde)..."
                value={macInput}
                onChange={(e) => setMacInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLookup(macInput)}
                className="w-full bg-slate-950 border border-slate-850 focus:border-emerald-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-600"
              />
            </div>
            <button
              onClick={() => handleLookup(macInput)}
              disabled={loading}
              className="bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 px-5 py-2 rounded text-xs font-mono transition font-bold cursor-pointer disabled:opacity-50"
            >
              {loading ? "SEARCHING..." : "RUN OUI CODES"}
            </button>
          </div>

          {/* Quick Examples */}
          <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-[10px]">
            <span className="text-slate-600 uppercase font-semibold">Pre-cached Samples:</span>
            {sampleMacs.map((samp, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setMacInput(samp.mac);
                  handleLookup(samp.mac);
                }}
                className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 px-2 py-0.5 rounded transition cursor-pointer"
              >
                {samp.label}
              </button>
            ))}
          </div>

          {error && (
            <div className="p-3 bg-red-950/20 border border-red-900/50 rounded flex items-center gap-2 text-xs font-mono text-red-400">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center p-12 bg-slate-950/40 border border-slate-900 rounded space-y-3">
          <div className="relative flex h-8 w-8">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-8 w-8 bg-emerald-600"></span>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Querying OUI hardware indexes and computing binary parity flags...
          </span>
        </div>
      )}

      {result && !loading && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          {/* Summary Column */}
          <div className="space-y-4">
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 relative overflow-hidden">
              <div className={`absolute top-0 left-0 right-0 h-1 ${
                result.isRandomized ? "bg-amber-500" : "bg-emerald-500"
              }`} />

              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-mono font-bold text-slate-400 uppercase">Hardware Registry</span>
                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border uppercase ${
                  result.isRandomized
                    ? "bg-amber-950 text-amber-500 border-amber-950"
                    : "bg-emerald-950 text-emerald-500 border-emerald-950"
                }`}>
                  {result.isRandomized ? "RANDOMIZED MAC" : "BURNED-IN (BIA)"}
                </span>
              </div>

              <div className="flex items-center gap-3 border-b border-slate-900 pb-4 mb-4">
                <Cpu className={`w-8 h-8 text-slate-500 ${result.isRandomized ? "text-amber-500 animate-pulse" : "text-emerald-500"}`} />
                <div className="min-w-0">
                  <h3 className="text-sm font-mono font-bold text-slate-100 truncate">{result.macAddress}</h3>
                  <span className="text-[10px] font-mono text-slate-500 uppercase font-semibold">OUI: {result.oui}</span>
                </div>
              </div>

              {/* Hardware Information Table */}
              <div className="space-y-3 font-mono text-[11px]">
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">MANUFACTURER:</span>
                  <span className="text-slate-200 truncate max-w-[170px] text-right font-bold">{result.vendor}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">BLOCK RESOLVED:</span>
                  <span className="text-slate-350">{result.assignment}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">TRANSMISSION:</span>
                  <span className="text-slate-350">{result.macType}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900/40 pb-1.5">
                  <span className="text-slate-500">ADMIN SCOPE:</span>
                  <span className="text-slate-350">{result.scope}</span>
                </div>
              </div>

              {/* Quick Status Tagging */}
              <div className="mt-4 pt-3 border-t border-slate-900">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-semibold block mb-2">
                  Privacy Reputation Status
                </span>
                <div className="p-2.5 bg-slate-950 rounded border border-slate-900 text-[10px] font-mono leading-relaxed text-slate-400">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${result.isRandomized ? "bg-amber-400" : "bg-emerald-400"}`} />
                    <span className="text-slate-200 uppercase font-bold text-[9px]">{result.securityReputation}</span>
                  </div>
                  {result.securityNote}
                </div>
              </div>
            </div>
          </div>

          {/* Details Column (Middle and Right together) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Multi-Bit Analysis (Real Science Visual!) */}
            {octetBits && (
              <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
                <h3 className="text-xs font-mono font-bold text-slate-200 tracking-wider uppercase mb-1.5 flex items-center gap-2">
                  <Binary className="w-4 h-4 text-emerald-400" />
                  FIRST OCTET BINARY DIAGNOSTICS & PARITY CORRELATION
                </h3>
                <p className="text-[10px] font-mono text-slate-500 mb-4">
                  The first physical octet of a MAC address (Hex: <span className="text-slate-350 font-bold">{octetBits.hex}</span>, Dec: <span className="text-slate-350 font-bold">{octetBits.val}</span>) holds metadata bits defining frame transmission scale and privacy profiles.
                </p>

                {/* Binary visual grid */}
                <div className="bg-slate-950 border border-slate-900 rounded p-4 mb-4">
                  <div className="grid grid-cols-8 gap-1.5 text-center font-mono">
                    {octetBits.bits.map((bit, i) => {
                      // Highlighting Bit 7 (Transmission - index 7) and Bit 6 (Administration - index 6)
                      const isTransBit = i === 7;
                      const isAdminBit = i === 6;
                      return (
                        <div key={i} className="space-y-1">
                          <span className="text-[9px] text-slate-600 block">BIT {7 - i}</span>
                          <div className={`p-2 border rounded font-bold text-xs ${
                            isTransBit ? "bg-emerald-950/40 text-emerald-400 border-emerald-500/40" :
                            isAdminBit ? "bg-amber-950/40 text-amber-400 border-amber-500/40" :
                            "bg-slate-900 border-slate-800 text-slate-400"
                          }`}>
                            {bit}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Explanations of decoded bits */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 text-[10px] font-mono pt-3 border-t border-slate-900">
                    <div className="p-2 rounded bg-emerald-950/10 border border-emerald-900/30">
                      <span className="text-emerald-400 font-bold block mb-0.5 uppercase">
                        Bit 0 (I/G Bit - Individual/Group)
                      </span>
                      <span>
                        Value is <strong className="text-slate-100">{octetBits.bits[7]}</strong>. 
                        {octetBits.bits[7] === "0" 
                          ? " Set to 0, establishing Unicast mapping (standard device communication directly to a single routing segment)."
                          : " Set to 1, representing Multicast/Broadcast addressing which target grouped segment distributions."}
                      </span>
                    </div>

                    <div className="p-2 rounded bg-amber-950/10 border border-amber-900/30">
                      <span className="text-amber-400 font-bold block mb-0.5 uppercase">
                        Bit 1 (U/L Bit - Universal/Local)
                      </span>
                      <span>
                        Value is <strong className="text-slate-100">{octetBits.bits[6]}</strong>. 
                        {octetBits.bits[6] === "0"
                          ? " Set to 0, proving Universal/Global registry. Manufacturers burn this OUI permanently at factory segments."
                          : " Set to 1, displaying Local Administration. This proves a software-defined randomized or virtual interface."}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* AI Diagnostics & System Security Guidance */}
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4">
              <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                FORENSIC HARDWARE SIGNATURE ANALYSIS
              </h3>
              
              <div className="bg-slate-950 border border-slate-900 p-3.5 rounded font-mono text-xs text-slate-300 leading-relaxed mb-4">
                <div className="flex items-start gap-1.5">
                  <Info className="w-4 h-4 shrink-0 text-blue-400 mt-0.5" />
                  <div>
                    <span className="text-slate-400 uppercase font-semibold block mb-1">Diagnostic Verification</span>
                    <p className="text-slate-300 text-[11px] font-normal leading-sm">
                      {result.diagnosticDetails}
                    </p>
                  </div>
                </div>
              </div>

              {/* MAC address spoofing and diagnostics information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] font-mono leading-relaxed">
                <div className="p-3 bg-slate-950 border border-slate-900/80 rounded space-y-1">
                  <span className="text-slate-400 font-bold uppercase block">ARP Spoofing Risk Analysis</span>
                  <p className="text-slate-500 text-[10px]">
                    Adversaries readily spoof MAC addresses to listen to segmented broadcast streams (ARP Poisoning). Always compare the parsed OUI manufacturer vendor with active DHCP leases to spot discrepancies in hostname footprints.
                  </p>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-900/80 rounded space-y-1">
                  <span className="text-slate-400 font-bold uppercase block">Audit & Incident Best Practice</span>
                  <p className="text-slate-500 text-[10px]">
                    If a locally-administered randomized MAC targets system assets on unauthorized networks, isolate the port and inspect endpoints for tools like Macchanger or security rotations in client registry settings of the OS.
                  </p>
                </div>
              </div>

              {/* Footer copy options */}
              <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center select-none text-[10px] font-mono">
                <span className="text-slate-600">LAYER-2 OSI PHYSICAL IDENTIFIERS</span>
                <button
                  onClick={handleCopy}
                  className="text-[9px] font-mono text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-950 border border-slate-900 px-2.5 py-1 rounded cursor-pointer"
                >
                  {copied ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                  Copy Output JSON
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
