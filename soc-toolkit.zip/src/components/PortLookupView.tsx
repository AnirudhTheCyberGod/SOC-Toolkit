/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Binary,
  Search,
  ShieldCheck,
  AlertTriangle,
  Info,
  Layers,
  ArrowRight,
  ShieldAlert,
  Server,
  Zap,
  Tag,
  Copy,
  Check
} from "lucide-react";

interface PortProtocolDetail {
  port: string;
  name: string;
  transport: "TCP" | "UDP" | "Both";
  category: "Web & Content" | "Active Directory & Windows" | "Database" | "Infrastructure" | "File Transfer" | "Mail Services";
  description: string;
  securityRecommendation: string;
  isHighRiskExposure: boolean;
}

const standardPortsDatabase: PortProtocolDetail[] = [
  {
    port: "21",
    name: "FTP (File Transfer Protocol)",
    transport: "TCP",
    category: "File Transfer",
    description: "Used for transferring files between client and server. Transmits accounts, credentials, and payload files in cleartext.",
    securityRecommendation: "Highly discouraged. Prefer SFTP (SSH-based, Port 22) or FTPS (TLS-secured) to wrap data payloads securely.",
    isHighRiskExposure: true
  },
  {
    port: "22",
    name: "SSH (Secure Shell) / SFTP",
    transport: "TCP",
    category: "Infrastructure",
    description: "Standard for secure remote network logins, remote command execution, and encrypted file transfers.",
    securityRecommendation: "Should never be exposed wide to the index Internet. Implement source IP whitelisting or VPN ingress access.",
    isHighRiskExposure: true
  },
  {
    port: "23",
    name: "Telnet",
    transport: "TCP",
    category: "Infrastructure",
    description: "Legacy unencrypted command-line session protocol. Credentials and keystrokes travel in clear raw text.",
    securityRecommendation: "CRITICAL: Disable immediately on corporate endpoints. Replace with SSH (Port 22) to enforce encryption.",
    isHighRiskExposure: true
  },
  {
    port: "25",
    name: "SMTP (Simple Mail Transfer Protocol)",
    transport: "TCP",
    category: "Mail Services",
    description: "Primary protocol for routing email traffic across the Internet. Vulnerable to open relay hijackings and mass phishing injections.",
    securityRecommendation: "Block external ingestion relays. Secure mailhops using Opportunistic TLS/STARTTLS to encrypt in flight.",
    isHighRiskExposure: false
  },
  {
    port: "53",
    name: "DNS (Domain Name System)",
    transport: "Both",
    category: "Infrastructure",
    description: "Resolves domain hostnames into numeric IP addresses. UDP is typical for queries, TCP for zone transfers/large responses.",
    securityRecommendation: "Protect against DNS spoofing, cache poisoning, and DNS amplification DDOS. Lock down DNS zone transfer rights.",
    isHighRiskExposure: false
  },
  {
    port: "80",
    name: "HTTP (Hypertext Transfer Protocol)",
    transport: "TCP",
    category: "Web & Content",
    description: "The foundation of data communication for the World Wide Web. Sends headers and body payloads unencrypted.",
    securityRecommendation: "Redirect all cleartext port 80 traffic to HTTPS (Port 443) and enforce HTTP Strict Transport Security (HSTS).",
    isHighRiskExposure: false
  },
  {
    port: "88",
    name: "Kerberos",
    transport: "Both",
    category: "Active Directory & Windows",
    description: "Primary authentication protocol in Microsoft Active Directory. Issues Ticket Granting Tickets (TGTs) for single sign-on authentication.",
    securityRecommendation: "Restrict access to Domain Controllers. Protect AD environments against Kerberoasting and Golden Ticket campaigns.",
    isHighRiskExposure: true
  },
  {
    port: "123",
    name: "NTP (Network Time Protocol)",
    transport: "UDP",
    category: "Infrastructure",
    description: "Synchronizes computer clocks across packet-switched networks to guarantee precise forensic logging sequences on SIEM consoles.",
    securityRecommendation: "Utilize secure, authenticated NTP queries. Watch out for NTP amplification DDOS attacks.",
    isHighRiskExposure: false
  },
  {
    port: "135",
    name: "RPC / MS-RPCEP (Remote Procedure Call)",
    transport: "TCP",
    category: "Active Directory & Windows",
    description: "Microsoft RPC endpoint mapper. Maps interface identifiers to specific ports inside Windows server subsystems.",
    securityRecommendation: "Block on edge firewalls. Used by threat actors for domain enumeration, remote profiling, and pivoting inside local subnets.",
    isHighRiskExposure: true
  },
  {
    port: "161",
    name: "SNMP (Simple Network Management Protocol)",
    transport: "UDP",
    category: "Infrastructure",
    description: "Monitors and configures network hardware (routers, switches). Communities can leak network topologies if misconfigured.",
    securityRecommendation: "Never use SNMP v1 or v2c which transmit strings (community names) in cleartext. Upgrade to SNMP v3 (authenticated).",
    isHighRiskExposure: true
  },
  {
    port: "389",
    name: "LDAP (Lightweight Directory Access Protocol)",
    transport: "Both",
    category: "Active Directory & Windows",
    description: "Directory query protocol used to search user groups and system structures in Active Directory.",
    securityRecommendation: "Enforce LDAPS (Port 636) or sign LDAP requests. Do not transmit directory lookups over unencrypted cleartext streams.",
    isHighRiskExposure: true
  },
  {
    port: "443",
    name: "HTTPS (HTTP Secure / TLS)",
    transport: "TCP",
    category: "Web & Content",
    description: "Encrypted web transit wrapping standard HTTP requests inside TLS handshakes. Secures payment details and credentials.",
    securityRecommendation: "Keep cipher suites updated. Disable legacy protocols (SSLv3, TLS 1.0, TLS 1.1) to block handshake down-negotiations.",
    isHighRiskExposure: false
  },
  {
    port: "445",
    name: "SMB (Server Message Block)",
    transport: "TCP",
    category: "Active Directory & Windows",
    description: "Enables file shares, printer pools, and named pipe communications across Windows systems. Historically abused by EternalBlue (WannaCry).",
    securityRecommendation: "CRITICAL: Never expose SMB Port 445 directly to the Internet. Enforce SMB signing and upgrade entirely to SMBv3.",
    isHighRiskExposure: true
  },
  {
    port: "1433",
    name: "MSSQL (Microsoft SQL Server)",
    transport: "TCP",
    category: "Database",
    description: "Default listener for Microsoft SQL Server databases. High impact target for corporate records theft and drop tables requests.",
    securityRecommendation: "Isolate DB servers inside non-routable DMZ segments. Do not use default administrative passwords to block credential sprays.",
    isHighRiskExposure: true
  },
  {
    port: "3306",
    name: "MySQL Database",
    transport: "TCP",
    category: "Database",
    description: "Routines database backend used by WordPress, LAMP stacks, and standard web applications.",
    securityRecommendation: "Bind MySQL to localhost (127.0.0.1) unless external cluster replication is specifically required. Enforce strong passwords.",
    isHighRiskExposure: true
  },
  {
    port: "3389",
    name: "RDP (Remote Desktop Protocol)",
    transport: "TCP",
    category: "Active Directory & Windows",
    description: "Microsoft's GUI remote terminal agent. Heavily scanned by botnets looking for weak credentials or BlueKeep exploits.",
    securityRecommendation: "CRITICAL: Guard with MFA/Network Level Authentication (NLA). Place RDP nodes behind VPN gates, never open on WAN ranges.",
    isHighRiskExposure: true
  },
  {
    port: "5432",
    name: "PostgreSQL Database",
    transport: "TCP",
    category: "Database",
    description: "Enterprise relational database. Highly performant structured records system.",
    securityRecommendation: "Filter remote logins in pg_hba.conf configurations. Enforce TLS connections for remote database queries.",
    isHighRiskExposure: true
  },
  {
    port: "5985",
    name: "WinRM HTTP (Windows Remote Management)",
    transport: "TCP",
    category: "Active Directory & Windows",
    description: "Windows WS-Management protocol. Powers remote PowerShell (Enter-PSSession) commands over HTTP.",
    securityRecommendation: "Enforce HTTPS WinRM Port 5986 over secure TLS sockets in production. Restrict accessible host IPs via TrustedHosts.",
    isHighRiskExposure: true
  },
  {
    port: "5986",
    name: "WinRM HTTPS (Windows Remote Management Secure)",
    transport: "TCP",
    category: "Active Directory & Windows",
    description: "Encrypted remote administrative PowerShell listener utilizing local machine certificates.",
    securityRecommendation: "Safeguard administrative credentials. Monitor system execute events to flag abnormal lateral scripting pivots.",
    isHighRiskExposure: true
  },
  {
    port: "6379",
    name: "Redis (In-Memory Key-Value Store)",
    transport: "TCP",
    category: "Database",
    description: "Standard cache database store. Shipped by default with zero password security requirements.",
    securityRecommendation: "Secure inside internal backend networks. Enable ACL authentication configs and rename high-impact commands.",
    isHighRiskExposure: true
  }
];

export default function PortLookupView() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPort, setSelectedPort] = useState<PortProtocolDetail | null>(standardPortsDatabase.find(p => p.port === "443") || null);
  const [copiedText, setCopiedText] = useState(false);

  // Filter ports database
  const filteredPorts = standardPortsDatabase.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      p.port.includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  });

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Title console */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
            <Binary className="w-4 h-4 text-emerald-400 animate-pulse" />
            IP PROTOCOL PORT NUMBER LOOKUP
          </h2>
          <p className="text-xs text-slate-550 font-mono">
            Audit standard service ports, transport protocols, and security hardening recommendations for firewall policies.
          </p>
        </div>

        {/* Search bar */}
        <div className="relative max-w-xs w-full font-mono">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            id="protocol-port-search"
            type="text"
            placeholder="Search port # or protocol name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 focus:outline-none rounded pl-8 pr-4 py-1.5 text-xs text-slate-201 placeholder-slate-600 font-bold"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left List section */}
        <div className="bg-slate-950/50 backdrop-blur-md border border-slate-900 rounded p-3 text-xs font-mono select-none h-[500px] overflow-y-auto space-y-1">
          <span className="text-[9px] text-slate-550 px-2 uppercase font-bold tracking-widest block mb-1.5">REGISTRY PORTS</span>
          {filteredPorts.length === 0 ? (
            <div className="text-slate-600 text-center py-8">No ports match.</div>
          ) : (
            filteredPorts.map((item) => (
              <button
                key={item.port}
                onClick={() => setSelectedPort(item)}
                className={`w-full text-left px-3 py-2 rounded transition flex items-center justify-between ${
                  selectedPort?.port === item.port
                    ? "bg-red-950/20 text-red-400 border-l-2 border-red-500 pl-2.5"
                    : "text-slate-400 hover:text-slate-202 hover:bg-slate-900/40"
                }`}
              >
                <div className="flex items-center gap-2 select-all">
                  <span className="font-bold text-slate-100 min-w-[32px]">:{item.port}</span>
                  <span className="truncate max-w-[120px] font-sans text-slate-400 font-semibold">{item.name.split(" ")[0]}</span>
                </div>
                {item.isHighRiskExposure && (
                  <span className="text-[8px] bg-red-950 text-red-500 font-bold px-1 rounded uppercase tracking-wider" title="High WAN Exposure Risk">
                    Risk
                  </span>
                )}
              </button>
            ))
          )}
        </div>

        {/* Right Details section */}
        <div className="md:col-span-3 bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5 space-y-6">
          {selectedPort ? (
            <div className="space-y-6">
              {/* Header card block */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-900 pb-4 gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-md sm:text-lg font-mono font-bold bg-slate-900 text-emerald-400 border border-slate-850 px-2.5 py-0.5 rounded leading-none select-all">
                      PORT {selectedPort.port}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 uppercase font-bold">
                      {selectedPort.transport}
                    </span>
                  </div>
                  <h3 className="text-sm font-sans font-extrabold text-slate-200 mt-1 select-all">
                    {selectedPort.name}
                  </h3>
                </div>

                <div className="space-y-1 text-right shrink-0">
                  <span className="text-[10px] font-mono text-slate-500 block uppercase">HARDENING MODULE</span>
                  <span className="text-slate-350 text-[10px] font-mono font-bold bg-slate-900 border border-slate-800 px-2 py-0.5 rounded uppercase">
                    {selectedPort.category}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2 leading-relaxed text-xs">
                <span className="text-[10px] text-slate-500 block font-mono uppercase">FUNCTIONAL DESCRIPTION</span>
                <p className="text-slate-300 font-sans text-sm font-medium leading-relaxed">{selectedPort.description}</p>
              </div>

              {/* Hardening guidance */}
              <div className="p-4 bg-slate-950 border border-slate-900 rounded space-y-2 text-xs border-l-2 border-l-orange-500 font-sans leading-relaxed">
                <span className="font-bold text-orange-500 font-mono text-[10.5px] uppercase flex items-center gap-1.5 block">
                  <ShieldAlert className="w-4 h-4 text-orange-500 animate-pulse shrink-0" />
                  FIREWALL Hardening & Active Deployment Recommendation:
                </span>
                <p className="font-medium text-slate-202">{selectedPort.securityRecommendation}</p>
              </div>

              {/* Warning level Indicators */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono select-none">
                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                  <span className="text-[10px] text-slate-500 block uppercase">EXTERNAL PORT WAN EXPOSURE RISK</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`w-2 h-2 rounded-full ${selectedPort.isHighRiskExposure ? "bg-red-500 animate-ping" : "bg-emerald-500"}`} />
                    <span className={`font-bold uppercase ${selectedPort.isHighRiskExposure ? "text-red-500" : "text-emerald-450"}`}>
                      {selectedPort.isHighRiskExposure ? "HIGH CRITICAL SECURITY WAN RISK" : "STANDARD PROTECTED ACCESS LEVEL"}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded">
                  <span className="text-[10px] text-slate-500 block uppercase">SECURITY CONFIG CONTROL STATUS</span>
                  <span className="text-slate-400 font-bold block mt-1 uppercase text-[11px] leading-tight flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    EDR INVENTORY AUDITED / RESOLVED
                  </span>
                </div>
              </div>

              {/* General SOC hardening tips */}
              <div className="bg-slate-900/40 p-3.5 rounded text-[11.5px] text-slate-500 leading-normal border border-slate-900 font-sans space-y-1.5">
                <span className="font-bold text-slate-400 block font-mono text-[10px] uppercase">🧭 GENERAL EXPOSURE POLICY</span>
                <p className="font-medium">Ports represent dedicated pipeline sockets in active host transport stacks. Scanners like Shodan or Censys map public ports continuously. Maintaining strict ingress policies, blocking unnecessary endpoints, and wrapping database and shell channels in modern private VPN tunnels secures against malicious lateral threat executions.</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-20 text-slate-550 font-mono text-xs">
              <Info className="w-8 h-8 text-slate-605 mx-auto mb-2 text-slate-600" />
              Please select an Internet registry port from the index menu to view dedicated forensic diagnostics.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
