/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { Terminal as TerminalIcon, AlertCircle, Trash, RefreshCw } from "lucide-react";

interface TerminalLine {
  type: "input" | "output" | "system";
  text: string;
}

export default function WhoisTerminalView() {
  const [history, setHistory] = useState<TerminalLine[]>([
    { type: "system", text: "SOC TERMINAL INGRESS -- SECURITY HUB UTILITY v1.4.0" },
    { type: "system", text: "Host: SOC_TOOL_CLI - Platform Node Enriched (Vite-Container)" },
    { type: "system", text: "Type 'help' to see active supported command vectors.\n" }
  ]);
  const [commandInput, setCommandInput] = useState("");
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [loading, setLoading] = useState(false);
  const terminalLogsRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    if (terminalLogsRef.current) {
      terminalLogsRef.current.scrollTop = terminalLogsRef.current.scrollHeight;
    }
  }, [history, loading]);

  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = commandInput.trim();
    if (!cmd) return;

    // Append user input
    const nextLines: TerminalLine[] = [...history, { type: "input", text: `root@soc-terminal:~# ${cmd}` }];
    setHistory(nextLines);
    setCommandInput("");
    setCommandHistory([...commandHistory, cmd]);
    setHistoryIndex(-1);

    const parts = cmd.split(/\s+/);
    const instruction = parts[0].toLowerCase();
    const target = parts.slice(1).join(" ");

    if (instruction === "clear") {
      setHistory([]);
      return;
    }

    if (instruction === "help") {
      setHistory([
        ...nextLines,
        {
          type: "output",
          text: `SOC Terminal System Command Index:
  whois [domain.com]     Perform WHOIS registrar diagnostic lookup
  dig [domain.com]       Fetch complex DNS resolver attributes
  nslookup [domain.com]  Return primary host resolver record mappings
  host [domain.com]      Determine host addressing pointers
  clear                  Flush systemic terminal buffer histories
  help                   Show this console mapping guide.`
        }
      ]);
      return;
    }

    if (!["whois", "dig", "nslookup", "dns", "host"].includes(instruction)) {
      setHistory([
        ...nextLines,
        { type: "output", text: `bash: command not found: ${instruction}. Type 'help' to review supported terminal actions.` }
      ]);
      return;
    }

    if (!target) {
      setHistory([
        ...nextLines,
        { type: "output", text: `Error: Missing target node. Usage example: \`${instruction} google.com\`` }
      ]);
      return;
    }

    // Call server API simulated cmd or real Gemini resolution
    setLoading(true);
    try {
      const response = await fetch("/api/terminal/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command: cmd,
          apiKeys: {
            whoisjson: localStorage.getItem("WHOISJSON_API_KEY") || "",
            gemini: localStorage.getItem("GEMINI_API_KEY") || ""
          }
        })
      });

      if (response.ok) {
        const data = await response.json();
        setHistory([
          ...nextLines,
          { type: "output", text: data.output }
        ]);
      } else {
        setHistory([
          ...nextLines,
          { type: "output", text: "Error: Unresponsive command socket tunnel." }
        ]);
      }
    } catch (err) {
      setHistory([
        ...nextLines,
        { type: "output", text: `Terminal socket connection refused: ${(err as Error).message}` }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Command history cycling using arrow keys
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowUp") {
      e.preventDefault();
      if (commandHistory.length === 0) return;
      const nextIdx = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIdx);
      setCommandInput(commandHistory[nextIdx]);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (commandHistory.length === 0) return;
      if (historyIndex === -1) return;
      const nextIdx = historyIndex + 1;
      if (nextIdx >= commandHistory.length) {
        setHistoryIndex(-1);
        setCommandInput("");
      } else {
        setHistoryIndex(nextIdx);
        setCommandInput(commandHistory[nextIdx]);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Overview instructions banner */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 flex justify-between items-center select-none font-mono text-xs">
        <div>
          <h2 className="text-sm font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
            <TerminalIcon className="w-4 h-4 text-emerald-400" />
            WHOIS TERMINAL SHELL
          </h2>
          <p className="text-[11px] text-slate-550 leading-sm">
            Interactive DNS query toolkit using real network resolution bindings. ArrowUp/Down cycles CLI histories.
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          <button
            onClick={() => setHistory([])}
            className="p-1.5 rounded hover:bg-slate-900 border border-slate-850 hover:border-slate-700 text-slate-400 hover:text-slate-200 cursor-pointer"
            title="Flush buffer"
          >
            <Trash className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal View Body */}
      <div className="bg-black border border-emerald-950/40 rounded flex flex-col h-[520px] shadow-2l relative overflow-hidden">
        {/* Terminal Header */}
        <div className="bg-zinc-950 border-b border-emerald-950/30 px-4 py-2 flex items-center justify-between select-none">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-650 opacity-80" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-650 opacity-80" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-650 opacity-80" />
            <span className="text-[10px] font-mono text-zinc-600 ml-2">root@soc-terminal: /bin/security-bash</span>
          </div>
          <span className="text-[9px] font-mono text-emerald-500/40 tracking-widest">TTY_023</span>
        </div>

        {/* Display screen */}
        <div
          ref={terminalLogsRef}
          className="flex-1 p-4 overflow-y-auto font-mono text-xs text-emerald-400 space-y-2 selection:bg-emerald-950 selection:text-emerald-200 leading-relaxed italic"
        >
          {history.map((line, idx) => (
            <div key={idx} className="whitespace-pre-wrap">
              {line.type === "input" ? (
                <span className="text-emerald-205 font-bold">{line.text}</span>
              ) : line.type === "system" ? (
                <span className="text-zinc-505 font-semibold text-[11px]">{line.text}</span>
              ) : (
                <span className="text-emerald-400/90">{line.text}</span>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-amber-500">
              <span className="animate-spin text-[10px]">
                <RefreshCw className="w-3 h-3" />
              </span>
              <span>RESOLVING IP NETWORK PTRS -- STG...</span>
            </div>
          )}
        </div>

        {/* Interactive CLI command bar form */}
        <form
          onSubmit={handleCommandSubmit}
          className="border-t border-emerald-950/20 bg-zinc-950/90 flex items-center p-3 select-none"
        >
          <span className="font-mono text-xs text-emerald-500 font-bold mr-2 shrink-0">
            root@soc-terminal:~#
          </span>
          <div className="flex-1 relative flex items-center font-mono text-xs">
            <input
              id="terminal-command-cli-input"
              type="text"
              autoFocus
              autoComplete="off"
              spellCheck={false}
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent focus:outline-none text-emerald-300 font-bold caret-emerald-500 pr-10"
              placeholder="whois threat-domain.com ..."
            />
            {/* Blinking interactive fake cursor line when field has text or focus */}
            <span className="animate-pulse bg-emerald-500 w-1.5 h-4 absolute right-2 opacity-60" />
          </div>
        </form>
      </div>

      <div className="font-mono text-[9px] text-slate-550 flex justify-between px-1">
        <span>ENCODED VIA SECURE COMPRESSED HTTPS SSH TUNNEL</span>
        <span>AGENT STAT // READY</span>
      </div>
    </div>
  );
}
