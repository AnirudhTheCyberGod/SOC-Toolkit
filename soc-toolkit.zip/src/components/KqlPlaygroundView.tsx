/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import { KqlQuery } from "../types";
import {
  FileCode2,
  Search,
  Copy,
  Check,
  Terminal,
  ShieldAlert,
  Cpu,
  Layers,
  Radio,
  Rss,
  ExternalLink,
  Download,
  Sparkles,
  Filter,
  Clock,
  Flame,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Send,
  Server,
  Globe,
  Hash,
  FileText,
  Mail,
  Key,
  Network,
  Crosshair,
  Activity,
  AlertTriangle,
  X,
  Play
} from "lucide-react";

export interface KqlThreatContext {
  title?: string;
  cves?: string[];
  ips?: string[];
  domains?: string[];
  urls?: string[];
  hashes?: string[];
  files?: string[];
  vendor?: string;
  product?: string;
  sourceType?: "cisa-kev" | "bleepingcomputer" | "custom";
}

interface KqlPlaygroundViewProps {
  initialContext?: KqlThreatContext | null;
  onClearContext?: () => void;
}

interface BleepingArticleSummary {
  id: string;
  title: string;
  pubDate: string;
  link: string;
  totalIocs: number;
  iocs: {
    cves: string[];
    ips: string[];
    domains: string[];
    urls: string[];
    hashes: string[];
    files: string[];
  };
}

interface CisaVulnerabilitySummary {
  cveID: string;
  vendorProject: string;
  product: string;
  vulnerabilityName: string;
  dateAdded: string;
  dueDate: string;
  knownRansomwareCampaignUse: string;
  shortDescription: string;
}

export default function KqlPlaygroundView({ initialContext, onClearContext }: KqlPlaygroundViewProps) {
  // Main view mode: TI Live Source Collections vs Custom IOC / CVE Input vs Baseline Sentinel Repository
  const [activeMode, setActiveMode] = useState<"ti-collections" | "custom-iocs" | "baseline-rules">(
    initialContext ? "custom-iocs" : "ti-collections"
  );

  // Active Threat Context for Query Generation
  const [activeThreat, setActiveThreat] = useState<KqlThreatContext>(
    initialContext || {
      title: "CVE-2024-38077 (Windows Remote Desktop Licensing Service RCE)",
      cves: ["CVE-2024-38077"],
      ips: ["185.156.74.52", "45.142.214.19"],
      domains: ["licensing-update-cdn.com", "win-rdp-broker.net"],
      urls: ["http://185.156.74.52/payload.dll"],
      hashes: ["e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"],
      files: ["rdp_exploit.dll", "cmd_spawn.scr"],
      vendor: "Microsoft",
      product: "Windows Server",
      sourceType: "custom"
    }
  );

  // Custom IOC Inputs
  const [customCveInput, setCustomCveInput] = useState("");
  const [customTitleInput, setCustomTitleInput] = useState("");
  const [customIpsInput, setCustomIpsInput] = useState("");
  const [customDomainsInput, setCustomDomainsInput] = useState("");
  const [customUrlsInput, setCustomUrlsInput] = useState("");
  const [customHashesInput, setCustomHashesInput] = useState("");
  const [customFilesInput, setCustomFilesInput] = useState("");
  const [rawPastedIocs, setRawPastedIocs] = useState("");

  // Query Generation Settings
  const [timeHorizon, setTimeHorizon] = useState<string>("ago(7d)");
  const [platformTarget, setPlatformTarget] = useState<"sentinel" | "mde">("sentinel");
  const [selectedTemplateCategory, setSelectedTemplateCategory] = useState<string>("all");

  // TI Feed Ingestion States
  const [tiSourceTab, setTiSourceTab] = useState<"bleepingcomputer" | "cisa-kev">("bleepingcomputer");
  const [bleepingArticles, setBleepingArticles] = useState<BleepingArticleSummary[]>([]);
  const [cisaVulns, setCisaVulns] = useState<CisaVulnerabilitySummary[]>([]);
  const [loadingFeeds, setLoadingFeeds] = useState(false);
  const [feedError, setFeedError] = useState<string | null>(null);
  const [tiSearchQuery, setTiSearchQuery] = useState("");

  // Baseline KQL Repository states
  const [baselineQueries, setBaselineQueries] = useState<KqlQuery[]>([]);
  const [loadingBaseline, setLoadingBaseline] = useState(false);
  const [baselineSearch, setBaselineSearch] = useState("");
  const [selectedBaselineCategory, setSelectedBaselineCategory] = useState("All");

  // UI States
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiObjective, setAiObjective] = useState("");
  const [aiSelectedTable, setAiSelectedTable] = useState("DeviceProcessEvents");
  const [generatingAi, setGeneratingAi] = useState(false);
  const [aiGeneratedResult, setAiGeneratedResult] = useState<any | null>(null);

  // Sync initialContext if provided from parent props
  useEffect(() => {
    if (initialContext) {
      setActiveThreat(initialContext);
      setActiveMode("ti-collections");
      if (initialContext.cves?.length) setCustomCveInput(initialContext.cves.join(", "));
      if (initialContext.ips?.length) setCustomIpsInput(initialContext.ips.join("\n"));
      if (initialContext.domains?.length) setCustomDomainsInput(initialContext.domains.join("\n"));
      if (initialContext.urls?.length) setCustomUrlsInput(initialContext.urls.join("\n"));
      if (initialContext.hashes?.length) setCustomHashesInput(initialContext.hashes.join("\n"));
      if (initialContext.files?.length) setCustomFilesInput(initialContext.files.join("\n"));
      if (initialContext.title) setCustomTitleInput(initialContext.title);
    }
  }, [initialContext]);

  // Load Baseline KQL queries
  const fetchBaselineQueries = async () => {
    setLoadingBaseline(true);
    try {
      const res = await fetch("/api/kql/queries");
      if (res.ok) {
        const data = await res.json();
        setBaselineQueries(data);
      }
    } catch (err) {
      console.error("Failed to load baseline KQL queries:", err);
    } finally {
      setLoadingBaseline(false);
    }
  };

  // Load TI feeds for live linking
  const fetchTiFeeds = async () => {
    setLoadingFeeds(true);
    setFeedError(null);
    try {
      // Parallel fetch BleepingComputer + CISA KEV
      const [bcRes, cisaRes] = await Promise.allSettled([
        fetch("/api/feeds/bleepingcomputer"),
        fetch("/api/feeds/cisa-kev?limit=150")
      ]);

      if (bcRes.status === "fulfilled" && bcRes.value.ok) {
        const bcData = await bcRes.value.json();
        setBleepingArticles(bcData.articles || []);
      }

      if (cisaRes.status === "fulfilled" && cisaRes.value.ok) {
        const cisaData = await cisaRes.value.json();
        setCisaVulns(cisaData.vulnerabilities || []);
      }
    } catch (err: any) {
      console.error("Failed to load threat feeds for KQL generator:", err);
      setFeedError(err.message || "Failed to load live threat feed collections");
    } finally {
      setLoadingFeeds(false);
    }
  };

  useEffect(() => {
    fetchTiFeeds();
    fetchBaselineQueries();
  }, []);

  // Handle Copy
  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Export as .kql file
  const handleDownloadKql = (title: string, query: string) => {
    const filename = `${title.toLowerCase().replace(/[^a-z0-9]/g, "_")}.kql`;
    const blob = new Blob([query], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Parse Raw Mixed Text for IOCs
  const handleParseRawIocs = (text: string) => {
    if (!text.trim()) return;

    // IP Regex
    const ipRegex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
    const foundIps = Array.from(new Set(text.match(ipRegex) || []));

    // CVE Regex
    const cveRegex = /\bCVE-\d{4}-\d{4,7}\b/gi;
    const foundCves = Array.from(new Set(text.match(cveRegex) || [])).map((c) => c.toUpperCase());

    // Hash Regex (MD5, SHA1, SHA256)
    const hashRegex = /\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{64}\b/g;
    const foundHashes = Array.from(new Set(text.match(hashRegex) || []));

    // Domain Regex
    const domainRegex = /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b/g;
    const rawDomains = Array.from(new Set(text.match(domainRegex) || []));
    const foundDomains = rawDomains.filter(
      (d) =>
        !foundIps.includes(d) &&
        !d.endsWith(".exe") &&
        !d.endsWith(".dll") &&
        !d.endsWith(".zip") &&
        !d.endsWith(".pdf") &&
        !["bleepingcomputer.com", "cisa.gov", "microsoft.com", "google.com"].includes(d.toLowerCase())
    );

    // URL Regex
    const urlRegex = /https?:\/\/[^\s"'<>]+/gi;
    const foundUrls = Array.from(new Set(text.match(urlRegex) || []));

    // File Regex
    const fileRegex = /\b[a-zA-Z0-9_\-\.]{1,60}\.(?:exe|dll|ps1|bat|vbs|scr|bin|elf|apk|sys|hta|zip|iso|7z)\b/gi;
    const foundFiles = Array.from(new Set(text.match(fileRegex) || []));

    const newThreat: KqlThreatContext = {
      title: customTitleInput || (foundCves[0] ? `${foundCves[0]} Discovered Threat Hunt` : "Pasted IOCs Collection Hunt"),
      cves: foundCves.length ? foundCves : customCveInput ? [customCveInput] : [],
      ips: foundIps,
      domains: foundDomains,
      urls: foundUrls,
      hashes: foundHashes,
      files: foundFiles,
      sourceType: "custom"
    };

    setActiveThreat(newThreat);
    setCustomCveInput(newThreat.cves?.join(", ") || "");
    setCustomIpsInput(newThreat.ips?.join("\n") || "");
    setCustomDomainsInput(newThreat.domains?.join("\n") || "");
    setCustomUrlsInput(newThreat.urls?.join("\n") || "");
    setCustomHashesInput(newThreat.hashes?.join("\n") || "");
    setCustomFilesInput(newThreat.files?.join("\n") || "");
  };

  // Apply custom fields
  const handleApplyCustomFields = () => {
    const parseList = (str: string) =>
      str
        .split(/[\n,;]+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

    const cves = parseList(customCveInput).map((c) => (c.startsWith("CVE-") ? c.toUpperCase() : `CVE-${c.toUpperCase()}`));
    const ips = parseList(customIpsInput);
    const domains = parseList(customDomainsInput);
    const urls = parseList(customUrlsInput);
    const hashes = parseList(customHashesInput);
    const files = parseList(customFilesInput);

    setActiveThreat({
      title: customTitleInput || (cves[0] ? `${cves[0]} Threat Hunting Rule` : "Custom Discovered IOCs Hunt"),
      cves,
      ips,
      domains,
      urls,
      hashes,
      files,
      sourceType: "custom"
    });
  };

  // Load BleepingComputer Article into Context
  const handleSelectBleepingArticle = (article: BleepingArticleSummary) => {
    const threat: KqlThreatContext = {
      title: article.title,
      cves: article.iocs.cves,
      ips: article.iocs.ips,
      domains: article.iocs.domains,
      urls: article.iocs.urls,
      hashes: article.iocs.hashes,
      files: article.iocs.files,
      sourceType: "bleepingcomputer"
    };
    setActiveThreat(threat);
    setCustomTitleInput(article.title);
    setCustomCveInput(article.iocs.cves.join(", "));
    setCustomIpsInput(article.iocs.ips.join("\n"));
    setCustomDomainsInput(article.iocs.domains.join("\n"));
    setCustomUrlsInput(article.iocs.urls.join("\n"));
    setCustomHashesInput(article.iocs.hashes.join("\n"));
    setCustomFilesInput(article.iocs.files.join("\n"));
  };

  // Load CISA KEV Vulnerability into Context
  const handleSelectCisaVuln = (vuln: CisaVulnerabilitySummary) => {
    const threat: KqlThreatContext = {
      title: `${vuln.cveID} - ${vuln.vulnerabilityName} (${vuln.vendorProject} ${vuln.product})`,
      cves: [vuln.cveID],
      ips: [],
      domains: [],
      urls: [],
      hashes: [],
      files: [],
      vendor: vuln.vendorProject,
      product: vuln.product,
      sourceType: "cisa-kev"
    };
    setActiveThreat(threat);
    setCustomTitleInput(`${vuln.cveID} - ${vuln.vulnerabilityName}`);
    setCustomCveInput(vuln.cveID);
    setCustomIpsInput("");
    setCustomDomainsInput("");
    setCustomUrlsInput("");
    setCustomHashesInput("");
    setCustomFilesInput("");
  };

  // Request AI-Tuned Custom KQL Query
  const handleGenerateAiKql = async () => {
    setGeneratingAi(true);
    setAiGeneratedResult(null);
    try {
      const res = await fetch("/api/kql/generate-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: activeThreat.title,
          cve: activeThreat.cves?.[0] || "",
          iocs: {
            ips: activeThreat.ips || [],
            domains: activeThreat.domains || [],
            urls: activeThreat.urls || [],
            hashes: activeThreat.hashes || [],
            files: activeThreat.files || []
          },
          targetTable: aiSelectedTable,
          timeRange: timeHorizon,
          huntObjective: aiObjective || "Hunt for exploitation, command-line anomalies, and network callback beacons"
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data = await res.json();
      if (data.generatedQuery) {
        setAiGeneratedResult(data.generatedQuery);
      }
    } catch (err: any) {
      console.error("AI KQL generation failed:", err);
      alert(`AI KQL Generation Error: ${err.message}`);
    } finally {
      setGeneratingAi(false);
    }
  };

  // -------------------------------------------------------------
  // PREDEFINED PRODUCTION KQL QUERY GENERATORS (DETERMINISTIC)
  // -------------------------------------------------------------
  const generatedTemplates = useMemo(() => {
    const cves = activeThreat.cves || [];
    const ips = activeThreat.ips || [];
    const domains = activeThreat.domains || [];
    const urls = activeThreat.urls || [];
    const hashes = activeThreat.hashes || [];
    const files = activeThreat.files || [];
    const title = activeThreat.title || "Target Threat Campaign";
    const primaryCve = cves[0] || "CVE-UNKNOWN";

    const cvesFormatted = cves.map((c) => `"${c}"`).join(", ");
    const ipsFormatted = ips.map((i) => `"${i}"`).join(", ");
    const domainsFormatted = domains.map((d) => `"${d}"`).join(", ");
    const urlsFormatted = urls.map((u) => `"${u}"`).join(", ");
    const hashesFormatted = hashes.map((h) => `"${h}"`).join(", ");
    const filesFormatted = files.map((f) => `"${f}"`).join(", ");

    const templates = [
      // 1. Device TVM Vulnerability Exposure (CISA / CVE testing)
      {
        id: "template-tvm-vulnerability",
        title: "Device Vulnerability & Asset Fleet Exposure",
        category: "vulnerability",
        targetTable: "DeviceTvmSoftwareVulnerabilities",
        mitreMappings: ["T1190", "T1203"],
        description: `Searches Microsoft Defender Vulnerability Management (TVM) to detect all endpoints exposing ${primaryCve} or unpatched vendor software across the enterprise.`,
        applicable: cves.length > 0,
        query: `// =========================================================================
// MDE Threat & Vulnerability Management (TVM): Fleet Vulnerability Exposure
// Target: ${title}
// Time Horizon: ${timeHorizon}
// =========================================================================
let TargetCves = dynamic([${cvesFormatted || `"${primaryCve}"`}]);
DeviceTvmSoftwareVulnerabilities
| where TimeGenerated >= ${timeHorizon}
| where CveId in~ (TargetCves)
| project TimeGenerated, DeviceName, DeviceId, CveId, SoftwareVendor, SoftwareName, SoftwareVersion, VulnerabilitySeverityLevel
| join kind=inner (
    DeviceInfo
    | where TimeGenerated >= ${timeHorizon}
    | summarize arg_max(TimeGenerated, *) by DeviceId
    | project DeviceId, PublicIP, OSPlatform, OSVersion, ExposureLevel
) on DeviceId
| summarize 
    ExposedDevicesCount = dcount(DeviceId), 
    VulnerableSoftware = make_set(strcat(SoftwareVendor, " ", SoftwareName, " v", SoftwareVersion)),
    ImpactedEndpoints = make_set(DeviceName) 
    by CveId, VulnerabilitySeverityLevel
| order by ExposedDevicesCount desc`
      },

      // 2. Endpoint Process Execution & Exploitation Hunting (MDE)
      {
        id: "template-process-exploitation",
        title: "Endpoint Process Execution & Exploitation Anomaly Hunting",
        category: "process",
        targetTable: "DeviceProcessEvents",
        mitreMappings: ["T1059", "T1203", "T1055"],
        description: `Hunts for anomalous process launches, shell spawning under vulnerable server processes (e.g. w3wp, sqlservr), or malicious payload executions.`,
        applicable: true,
        query: `// =========================================================================
// MDE DeviceProcessEvents: Exploitation & Malicious Process Execution
// Threat: ${title}
// Target Payloads: ${files.length ? files.slice(0, 3).join(", ") : "Exploit Artifacts"}
// =========================================================================
let TimeWindow = ${timeHorizon};
let TargetHashes = dynamic([${hashesFormatted}]);
let TargetPayloads = dynamic([${filesFormatted}]);
let TargetCves = dynamic([${cvesFormatted}]);
DeviceProcessEvents
| where TimeGenerated >= TimeWindow
| where 
    (array_length(TargetHashes) > 0 and (SHA256 in~ (TargetHashes) or MD5 in~ (TargetHashes) or SHA1 in~ (TargetHashes)))
    or (array_length(TargetPayloads) > 0 and (FileName in~ (TargetPayloads) or ProcessCommandLine has_any (TargetPayloads)))
    ${cves.length > 0 ? `or (array_length(TargetCves) > 0 and ProcessCommandLine has_any (TargetCves))` : ""}
    or (
        // Common post-exploit and shell-spawning anomaly detection
        InitiatingProcessFileName in~ ("w3wp.exe", "httpd.exe", "nginx.exe", "sqlservr.exe", "spoolsv.exe")
        and FileName in~ ("cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "mshta.exe", "certutil.exe", "bitsadmin.exe", "curl.exe")
    )
| project 
    TimeGenerated, 
    DeviceName, 
    AccountName, 
    InitiatingProcessAccountName, 
    InitiatingProcessFileName, 
    InitiatingProcessCommandLine, 
    FileName, 
    ProcessCommandLine, 
    SHA256, 
    ProcessId
| order by TimeGenerated desc`
      },

      // 3. Network C2 & Outbound Beaconing Hunting (DeviceNetworkEvents)
      {
        id: "template-network-c2",
        title: "C2 Beaconing & Outbound Threat Infrastructure Traffic",
        category: "network",
        targetTable: "DeviceNetworkEvents",
        mitreMappings: ["T1071", "T1571"],
        description: `Detects internal devices establishing connections with known threat actor IP addresses, C2 staging servers, or malicious domains.`,
        applicable: ips.length > 0 || domains.length > 0 || urls.length > 0,
        query: `// =========================================================================
// MDE DeviceNetworkEvents: C2 Beaconing & Outbound Infrastructure Traffic
// Target Threat: ${title}
// Threat IPs (${ips.length}) | Threat Domains (${domains.length})
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatIps = dynamic([${ipsFormatted}]);
let ThreatDomains = dynamic([${domainsFormatted}]);
let ThreatUrls = dynamic([${urlsFormatted}]);
DeviceNetworkEvents
| where TimeGenerated >= TimeWindow
| where ActionType in ("ConnectionSuccess", "InboundConnectionAccepted")
| where 
    (array_length(ThreatIps) > 0 and (RemoteIP in (ThreatIps) or LocalIP in (ThreatIps)))
    or (array_length(ThreatDomains) > 0 and RemoteUrl has_any (ThreatDomains))
    or (array_length(ThreatUrls) > 0 and RemoteUrl has_any (ThreatUrls))
| project 
    TimeGenerated, 
    DeviceName, 
    InitiatingProcessAccountName, 
    InitiatingProcessFileName, 
    InitiatingProcessCommandLine, 
    LocalIP, 
    RemoteIP, 
    RemotePort, 
    RemoteUrl
| summarize 
    TotalConnections = count(), 
    FirstSeen = min(TimeGenerated), 
    LastSeen = max(TimeGenerated), 
    CommunicatingUsers = make_set(InitiatingProcessAccountName), 
    ParentProcesses = make_set(InitiatingProcessFileName) 
    by DeviceName, RemoteIP, RemoteUrl, RemotePort
| order by TotalConnections desc`
      },

      // 4. Perimeter Firewall & Egress Filter Hunting (CommonSecurityLog)
      {
        id: "template-firewall-egress",
        title: "Perimeter Firewall Egress & Inbound Exploit Probes",
        category: "firewall",
        targetTable: "CommonSecurityLog",
        mitreMappings: ["T1071.001", "T1041"],
        description: `Sweeps Palo Alto, Fortinet, Check Point, Cisco ASA, and perimeter firewalls for network flows matching the threat infrastructure.`,
        applicable: ips.length > 0 || domains.length > 0,
        query: `// =========================================================================
// Microsoft Sentinel: CommonSecurityLog (Firewalls & Perimeter Appliances)
// Ingests: Palo Alto Networks, Fortinet, Check Point, Cisco ASA, pfSense
// Target Threat: ${title}
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatIps = dynamic([${ipsFormatted}]);
let ThreatDomains = dynamic([${domainsFormatted}]);
CommonSecurityLog
| where TimeGenerated >= TimeWindow
| where 
    (array_length(ThreatIps) > 0 and (DestinationIP in (ThreatIps) or SourceIP in (ThreatIps)))
    or (array_length(ThreatDomains) > 0 and (DestinationHostName has_any (ThreatDomains) or RequestURL has_any (ThreatDomains)))
| project 
    TimeGenerated, 
    DeviceVendor, 
    DeviceProduct, 
    Activity, 
    DeviceAction, 
    SourceIP, 
    SourcePort, 
    DestinationIP, 
    DestinationPort, 
    DestinationHostName, 
    ReceivedBytes, 
    SentBytes, 
    Message
| summarize 
    HitCount = count(), 
    ActionsTaken = make_set(DeviceAction), 
    InternalSourceIps = make_set(SourceIP) 
    by DeviceVendor, DestinationIP, DestinationPort, DestinationHostName
| order by HitCount desc`
      },

      // 5. Dropped Payloads & Staging Artifacts (DeviceFileEvents)
      {
        id: "template-file-staging",
        title: "Malicious Payloads & Staged Dropper Artifacts",
        category: "file",
        targetTable: "DeviceFileEvents",
        mitreMappings: ["T1105", "T1027", "T1036"],
        description: `Detects file creation, modification, or staging of malicious payload files and known attacker hashes in sensitive or temporary folders.`,
        applicable: hashes.length > 0 || files.length > 0,
        query: `// =========================================================================
// MDE DeviceFileEvents: Malicious Payloads, Staged Artifacts & Dropped Scripts
// Target Threat: ${title}
// Hashes: (${hashes.length}) | Payloads: (${files.length})
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatHashes = dynamic([${hashesFormatted}]);
let ThreatFiles = dynamic([${filesFormatted}]);
DeviceFileEvents
| where TimeGenerated >= TimeWindow
| where ActionType in ("FileCreated", "FileModified", "FileRenamed")
| where 
    (array_length(ThreatHashes) > 0 and (SHA256 in~ (ThreatHashes) or MD5 in~ (ThreatHashes) or SHA1 in~ (ThreatHashes)))
    or (array_length(ThreatFiles) > 0 and (FileName in~ (ThreatFiles) or PreviousFileName in~ (ThreatFiles)))
    or (
        // File drop into high-risk temp & persistence directories
        FolderPath matches regex @"(?i)(AppData\\\\Local\\\\Temp|C:\\\\Windows\\\\Temp|C:\\\\ProgramData\\\\|/tmp/|/dev/shm)"
        and FileName endswith any (".ps1", ".vbs", ".bat", ".scr", ".exe", ".dll", ".hta", ".js")
    )
| project 
    TimeGenerated, 
    DeviceName, 
    ActionType, 
    FileName, 
    FolderPath, 
    SHA256, 
    MD5, 
    FileSize, 
    InitiatingProcessAccountName, 
    InitiatingProcessFileName, 
    InitiatingProcessCommandLine
| order by TimeGenerated desc`
      },

      // 6. DNS Resolution & Domain Probing Hunting (DnsEvents / DeviceEvents)
      {
        id: "template-dns-resolution",
        title: "DNS Resolution & C2 Domain Lookups",
        category: "dns",
        targetTable: "DnsEvents / DeviceEvents",
        mitreMappings: ["T1071.004"],
        description: `Tracks internal hosts resolving discovered attacker command-and-control domains or phishing infrastructure via Windows DNS and MDE.`,
        applicable: domains.length > 0,
        query: `// =========================================================================
// Microsoft Sentinel & MDE: DnsEvents & DeviceEvents (C2 DNS Lookup Hunting)
// Target Domains: ${domains.slice(0, 4).join(", ") || "None"}
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatDomains = dynamic([${domainsFormatted}]);
union isfuzzy=true
(
    DnsEvents
    | where TimeGenerated >= TimeWindow
    | where array_length(ThreatDomains) > 0 and Name has_any (ThreatDomains)
    | project TimeGenerated, SourceType="DnsEvents", DeviceName=Computer, ClientIP, QueryName=Name, ResultCode, IPAddresses
),
(
    DeviceEvents
    | where TimeGenerated >= TimeWindow
    | where ActionType == "DnsQueryResponse"
    | extend QueryName = tostring(AdditionalFields.QueryName)
    | extend DnsResolvedIPs = tostring(AdditionalFields.DnsResolvedIPs)
    | where array_length(ThreatDomains) > 0 and QueryName has_any (ThreatDomains)
    | project TimeGenerated, SourceType="DeviceEvents (MDE)", DeviceName, ClientIP=LocalIP, QueryName, ResultCode=ActionType, IPAddresses=DnsResolvedIPs
)
| summarize QueryCount = count(), FirstAttempt = min(TimeGenerated), LastAttempt = max(TimeGenerated) by DeviceName, ClientIP, QueryName, IPAddresses
| order by QueryCount desc`
      },

      // 7. Phishing & Inbound Email Delivery (Defender for Office 365)
      {
        id: "template-email-phishing",
        title: "Inbound Phishing & Malicious Email Delivery",
        category: "email",
        targetTable: "EmailEvents & EmailUrlInfo",
        mitreMappings: ["T1566", "T1566.001", "T1566.002"],
        description: `Cross-examines Microsoft Defender for Office 365 logs to identify emails received containing weaponized URLs, threat domains, or malicious attachments.`,
        applicable: urls.length > 0 || domains.length > 0 || hashes.length > 0 || files.length > 0 || ips.length > 0,
        query: `// =========================================================================
// Defender for Office 365 (MDO): EmailEvents, EmailUrlInfo & EmailAttachmentInfo
// Threat Campaign: ${title}
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatIps = dynamic([${ipsFormatted}]);
let ThreatUrls = dynamic([${urlsFormatted}]);
let ThreatDomains = dynamic([${domainsFormatted}]);
let ThreatHashes = dynamic([${hashesFormatted}]);
let ThreatFiles = dynamic([${filesFormatted}]);
EmailEvents
| where TimeGenerated >= TimeWindow
| where 
    (array_length(ThreatIps) > 0 and SenderIPv4 in (ThreatIps))
    or (array_length(ThreatDomains) > 0 and (SenderFromDomain has_any (ThreatDomains) or SenderMailFromDomain has_any (ThreatDomains)))
| join kind=leftouter (
    EmailUrlInfo
    | where TimeGenerated >= TimeWindow
    | where (array_length(ThreatUrls) > 0 and Url has_any (ThreatUrls)) or (array_length(ThreatDomains) > 0 and UrlDomain has_any (ThreatDomains))
    | project NetworkMessageId, MaliciousUrl=Url
) on NetworkMessageId
| join kind=leftouter (
    EmailAttachmentInfo
    | where TimeGenerated >= TimeWindow
    | where (array_length(ThreatHashes) > 0 and SHA256 in~ (ThreatHashes)) or (array_length(ThreatFiles) > 0 and FileName in~ (ThreatFiles))
    | project NetworkMessageId, MaliciousAttachment=FileName, AttachmentSHA256=SHA256
) on NetworkMessageId
| project 
    TimeGenerated, 
    Subject, 
    SenderFromAddress, 
    RecipientEmailAddress, 
    SenderIPv4, 
    DeliveryAction, 
    ConfidenceLevel, 
    MaliciousUrl, 
    MaliciousAttachment, 
    AttachmentSHA256
| order by TimeGenerated desc`
      },

      // 8. Identity & Compromised Account Sign-ins (Entra ID / SigninLogs)
      {
        id: "template-identity-signins",
        title: "Compromised Account Sign-ins & Entra ID Access",
        category: "identity",
        targetTable: "SigninLogs & AADNonInteractiveUserSignInLogs",
        mitreMappings: ["T1078", "T1078.004"],
        description: `Hunts for corporate user authentications and conditional access evaluations originating from the discovered threat actor IP addresses.`,
        applicable: ips.length > 0,
        query: `// =========================================================================
// Microsoft Entra ID (Azure AD): SigninLogs & AADNonInteractiveUserSignInLogs
// Target: Compromised identity checks & authentications originating from Threat IPs
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatIps = dynamic([${ipsFormatted}]);
union isfuzzy=true SigninLogs, AADNonInteractiveUserSignInLogs
| where TimeGenerated >= TimeWindow
| where array_length(ThreatIps) > 0 and IPAddress in (ThreatIps)
| project 
    TimeGenerated, 
    UserPrincipalName, 
    UserDisplayName, 
    IPAddress, 
    Location, 
    AppDisplayName, 
    ClientAppUsed, 
    RiskState, 
    RiskLevelDuringSignIn, 
    ConditionalAccessStatus, 
    ResultType, 
    ResultDescription
| summarize 
    AttemptCount = count(), 
    ApplicationsTargeted = make_set(AppDisplayName), 
    TargetedAccounts = make_set(UserPrincipalName), 
    Locations = make_set(Location) 
    by IPAddress, ResultType
| order by AttemptCount desc`
      },

      // 9. ENTERPRISE ALL-IN-ONE SUPER HUNT (DYNAMIC UNION)
      {
        id: "template-super-hunt",
        title: "Enterprise Multi-Telemetry All-in-One Super Hunt",
        category: "superhunt",
        targetTable: "Unified Union (Network + Process + File + DNS)",
        mitreMappings: ["T1190", "T1059", "T1071", "T1105"],
        description: `Executes a comprehensive, single-pass union query sweeping all endpoints in the fleet across Network, Process, File, and DNS telemetry.`,
        applicable: true,
        query: `// =========================================================================
// ENTERPRISE ALL-IN-ONE SUPER HUNT (DYNAMIC UNION SWEEP)
// Target: Complete tenant-wide sweep across Network, Process, File, & DNS
// Threat Context: ${title}
// =========================================================================
let TimeWindow = ${timeHorizon};
let ThreatIps = dynamic([${ipsFormatted}]);
let ThreatDomains = dynamic([${domainsFormatted}]);
let ThreatHashes = dynamic([${hashesFormatted}]);
let ThreatFiles = dynamic([${filesFormatted}]);
let ThreatCves = dynamic([${cvesFormatted}]);
union isfuzzy=true
(
    DeviceNetworkEvents
    | where TimeGenerated >= TimeWindow
    | where (array_length(ThreatIps) > 0 and RemoteIP in (ThreatIps)) or (array_length(ThreatDomains) > 0 and RemoteUrl has_any (ThreatDomains))
    | project TimeGenerated, TelemetryType="Network Communication", DeviceName, AccountName=InitiatingProcessAccountName, Detail=strcat("Remote IP: ", RemoteIP, " URL: ", RemoteUrl), Initiator=InitiatingProcessFileName
),
(
    DeviceProcessEvents
    | where TimeGenerated >= TimeWindow
    | where (array_length(ThreatHashes) > 0 and (SHA256 in~ (ThreatHashes) or MD5 in~ (ThreatHashes)))
        or (array_length(ThreatFiles) > 0 and (FileName in~ (ThreatFiles) or ProcessCommandLine has_any (ThreatFiles)))
        ${cves.length > 0 ? `or (array_length(ThreatCves) > 0 and ProcessCommandLine has_any (ThreatCves))` : ""}
    | project TimeGenerated, TelemetryType="Process Execution", DeviceName, AccountName, Detail=strcat("Command: ", ProcessCommandLine), Initiator=FileName
),
(
    DeviceFileEvents
    | where TimeGenerated >= TimeWindow
    | where (array_length(ThreatHashes) > 0 and (SHA256 in~ (ThreatHashes) or MD5 in~ (ThreatHashes)))
        or (array_length(ThreatFiles) > 0 and FileName in~ (ThreatFiles))
    | project TimeGenerated, TelemetryType="File Dropped", DeviceName, AccountName=InitiatingProcessAccountName, Detail=strcat("File: ", FolderPath, "\\\\", FileName), Initiator=InitiatingProcessFileName
),
(
    DnsEvents
    | where TimeGenerated >= TimeWindow
    | where array_length(ThreatDomains) > 0 and Name has_any (ThreatDomains)
    | project TimeGenerated, TelemetryType="DNS Lookup", DeviceName=Computer, AccountName="N/A", Detail=strcat("Resolved Domain: ", Name), Initiator="DNS Client"
)
| summarize FirstSeen=min(TimeGenerated), LastSeen=max(TimeGenerated), HitCount=count() by TelemetryType, DeviceName, AccountName, Initiator, Detail
| order by HitCount desc`
      }
    ];

    return templates;
  }, [activeThreat, timeHorizon]);

  // Filter templates by category
  const filteredTemplates = useMemo(() => {
    if (selectedTemplateCategory === "all") return generatedTemplates;
    return generatedTemplates.filter((t) => t.category === selectedTemplateCategory);
  }, [generatedTemplates, selectedTemplateCategory]);

  // Filter TI Bleeping Articles
  const filteredBleepingArticles = useMemo(() => {
    if (!tiSearchQuery.trim()) return bleepingArticles;
    const q = tiSearchQuery.toLowerCase();
    return bleepingArticles.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        a.iocs.cves.some((c) => c.toLowerCase().includes(q)) ||
        a.iocs.ips.some((ip) => ip.includes(q)) ||
        a.iocs.domains.some((d) => d.toLowerCase().includes(q))
    );
  }, [bleepingArticles, tiSearchQuery]);

  // Filter CISA KEV vulnerabilities
  const filteredCisaVulns = useMemo(() => {
    if (!tiSearchQuery.trim()) return cisaVulns;
    const q = tiSearchQuery.toLowerCase();
    return cisaVulns.filter(
      (v) =>
        v.cveID.toLowerCase().includes(q) ||
        v.vendorProject.toLowerCase().includes(q) ||
        v.product.toLowerCase().includes(q) ||
        v.vulnerabilityName.toLowerCase().includes(q)
    );
  }, [cisaVulns, tiSearchQuery]);

  // Filter Baseline Rules
  const filteredBaseline = useMemo(() => {
    return baselineQueries.filter((q) => {
      const matchCat = selectedBaselineCategory === "All" || q.useCase === selectedBaselineCategory;
      const matchSearch =
        !baselineSearch.trim() ||
        q.title.toLowerCase().includes(baselineSearch.toLowerCase()) ||
        q.description.toLowerCase().includes(baselineSearch.toLowerCase()) ||
        q.query.toLowerCase().includes(baselineSearch.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [baselineQueries, selectedBaselineCategory, baselineSearch]);

  const baselineCategories = useMemo(() => {
    return ["All", ...Array.from(new Set(baselineQueries.map((q) => q.useCase)))];
  }, [baselineQueries]);

  // Export all KQL templates into single file
  const handleExportAllKql = () => {
    let combined = `// =========================================================================\n`;
    combined += `// MICROSOFT SENTINEL & DEFENDER KQL HUNTING PLAYBOOK\n`;
    combined += `// THREAT TARGET: ${activeThreat.title || "Discovered Threat Indicators"}\n`;
    combined += `// TIME WINDOW: ${timeHorizon}\n`;
    combined += `// EXPORTED AT: ${new Date().toISOString()}\n`;
    combined += `// =========================================================================\n\n`;

    generatedTemplates.forEach((t, i) => {
      combined += `// -------------------------------------------------------------------------\n`;
      combined += `// RULE ${i + 1}: ${t.title}\n`;
      combined += `// TABLE: ${t.targetTable}\n`;
      combined += `// MITRE ATT&CK: ${t.mitreMappings.join(", ")}\n`;
      combined += `// PURPOSE: ${t.description}\n`;
      combined += `// -------------------------------------------------------------------------\n\n`;
      combined += `${t.query}\n\n\n`;
    });

    const blob = new Blob([combined], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `kql_hunt_${(activeThreat.cves?.[0] || activeThreat.title || "threat_ioc").replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()}.kql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6" id="kql-generator-view">
      {/* Top Banner Header */}
      <div className="bg-slate-950/70 border border-slate-900 rounded p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase flex items-center gap-2">
                <FileCode2 className="w-4 h-4 text-emerald-400" />
                KQL THREAT HUNT GENERATOR // TI COLLECTIONS LINKED
              </h2>
            </div>
            <p className="text-xs text-slate-400 font-mono max-w-3xl leading-relaxed">
              Dynamically generate battle-tested, syntax-validated Microsoft Sentinel and Defender XDR (MDE) hunting queries
              directly populated with IOCs and CVEs from live CISA KEV, BleepingComputer feeds, or custom intelligence.
            </p>

            <div className="flex flex-wrap items-center gap-2 mt-2.5 text-[10px] font-mono">
              <span className="text-slate-500">INTEGRATED TI SOURCES:</span>
              <span className="bg-slate-900 text-red-400 border border-slate-800 px-2 py-0.5 rounded flex items-center gap-1 font-bold">
                <Rss className="w-2.5 h-2.5 text-red-400" />
                BLEEPINGCOMPUTER RSS ({bleepingArticles.length} ARTICLES)
              </span>
              <span className="bg-slate-900 text-amber-400 border border-slate-800 px-2 py-0.5 rounded flex items-center gap-1 font-bold">
                <ShieldAlert className="w-2.5 h-2.5 text-amber-400" />
                CISA KEV CATALOG ({cisaVulns.length}+ ACTIVE ZERO-DAYS)
              </span>
              <span className="bg-slate-900 text-emerald-400 border border-slate-800 px-2 py-0.5 rounded flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-emerald-400" />
                GEMINI AI KQL TUNER
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleExportAllKql}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 px-3 py-2 rounded text-xs font-mono font-bold transition cursor-pointer"
              title="Download all 9 generated KQL templates as a single .kql playbook"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              EXPORT PLAYBOOK (.KQL)
            </button>

            <button
              onClick={() => setIsAiModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 hover:text-white px-3.5 py-2 rounded text-xs font-mono font-bold transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              AI CUSTOM HUNT TUNER
            </button>
          </div>
        </div>
      </div>

      {/* Mode Switcher Navigation Tabs */}
      <div className="flex flex-wrap border-b border-slate-900 font-mono text-xs">
        <button
          onClick={() => setActiveMode("ti-collections")}
          className={`px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            activeMode === "ti-collections"
              ? "border-emerald-500 text-emerald-400 bg-emerald-950/10"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <Rss className="w-3.5 h-3.5 text-emerald-400" />
          TI FEED COLLECTIONS (BLEEPINGCOMPUTER + CISA KEV)
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-900 uppercase">
            LIVE TI LINK
          </span>
        </button>

        <button
          onClick={() => setActiveMode("custom-iocs")}
          className={`px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            activeMode === "custom-iocs"
              ? "border-emerald-500 text-emerald-400 bg-emerald-950/10"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <Crosshair className="w-3.5 h-3.5 text-blue-400" />
          DISCOVERED IOC / CVE HUNT GENERATOR
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-blue-950 text-blue-400 border border-blue-900 uppercase">
            CUSTOM
          </span>
        </button>

        <button
          onClick={() => setActiveMode("baseline-rules")}
          className={`px-5 py-3 border-b-2 font-bold flex items-center gap-2 transition cursor-pointer ${
            activeMode === "baseline-rules"
              ? "border-emerald-500 text-emerald-400 bg-emerald-950/10"
              : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40"
          }`}
        >
          <Server className="w-3.5 h-3.5 text-purple-400" />
          SENTINEL RULES REPOSITORY (BASELINE PRESETS)
          <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-purple-950 text-purple-400 border border-purple-900 uppercase">
            LIBRARY
          </span>
        </button>
      </div>

      {/* MODE 1: TI FEED COLLECTIONS (BleepingComputer & CISA KEV Picker) */}
      {activeMode === "ti-collections" && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-300 uppercase">SELECT TI STREAM:</span>
              <div className="flex bg-slate-900 p-0.5 rounded border border-slate-800 text-xs font-mono">
                <button
                  onClick={() => setTiSourceTab("bleepingcomputer")}
                  className={`px-3 py-1 rounded transition cursor-pointer flex items-center gap-1.5 ${
                    tiSourceTab === "bleepingcomputer"
                      ? "bg-red-950 text-red-300 font-bold border border-red-800/80"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Rss className="w-3 h-3 text-red-400" />
                  BleepingComputer RSS ({bleepingArticles.length})
                </button>
                <button
                  onClick={() => setTiSourceTab("cisa-kev")}
                  className={`px-3 py-1 rounded transition cursor-pointer flex items-center gap-1.5 ${
                    tiSourceTab === "cisa-kev"
                      ? "bg-amber-950 text-amber-300 font-bold border border-amber-800/80"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <ShieldAlert className="w-3 h-3 text-amber-400" />
                  CISA KEV Catalog ({cisaVulns.length})
                </button>
              </div>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search CVE, actor, vendor, keyword..."
                value={tiSearchQuery}
                onChange={(e) => setTiSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono pl-8 pr-3 py-1.5 rounded focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Feed List Picker */}
          {loadingFeeds ? (
            <div className="text-center py-6 font-mono text-xs text-slate-500">
              <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-emerald-400" />
              Loading Threat Feed Collections...
            </div>
          ) : tiSourceTab === "bleepingcomputer" ? (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {filteredBleepingArticles.length === 0 ? (
                <p className="text-xs font-mono text-slate-500 text-center py-4">No articles match your search.</p>
              ) : (
                filteredBleepingArticles.map((art) => {
                  const isSelected = activeThreat.title === art.title;
                  return (
                    <div
                      key={art.id}
                      onClick={() => handleSelectBleepingArticle(art)}
                      className={`p-3 rounded border transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono ${
                        isSelected
                          ? "bg-red-950/40 border-red-800 text-slate-100"
                          : "bg-slate-900/40 border-slate-850 hover:border-slate-750 text-slate-300"
                      }`}
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-red-400 font-bold flex items-center gap-1">
                            <Rss className="w-3 h-3 text-red-400" />
                            {art.title}
                          </span>
                          {isSelected && (
                            <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-1.5 py-0.2 rounded text-[9px] font-bold">
                              ACTIVE TARGET
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400">
                          <span>{new Date(art.pubDate).toLocaleDateString()}</span>
                          {art.iocs.cves.length > 0 && (
                            <span className="text-red-400">CVEs: {art.iocs.cves.join(", ")}</span>
                          )}
                          {art.iocs.ips.length > 0 && <span>IPs: {art.iocs.ips.length}</span>}
                          {art.iocs.domains.length > 0 && <span>Domains: {art.iocs.domains.length}</span>}
                          {art.iocs.hashes.length > 0 && <span>Hashes: {art.iocs.hashes.length}</span>}
                          {art.iocs.files.length > 0 && <span>Files: {art.iocs.files.length}</span>}
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectBleepingArticle(art);
                        }}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold shrink-0 transition ${
                          isSelected
                            ? "bg-emerald-600 text-white"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                        }`}
                      >
                        {isSelected ? "LOADED" : "SELECT & GENERATE KQL"}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {filteredCisaVulns.length === 0 ? (
                <p className="text-xs font-mono text-slate-500 text-center py-4">No CISA KEV entries match your search.</p>
              ) : (
                filteredCisaVulns.map((v) => {
                  const isSelected = activeThreat.cves?.[0] === v.cveID;
                  return (
                    <div
                      key={v.cveID}
                      onClick={() => handleSelectCisaVuln(v)}
                      className={`p-3 rounded border transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono ${
                        isSelected
                          ? "bg-amber-950/40 border-amber-800 text-slate-100"
                          : "bg-slate-900/40 border-slate-850 hover:border-slate-750 text-slate-300"
                      }`}
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-amber-400 font-bold bg-amber-950/60 border border-amber-800 px-1.5 py-0.5 rounded">
                            {v.cveID}
                          </span>
                          <span className="text-slate-200 font-bold truncate">{v.vulnerabilityName}</span>
                          {v.knownRansomwareCampaignUse === "Known" && (
                            <span className="text-[9px] bg-red-950 text-red-400 border border-red-800 px-1 rounded flex items-center gap-0.5">
                              <Flame className="w-2.5 h-2.5 text-red-400" />
                              RANSOMWARE
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-400">
                          <span>
                            Vendor: <strong className="text-slate-300">{v.vendorProject}</strong>
                          </span>
                          <span>
                            Product: <strong className="text-slate-300">{v.product}</strong>
                          </span>
                          <span>Remediation Due: {v.dueDate}</span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectCisaVuln(v);
                        }}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold shrink-0 transition ${
                          isSelected
                            ? "bg-emerald-600 text-white"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                        }`}
                      >
                        {isSelected ? "LOADED" : "GENERATE EXPLOIT HUNT"}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      )}

      {/* MODE 2: CUSTOM IOC / CVE INPUT FORM */}
      {activeMode === "custom-iocs" && (
        <div className="bg-slate-950/60 border border-slate-900 rounded p-4 space-y-4">
          <div className="border-b border-slate-900 pb-3">
            <h3 className="text-xs font-mono font-bold text-slate-200 uppercase flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-blue-400" />
              INGEST DISCOVERED IOCS & CUSTOM THREAT INTELLIGENCE
            </h3>
            <p className="text-[11px] font-mono text-slate-400 mt-0.5">
              Paste or input newly discovered indicators to instantaneously construct detection and threat hunting queries.
            </p>
          </div>

          {/* Quick Paste Raw Threat Report / Unstructured Text */}
          <div className="bg-slate-900/50 p-3 rounded border border-slate-850 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-mono font-bold text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                AUTO-EXTRACT FROM UNSTRUCTURED ADVISORY / OSINT REPORT
              </label>
              <button
                onClick={() => handleParseRawIocs(rawPastedIocs)}
                className="bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-300 text-[10px] font-mono font-bold px-2.5 py-1 rounded cursor-pointer transition"
              >
                EXTRACT & BUILD QUERIES
              </button>
            </div>
            <textarea
              rows={2}
              placeholder="Paste raw advisory text containing mixed IPs, Domains, CVEs, Hashes, or URLs..."
              value={rawPastedIocs}
              onChange={(e) => setRawPastedIocs(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs font-mono p-2.5 rounded focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          {/* Granular Field Ingestion */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                Campaign / Advisory Title
              </label>
              <input
                type="text"
                placeholder="e.g. Lumma Stealer C2 Beaconing"
                value={customTitleInput}
                onChange={(e) => setCustomTitleInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono px-3 py-2 rounded focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
                <ShieldAlert className="w-3 h-3 text-red-400" /> Target CVE Identifier(s)
              </label>
              <input
                type="text"
                placeholder="e.g. CVE-2024-38077, CVE-2023-36884"
                value={customCveInput}
                onChange={(e) => setCustomCveInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono px-3 py-2 rounded focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
                <Activity className="w-3 h-3 text-blue-400" /> Discovered IP Addresses
              </label>
              <textarea
                rows={2}
                placeholder="185.156.74.52&#10;45.142.214.19"
                value={customIpsInput}
                onChange={(e) => setCustomIpsInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono p-2 rounded focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-400" /> Discovered Domains / Hostnames
              </label>
              <textarea
                rows={2}
                placeholder="licensing-update-cdn.com&#10;win-rdp-broker.net"
                value={customDomainsInput}
                onChange={(e) => setCustomDomainsInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono p-2 rounded focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
                <Hash className="w-3 h-3 text-purple-400" /> File Hashes (SHA256, MD5)
              </label>
              <textarea
                rows={2}
                placeholder="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
                value={customHashesInput}
                onChange={(e) => setCustomHashesInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono p-2 rounded focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
                <FileCode2 className="w-3 h-3 text-amber-400" /> Filenames / Malicious Payloads
              </label>
              <textarea
                rows={2}
                placeholder="rdp_exploit.dll&#10;cmd_spawn.scr"
                value={customFilesInput}
                onChange={(e) => setCustomFilesInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono p-2 rounded focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              onClick={handleApplyCustomFields}
              className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 font-bold px-4 py-2 rounded text-xs font-mono transition cursor-pointer flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              APPLY INDICATORS & REGENERATE KQL TEMPLATES
            </button>
          </div>
        </div>
      )}

      {/* MODE 3: SENTINEL BASELINE RULES REPOSITORY */}
      {activeMode === "baseline-rules" && (
        <div className="space-y-4">
          <div className="bg-slate-950/60 border border-slate-900 rounded p-4 space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search baseline Sentinel rules, MITRE tactics, or query content..."
                  value={baselineSearch}
                  onChange={(e) => setBaselineSearch(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono pl-9 pr-3 py-2 rounded focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={fetchBaselineQueries}
                  className="px-3 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-mono rounded flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingBaseline ? "animate-spin" : ""}`} />
                  REFRESH
                </button>
              </div>
            </div>

            {/* Category Selector */}
            <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono">
              <span className="text-slate-500 mr-1">CATEGORIES:</span>
              {baselineCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedBaselineCategory(cat)}
                  className={`px-2 py-0.5 rounded border transition cursor-pointer ${
                    selectedBaselineCategory === cat
                      ? "bg-purple-950 border-purple-800 text-purple-300 font-bold"
                      : "bg-slate-900/80 border-slate-850 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Baseline queries grid */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {filteredBaseline.map((q) => (
              <div
                key={q.id}
                className="bg-slate-950/70 border border-slate-900 rounded p-4 flex flex-col justify-between hover:border-slate-800 transition shadow-lg space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-purple-400 font-bold bg-purple-950/60 border border-purple-800 px-2 py-0.5 rounded">
                      {q.useCase.toUpperCase()}
                    </span>
                    <div className="flex gap-1">
                      {q.mitreMappings.map((m, idx) => (
                        <span
                          key={idx}
                          className="bg-slate-900 text-slate-300 border border-slate-800 px-1.5 py-0.5 rounded font-mono text-[9px]"
                        >
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>

                  <h3 className="text-xs font-mono font-bold text-slate-100">{q.title}</h3>
                  <p className="text-[11px] font-sans text-slate-400 leading-relaxed">{q.description}</p>

                  <div className="relative bg-slate-950 border border-slate-900 rounded overflow-hidden mt-2">
                    <pre className="p-3 font-mono text-[10px] text-emerald-400 overflow-x-auto max-h-[140px] whitespace-pre bg-slate-1000">
                      {q.query}
                    </pre>
                    <button
                      onClick={() => handleCopy(q.id, q.query)}
                      className="absolute top-2 right-2 bg-slate-900/90 border border-slate-800 p-1.5 rounded font-mono text-[9px] hover:bg-slate-800 hover:text-white transition flex items-center gap-1 cursor-pointer"
                    >
                      {copiedId === q.id ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      {copiedId === q.id ? "COPIED" : "COPY KQL"}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-2 border-t border-slate-900">
                  <span>RULE ID: {q.id}</span>
                  <span className="text-emerald-400 font-bold">READY TO DEPLOY</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ACTIVE THREAT HUNT CONTEXT & TELEMETRY CONTROLS */}
      {(activeMode === "ti-collections" || activeMode === "custom-iocs") && (
        <div className="space-y-6">
          {/* Active Target Threat Banner */}
          <div className="bg-slate-950/80 border border-emerald-950/80 rounded p-4.5 space-y-3 shadow-xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3 h-3 text-emerald-400" />
                  ACTIVE THREAT HUNT CONTEXT
                </span>
                <h3 className="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
                  {activeThreat.title || "Discovered Threat Indicators"}
                </h3>
              </div>

              {/* Parameter Controls: Time Window & Platform */}
              <div className="flex flex-wrap items-center gap-2.5 text-xs font-mono">
                <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-400 text-[10px]">TIME HORIZON:</span>
                  <select
                    value={timeHorizon}
                    onChange={(e) => setTimeHorizon(e.target.value)}
                    className="bg-transparent text-emerald-400 font-bold text-xs focus:outline-none cursor-pointer"
                  >
                    <option value="ago(24h)">ago(24h) - Last 1 Day</option>
                    <option value="ago(7d)">ago(7d) - Last 7 Days</option>
                    <option value="ago(14d)">ago(14d) - Last 14 Days</option>
                    <option value="ago(30d)">ago(30d) - Last 30 Days</option>
                    <option value="ago(90d)">ago(90d) - Last 90 Days</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded">
                  <Terminal className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-400 text-[10px]">TARGET ENGINE:</span>
                  <select
                    value={platformTarget}
                    onChange={(e: any) => setPlatformTarget(e.target.value)}
                    className="bg-transparent text-blue-400 font-bold text-xs focus:outline-none cursor-pointer"
                  >
                    <option value="sentinel">Microsoft Sentinel (SIEM)</option>
                    <option value="mde">Defender XDR (Advanced Hunting)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Injected Indicators Badges */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-900 text-xs font-mono">
              <span className="text-[10px] text-slate-500 uppercase font-bold">INJECTED INDICATORS:</span>

              {activeThreat.cves && activeThreat.cves.length > 0 && (
                <span className="bg-red-950/60 text-red-300 border border-red-800 px-2 py-0.5 rounded text-[11px] font-bold flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-red-400" />
                  CVEs ({activeThreat.cves.length}): {activeThreat.cves.join(", ")}
                </span>
              )}

              {activeThreat.ips && activeThreat.ips.length > 0 && (
                <span className="bg-blue-950/60 text-blue-300 border border-blue-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                  <Activity className="w-3 h-3 text-blue-400" />
                  IPs ({activeThreat.ips.length})
                </span>
              )}

              {activeThreat.domains && activeThreat.domains.length > 0 && (
                <span className="bg-emerald-950/60 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                  <Globe className="w-3 h-3 text-emerald-400" />
                  Domains ({activeThreat.domains.length})
                </span>
              )}

              {activeThreat.hashes && activeThreat.hashes.length > 0 && (
                <span className="bg-purple-950/60 text-purple-300 border border-purple-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                  <Hash className="w-3 h-3 text-purple-400" />
                  Hashes ({activeThreat.hashes.length})
                </span>
              )}

              {activeThreat.files && activeThreat.files.length > 0 && (
                <span className="bg-amber-950/60 text-amber-300 border border-amber-800 px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                  <FileCode2 className="w-3 h-3 text-amber-400" />
                  Payloads ({activeThreat.files.length})
                </span>
              )}
            </div>
          </div>

          {/* Template Category Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
            <span className="text-slate-500 text-[10px] uppercase font-bold mr-1">TELEMETRY FILTER:</span>
            {[
              { id: "all", label: `ALL TEMPLATES (${generatedTemplates.length})` },
              { id: "superhunt", label: "ENTERPRISE SUPER HUNT" },
              { id: "vulnerability", label: "VULNERABILITY (TVM)" },
              { id: "process", label: "PROCESS EXECUTION" },
              { id: "network", label: "NETWORK & C2" },
              { id: "firewall", label: "FIREWALL (COMMONSECURITYLOG)" },
              { id: "file", label: "FILE & PAYLOADS" },
              { id: "dns", label: "DNS RESOLUTION" },
              { id: "email", label: "EMAIL & PHISHING" },
              { id: "identity", label: "IDENTITY (ENTRA ID)" }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedTemplateCategory(cat.id)}
                className={`px-2.5 py-1 rounded border transition cursor-pointer text-[10px] font-bold ${
                  selectedTemplateCategory === cat.id
                    ? "bg-emerald-950 border-emerald-800 text-emerald-300"
                    : "bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-200"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* GENERATED TEMPLATES CARDS GRID */}
          <div className="grid grid-cols-1 gap-5">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-slate-950/70 border border-slate-900 rounded p-4 sm:p-5 hover:border-slate-800 transition shadow-xl space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                      <span className="bg-slate-900 text-emerald-400 border border-slate-800 px-2 py-0.5 rounded font-bold text-[10px]">
                        TABLE: {template.targetTable}
                      </span>
                      <div className="flex gap-1">
                        {template.mitreMappings.map((m, idx) => (
                          <span
                            key={idx}
                            className="bg-amber-950/50 text-amber-300 border border-amber-850 px-1.5 py-0.5 rounded text-[9px] font-bold"
                          >
                            MITRE {m}
                          </span>
                        ))}
                      </div>
                    </div>
                    <h3 className="text-sm font-mono font-bold text-slate-100">{template.title}</h3>
                    <p className="text-xs font-sans text-slate-400">{template.description}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 pt-1">
                    <button
                      onClick={() => handleDownloadKql(template.title, template.query)}
                      className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-mono rounded flex items-center gap-1 cursor-pointer"
                      title="Download query as .kql file"
                    >
                      <Download className="w-3 h-3 text-slate-400" />
                      .KQL
                    </button>

                    <button
                      onClick={() => handleCopy(template.id, template.query)}
                      className="px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-xs font-mono font-bold rounded flex items-center gap-1.5 cursor-pointer transition"
                    >
                      {copiedId === template.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          COPIED!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          COPY QUERY
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* KQL Code block */}
                <div className="relative bg-slate-950 border border-slate-900 rounded overflow-hidden">
                  <pre className="p-3.5 font-mono text-xs text-emerald-400 overflow-x-auto max-h-56 whitespace-pre scrollbar-thin bg-slate-1000">
                    {template.query}
                  </pre>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI CUSTOM HUNT QUERY GENERATOR MODAL */}
      {isAiModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg max-w-2xl w-full p-6 space-y-4 shadow-2xl font-mono">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                AI-POWERED SENTINEL KQL TUNER (GEMINI)
              </h3>
              <button
                onClick={() => setIsAiModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Provide a specific hunting hypothesis or operational objective. The Gemini AI engine will synthesize
              a custom KQL query optimized for your specified telemetry table and target indicators.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-bold">Target Threat Context</label>
                <input
                  type="text"
                  value={activeThreat.title || ""}
                  disabled
                  className="w-full bg-slate-950 border border-slate-800 text-slate-400 p-2 rounded text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">Target Telemetry Table</label>
                  <select
                    value={aiSelectedTable}
                    onChange={(e) => setAiSelectedTable(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded text-xs"
                  >
                    <option value="DeviceProcessEvents">DeviceProcessEvents (Process Spawning)</option>
                    <option value="DeviceNetworkEvents">DeviceNetworkEvents (C2 Traffic)</option>
                    <option value="DeviceFileEvents">DeviceFileEvents (Payload Drops)</option>
                    <option value="DeviceTvmSoftwareVulnerabilities">DeviceTvmSoftwareVulnerabilities (TVM)</option>
                    <option value="CommonSecurityLog">CommonSecurityLog (Firewalls)</option>
                    <option value="SigninLogs">SigninLogs (Entra ID Authentications)</option>
                    <option value="DnsEvents">DnsEvents (DNS Resolution)</option>
                    <option value="EmailEvents">EmailEvents (Defender for Office)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 block mb-1 font-bold">Time Window</label>
                  <select
                    value={timeHorizon}
                    onChange={(e) => setTimeHorizon(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded text-xs"
                  >
                    <option value="ago(24h)">ago(24h)</option>
                    <option value="ago(7d)">ago(7d)</option>
                    <option value="ago(30d)">ago(30d)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-bold">
                  Hunting Objective & Analytical Requirement
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Find instances where vulnerable processes spawn PowerShell with base64 encoded parameters or write DLLs to Temp directory..."
                  value={aiObjective}
                  onChange={(e) => setAiObjective(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 p-2 rounded text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setIsAiModalOpen(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleGenerateAiKql}
                disabled={generatingAi}
                className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 ${generatingAi ? "animate-spin" : ""}`} />
                {generatingAi ? "SYNTHESIZING KQL..." : "GENERATE QUERY"}
              </button>
            </div>

            {/* Render AI Result if available */}
            {aiGeneratedResult && (
              <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-emerald-400">{aiGeneratedResult.title}</h4>
                  <button
                    onClick={() => handleCopy("ai-query", aiGeneratedResult.kqlQuery)}
                    className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded flex items-center gap-1 cursor-pointer"
                  >
                    {copiedId === "ai-query" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copiedId === "ai-query" ? "COPIED" : "COPY KQL"}
                  </button>
                </div>
                <p className="text-[11px] text-slate-300 font-sans">{aiGeneratedResult.description}</p>
                <pre className="p-3 bg-slate-950 border border-slate-800 rounded text-xs text-emerald-400 overflow-x-auto max-h-48 whitespace-pre">
                  {aiGeneratedResult.kqlQuery}
                </pre>
                {aiGeneratedResult.investigationGuidance && (
                  <p className="text-[10px] text-amber-300/90 font-sans bg-amber-950/20 border border-amber-900/50 p-2 rounded">
                    <strong>Investigation Guidance:</strong> {aiGeneratedResult.investigationGuidance}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
