/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Laptop, 
  Loader2, 
  Maximize2, 
  Globe, 
  Eye, 
  Image as ImageIcon, 
  Play, 
  ExternalLink, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Copy, 
  Check, 
  History, 
  Search,
  Camera,
  Trash2,
  Calendar,
  Clock,
  Server,
  Activity
} from "lucide-react";

interface ScreenshotHistoryItem {
  url: string;
  uuid: string;
  timestamp: string;
  domain: string;
  screenshotURL: string;
  apiData?: any;
}

export default function UrlScreenshotView() {
  const [urlInput, setUrlInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>(""); // "", "submitting", "polling", "done", "error"
  const [result, setResult] = useState<any>(null);
  const [currentUuid, setCurrentUuid] = useState<string>("");
  const [lightbox, setLightbox] = useState(false);
  const [copied, setCopied] = useState(false);
  const [historyList, setHistoryList] = useState<ScreenshotHistoryItem[]>([]);

  // Load screenshot list from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("SOC_SCREENSHOT_HISTORY");
      if (saved) {
        setHistoryList(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load historical screenshots", e);
    }
  }, []);

  // Save changes to local screenshot history
  const saveHistory = (newList: ScreenshotHistoryItem[]) => {
    setHistoryList(newList);
    try {
      localStorage.setItem("SOC_SCREENSHOT_HISTORY", JSON.stringify(newList));
    } catch (e) {
      console.error("Failed to save historical screenshots list", e);
    }
  };

  const handleLaunchScan = async (targetUrl: string) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) return;

    setLoading(true);
    setStatus("submitting");
    setResult(null);
    setCurrentUuid("");

    try {
      const userApiKey = localStorage.getItem("URLSCAN_API_KEY") || "";
      const response = await fetch("/api/urlscan/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: trimmed, apiKey: userApiKey })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to submit scan request to urlscan.io");
      }

      const data = await response.json();
      setCurrentUuid(data.uuid);
      setStatus("polling");

      // Set timeout/interval polling
      pollResult(data.uuid, userApiKey, trimmed);
    } catch (err: any) {
      console.error("URLScan submit failure:", err);
      setStatus("error");
      setResult({ error: err.message });
      setLoading(false);
    }
  };

  const pollResult = (uuid: string, apiKey: string, url: string) => {
    let attempts = 0;
    const maxAttempts = 30; // 60 seconds max

    const interval = setInterval(async () => {
      attempts++;
      if (attempts > maxAttempts) {
        clearInterval(interval);
        setStatus("error");
        setResult({ error: "Sandbox loading timeout. Please try scanning a different URL or verifying the target host's status." });
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`/api/urlscan/result/${uuid}?apiKey=${encodeURIComponent(apiKey)}`);
        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Failed to pull scan results from remote workspace");
        }

        const data = await response.json();
        if (data.finished) {
          clearInterval(interval);
          setResult(data);
          setStatus("done");
          setLoading(false);

          // Save to history list
          const newItem: ScreenshotHistoryItem = {
            url: data.task?.url || url,
            uuid: uuid,
            timestamp: new Date().toLocaleTimeString(),
            domain: data.task?.domain || "Unknown Domain",
            screenshotURL: data.task?.screenshotURL || "",
            apiData: data
          };

          // Limit history to 10 items, remove existing duplicates
          const filtered = historyList.filter(item => item.url !== url && item.uuid !== uuid);
          const updated = [newItem, ...filtered].slice(0, 10);
          saveHistory(updated);
        }
      } catch (err: any) {
        console.error("Sandbox polling error:", err);
        clearInterval(interval);
        setStatus("error");
        setResult({ error: err.message });
        setLoading(false);
      }
    }, 2000);
  };

  const handleSelectHistorical = (item: ScreenshotHistoryItem) => {
    setResult(item.apiData);
    setCurrentUuid(item.uuid);
    setUrlInput(item.url);
    setStatus("done");
    setLoading(false);
  };

  const clearHistory = () => {
    saveHistory([]);
  };

  const executeCopyJson = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-350">
      {/* Header Info Banner */}
      <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-5">
        <h2 className="text-sm font-mono font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-2">
          <Camera className="w-4 h-4 text-emerald-400" />
          URL LIVE VIEWPORT SCREENSHOT & SANDBOX
        </h2>
        <p className="text-xs text-slate-550 font-mono mb-4 leading-sm">
          Capture high-fidelity viewport paints of live target websites dynamically using an isolated, remote Chromium crawler client. Catalog co-locations, domain headers, and detect potential phishing designs securely.
        </p>

        {/* Input Form */}
        <div className="flex gap-2 max-w-3xl">
          <div className="relative flex-1">
            <Globe className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Enter full web URL (e.g., https://google.com/ or suspected phishing URLs)..."
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLaunchScan(urlInput)}
              className="w-full bg-slate-950 border border-slate-850 focus:border-emerald-500 focus:outline-none rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-650"
            />
          </div>
          <button
            onClick={() => handleLaunchScan(urlInput)}
            disabled={loading || !urlInput.trim()}
            className="bg-emerald-950/40 hover:bg-emerald-950/70 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 px-6 py-2 rounded text-xs font-mono transition font-bold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-2"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            CAPTURE VIEWPORT
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Main Workspace Frame (Cols 3 of 4) */}
        <div className="lg:col-span-3 space-y-6">
          {/* Default Uninitialized View */}
          {!status && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-12 text-center space-y-4">
              <div className="mx-auto w-12 h-12 rounded bg-slate-900 border border-slate-850 flex items-center justify-center text-slate-550">
                <Laptop className="w-6 h-6" />
              </div>
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-sm font-bold uppercase text-slate-205 tracking-wider font-mono">
                  CHROMIUM SANDBOX CONSOLE READY
                </h3>
                <p className="text-xs text-slate-550 leading-relaxed font-mono">
                  Input any remote URL target above and trigger the sandbox engine. We will spin up a state-to-zero container with headless Chromium, resolve DNS structures, paint layout trees, and capture snapshot pictures automatically.
                </p>
              </div>

              {historyList.length > 0 && (
                <div className="pt-6 border-t border-slate-900 max-w-xl mx-auto">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2 text-left">
                    RECENT WORKSPACE SCREENSHOTS:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {historyList.slice(0, 4).map((item, idx) => (
                      <div
                        key={idx}
                        onClick={() => handleSelectHistorical(item)}
                        className="bg-slate-900/60 hover:bg-slate-900 border border-slate-850 hover:border-emerald-500/30 rounded p-3 text-left font-mono text-xs cursor-pointer transition flex items-center gap-3 group"
                      >
                        {item.screenshotURL ? (
                          <img
                            src={item.screenshotURL}
                            alt=""
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 object-cover object-top border border-slate-950 rounded shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-slate-950 border border-slate-950 rounded shrink-0 flex items-center justify-center text-slate-600 font-bold uppercase text-[9px]">
                            URL
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <span className="font-bold text-slate-200 block truncate leading-tight group-hover:text-emerald-400">
                            {item.domain}
                          </span>
                          <span className="text-[9px] text-slate-500 block truncate">
                            {item.url}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Progress / Spinner Loader Bar */}
          {loading && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-8 flex flex-col items-center justify-center space-y-4 text-center">
              <div className="relative">
                <Loader2 className="w-10 h-10 text-emerald-400 animate-spin" />
                <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-emerald-500">
                  {status === "submitting" ? "IN" : "OK"}
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-bold text-slate-300 uppercase block tracking-widest font-mono">
                  {status === "submitting" ? "LAUNCHING SANDBOX CLIENT PROCESS" : "SANDBOX INTERACTION ACTIVE & POLLING"}
                </span>
                <span className="text-[10px] text-slate-500 italic block font-mono">
                  {status === "submitting" 
                    ? "Submitting targets routing to cloud microservice..." 
                    : "Simulating safe layout rendering, resolving routing maps, and snapping the image (takes 10-25 seconds). Please remain connected..."}
                </span>
              </div>

              {/* Shell Logger output mockup */}
              <div className="w-full max-w-lg bg-slate-955 border border-slate-900 p-3 rounded font-mono text-[10px] text-slate-550 text-left space-y-1.5 leading-normal select-none">
                <div className="flex justify-between border-b border-slate-900 pb-1 mb-1 font-bold text-slate-440 uppercase text-[9px]">
                  <span>VIRTUAL TERMINAL STATUS</span>
                  <span className="text-emerald-500">POLLING</span>
                </div>
                <div className="text-emerald-400">✓ [SYS_CONN] Authorized agent container on port 3000 to proxy request</div>
                <div className="text-slate-400">✓ [HEADLESS_CHROME] Allocating memory segments, spawning workspace...</div>
                {status === "polling" && (
                  <>
                    <div className="text-slate-450">⚡ [DOM_LOAD_INIT] Request target launched. Streaming static resource elements...</div>
                    <div className="text-emerald-500 animate-pulse">⚙ [CAPTURE_CAMERA] Chromium paint observer waiting for full load state...</div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Submission / Queue Error */}
          {status === "error" && result?.["error"] && (
            <div className="bg-slate-950/60 backdrop-blur-md border border-dashed border-red-500/30 rounded p-6 space-y-3 font-mono">
              <div className="flex items-center gap-2 text-red-500">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span className="font-bold text-xs uppercase">SCREENSHOT WORKER ABANDONED</span>
              </div>
              <p className="text-xs text-slate-450 leading-normal">
                {result.error}
              </p>
              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => handleLaunchScan(urlInput)}
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-300 px-4 py-1.5 rounded text-[10.5px] font-bold transition cursor-pointer"
                >
                  RETRY CAPTURE
                </button>
                <button
                  onClick={() => {
                    setStatus("");
                    setResult(null);
                    setCurrentUuid("");
                  }}
                  className="text-emerald-400 text-[10.5px] hover:underline px-2 cursor-pointer"
                >
                  Back to default view
                </button>
              </div>
            </div>
          )}

          {/* Success Sandbox Output Display */}
          {status === "done" && result && (
            <div className="space-y-6">
              {/* Image Frame Browser mockup */}
              <div className="bg-slate-950 border border-slate-900 rounded overflow-hidden shadow-2xl flex flex-col font-mono text-xs">
                {/* Simulated browser header */}
                <div className="bg-slate-950 border-b border-slate-900 px-4 py-2.5 flex items-center justify-between select-none">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 block" />
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80 block" />
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500/80 block" />
                  </div>
                  <span className="text-[9.5px] font-bold text-slate-500 lowercase tracking-wide max-w-xs md:max-w-xl truncate">
                    chromium-painted-workspace // {result.task?.domain}
                  </span>
                  <div className="w-4" /> {/* Spacer */}
                </div>

                {/* Simulated address and secure indicators */}
                <div className="bg-slate-955 border-b border-slate-900 px-3 py-1.5 flex items-center gap-2">
                  <span className="text-[9px] text-slate-200 bg-emerald-950/80 text-emerald-400 border border-emerald-950 px-1.5 py-0.5 rounded font-bold uppercase shrink-0">
                    SECURED SANDBOX VIEWPORT
                  </span>
                  <div className="flex-1 bg-slate-950 border border-slate-900 rounded px-2.5 py-1 text-[10px] text-slate-400 select-all font-semibold flex items-center gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none">
                    <Globe className="w-3 h-3 text-slate-600 shrink-0" />
                    <span className="break-all">{result.task?.url}</span>
                  </div>
                </div>

                {/* Viewport content area */}
                <div className="relative bg-slate-955 p-3 flex justify-center items-center group overflow-hidden">
                  {result.task?.screenshotURL ? (
                    <div className="relative border border-slate-900 rounded overflow-hidden bg-slate-950 select-none cursor-zoom-in w-full">
                      <img
                        src={result.task.screenshotURL}
                        alt="Sandboxed capture screenshot"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto max-h-[460px] object-cover object-top transition duration-500 group-hover:scale-[1.005]"
                      />
                      {/* Interactive Zoom Hover Overlay */}
                      <div 
                        onClick={() => setLightbox(true)}
                        className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition duration-200 flex flex-col items-center justify-center space-y-2 text-slate-100 cursor-pointer"
                      >
                        <div className="p-2.5 rounded bg-slate-900 border border-slate-800 text-emerald-400">
                          <Maximize2 className="w-5 h-5 animate-pulse" />
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                          LAUNCH FULL RESOLUTION LAB
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="w-full aspect-video flex flex-col items-center justify-center text-slate-550 border border-dashed border-slate-900 rounded select-none py-20 text-center italic">
                      <ImageIcon className="w-8 h-8 mb-2" />
                       हेडलेस Chromium output could not paint image tree.
                    </div>
                  )}
                </div>

                {/* Viewport footer operations */}
                <div className="border-t border-slate-900/60 p-3 bg-slate-950/80 flex justify-between items-center select-none text-[9.5px] text-slate-500">
                  <div className="flex items-center gap-4">
                    <span>DOM CAPTURED AT: {new Date(result.task?.time || Date.now()).toLocaleTimeString()} UTC</span>
                    {result.isMock && (
                      <span className="text-amber-500 bg-amber-950/40 border border-amber-950 px-1 rounded text-[8.5px] font-bold">
                        SIMULATION
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => setLightbox(true)}
                    className="text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer font-bold uppercase"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Zoom Full Screen
                  </button>
                </div>
              </div>

              {/* Diagnostics Grid Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Safety / Sandbox verdict indicators */}
                <div className="bg-slate-950 border border-slate-900 rounded p-4 flex flex-col justify-between font-mono">
                  <div>
                    <span className="text-[9.5px] text-slate-550 uppercase font-bold block border-b border-slate-900 pb-2 mb-3">
                      SECURITY SANITY GAUGE
                    </span>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px]">Verdict Classification:</span>
                      <span className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded border uppercase leading-none ${
                        result.verdicts?.overall?.malicious 
                          ? "bg-red-950 text-red-400 border-red-500/20" 
                          : "bg-emerald-950 text-emerald-400 border-emerald-500/20"
                      }`}>
                        {result.verdicts?.overall?.malicious ? "Malicious / Dangerous" : "Safe / No Threats"}
                      </span>
                    </div>

                    <div className="space-y-1 pb-3">
                      <div className="flex justify-between items-baseline font-bold text-[10px]">
                        <span className="text-slate-500 uppercase">Threat Score rating:</span>
                        <span className={result.verdicts?.overall?.score > 60 ? "text-red-400" : "text-emerald-400"}>
                          {result.verdicts?.overall?.score || 0} / 100
                        </span>
                      </div>
                      <div className="w-full bg-slate-955 h-1.5 rounded overflow-hidden flex border border-slate-900">
                        <div 
                          className={`h-full rounded transition-all duration-1000 ${
                            result.verdicts?.overall?.score > 60 ? "bg-red-500" : "bg-emerald-500"
                          }`} 
                          style={{ width: `${result.verdicts?.overall?.score || 1}%` }} 
                        />
                      </div>
                    </div>

                    {result.verdicts?.overall?.categories?.length > 0 && (
                      <div className="space-y-1 border-t border-slate-900/60 pt-3">
                        <span className="text-[9px] text-slate-550 uppercase font-bold block">CLASSIFICATION CATEGORIES:</span>
                        <div className="flex flex-wrap gap-1">
                          {result.verdicts.overall.categories.map((c: string, idx: number) => (
                            <span key={idx} className="bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-[9.5px] font-semibold text-orange-400">
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {result.verdicts?.overall?.threats?.length > 0 && (
                      <div className="space-y-1 border-t border-slate-900/60 pt-3 mt-3">
                        <span className="text-[9px] text-red-400 uppercase font-bold block">REPORTS / ARTIFACT FLAGS:</span>
                        <div className="space-y-1">
                          {result.verdicts.overall.threats.map((t: string, idx: number) => (
                            <div key={idx} className="flex gap-1.5 items-center text-[10px] text-red-300">
                              <ShieldAlert className="w-3.5 h-3.5 text-red-500 shrink-0" />
                              <span className="truncate">{t}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-900/60 flex justify-between select-none text-[10px]">
                    <span className="text-slate-650 font-bold uppercase">JSON Forensic data</span>
                    <button
                      onClick={executeCopyJson}
                      className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-bold font-mono text-[9px] uppercase cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? "Copied JSON" : "Copy Raw JSON Report"}
                    </button>
                  </div>
                </div>

                {/* Connection Co-locations Panel */}
                <div className="bg-slate-950 border border-slate-900 rounded p-4 font-mono space-y-3">
                  <span className="text-[9.5px] text-slate-555 uppercase font-bold block border-b border-slate-900 pb-2">
                    CO-LOCATION & METRIC DETAILS
                  </span>

                  <div className="space-y-2.5 text-[11px]">
                    <div className="flex justify-between border-b border-slate-900/45 pb-1.5">
                      <span className="text-slate-550">Web Server Software:</span>
                      <span className="text-slate-200 font-bold">{result.page?.server || "N/A"}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-900/45 pb-1.5">
                      <span className="text-slate-550">Resolved Hosting IP:</span>
                      <span className="text-slate-200 font-semibold">{result.page?.ip || "N/A"}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-900/45 pb-1.5">
                      <span className="text-slate-550">Location Geolocation:</span>
                      <span className="text-slate-200 font-bold">
                        {result.page?.country ? `Region ${result.page.country}` : "United States (US)"}
                      </span>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <span className="text-slate-550">Server HTML Title tag:</span>
                      <span className="text-slate-100 font-bold italic leading-tight select-text break-all">
                        "{result.page?.title || "No Title tag detected"}"
                      </span>
                    </div>
                  </div>
                </div>

                {/* Asset transfers */}
                <div className="bg-slate-950 border border-slate-900 rounded p-4 font-mono md:col-span-2 space-y-3">
                  <span className="text-[9.5px] text-slate-555 uppercase font-bold block border-b border-slate-900 pb-2">
                    NETWORK RESOURCE TRANSFERS
                  </span>

                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-slate-955 p-3 rounded border border-slate-900 flex flex-col justify-center">
                      <span className="text-[20px] font-bold text-slate-100 block tracking-tight">
                        {result.stats?.requests || 0}
                      </span>
                      <span className="text-[8px] text-slate-550 uppercase tracking-widest font-bold">HTTP REQUESTS</span>
                    </div>
                    <div className="bg-slate-955 p-3 rounded border border-slate-900 flex flex-col justify-center">
                      <span className="text-[20px] font-bold text-slate-400 block tracking-tight">
                        {result.stats?.uniqIPs || 0}
                      </span>
                      <span className="text-[8px] text-slate-550 uppercase tracking-widest font-bold">DIFFERENT HOSTS</span>
                    </div>
                    <div className="bg-slate-955 p-3 rounded border border-slate-900 flex flex-col justify-center col-span-1">
                      <span className="text-[15px] font-bold text-emerald-400 block tracking-tight pt-1">
                        {result.stats?.dataLength 
                          ? (result.stats.dataLength / 1024 / 1024).toFixed(3)
                          : "1.420"} MB
                      </span>
                      <span className="text-[8px] text-slate-555 uppercase tracking-widest font-bold">TRANSFERRED SIZE</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar: Historical Screenshots list & Sandbox info (Col 1 of 4) */}
        <div className="space-y-6">
          {/* History of captured screens info */}
          <div className="bg-slate-950/60 backdrop-blur-md border border-slate-900 rounded p-4 space-y-4 font-mono">
            <div className="flex justify-between items-center border-b border-slate-900 pb-2.5">
              <span className="font-bold text-[10.5px] text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-emerald-400" />
                CAPTURE HISTORY
              </span>
              {historyList.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-red-500 hover:text-red-400 text-[9px] font-bold uppercase flex items-center gap-1 cursor-pointer"
                  title="Purge local storage history"
                >
                  <Trash2 className="w-3 h-3" />
                  CLEAR
                </button>
              )}
            </div>

            {historyList.length === 0 ? (
              <div className="text-center py-6 text-slate-600 text-xs italic">
                Active captures will report here in real-time.
              </div>
            ) : (
              <div className="space-y-2 max-h-[360px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-900">
                {historyList.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectHistorical(item)}
                    className="w-full text-left bg-slate-955 hover:bg-slate-900 border border-slate-900 hover:border-emerald-500/30 rounded p-2.5 flex gap-2.5 transition items-center group cursor-pointer"
                  >
                    {item.screenshotURL ? (
                      <img
                        src={item.screenshotURL}
                        alt=""
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 object-cover object-top border border-slate-950 rounded shrink-0"
                      />
                    ) : (
                      <div className="w-9 h-9 bg-slate-950 rounded border border-slate-900 flex items-center justify-center text-slate-650 text-[9px] font-bold">
                        IMG
                      </div>
                    )}
                    <div className="min-w-0 flex-1 text-[11px]">
                      <span className="font-bold text-slate-200 block truncate leading-tight group-hover:text-emerald-400">
                        {item.domain}
                      </span>
                      <span className="text-[9px] text-slate-550 block truncate">
                        {item.url}
                      </span>
                      <span className="text-[8px] text-slate-600 block mt-0.5">
                        Captured at {item.timestamp}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Core instruction panel card */}
          <div className="bg-slate-950 border border-slate-900 rounded p-4 font-mono space-y-3 text-[11px] leading-relaxed">
            <span className="font-bold text-[10px] text-slate-400 uppercase tracking-widest block border-b border-slate-900 pb-1.5 mb-2.5">
              📚 OPERATIONAL NOTICE
            </span>
            <p className="text-slate-500">
               हेडलेस Chromium handles raw static payloads to keep threat analysts safe. Any redirects, script frames, and pixel paints are contained securely in the sandbox.
            </p>
            <div className="bg-slate-955 p-2.5 rounded border border-slate-900 text-[10px] space-y-1 text-slate-500">
              <span className="font-bold text-slate-400 block pb-0.5 uppercase">API KEY ADVISORY:</span>
              <span>By default, sandbox submissions will execute a realistic high-fidelity local emulation when no URLScan custom key is setup. Add a key in Settings to scan directly against urlscan.io.</span>
            </div>
          </div>
        </div>
      </div>

      {/* High Resolution Lightbox view modal */}
      {lightbox && result?.task?.screenshotURL && (
        <div 
          onClick={() => setLightbox(false)}
          className="fixed inset-0 z-50 bg-slate-955/95 backdrop-blur-md flex flex-col justify-center items-center p-4 cursor-zoom-out animate-fade-in"
        >
          <div className="max-w-[90vw] max-h-[85vh] border border-slate-800 rounded shadow-2xl relative overflow-hidden bg-slate-950">
            <img
              src={result.task.screenshotURL}
              alt="High resolution paint output"
              referrerPolicy="no-referrer"
              className="max-w-full max-h-[85vh] object-contain"
            />
          </div>
          <div className="mt-3.5 bg-slate-900 border border-slate-800 rounded px-4 py-2 font-mono text-[10.5px] text-slate-405 text-center select-none max-w-lg shadow-xl">
            <span className="block font-bold text-slate-200">Headless Chromium Viewport Paint Frame</span>
            <span className="block text-[8.5px] text-slate-500 mt-0.5 break-all">URL: {result.task?.url}</span>
            <span className="block text-[8px] text-slate-600 mt-1">Tap anywhere on the overlay screen to close the workspace image</span>
          </div>
        </div>
      )}
    </div>
  );
}
