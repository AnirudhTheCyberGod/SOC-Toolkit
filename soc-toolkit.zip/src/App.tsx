/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ActiveTab, SearchLog, ApiStatus } from "./types";

// Component imports
import Sidebar from "./components/Sidebar";
import DashboardView from "./components/DashboardView";
import ThreatIntelView from "./components/ThreatIntelView";
import WhoisTerminalView from "./components/WhoisTerminalView";
import IPInvestView from "./components/IPInvestView";
import DomainInvestView from "./components/DomainInvestView";
import UrlAnalysisView from "./components/UrlAnalysisView";
import UrlScreenshotView from "./components/UrlScreenshotView";
import HashAnalysisView from "./components/HashAnalysisView";
import FileAnalysisView from "./components/FileAnalysisView";
import HeaderAnalysisView from "./components/HeaderAnalysisView";
import MalwareAnalysisView from "./components/MalwareAnalysisView";
import OsintHubView from "./components/OsintHubView";
import RansomwareView from "./components/RansomwareView";
import MitreView from "./components/MitreView";
import KqlPlaygroundView from "./components/KqlPlaygroundView";
import UtilitiesView from "./components/UtilitiesView";
import SettingsView from "./components/SettingsView";
import MacLookupView from "./components/MacLookupView";
import SiemIntegrationView from "./components/SiemIntegrationView";
import AsnSslView from "./components/AsnSslView";
import EventIdEncyclopediaView from "./components/EventIdEncyclopediaView";
import PortLookupView from "./components/PortLookupView";
import AiCommandInterpreterView from "./components/AiCommandInterpreterView";
import LogAnalyzerView from "./components/LogAnalyzerView";
import ThreatGraphView from "./components/ThreatGraphView";
import HomographDetectorView from "./components/HomographDetectorView";
import IncidentReportView from "./components/IncidentReportView";

import { Clock, ShieldAlert, Cpu, Sun, Moon, Equal } from "lucide-react";

export default function App() {
  const [currentTab, setCurrentTab] = useState<ActiveTab>(ActiveTab.Dashboard);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    if (window.innerWidth < 768) {
      setIsMobileSidebarOpen((prev) => !prev);
    } else {
      setIsSidebarOpen((prev) => !prev);
    }
  };

  // Security warning overlay state
  const [securityNotice, setSecurityNotice] = useState<{ active: boolean; message: string }>({
    active: false,
    message: ""
  });

  // Theme state: default to dark, support toggle to light
  const [theme, setTheme] = useState<"light" | "dark" | string>(() => {
    return localStorage.getItem("soc_theme") || "dark";
  });

  useEffect(() => {
    localStorage.setItem("soc_theme", theme);
    const root = document.documentElement;
    if (theme === "light") {
      root.classList.add("light");
      root.classList.remove("dark");
    } else {
      root.classList.add("dark");
      root.classList.remove("light");
    }
  }, [theme]);

  // Handle auto-clearing of the security toast overlay
  useEffect(() => {
    let t: any;
    if (securityNotice.active) {
      t = setTimeout(() => {
        setSecurityNotice({ active: false, message: "" });
      }, 4000);
    }
    return () => clearTimeout(t);
  }, [securityNotice.active]);

  // Anti-Reproduction / Anti-Scraping protection event listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf("MAC") >= 0;
      const cmdOrCtrl = isMac ? e.metaKey : e.ctrlKey;

      // Class 1: Common saving/archiving key bindings (Ctrl+S, Ctrl+U)
      if (cmdOrCtrl && (e.key === "s" || e.key === "u" || e.keyCode === 83 || e.keyCode === 85)) {
        e.preventDefault();
        setSecurityNotice({
          active: true,
          message: "Aegis Core Sentinel: Page saving and source archiving have been restricted on this terminal to protect intellectual design."
        });
        return;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  // Shared forensic search logger state containing mock seed logs
  const [searchLogs, setSearchLogs] = useState<SearchLog[]>([
    {
      id: "log_01",
      type: "IP",
      query: "185.156.74.52",
      timestamp: "10m ago",
      reputation: "malicious",
      score: 88,
    },
    {
      id: "log_02",
      type: "Domain",
      query: "firmas-digitales.com",
      timestamp: "23m ago",
      reputation: "suspicious",
      score: 45,
    },
    {
      id: "log_03",
      type: "URL",
      query: "http://billing-update-support.xyz/login",
      timestamp: "1h ago",
      reputation: "malicious",
      score: 95,
    },
    {
      id: "log_04",
      type: "Hash",
      query: "6b251a3f6bd5b357be842decd23e20ab0a2decf",
      timestamp: "3h ago",
      reputation: "clean",
      score: 0,
    },
  ]);

  // Premium services configuration indicators
  const [apiStatus, setApiStatus] = useState<ApiStatus[]>([
    { service: "VirusTotal", status: "not-configured" },
    { service: "AbuseIPDB", status: "not-configured" },
    { service: "GreyNoise", status: "not-configured" },
    { service: "Shodan", status: "not-configured" },
  ]);

  // Hydrate settings from secure server-side cache on initial mount for cross-device compatibility
  useEffect(() => {
    const adminToken = localStorage.getItem("THREATNEXUS_ADMIN_TOKEN") || "";
    const headers: Record<string, string> = {};
    if (adminToken) headers["Authorization"] = `Bearer ${adminToken}`;

    fetch("/api/settings", { headers })
      .then((res) => {
        if (res.ok) return res.json();
      })
      .then((data) => {
        if (data) {
          const isConfigured = data.isConfigured || {};
          
          if (data.isAdmin && data.keys) {
            // Admin mode: keep keys in localStorage for immediate client fallback
            Object.keys(data.keys).forEach((key) => {
              if (data.keys[key]) localStorage.setItem(key, data.keys[key]);
            });
          } else {
            // Team Mode: sanitize browser localStorage to ensure zero client leaks
            const sensitiveKeys = [
              "VT_API_KEY", "ABUSEIPDB_API_KEY", "GREYNOISE_API_KEY", "SHODAN_API_KEY",
              "URLSCAN_API_KEY", "GEMINI_API_KEY", "IPINFO_API_KEY", "IP2PROXY_API_KEY",
              "IPQUALITYSCORE_API_KEY", "WHOISJSON_API_KEY"
            ];
            sensitiveKeys.forEach((key) => localStorage.removeItem(key));
          }

          // Update header status indicators from server-side vault verification
          const statusKeys = [
            { key: "VT_API_KEY", name: "VirusTotal" },
            { key: "ABUSEIPDB_API_KEY", name: "AbuseIPDB" },
            { key: "GREYNOISE_API_KEY", name: "GreyNoise" },
            { key: "SHODAN_API_KEY", name: "Shodan" },
          ];
          
          const status = statusKeys.map((item) => ({
            service: item.name,
            status: isConfigured[item.key] ? ("configured" as const) : ("not-configured" as const),
          }));
          setApiStatus(status);
        }
      })
      .catch((err) => console.error("Initial settings hydration failed:", err));
  }, [currentTab]);

  // State to hold parameters passed between investigative platforms
  const [pendingQueries, setPendingQueries] = useState<{
    IP: string;
    Domain: string;
    URL: string;
    Hash: string;
    Malware: string;
  }>({
    IP: "",
    Domain: "",
    URL: "",
    Hash: "",
    Malware: "",
  });

  // Clock dynamic UTC and IST (Chennai) telemetry
  const [currentTime, setCurrentTime] = useState("");
  const [chennaiTime, setChennaiTime] = useState("");
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setCurrentTime(d.toUTCString());
      const ist = d.toLocaleDateString("en-IN", {
        timeZone: "Asia/Kolkata",
        day: "2-digit",
        month: "short"
      }) + " " + d.toLocaleTimeString("en-IN", {
        timeZone: "Asia/Kolkata",
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      });
      setChennaiTime(ist);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleAddSearchLog = (log: {
    type: "IP" | "Domain" | "URL" | "Hash" | "Malware";
    query: string;
    reputation: "clean" | "suspicious" | "malicious" | "unknown";
    score?: number;
  }) => {
    const newLog: SearchLog = {
      id: `log_${Date.now()}`,
      type: log.type,
      query: log.query,
      timestamp: "Just now",
      reputation: log.reputation,
      score: log.score,
    };
    setSearchLogs([newLog, ...searchLogs]);
  };

  // Switch tabs and inject parameters directly when clicking 'ENRICH' from any matrix view
  const handleSelectQuery = (type: "IP" | "Domain" | "URL" | "Hash" | "Malware", value: string) => {
    setPendingQueries((prev) => ({
      ...prev,
      [type]: value,
    }));

    // Route to respective specific tab
    switch (type) {
      case "IP":
        setCurrentTab(ActiveTab.IPInvest);
        break;
      case "Domain":
        setCurrentTab(ActiveTab.DomainInvest);
        break;
      case "URL":
        setCurrentTab(ActiveTab.URLAnalysis);
        break;
      case "Hash":
        setCurrentTab(ActiveTab.HashAnalysis);
        break;
      case "Malware":
        setCurrentTab(ActiveTab.MalwareAnalysis);
        break;
      default:
        break;
    }
  };

  const [kqlThreatContext, setKqlThreatContext] = useState<any | null>(null);

  const handleNavigateToKql = (context: any) => {
    setKqlThreatContext(context);
    setCurrentTab(ActiveTab.KqlPlayground);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div id="soc-toolkit-app" className="flex bg-slate-1000 min-h-screen text-slate-100 selection:bg-red-500/25 selection:text-white relative">
      {/* Dynamic Nav Sidebar component */}
      <Sidebar 
        currentTab={currentTab} 
        onTabChange={setCurrentTab} 
        isOpen={isSidebarOpen}
        isOpenOnMobile={isMobileSidebarOpen}
        onToggle={toggleSidebar}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Mobile Drawer Backdrop Overlay */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden transition-opacity duration-300"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* Primary Workstation Layer */}
      <main className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        {/* Dynamic Telemetry Header - Seamless h-14 height aligned with sidebar */}
        <header className="h-14 bg-slate-950/80 backdrop-blur-md border-b border-slate-900 px-4 md:px-6 flex flex-row items-center justify-between gap-3 text-xs select-none shrink-0">
          <div className="flex items-center gap-3">
            {/* '=' Sidebar Toggle Button (Desktop & Mobile) */}
            <button
              type="button"
              id="sidebar-toggle-btn"
              onClick={toggleSidebar}
              className={`p-1.5 sm:p-2 rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-850 active:scale-95 transition-all duration-150 flex items-center justify-center cursor-pointer shadow-sm group ${
                !isSidebarOpen ? "bg-red-950/40 border-red-500/40 text-red-300" : ""
              }`}
              title="Toggle navigation sidebar (=)"
              aria-label="Toggle navigation sidebar"
            >
              <Equal className="w-4 h-4 text-red-400 group-hover:text-red-300 stroke-[2.5]" />
            </button>

            <Cpu className="w-5 h-5 text-red-500 animate-pulse shrink-0 hidden sm:block" />
            <div>
              <h1 className="text-xs sm:text-sm font-mono font-bold tracking-widest text-slate-100 uppercase">
                THREATNEXUS
              </h1>
              <span className="text-[8.5px] sm:text-[9.5px] font-mono text-slate-550 flex items-center gap-1 leading-none mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-ping" />
                ACTIVE // SOC ENCLAVE
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-[10px] sm:text-[11px] font-mono">
            {/* Live IST Chennai Time Telemetry */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-850 text-slate-200">
              <Clock className="w-3.5 h-3.5 text-red-500 animate-pulse shrink-0" />
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] text-slate-400 font-bold uppercase tracking-wider">IST (Chennai):</span>
                <span className="font-bold text-slate-100 font-mono text-[10.5px] sm:text-[11px]">{chennaiTime || "SYNCING..."}</span>
              </div>
            </div>

            <div className="hidden xl:flex items-center gap-1.5 text-slate-400">
              <span className="text-slate-500">UTC:</span>
              <span className="font-semibold text-slate-300">{currentTime || "SYNCING..."}</span>
            </div>

            {/* Interactive Color Mode Matrix Selector */}
            <div className="flex items-center gap-0.5 bg-slate-950 border border-slate-900 rounded-full p-0.5 select-none shrink-0" id="theme-toggle-switch">
              <button
                type="button"
                onClick={() => setTheme("light")}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[8.5px] font-mono font-bold transition cursor-pointer ${
                  theme === "light"
                    ? "bg-red-650 text-white shadow"
                    : "text-slate-550 hover:text-slate-350"
                }`}
              >
                <Sun className="w-2.5 h-2.5" />
                LIGHT
              </button>
              <button
                type="button"
                onClick={() => setTheme("dark")}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[8.5px] font-mono font-bold transition cursor-pointer ${
                  theme === "dark"
                    ? "bg-red-650 text-white shadow"
                    : "text-slate-550 hover:text-slate-350"
                }`}
              >
                <Moon className="w-2.5 h-2.5" />
                DARK
              </button>
            </div>
          </div>
        </header>

        {/* Content Segment */}
        <section className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto space-y-6">
          {currentTab === ActiveTab.Dashboard && (
            <DashboardView
              searchLogs={searchLogs}
              onSelectQuery={handleSelectQuery}
              apiStatus={apiStatus}
              onNavigate={setCurrentTab}
              onNavigateToKql={handleNavigateToKql}
            />
          )}

          {currentTab === ActiveTab.LogAnalyzer && (
            <LogAnalyzerView onPivotToIoc={(type, val) => handleSelectQuery(type, val)} />
          )}

          {currentTab === ActiveTab.ThreatGraph && (
            <ThreatGraphView onPivotToIoc={(type, val) => handleSelectQuery(type, val)} />
          )}

          {currentTab === ActiveTab.Homograph && (
            <HomographDetectorView
              onPivotToDomain={(domain) => handleSelectQuery("Domain", domain)}
              onPivotToUrl={(url) => handleSelectQuery("URL", url)}
            />
          )}

          {currentTab === ActiveTab.IncidentReport && (
            <IncidentReportView />
          )}

          {currentTab === ActiveTab.ThreatIntel && (
            <ThreatIntelView
              defaultSubTab="bleeping-computer"
              onPivotToIp={(ip) => handleSelectQuery("IP", ip)}
              onPivotToDomain={(domain) => handleSelectQuery("Domain", domain)}
              onPivotToUrl={(url) => handleSelectQuery("URL", url)}
              onPivotToHash={(hash) => handleSelectQuery("Hash", hash)}
              onNavigateToKql={handleNavigateToKql}
            />
          )}

          {currentTab === ActiveTab.IOCInvestigator && (
            <ThreatIntelView
              defaultSubTab="bulk"
              onPivotToIp={(ip) => handleSelectQuery("IP", ip)}
              onPivotToDomain={(domain) => handleSelectQuery("Domain", domain)}
              onPivotToUrl={(url) => handleSelectQuery("URL", url)}
              onPivotToHash={(hash) => handleSelectQuery("Hash", hash)}
              onNavigateToKql={handleNavigateToKql}
            />
          )}

          {currentTab === ActiveTab.Whois && <WhoisTerminalView />}

          {currentTab === ActiveTab.IPInvest && (
            <IPInvestView onAddSearchLog={handleAddSearchLog} initialQuery={pendingQueries.IP} />
          )}

          {currentTab === ActiveTab.DomainInvest && (
            <DomainInvestView onAddSearchLog={handleAddSearchLog} initialQuery={pendingQueries.Domain} />
          )}

          {currentTab === ActiveTab.URLAnalysis && (
            <UrlAnalysisView onAddSearchLog={handleAddSearchLog} initialQuery={pendingQueries.URL} />
          )}

          {currentTab === ActiveTab.UrlScreenshot && (
            <UrlScreenshotView />
          )}

          {currentTab === ActiveTab.HashAnalysis && (
            <HashAnalysisView onAddSearchLog={handleAddSearchLog} initialQuery={pendingQueries.Hash} />
          )}

          {currentTab === ActiveTab.FileAnalysis && (
            <FileAnalysisView />
          )}

          {currentTab === ActiveTab.HeaderAnalysis && (
            <HeaderAnalysisView />
          )}

          {currentTab === ActiveTab.MalwareAnalysis && (
            <MalwareAnalysisView onAddSearchLog={handleAddSearchLog} onSelectQuery={handleSelectQuery} />
          )}

          {currentTab === ActiveTab.OsintHub && <OsintHubView />}

          {currentTab === ActiveTab.Ransomware && <RansomwareView />}

          {currentTab === ActiveTab.Mitre && <MitreView />}

          {currentTab === ActiveTab.KqlPlayground && (
            <KqlPlaygroundView
              initialContext={kqlThreatContext}
              onClearContext={() => setKqlThreatContext(null)}
            />
          )}

          {currentTab === ActiveTab.Utilities && <UtilitiesView />}

          {currentTab === ActiveTab.AsnSsl && <AsnSslView />}

          {currentTab === ActiveTab.EventIdEncyclopedia && <EventIdEncyclopediaView />}

          {currentTab === ActiveTab.PortLookup && <PortLookupView />}

          {currentTab === ActiveTab.MacLookup && <MacLookupView />}

          {currentTab === ActiveTab.SIEM && <SiemIntegrationView />}

          {currentTab === ActiveTab.AICommandInterpreter && <AiCommandInterpreterView />}

          {currentTab === ActiveTab.Settings && <SettingsView />}
        </section>

        {/* Floating Security Protection Indicator Panel */}
        {securityNotice.active && (
          <div className="fixed bottom-16 right-6 z-550 max-w-sm bg-red-950/95 border border-red-500/40 p-4 rounded-lg shadow-xl backdrop-blur-md animate-bounce flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-mono text-xs font-bold text-red-400 uppercase tracking-wide">Aegis Shield Active</h4>
              <p className="text-[11px] text-slate-300 mt-1 font-sans leading-relaxed">
                {securityNotice.message}
              </p>
              <div className="mt-2 text-[9px] font-mono text-red-500/80">
                STATION_INTEGRITY_SHIELD // ANIRUDH_POLICY
              </div>
            </div>
          </div>
        )}

        {/* Console Footnote */}
        <footer className="mt-auto border-t border-slate-900 bg-slate-950/40 py-4 px-6 flex flex-col sm:flex-row items-center justify-center relative text-xs font-mono select-none">
          <div className="hidden lg:flex items-center gap-2 absolute left-6 text-[10px] text-slate-500">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
            <span>SECURE OPERATIONAL ENCLAVE // REGION-EAST</span>
          </div>

          <div className="flex items-center justify-center gap-2 text-slate-300 py-1 px-4 rounded-full bg-slate-900/60 border border-slate-800 shadow-sm">
            <span className="text-red-500 animate-pulse text-xs">❤️</span>
            <span className="text-xs tracking-wide">
              Built with passion by <span className="text-red-400 font-bold tracking-wider">Anirudh</span>
            </span>
          </div>

          <div className="hidden lg:flex items-center gap-2 absolute right-6 text-[10px] text-slate-500">
            <span>THREATNEXUS SOC</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
