/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ActiveTab {
  Dashboard = "dashboard",
  ThreatIntel = "threat-intel",
  IOCInvestigator = "ioc-investigator",
  Whois = "whois",
  IPInvest = "ip-invest",
  DomainInvest = "domain-invest",
  URLAnalysis = "url-analysis",
  UrlScreenshot = "url-screenshot",
  HashAnalysis = "hash-analysis",
  FileAnalysis = "file-analysis",
  HeaderAnalysis = "header-analysis",
  MalwareAnalysis = "malware-analysis",
  OsintHub = "osint-hub",
  Ransomware = "ransomware",
  Mitre = "mitre",
  KqlPlayground = "kql-playground",
  Utilities = "utilities",
  AsnSsl = "asn-ssl",
  EventIdEncyclopedia = "event-id-encyclopedia",
  PortLookup = "port-lookup",
  MacLookup = "mac-lookup",
  SIEM = "siem",
  AICommandInterpreter = "ai-command-interpreter",
  LogAnalyzer = "log-analyzer",
  ThreatGraph = "threat-graph",
  Homograph = "homograph-detector",
  IncidentReport = "incident-report",
  Settings = "settings"
}

export interface SearchLog {
  id: string;
  type: "IP" | "Domain" | "URL" | "Hash" | "Malware";
  query: string;
  timestamp: string;
  reputation: "clean" | "suspicious" | "malicious" | "unknown";
  score?: number;
}

export interface ApiStatus {
  service: string;
  status: "configured" | "not-configured";
}

export interface IPAnalysisResult {
  ip: string;
  riskScore: number; // 0 - 100
  country: string;
  countryCode: string;
  asn: string;
  isp: string;
  hosting: boolean;
  vpn: boolean;
  proxy: boolean;
  tor: boolean;
  abuseScore: number;
  vpnDetails: {
    isVpn: boolean;
    provider: string;
    proxyType: string;
    connectionType: string;
    confidenceScore: number;
  };
  threatIntelligence: {
    threatTypes: string[];
    malwareFamilies: string[];
    lastActive: string;
    description: string;
  };
  reputation: {
    abuseipdb?: { score: number; reportedCount: number; lastReported: string };
    virustotal?: { malicious: number; harmless: number; total: number };
    otx?: { pulseCount: number; references: number };
    greynoise?: { classification: string; actor: string; tags: string[] };
    shodan?: { ports: number[]; vulnerabilities: string[]; os: string };
  };
  historicalData: {
    date: string;
    activityType: string;
    source: string;
  }[];
  mitreMappings?: { id: string; name: string; tactic: string; description: string }[];
  threatActors?: string[];
  malwareAssociations?: string[];
  rawJson: string;
}

export interface DomainAnalysisResult {
  domain: string;
  age: string;
  registrar: string;
  createdDate: string;
  expiryDate: string;
  nameServers: string[];
  reputation: "clean" | "suspicious" | "malicious";
  categories: string[];
  vtDetections: { malicious: number; suspicious: number; clean: number };
  relatedIocs: { type: string; value: string; relation: string }[];
  dnsRecords: { type: string; value: string; ttl: number }[];
  mitreMappings?: { id: string; name: string; tactic: string; description: string }[];
  threatActors?: string[];
  malwareAssociations?: string[];
  rawJson: string;
}

export interface URLAnalysisResult {
  url: string;
  reputation: "clean" | "suspicious" | "malicious";
  stats: { malicious: number; suspicious: number; harmless: number };
  engines: { name: string; category: string; result: string }[];
  categories: string[];
  safeBrowsing: { listed: boolean; platform: string; threatType: string };
  mitreMappings?: { id: string; name: string; tactic: string; description: string }[];
  threatActors?: string[];
  malwareAssociations?: string[];
  rawJson: string;
}

export interface HashAnalysisResult {
  hash: string;
  type: "MD5" | "SHA1" | "SHA256";
  reputation: "clean" | "suspicious" | "malicious";
  reputationScore?: number;
  stats: { malicious: number; harmless: number };
  malwareFamily: string;
  fileNames: string[];
  tags: string[];
  firstSeen: string;
  lastSeen: string;
  detections: { engine: string; category: string; result: string }[];
  mitreMappings?: { id: string; name: string; tactic: string; description: string }[];
  threatActors?: string[];
  malwareAssociations?: string[];
  size?: number;
  md5?: string;
  sha1?: string;
  sha256?: string;
  typeDescription?: string;
  vtTags?: string[];
  magic?: string;
  creationTime?: string;
  rawJson: string;
}

export interface MalwareFamily {
  name: string;
  description: string;
  deliveryMethods: string[];
  mitreTechniques: { id: string; name: string }[];
  iocs: { type: "IP" | "Domain" | "Hash" | "URL"; value: string; description: string }[];
  detectionGuidance: string[];
}

export interface RansomwareVictim {
  id: string;
  victim_name: string;
  group_name: string;
  discovered: string;
  industry: string;
  country: string;
  website: string;
}

export interface RansomwareGroup {
  name: string;
  victim_count: number;
  first_seen: string;
  last_seen: string;
}

export interface MitreTechnique {
  id: string;
  name: string;
  tactic: string; // primary tactic for backwards compatibility
  description: string;
  detection: string;
  mitigation: string;
  threatGroups: string[]; // legacy mapped actors but now rich mapped as well
  
  // Real enterprise STIX properties
  platforms?: string[];
  dataSources?: string[];
  tactics?: string[];
  isSubtechnique?: boolean;
  parentTechniqueId?: string;
  mitigations?: { id: string; name: string; description: string }[];
  threatActors?: { id: string; name: string; description: string }[];
  malware?: { id: string; name: string; description: string }[];
  externalReferences?: { source_name: string; url?: string; external_id?: string; description?: string }[];
}

export interface KqlQuery {
  id: string;
  title: string;
  description: string;
  mitreMappings: string[]; // e.g., ["T1078", "T1136"]
  useCase: string;
  query: string;
}
